/*
 * Copyright (C) 2017-2023 Amarisoft
 */

Ext.define("lte.enb.tab", {

    extend: 'lte.client.tab',

    _chartList: [{
        title:        'Bitrate',
        fieldType:    ['dl_bitrate', 'ul_bitrate', 'mbms_bitrate'],
        unit:         'brate',
        serieStyle:   'font-size: 10px;',
    }, {
        title:        'TX/RETX',
        fieldType:    ['dl_tx', 'dl_retx', 'dl_bler', 'dl_per', 'ul_tx', 'ul_retx', 'ul_bler', 'ul_per'],
        unit:         ' pkt(s)',
        serieWidth:   300,
        serieStyle:   'font-size: 10px;',
    }, {
        title:        'UE',
        fieldType:    ['ue.dl_bitrate', 'ue.ul_bitrate', 'dl_mcs', 'ul_mcs', 'cqi', 'ri'],
        unit:         'brate',
        serieWidth:   300,
        serieStyle:   'font-size: 10px;',
    }, {
        title:        'Messages',
        fieldType:    ['messages'],
        serieWidth:   400,
        unit:         ''
    }, {
        title:        'Errors',
        fieldType:    ['errors'],
        serieWidth:   400,
        unit:         ''
    }],

    _fieldLabel: {
        'dl_bitrate': 'PHY DL bitrate',
        'ul_bitrate': 'PHY UL bitrate',
        'mbms_bitrate': 'PHY MBMS bitrate',
        'dl_mcs': 'DL MCS',
        'ul_mcs': 'UL MCS',
        'dl_tx': 'DL transmissions',
        'dl_retx': 'DL retransmissions',
        'ul_tx': 'UL transmissions',
        'ul_retx': 'UL retransmissions',
        'dl_bler': 'DL bler',
        'ul_bler': 'UL bler',
        'dl_per': 'DL per',
        'ul_per': 'UL per',
        'cqi': 'CQI',
        'ri': 'layers',
    },

    constructor: function (config) {

        this.callParent(arguments);
    },

    initComponent: function () {
        this.callParent(arguments);

        this.tbar.add(Ext.create('Ext.button.Button', {
            tooltip: lteLogs.tooltip("Informations"),
            iconCls: "icon-question2",
            text: 'Info',
            listeners: {
                scope: this,
                click: function(filter, e, eOpts) {
                    var win = this.client.getComponent('enbInfo');
                    if (!win) {
                        win = Ext.create('lte.client.enb.info', {
                            title: this.client.getName() + ' informations',
                            client: this.client,
                            listeners: {
                                scope: this,
                                close: function () {
                                    this.client.removeComponent('enbInfo', true);
                                }
                            }
                        });
                        this.client.addComponent('enbInfo', win);
                    }
                    win.show();
                }
            }
        }));

        this.addRFConfig(['npusch', 'pusch']);

        var cellStore = this._cellStore = Ext.create('Ext.data.Store', {
            fields: ["cell_id", "n_rb_dl", "n_rb_ul", "dl_bitrate", "ul_bitrate"]
        });

        var ueStore = Ext.create('Ext.data.Store', {
            fields: ['rnti', 'enb_ue_id', 'mme_ue_id', 'cells']
        });

        var sumPanel = Ext.create('Ext.panel.Panel', {
            border: 0,
            html: 'Total UEs: 0'
        });

        var definedSeries = {};
        var selectedUEID = null;
        var ueTab = null;
        var ueGrid = Ext.create('Ext.grid.Panel', {
            store: ueStore,
            allowDeselect: true,
            viewConfig: { markDirty: false },
            tbar: [ sumPanel ],
            columns: {
                defaults: {
                    menuDisabled: true,
                    flex: 1,
                    align: 'right',
                },
                items: [{
                    text: 'UE ID',
                    dataIndex: 'enb_ue_id',
                }, {
                    text: 'RNTI',
                    dataIndex: 'rnti',
                    renderer: function(rnti, metaData, record, rowIndex, colIndex, store, view) {
                        return '0x' + rnti.toString(16);
                    }
                }, {
                    text: 'Cells',
                    dataIndex: 'cells',
                    flex: 0.8,
                    renderer: (function(cells, metaData, record, rowIndex, colIndex, store, view) {
                        return cells.map((function (c) { return this._getCell(c.cell_id).getName(); }).bind(this)).join(",");
                    }).bind(this)
                }, {
                    text: 'Core ID',
                    dataIndex: 'mme_ue_id',
                }],
            },
            listeners: {
                scope: this,
                selectionchange: function(view, selected, eOpts) {
                    if (selected.length) {
                        selectedUEID = {
                            id: selected[0].get('enb_ue_id')
                        };
                        definedSeries = {};
                        ueChart.comp.reset();
                        ueChart.tab.setVisible(true);
                    } else {
                        selectedUEID = null;
                        ueChart.tab.setVisible(false);
                    }
                },

                // UE right click menu
                cellcontextmenu: function(view, td, cellIndex, record, tr, rowIndex, e, eOpts) {

                    var items = [];
                    var ue_data = record.getData();
                    var cell_id = ue_data.cells[0].cell_id;
                    for (var i = 0, count = cellStore.getCount(); i < count; i++) {
                        var cell_data = cellStore.getAt(i).getData();
                        if (cell_data.cell_id === cell_id) continue;

                        items.push({
                            text: 'Handover to cell ' + this._getCell(cell_data.cell_id).getName(),
                            scope: this,
                            iconCls: 'icon-air',
                            handler: (function(msg) {
                                this.client.sendMessage(msg, (function (r) {
                                    this._updater.update(true);
                                }).bind(this));
                            }).bind(this, {
                                message: 'handover',
                                enb_ue_id: ue_data.enb_ue_id,
                                pci: cell_data.cell_id,
                                dl_earfcn: cell_data.dl_earfcn
                            })
                        });
                    }

                    if (items.length) {
                        var menu = new Ext.menu.Menu({items: items});
                        var position = e.getXY();
                        e.stopEvent();
                        menu.showAt(position);
                    }
                },
            }
        });

        var ueCache = {};

        this._updater = Ext.create("lte.updater", {
            scope:            this,
            updateDelay:    1000,
            //autoDelay:        5000,
            dirty:            true,
            lock:            1,
            handler:        function () {
                this.client.sendMessage({message: 'ue_get'}, (function (msg) {

                    msg.ue_list.forEach(function (ue) {
                        if (ue.ran_ue_id !== undefined) ue.enb_ue_id = ue.ran_ue_id;
                        if (ue.amf_ue_id !== undefined) ue.mme_ue_id = ue.amf_ue_id;
                    });

                    // Update store
                    lteLogs.storeUpdate(ueCache, ueStore, msg.ue_list, 'rnti');
                    sumPanel.update('Total UEs: ' + msg.ue_list.length);

                    var sUE = selectedUEID;
                    if (selectedUEID === null || !lteLogs.storeGetById(ueStore, 'enb_ue_id', selectedUEID.id)) return;

                    this.client.sendMessage({message: 'ue_get', ue_id: selectedUEID.id, stats: true}, (function (msg) {

                        var ue = msg.ue_list[0];
                        var now = new Date() * 1;
                        var comp = ueChart.comp;

                        var list = ue.erab_list || ue.qos_flow_list;
                        if (list) {
                            var dl = 0;
                            var ul = 0;
                            for (var i = 0; i < list.length; i++) {
                                var erab = list[i];
                                dl += erab.dl_total_bytes;
                                ul += erab.ul_total_bytes;
                            }
                            if (selectedUEID.stats_time !== undefined) {
                                var id = selectedUEID.id + '-bitrate';
                                if (!definedSeries[id]) {
                                    comp.addSerie(id + '-dl', {title: 'UE #' + selectedUEID.id + ', DL PDCP'});
                                    comp.addSerie(id + '-ul', {title: 'UE #' + selectedUEID.id + ', UL PDCP'});
                                    definedSeries[id] = true;
                                }
                                var br = 8 * (dl - selectedUEID.dl) / (msg.time - selectedUEID.stats_time);
                                comp.addValues(id + '-dl', [{x: now, y: br}]);
                                var br = 8 * (ul - selectedUEID.ul) / (msg.time - selectedUEID.stats_time);
                                comp.addValues(id + '-ul', [{x: now, y: br}]);
                            }
                            selectedUEID.dl = dl;
                            selectedUEID.ul = ul;
                            selectedUEID.stats_time = msg.time;
                        }

                        ue.cells.forEach((function (cell) {
                            var id = selectedUEID.id + '-' + cell.cell_id;

                            if (!definedSeries[id]) {
                                var prefix = 'UE #' + selectedUEID.id + ', cell ' + this._getCell(cell.cell_id).getName();
                                comp.addSerie(id + 'dl_bitrate', {title: prefix + ' DL PHY'});
                                comp.addSerie(id + 'ul_bitrate', {title: prefix + ' UL PHY'});
                                comp.addSerie(id + 'dl_mcs', {title: prefix + ' DL MCS', y: ['z']});
                                comp.addSerie(id + 'ul_mcs', {title: prefix + ' UL MCS', y: ['z']});
                                comp.addSerie(id + 'cqi', {title: prefix + ' CQI', y: ['z']});
                                comp.addSerie(id + 'ri', {title: prefix + ' RI', y: ['z']});
                                definedSeries[id] = true;
                            };

                            comp.addValues(id + 'dl_bitrate', [{x: now, y: cell.dl_bitrate}]);
                            comp.addValues(id + 'ul_bitrate', [{x: now, y: cell.ul_bitrate}]);
                            if (cell.dl_mcs) comp.addValues(id + 'dl_mcs', [{x: now, z: cell.dl_mcs}]);
                            if (cell.ul_mcs) comp.addValues(id + 'ul_mcs', [{x: now, z: cell.ul_mcs}]);
                            if (cell.ri !== undefined) comp.addValues(id + 'ri', [{x: now, z: cell.ri}]);
                        }).bind(this));
                        comp.update();
                    }).bind(this));
                }).bind(this));
            }
        });

        this.statsRFSamplesInit();

        this.add({
            region: 'west',
            layout: 'fit',
            width: 300,
            items: [ueGrid],
        });

        this.add({
            split: true,
            layout: 'fit',
            region: 'center',
            items: [this.getChartPanel(this._statsChart)],
        });

        var ueChart = this._field2chart['ue.dl_bitrate'];
        ueChart.tab = this._chartPanel.tabBar.getComponent(ueChart.index);
        ueChart.tab.setVisible(false);
    },

    setClientConfig: function (config) {
        // Better access
        var client = this.client;
        var data = client.getCellIds().map((function (id) { return client.getCell(id); }).bind(this));
        if (data.length > 0) {
            this._cellStore.setData(data);
        }

        this.setClientConfigRF(config);
    },

    _getCell: function (cell_id) {
        return this.client.getCell(cell_id);
    },

    _cellsStatsUpdate: function (chart, cells, now, global) {

        chart.fieldType.forEach((function (field) {

            var total = 0;
            var count = 0;
            var comp  = chart.comp;
            var g     = global;

            for (var cell_id in cells) {
                var cell = cells[cell_id];
                switch (field) {
                case 'dl_bler':
                    if (!cell.dl_tx && !cell.dl_retx) continue;
                    value = cell.dl_retx / (cell.dl_tx + cell.dl_retx);
                    var y = 'bler';
                    g = false;
                    break;
                case 'ul_bler':
                    if (!cell.ul_tx && !cell.ul_retx) continue;
                    value = cell.ul_retx / (cell.ul_tx + cell.ul_retx);
                    var y = 'bler';
                    g = false;
                    break;
                case 'dl_per':
                    if (!cell.dl_tx && !cell.dl_err) continue;
                    value = cell.dl_err / (cell.dl_tx + cell.dl_err);
                    var y = 'bler';
                    g = false;
                    break;
                case 'ul_per':
                    if (!cell.ul_tx && !cell.ul_err) continue;
                    value = cell.ul_err / (cell.ul_tx + cell.ul_err);
                    var y = 'bler';
                    g = false;
                    break;
                default:
                    var y = 'y';
                    var value = cell[field];
                    break;
                }
                if (value === undefined) continue;

                var clientCell = this._getCell(cell_id);
                if (!clientCell) continue;

                var id = cell_id + "-" + field;
                var v = { x: now };
                v[y] = value;
                comp.addSerie(id, {
                    title: "Cell " + clientCell.getName() + " " + (this._fieldLabel[field] || field),
                    values: [v],
                    y: [y],
                });
                total += value;
                count++;
            };

            if (g && count) {
                comp.addSerie(field, {
                    title: 'Global ' + field,
                    values: [{x: now, y: total}]
                });
            }
            comp.update();
        }).bind(this));
    },

    _eventListener: function (event) {

        switch (event.type) {
        case 'stats':
            var now = new Date() * 1;
            var cells = event.data.cells;
            var global = Object.keys(cells).length > 1;
            this._cellsStatsUpdate(this._chartList[0], cells, now, global);
            this._cellsStatsUpdate(this._chartList[1], cells, now, global);
            this.statsRFSamplesFeed(event);
            this._updateCounters(now, event.data.counters);

            this._updater.update(true);
            break;
        }
    },
});


Ext.define("lte.client.enb.info", {

    extend: 'Ext.window.Window',
    layout: 'fit',
    width: 400,
    height: 600,

    constructor: function (config) {
        this.callParent(arguments);
    },

    initComponent: function () {
        this.callParent(arguments);

        var ports = [];

        var addNode = function (list, cell, name, param) {
            list.push({
                name: name,
                param: param,
                cell: cell,
                type: name.toLowerCase(),
                leaf: true,
            });
        };
        var getValue = function (cell, param) {
            if (cell) {
                if (typeof param === 'string')
                    return cell[param];
                if (typeof param === 'function')
                    return param(cell);
            }
            return null;
        };

        var cells = this.client.getCells().map(function (cell) {
            var children = [];
            addNode(children, cell, 'Mode', 'mode');
            addNode(children, cell, 'Physical cell id', 'pci');
            addNode(children, cell, 'Antenna', function (cell) { return cell.n_antenna_dl + 'T' + cell.n_antenna_ul + 'R'; });
            addNode(children, cell, 'Layers', function (cell) { return 'DL: ' + cell.n_layer_dl + ', UL: ' + cell.n_layer_ul; });
            switch (cell.rat) {
            case 'lte':
                addNode(children, cell, 'DL EARFCN', 'dl_earfcn');
                addNode(children, cell, 'UL EARFCN', 'ul_earfcn');
                break;
            case 'nbiot':
                addNode(children, cell, 'DL EARFCN', 'dl_earfcn');
                addNode(children, cell, 'UL EARFCN', 'ul_earfcn');
                break;
            case 'nr':
                addNode(children, cell, 'DL ARFCN', 'dl_nr_arfcn');
                addNode(children, cell, 'UL ARFCN', 'ul_nr_arfcn');
                break;
            }

            addNode(children, cell, 'Gain', 'gain');

            return {
                name: 'Cell #' + cell.cell_id + (cell.label ? ', ' + cell.label : ''),
                expandable: true,
                expanded: false,
                cell: cell,
                iconCls: 'icon-comp',
                param: 'rat',
                children: children,
            };
        });

        var client = this.client;
        var edit = null;
        var grid = this._grid = Ext.create('Ext.tree.Panel', {
            store: {
                fields: ['name', 'param', 'cell', 'type'],
                root: {
                    name: '',
                    expanded: true,
                    children: [{
                        name: 'Cells',
                        expanded: true,
                        children: cells
                    }]
                }
            },
            rootVisible: false,
            viewConfig:{markDirty: false},
            plugins: [
                Ext.create('Ext.grid.plugin.CellEditing', {
                    clicksToEdit: 1,
                    listeners: {
                        scope: this,
                        beforeedit: function (a, b, c, d, e) {
                            edit = grid.getStore().getAt(b.rowIdx);
                            switch (edit.get('type')) {
                            case 'gain':
                                return true;
                            }
                            return false;
                        },
                        afteredit: function (a, b, c, d, e) {
                            edit = null;
                        }
                    }
                })
            ],
            columns: {
                defaults: {
                    menuDisabled: true,
                },
                items: [{
                    xtype: 'treecolumn',
                    text: 'Information',
                    dataIndex: 'name',
                    width: 250,
                }, {
                    text: 'Value',
                    dataIndex: 'value',
                    flex: 1,
                    renderer: function(param, metaData, rec, rowIndex, colIndex, store, view) {
                        var v = getValue(rec.get('cell'), rec.get('param'));
                        if (v !== null)
                            return v;
                        return '&nbsp;'
                    },
                    getEditor: function (rec) {
                        var cell = rec.get('cell');
                        switch (rec.get('type')) {
                        case 'gain':
                            return {
                                xtype: 'numberfield',
                                maxValue: 0,
                                minValue: -200,
                                value: cell.gain,
                                listeners: {
                                    scope: this,
                                    change: function (me, value) {
                                        client.sendMessage({
                                            message: "cell_gain",
                                            cell_id: rec.get('cell').cell_id,
                                            gain: value
                                        });
                                        cell.gain = value;
                                    }
                                },
                            };
                            break;
                        }
                    },
                }],
            },
            listeners: {
                scope: this,
            },
        });
        this.add(grid);
        lteLogs.setWindowAutoHeight(this);
        this._listenerId = client.registerEventListener('*', this._eventListener.bind(this));
    },

    _eventListener: function (event) {
    },

    listeners: {
        close: function () {
            this.client.unregisterEventListener(this._listenerId);
        },
    },
});


