/*
 * Place your code here to handle your application results
 */
var SimCustomHandler = function (tag, output, error)
{
	var ratio = 0;		/* Between 0 and 1 */
	var log   = output; /* Array of string */

	switch (tag) {
	case 'iperf':
		if (!error)
			ratio = 1;
		break;

	case 'ping':
		output.forEach(function (l) {
			var info = l.match(/(\d+)% packet loss/);
			if (info) {
				ratio = (100 - info[1]) / 100;
			}
		});
		break;
	}

	if (error)
		log.push('<b>', error, '</b>');

	return {
		ratio: ratio,
		log:   log,
	};
}

