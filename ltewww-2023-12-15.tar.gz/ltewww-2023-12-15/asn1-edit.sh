#!/bin/bash
# Log viewer launcher version 2023-12-15
# Copyright (C) 2016-2023 Amarisoft

set -e

function Help
{
    echo "Usage:"
    echo "  ./asn1-edit.sh [options] [<file>] "
    echo "  Options:"
    echo "    -t <type>: ASN.1 type"
    echo "    -d: debug mode"
    exit 1
}

NW=$(which nw 2>&1 || echo "")
if [ ! -e "$NW" ] ; then
    if [ "$(which npm)" = "" ] ; then
        echo "Please install nodejs and npm"
        echo "On Fedora:"
        echo "> sudo dnf install nodejs npm"
        exit 1
    fi
    echo "Please install node webkit"
    echo "> sudo npm install -g nw --unsafe-perm=true"
    exit 1
fi

DIR=$(readlink -f "$(dirname $0)")
CUR=$(readlink -f "$(pwd)")
ARGS=("${DIR}" "${CUR}")

while [ "$1" != "" ] ; do
    case "$1" in
    -d)
        DEBUG=1
        ARGS+=("$1")
        ;;
    -t)
        ARGS+=("$1" "$2")
        shift
        ;;
    -h|--help)
        Help
        ;;
    *)
        ARGS+=("$1")
        ;;
    esac
    shift
done

idx=0
while [ true ] ; do
    NAME="asn1-edit-$idx"
    if [ ! -L "$HOME/.config/$NAME/SingletonLock" ] ; then
        break
    fi
    idx=$(( $idx + 1 ))
done

rm -f "$DIR/package.json"
cat "$DIR/package.tpl" | sed -e "s/<NAME>/$NAME/" | sed -e "s/index/asn1/"  > "$DIR/package.json"

if [ "$DEBUG" = "1" ] ; then
    ${NW} "${ARGS[@]}"
else
    nohup ${NW} "${ARGS[@]}" </dev/null 2>&1 | cat &
fi

