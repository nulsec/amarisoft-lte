/*
 * Copyright (C) 2012-2023 Amarisoft
 *
 * Amarisoft Web interface 2023-12-15
 */

const UEConfig = {


    series: {
        br: {
            dl_bitrate: {title: '#<cell> DL bitrate'},
            ul_bitrate: {title: '#<cell> UL bitrate'},
        },
        sched: {
            dl_sched_users_min: {title: "#<cell> DL min users / TTI", enabled: false},
            dl_sched_users_avg: {title: "#<cell> DL average users / TTI"},
            dl_sched_users_max: {title: "#<cell> DL max users / TTI", enabled: false},
            ul_sched_users_min: {title: "#<cell> UL min users / TTI", enabled: false},
            ul_sched_users_avg: {title: "#<cell> UL average users / TTI"},
            ul_sched_users_max: {title: "#<cell> UL max users / TTI", enabled: false},
        },
        count: {
            ue_count: {title: '#<cell> UE count', y: ['z']},
        },
        packets: {
            dl_rx_count: {title: '#<cell> DL rx'},
            dl_err_count: {title: '#<cell> DL errors'},
            dl_bler: {title: '#<cell> DL BLER', y: ['bler']},
            ul_tx_count: {title: '#<cell> UL tx'},
            ul_retx_count: {title: '#<cell> UL retx'},
        },
    },

    setSerie: function (chart, serie, cells, y) {

        serie = this.series[serie];

        for (var cell_index in cells) {
            for (var id in serie) {
                var cfg = lteLogs.clone(serie[id]);
                if (!cfg.y && y) {
                    cfg.y = [y];
                }
                cfg.title = cfg.title.replace(/<cell>/, cells[cell_index].pci);
                chart.addSerie(id + '.' + cell_index, cfg);
            }
        }
    },
};


Ext.define("lte.ue.tab", {

    extend: 'lte.client.tab',

    useRefresh: true,

    constructor: function (config) {
        this.callParent(arguments);
        lteSim.registerTab(this);
    },

    listeners: {
        activate: function () {
            // Workaround
            this._ueGrid.view.refresh();
        },
    },

    initComponent: function () {

        this.callParent(arguments);

        this.addRFConfig(['pdsch', 'npdsch']);

        var startSimButton = new Ext.create('Ext.Button', {
            text: 'Scenario...',
            scope: this,
            iconCls: 'icon-play',
            tooltip: lteLogs.tooltip('Click to select scenario and start it'),
            handler: function (b, e) {

                var ueList = ueGrid.getSelection().map(function (rec) { return rec.get("ue_id"); });

                var items = [];
                var sims = lteSim.get();
                for (var i = 0; i < sims.length; i++) {
                    var sim = sims[i];

                    if (sim.get("ue").count) {
                        items.push({
                            text: 'Start scenario ' + sim.get('name'),
                            iconCls: 'icon-play',
                            scope: this,
                            handler: (function(sim) { this.createUESimTab(sim); }).bind(this, sim.getData()),
                        });
                    } else if (ueList.length) {
                        items.push({
                            text: 'Start scenario ' + sim.get('name') + ' on selected UEs',
                            iconCls: 'icon-play',
                            scope: this,
                            handler: (function(sim) { this.createUESimTab(sim, ueList); }).bind(this, sim.getData()),
                        });
                    }
                }

                if (!items.length) {
                    Ext.Msg.alert('No scenario defined', 'Go to UE Scenario tab to create scenario.<br/>Only scenario creating UE are available.');
                    return;
                }

                var menu = new Ext.menu.Menu({items: items});
                var position = e.getXY();
                menu.showAt(position);
            }
        });
        this.tbar.add(startSimButton);

        var stopSimButton = new Ext.create('Ext.Button', {
            text: 'Stop scenario',
            scope: this,
            iconCls: 'icon-stop',
            tooltip: lteLogs.tooltip('Stop any pending scenario'),
            handler: function (b, e) {
                this.client.sendMessage({message: 'cancel'}, function (msg) {
                });
            }
        });
        this.tbar.add(stopSimButton);

        var reestButton = new Ext.create('Ext.Button', {
            text: 'Reestablishment',
            scope: this,
            iconCls: 'icon-sync',
            tooltip: lteLogs.tooltip('Force reestablishment on selected UEs'),
            disabled: true,
            handler: function (b, e) {
                var ueList = ueGrid.getSelection().map(function (rec) { return rec.get("ue_id"); });

                this.client.sendMessage(ueList.map(function (ue_id) {
                    return { message: 'rrc_reest', ue_id: ue_id };
                }));
            }
        });
        this.tbar.add(reestButton);

        // Update UE list
        this._updater = Ext.create("lte.updater", {
            scope:            this,
            updateDelay:    1000,
            dirty:            true,
            lock:            1,
            handler:        function () {
            }
        });

        // UE list management
        this._ueList = {
            cache: {},
            dirty: true,
            timer: 0,
            request: false,
            time: new Date() * 1,
        };
        this.getUESend();

        var ueStore = this._ueStore = Ext.create('Ext.data.Store', {
            fields: ["imsi", "ue_id", "category", "power_on", "timing_advance", "rnti", "rrc_state", "emm_state", 'pdn_list', 'cell_index']
        });

        var ueGrid = this._ueGrid = Ext.create('Ext.grid.Panel', {
            store: ueStore,
            selModel: {
                mode: "MULTI"
            },
            viewConfig:{
                markDirty: false
            },
            columns: [{
                xtype: 'actioncolumn',
                width: 30,
                text: "",
                dataIndex: 'power_on',
                items: [{
                    scope: this,
                    getClass: function (state, meta, rec, rowIndex, colIndex, store) {
                        return state ? 'icon-ok' : 'icon-off';
                    },
                    tooltip: lteLogs.tooltip('Power on/off'),
                    handler: function(view, rowIndex, colIndex, item, e, record) {
                        this.client.sendMessage({
                            message: record.get('power_on') ? 'power_off' : 'power_on',
                            ue_id: record.get('ue_id'),
                        }, function (resp) {
                        });
                    }
                }],
            }, {
                text: "ID",
                dataIndex: "ue_id",
                width: 45
            }, {
                text: "IMSI",
                dataIndex: "imsi",
                width: 150
            }, {
                text: 'RNTI',
                dataIndex: 'rnti',
                renderer: function (value) { return value !== undefined ? value.toString(16) : '&nbsp'; },
                width: 70
            }, {
                text: 'Cat.',
                dataIndex: 'category',
                width: 45,
                renderer: function (value) {
                    switch (value) {
                    case -2: return 'NB-IoT';
                    case -1: return 'M1';
                    default: return value;
                    }
                }
            }, {
                text: 'RRC',
                dataIndex: 'rrc_state',
                width: 110
            }, {
                text: 'EMM',
                dataIndex: 'emm_state',
                width: 150
            }, {
                text: 'Cell (PCI)',
                dataIndex: 'pci',
                scope: this,
                renderer: function (pci) {
                    if (pci === undefined) return '?';
                    return '0x' + pci;
                },
            }, {
                text: 'RSRP',
                dataIndex: 'rsrp',
                width: 70,
                renderer: function (value) { return value.toFixed(1); },
            }, {
                text: 'SNR',
                dataIndex: 'snr',
                width: 70,
                renderer: function (value) { return value.toFixed(1); },
            }, {
                text: 'TA',
                dataIndex: 'timing_advance',
                width: 35,
            }, {
                text: 'Position',
                dataIndex: 'position',
                renderer: function (value) { return value || '&lt;none&gt;'; },
                width: 70,
            }, {
                text: 'IP',
                dataIndex: 'pdn_list',
                renderer: function (pdn_list) {
                    if (!pdn_list) return '&lt;none&gt;';

                    var ips = [];
                    pdn_list.forEach(function (pdn) {
                        if (pdn.ipv4) ips.push(pdn.ipv4);
                        if (pdn.ipv6) ips.push(pdn.ipv6);
                    });
                    return ips.join(', ');
                },
                flex: 1,
            }],
            listeners: {
                scope: this,
                selectionchange: function (view, selected, eOpts) {
                    reestButton.setDisabled(selected.length === 0);
                },
                cellcontextmenu: function(myGrid, td, cellIndex, record, tr, rowIndex, e, eOpts) {
                    var items = [];

                    var power_on = record.get("power_on");
                    items.push({
                        text: power_on ? 'Power off': 'Power on',
                        scope: this,
                        iconCls: power_on ? 'icon-off' : 'icon-ok',
                        handler: function() {
                            this.client.sendMessage({message: power_on ? 'power_off' : 'power_on', ue_id: record.get('ue_id')});
                        }
                    });
                    // Connect to PDN
                    items.push({
                        text: 'Connect pdn',
                        scope: this,
                        iconCls: 'icon-dial',
                        handler: function() {
                            Ext.Msg.prompt('PDN Connect', 'Please enter APN:', function(btn, text) {
                                if (btn === 'ok') {
                                    this.client.sendMessage({message: 'pdn_connect', apn: text, ue_id: record.get('ue_id')});
                                }
                            }, this);
                        }
                    });
                    if (record.get("rrc_state") === "connected") {
                        items.push({
                            text: 'RRC reestablishment',
                            scope: this,
                            iconCls: 'icon-sync',
                            handler: function() {
                                this.client.sendMessage({message: 'rrc_reest', ue_id: record.get('ue_id')});
                            }
                        });
                    }

                    // Scenario
                    var sims = lteSim.get();
                    for (var i = 0; i < sims.length; i++) {
                        var sim = sims[i];

                        if (sim.get("ue").count) continue;
                        if (!sim.get('scripts').length && !sim.get('power').enabled) continue;

                        if (!i)
                            items.push({xtype: 'menuseparator'});

                        items.push({
                            text: 'Start scenario ' + sim.get('name'),
                            iconCls: 'icon-play',
                            scope: this,
                            handler: (function(sim, ue_id) { this.createUESimTab(sim, [ue_id]); }).bind(this, sim.getData(), record.get("ue_id")),
                        });
                    };

                    var menu = new Ext.menu.Menu({items: items});
                    var position = e.getXY();
                    e.stopEvent();
                    menu.showAt(position);

                    myGrid.select(record);
                }
            }
        });

        this.statsRFSamplesInit();

        this.add({
            region: 'center',
            layout: 'fit',
            items: [ueGrid],
        }, {
            region: 'south',
            layout: 'fit',
            height: 300,
            split: true,
            items: [this.getChartPanel(this._statsChart)],
        });
    },

    _chartList: [{
        title:    'Bitrate',
        fieldType:    ['bitrate'],
        unit:    'brate',
        serieWidth: 300,
    }, {
        title:    'Packets',
        fieldType:    ['dl_rx_count', 'dl_err_count', 'ul_tx_count', 'ul_retx_count'],
        unit:    '',
        serieWidth: 300,
    }, {
        title:    'Scheduler',
        fieldType:    ['sched'],
        unit:    '',
        serieWidth: 300,
    }, {
        title:        'Messages',
        fieldType:    ['messages'],
        serieWidth: 400,
        unit: ''
    }, {
        title:        'Errors',
        fieldType:    ['errors'],
        serieWidth: 400,
        unit: ''
    }],

    _eventListener: function (event) {

        switch (event.type) {
        case 'stats':
            var bitrates = this._field2chart.bitrate;
            var packets = this._field2chart.dl_rx_count;
            var sched = this._field2chart.sched;
            if (!bitrates) return;

            var now = new Date() - 0;
            for (var cell_index in event.data.cells) {
                var data = event.data.cells[cell_index];

                for (var id in UEConfig.series.br) {
                    bitrates.comp.addValues(id + '.' + cell_index, [{ x: now, y: data[id] }]);
                }
                for (var id in UEConfig.series.packets) {
                    switch (id) {
                    case 'dl_bler':
                        var total = data.dl_rx_count + data.dl_err_count;
                        if (total) {
                            packets.comp.addValues(id + '.' + cell_index, [{ x: now, bler: data.dl_err_count / total }]);
                        }
                        break;
                    default:
                        packets.comp.addValues(id + '.' + cell_index, [{ x: now, y: data[id] }]);
                        break;
                    }
                }
                for (var id in UEConfig.series.sched) {
                    sched.comp.addValues(id + '.' + cell_index, [{ x: now, y: data[id] }]);
                }
            }

            this.statsRFSamplesFeed(event);
            this._updateCounters(now, event.data.counters);
            break;

        case 'close':
            lteSim.unregisterTab(this);
            break;
        }
    },

    // Create UE main tab
    createUESimTab: function (sim, ue_ids) {
        if (!sim.ue.count && !ue_ids) {
            var cb = (function (ue_ids) { this.createUESimTab(sim, this.getUEIDs()); }).bind(this);

            // Defer simulation when UE list complete
            if (this._ueList.dirty) {
                this._ueList.onComplete = cb;
            } else {
                cb();
            }
            return;
        }

        var tab = Ext.create('lte.ue.sim', {
            title: this.client.getName() + ": " + sim.name,
            sim: sim,
            cells: this._cells,
            ue_ids: ue_ids,
            client: this.client,
            tab: this
        });
    },

    setClientConfig: function (config) {

        this._cells = config.cells;
        UEConfig.setSerie(this._field2chart.bitrate.comp, 'br', this._cells);
        UEConfig.setSerie(this._field2chart.dl_rx_count.comp, 'packets', this._cells);
        UEConfig.setSerie(this._field2chart.sched.comp, 'sched', this._cells);

        this.setClientConfigRF(config);
    },

    getUE: function (ue_id) {
        var record = this._ueList.cache[ue_id];
        if (record)
            return record.getData();
        return null;
    },

    getUESend: function () {

        var ueList = this._ueList;
        if (this._closed || ueList.request) return;

        if (ueList.timer) {
            clearTimeout(ueList.timer);
            ueList.timer   = 0;
        }

        this.client.sendMessage({message: 'ue_get', max: 256}, this.getUECb.bind(this));
        ueList.request = true;
    },

    getUECb: function (msg) {

        var ueList = this._ueList;
        ueList.request = false;
        if (this._closed) return;

        var store = this._ueStore;
        if (msg.ue_list && msg.ue_list.length) {
            this.client.sendEvent({type: 'ue', data: msg.ue_list, time: msg.time});
            // Add non present fields to force display refresh
            msg.ue_list.forEach(function (ue) {
                if (!ue.pdn_list) ue.pdn_list = null;
                if (ue.cells) {
                    ue.pci = ue.cells[0].pci;
                    ue.rsrp = ue.cells[0].rsrp;
                    ue.snr = ue.cells[0].snr;
                    ue.cell_index = ue.cells[0].index;
                }
            });
            lteLogs.storeUpdate(ueList.cache, store, msg.ue_list, 'ue_id', true);
        }

        if (!msg.pending) {
            if (ueList.dirty) {
                ueList.dirty = false;
                if (ueList.onComplete) {
                    ueList.onComplete();
                    ueList.onComplete = null;
                }
            }
        }

        var now = new Date() * 1;
        var delay = this.client.getRefreshDelay();
        while (ueList.time < now) ueList.time += delay;

        ueList.timer = setTimeout(this.getUESend.bind(this), ueList.time - now);
    },

    getUEIDs: function () {
        return Object.keys(this._ueList.cache).map(function (id) { return id | 0; });
    },
});



Ext.define("lte.ue.sim", {

    extend: 'Ext.panel.Panel',
    layout: 'border',
    closable: true,
    iconCls: 'icon-report',

    constructor: function (config) {
        this._sim       = config.sim;
        this._ue_ids    = config.ue_ids || [];
        this._cells     = config.cells;
        this._startDate = new Date();
        this._ueTab     = config.tab;

        // Listen events
        this._listenerId = config.client.registerEventListener('*', this._eventListener.bind(this));
        this._testTimeout = 0;

        this.callParent(arguments);
    },

    listeners: {
        activate: function () {
            this._updater.unlock();
            switch (this._testState) {
            case 'init':
            case 'start':
                this.setLoading(true);
                break;
            }
        },
        deactivate: function () {
            this._updater.lock();
        },
        close: function () {
            this._stopTest();
            this._closed = true;
            clearTimeout(this._testTimeout);
            this._updater.destroy();
            this.client.unregisterEventListener(this._listenerId);
        },
    },

    initComponent: function () {
        this.callParent(arguments);

        this._restartButton = Ext.create('Ext.Button', {
            text: 'Retry',
            iconCls: 'icon-refresh',
            scope: this,
            disabled: true,
            handler: function () {
                this._reset();
                this._startTest();
            }
        });

        this._stopButton = new Ext.create('Ext.Button', {
            text: 'Stop',
            scope: this,
            iconCls: 'icon-stop',
            disabled: true,
            tooltip: lteLogs.tooltip('Stop current scenario'),
            handler: function (b, e) {
                this._stopTest();
            }
        });

        this._exportButton = Ext.create('Ext.Button', {
            text: 'Export',
            iconCls: 'icon-download',
            scope: this,
            disabled: true,
            handler: function () {
                this._exportReport();
            }
        });

        // Reset
        this._reset();

        this.add({
            tbar: {items:[this._restartButton, this._stopButton, this._exportButton]},
            split: true,
            layout: 'fit',
            region: 'center',
            items: [this._createSimReport()]
        });

        // Create UE ?
        if (this._sim.ue.count) {
            this._ueCreateUpdate();
        } else {
            this._startTest(true);
        }
    },

    _ueCreateUpdate: function () {

        lteLogs.load(true);

        var index = 0;
        var longList = this._ueList.map(function (ue) {
            var cfg = {};
            for (var i in ue) {
                if (i !== "scripts")
                    cfg[i] = ue[i];
            }
            return cfg;
        });

        // Add UE by chunks
        var addUE = (function (resp) {

            if (this._closed) return;

            if (resp) {
                var info = resp.info;
                var errors = info.filter(function (m) { return !m.match(/UE #\d+ already created/); });
                if (errors.length > 0) {
                    Ext.Msg.alert('Error', errors.join('<br/>'));
                    lteLogs.load(false);
                    return;
                }
            }

            var shortList = longList.splice(0, 1000);
            if (!shortList.length) {
                lteLogs.load(false);
                this._startTest(true);
                return;
            }

            this.client.sendMessage({
                    message:    'ue_add',
                    text:        'Create UEs',
                    list:        shortList
                },
                addUE, true);
        }).bind(this);

        // First delete UEs
        this.client.sendMessage({
                message:    'ue_del',
                text:       'Delete UEs',
                ue_id:      longList.map(function (ue) { return ue.ue_id; })
            },
            (function (resp) {
                addUE();
            }).bind(this),
            true
        );
    },

    _setScriptResult: function (script, results) {

        var globalRatio = 0;
        var log  = [];
        switch (script.type) {
        case "ping":
            var result = results[0];
            var report = result.report;
            if (report) {
                log.push(report.recv + "/" + report.sent + " replies");
                if (report.sent > 0)
                    globalRatio = report.recv / report.sent;
            } else {
                log.push(result.error);
            }
            break;

        case "udp":
        case "ethernet":
        case "rtp":
        case "flood":
        case "voip":
            var ok = 0;
            var total = 0;
            for (var i = 0; i < results.length; i++) {
                var result = results[i];
                var report = result.report;
                var msg = script.msg[i];

                if (report) {
                    total += report.sent;
                    ok += report.recv;
                    switch (msg.message) {
                    case 'cbr_recv':
                    case 'flood_recv':
                        if (report.sent > 0) {
                            var ratio = report.recv / report.sent;
                            log.push('DL: ' + Math.floor(ratio * 100) + '%, ' + report.recv + '/' + report.sent + ' packet(s) received');
                        }
                        break;

                    case 'cbr_send':
                    case 'flood_send':
                        if (report.sent > 0) {
                            var ratio = report.recv / report.sent;
                            log.push('UL: ' + Math.floor(ratio * 100) + '%, ' + report.recv + '/' + report.sent + ' packet(s) transferred');
                        }
                        break;
                    }
                } else {
                    log.push(result.error);
                }
            }
            if (total > 0)
                globalRatio = ok / total;
            break;

        case "http":
            var report = results[0].report;
            var rate = report.duration > 0 ? (8 * report.rx_size / report.duration / 1000000).toFixed(3) : 0;
            log.push(rate + " Mbps, " + (report.rx_size / 1000000).toFixed(3) + " MB, " + report.connections + " connection(s)");
            globalRatio = report.rx_size ? 1 : 0;
            break;
        case 'app':
            var res = SimCustomHandler(script.msg[0].tag, script.output.split(/\n/), script.error);
            globalRatio = Math.max(0, Math.min(1, res.ratio));
            log = res.log;
            break;
        }
        var r = ('00' + Math.round((1 - globalRatio) * 255).toString(16)).slice(-2);
        var g = ('00' + Math.round(globalRatio * 255).toString(16)).slice(-2);
        var b = ('00' + Math.round(32).toString(16)).slice(-2);

        script.ratio    = globalRatio;
        script.log        = log.join('<br/>');
        script.color    = "#" + r + g + b;
        script.status    = "done";

        if (results[0].cancel)
            script.status = 'cancel';
    },

    _scriptMessageNotif: function (script, resp) {

        var ts = resp.time - this._startTS - script.time;

        switch (resp.notification) {
        case 'start':
            if (script.status !== 'start') {
                script.status = 'start';
                script.log    = 'In progress...';

                this._globalStatusDirty = true;
                this._scriptToolTipUpdate(script);

                script.network = resp.network;
            }
            break;
        case 'info':
            if (resp.info)
                script.events.push(resp.info + ' at ' + ts.toFixed(1) + 's');
            break;
        case 'progress':
            if (resp.output) {
                script.output += resp.output;
            }
            if (resp.error) {
                script.error += resp.error;
            }
            break;
        }

        // Network state update
        if (resp.network !== undefined && script.network !== resp.network) {
            if (resp.network)
                script.events.push('Network up at ' + ts.toFixed(1) + 's');
            else
                script.events.push('Network down at ' + ts.toFixed(1) + 's');
            script.network = resp.network;
        }
    },

    _scriptMessageCallback: function (script, respList, resp, index, end) {

        // Protect
        if (this._closed) return;

        switch (script.type) {
        case 'power':
            if (resp.message === 'power_on') {
                script.status = 'start';
                script.log    = 'On';
            } else {
                script.status = 'done';
                script.log    = 'Off';
            }
            break;

        default:
            // Notification received
            if (resp.notification)
                return this._scriptMessageNotif(script, resp);

            resp.notification = 'progress'; // Fake
            this._scriptMessageNotif(script, resp);

            this._globalStatusDirty = true;

            // Log
            if (end)
                this._setScriptResult(script, respList);
            break;
        }

        if (this._testState === 'done')
            this._endTest();
    },

    _reset: function () {
        this._scriptList = [];
        this._globalStatus = this._getGlobalStatus();
        this._loopCount = 0;

        // Generate scripts
        var gen = lteSim.generateScripts(this._sim, this._ue_ids, {imeisv: (lteLogs.hash(this.client.config.address) % 1e9) + '$01'});
        var ueList = this._ueList = gen.list;
        this._scriptList = gen.scripts;
        this._duration = gen.duration;

        // Initialize display
        ueList.forEach((function (ue) {
            var sList = ue.scripts.filter(function (script) { return script.ip; });

            var curList = [];
            for (var i = 0; i < sList.length; i++) {
                var s0 = sList[i];

                s0.overlapList    = [];
                s0.overlapMax    = 0;

                // Purge
                for (var j = curList.length; j--;) {
                    var s1 = curList[j];
                    if (s1.time + s1.duration <= s0.time)
                        curList.splice(j, 1);
                }

                var n = curList.push(s0);

                for (var j = 0; j < curList.length; j++) {
                    var s1 = curList[j];
                    s1.overlapMax = Math.max(n, s1.overlapMax);
                    s1.overlapList.push(s0);
                    s0.overlapList.push(s1);
                }
            }
            
            var hUE = this._hUE;
            var tMargin = this._timeMargin;
            var sMargin = this._scriptMargin;
            for (var i = 0; i < ue.scripts.length; i++) {
                var script = ue.scripts[i];

                var x0 = (script.time + tMargin) * this._tScale;
                var x1 = x0 + script.duration * this._tScale;

                switch (script.type) {
                case 'power':
                    script.x0 = x0;
                    script.x1 = x1;
                    script.y0 = 0;
                    script.y1 = hUE;
                    break;

                default:
                    if (script.ip) {
                        var n = script.overlapList.reduce(function (a, b) { return Math.max(a, b.overlapMax); }, script.overlapMax);

                        var used = new Array(n); // Count me !
                        script.overlapList.forEach(function (s) { if (s.overlapIndex !== undefined) used[s.overlapIndex] = true});
                        for (var j = 0; j < n && used[j] !== undefined; j++);
                        script.overlapIndex = j;

                        script.x0 = x0;
                        script.x1 = x1;
                        script.y0 = Math.floor(j * hUE / n) + (sMargin >> 1);
                        script.y1 = Math.floor(++j * hUE / n) - (sMargin >> 1);
                    }
                    break;
                }
            }
        }).bind(this));

        clearTimeout(this._testTimeout);
        this._testTimeout = 0;
        this._testState = 'init';
        this.client.info("Start sim ", this._sim.name, "for", ueList.length);
    },

    // Start
    _startTest: function (first) {

        this._stopped = false;
        if (first) {
            if (!this._duration) {
                Ext.Msg.alert(this._sim.name, 'Done');
                return;
            }
            lteLogs.addTab(this);
        }

        var count = this._ueList.length;
        if (!count) {
            this._startTest1(); // XXX May never happen
        } else {
            this._ueList.forEach((function (ue) {
                this.client.sendMessage({message: 'cancel', group_id: ue.ue_id}, (function (msg) {
                    if (!(--count))
                        this._startTest1();
                }).bind(this));
            }).bind(this));
        }
    },

    _startTest1: function () {
        this._testState = 'init';

        // Graph
        var graph = this._graph = new Graph({
            margin: {left: this._wName, top: 5, bottom: 20, right: 0},
            axis: {
                x: {
                    auto: 'fix',
                    min: -this._timeMargin * 1000,
                    max: (this._duration + this._timeMargin) * 1000,
                    unit: 'duration',
                    stepFrac: Math.floor(this._duration / 10),
                    //grad: false,
                },
                y: {
                    axis: 0,
                    unit: 'brate'
                },
                z: {
                    axis: 0,
                },
                bler: {
                    unit: '%',
                }
            },
            overMode: 'time',
            series: {},
            onOver: this._onGraphOver.bind(this),
        });
        UEConfig.setSerie(graph, 'count', this._cells);
        UEConfig.setSerie(graph, 'br', this._cells);
        UEConfig.setSerie(graph, 'packets', this._cells, 'z');

        // Reset state
        var prereqList = [];

        if (this._sim.power.enabled) {
            this._ueList.forEach(function (ue) {
                prereqList.push({
                    message: 'power_off',
                    ue_id: ue.ue_id,
                });
            });
        }

        if (this._sim.chan.type !== 'none') {
            this._ueList.forEach(function (ue) {
                prereqList.push({
                    message: 'ue_move',
                    ue_id: ue.ue_id,
                    position: ue.position,
                    speed: ue.speed,
                    direction: ue.direction
                });
            });
        }

        if (prereqList.length > 0) {
            this.client.sendMessageList(prereqList, (function (resp) {
                if (this._closed) return;
                this._startTest2();
            }).bind(this));
        } else {
            this._startTest2();
        }
    },

    _startTest2: function () {
        this._testState = 'start';
    },

    _startTest3: function () {

        // Init
        this._restartButton.setDisabled(true);
        this._exportButton.setDisabled(true);
        this._stopButton.setDisabled(false);
        this.client.profileReset();

        var startTS = this._startTS;

        // Start scripts
        for (var i = 0, count = this._scriptList.length; i < count; i++) {
            var script = this._scriptList[i];

            script.color = null;
            script.ratio = 0;
            script.log = "Not started";
            script.status = "wait";
            script.output = '';
            script.error  = '';
            script.events = [];
            script.network = false;
            script.msg.forEach(function (m) { m.group_id = m.ue_id; });

            // Convert to absolute time
            var msgList = script.msg.map(function (m) {

                var m1 = Object.assign({absolute_time: true}, m);
                m1.start_time += startTS;
                if (m1.end_time !== undefined)
                    m1.end_time += startTS;

                return m1;
            });

            switch (msgList[0].message) {
            case 'pdn_connect':
                var msg = msgList.shift();
                this.client.sendMessage(msg, (function (msgs, resp) {

                    if (!this._closed)
                        this.client.sendMessageList(msgs, this._scriptMessageCallback.bind(this, script), true);

                }).bind(this, msgList), true);
                break;
            default:
                this.client.sendMessageList(msgList, this._scriptMessageCallback.bind(this, script), true);
                break;
            }
        };

        var now = new Date();
        this._startTime = now - 0;
        this._testState = 'run';
        this._globalStatusDirty = true;
        this._statsDB = [];
        this._ueDB = [];
        this._updater.update(true);

        this.setLoading(false);
    },

    _getGlobalStatus: function () {

        var result  = 0;
        var ended   = 0;
        var started = 0;
        var error   = 0;
        var ok      = 0;
        var total   = 0;

        for (var i = 0, count = this._scriptList.length; i < count; i++) {
            var script = this._scriptList[i];
            if (!script.ip) continue;

            total++;
            switch (script.status) {
            case "start":
                started++;
                break;
            case "timeout":
            case 'cancel':
                ended++;
                error++;
                break;
            case "done":
                result += script.ratio;
                ended++;
                if (!script.ratio)
                    error++;
                else if (script.ratio >= 1)
                    ok++;
                break;
            }
        }
        return {
            result: result,
            ended: ended,
            started: started,
            error: error,
            ok: ok,
            total: total,
        };
    },

    _formatGlobalStatus: function (status) {

        var list = [];

        if (status.ended > 0)
            list.push(Math.round(100 * status.result / status.ended) + "%");
        list.push(status.total + " simulation(s)");
        if (status.started > 0)
            list.push(status.started + " in progress");
        if (status.error > 0)
            list.push(status.error + " error(s)");
        if (status.ok > 0)
            list.push(status.ok + " ok");
        if (status.ended > 0)
            list.push(status.ended + " done");

        return list;
    },

    _updateGlobalStatus: function () {

        var status = this._getGlobalStatus();
        var list = this._formatGlobalStatus(status);

        if (this._sim.loop > 0) {
            for (var i in status) status[i] += this._globalStatus[i];
            var list1 = this._formatGlobalStatus(status);
            this._scriptLabel.setText('Run ' + (this._loopCount + 1) + '/' + (this._sim.loop + 1) + ', ' + list.join(', ') + ' / Total: ' + list1.join(', '));
        } else {
            this._scriptLabel.setText(list.join(", "));
        }
    },

    // End
    _endTest: function () {

        if (this._testState !== 'done') {
            this.client.profileDump();
            this._testState = 'done';
            this._endDate = new Date() * 1;
        }

        this._updater.update(true);
        if (this._globalStatusDirty) {
            this._updateGlobalStatus();
            this._globalStatusDirty = false;
        }

        if (!this._testTimeout) {
            if (!this._checkAllScriptDone()) {
                this._testTimeout = Ext.Function.defer(this._endTestTimeout, 15000, this);
                return;
            }
        }

        if (!this._stopped && this._loopCount++ < this._sim.loop) {
            var status = this._getGlobalStatus();
            for (var i in status) this._globalStatus[i] += status[i];
            this._startTest1();
        } else {
            this._restartButton.setDisabled(false);
            this._exportButton.setDisabled(false);
            this._stopButton.setDisabled(true);
        }
    },

    _stopTest: function () {

        switch (this._testState) {
        case 'run':
        case 'start':
            this._ueList.forEach((function (ue) {
                this.client.sendMessage({message: 'cancel', group_id: ue.ue_id});
            }).bind(this));
            break;
        default:
            break;
        }

        this._stopped = true;
        this._endTest();
    },

    _checkAllScriptDone: function () {
        for (var i = 0; i < this._scriptList.length; i++) {
            var script = this._scriptList[i];
            if (script.status !== 'done' && script.status !== 'cancel') {
                return false;
            }
        }
        return true;
    },

    _endTestTimeout: function () {
        this._scriptList.forEach(function (script) {
            switch (script.status) {
            case 'done':
            case 'cancel':
                break;
            default:
                script.status = 'timeout';
                script.log    = 'Timeout';
                break;
            }
        });

        console.log('Timeout');
        this._endTest();
        this._testTimeout = 0;
    },

    // Draw config
    _hUE: 30,
    _wName: 50,
    _tScale: 3,
    _marginWidth: 2.5,
    _marginHeight: 2.5,
    _graphHeight: 180,
    _scriptMargin: 4,
    _timeMargin: 1,
    _scrollSize: 20,

    _createSimReport: function () {

        this._scriptLabel = Ext.create('Ext.form.Label', {
            text: 'Status:',
            width: '100%',
            style: {'font-size':'16px'}
        });

        this._updater = Ext.create("lte.updater", {
            scope:            this,
            updateDelay:    500,
            dirty:            false,
            lock:            1,
            handler:        (function () {
                this._drawReport();
                this._updateGlobalStatus();
            }).bind(this)
        });

        // Create canvas
        this._canvasContainer = Ext.create('Ext.panel.Panel', {
            tbar: {items: [this._scriptLabel]},
            html: '<canvas></canvas>',
            layout: 'fit',
            listeners: {
                scope: this,
                resize: function(container, width, height) {
                    if (!this._canvas) {
                        // Configure canvas
                        var canvas = this._canvas = container.el.down("canvas").dom;
                        this._updateArea(canvas, width, height);
                        canvas.addEventListener("mousemove", this._mouseMoveEvent.bind(this), false);
                        canvas.addEventListener("mouseout", this._mouseOutEvent.bind(this), false);
                        canvas.addEventListener('mousedown', this._mouseDownEvent.bind(this), false);
                        canvas.addEventListener('mouseup', this._mouseUpEvent.bind(this), false);
                        canvas.addEventListener(lteLogs.getMouseWheelEvent(), this._mouseWheelEvent.bind(this), false);

                        this._toolTip = Ext.create('Ext.tip.ToolTip', {
                            target: canvas,
                            trackMouse: false,
                            autoHide: false,
                        });
                    }
                    this._updateArea(this._canvas, width, height);
                    this._setScroll(this._scrollX, this._scrollY);
                    this._updater.update(true);
                }
            }
        });
        return this._canvasContainer;
    },

    _exportReport: function () {

        var csv = [];
        var sim = this._sim;

        // Config
        var cells = this.client.getParams('cells');
        csv.push("*** Config ***");
        for (var i in cells) {
            csv.push(['RB DL #' + i, cells[i].n_rb_dl]);
            csv.push(['RB UL #' + i, cells[i].n_rb_ul]);
        }
        if (sim.power.enabled) {
            csv.push(["CAPS", sim.power.caps]);
            csv.push(["Max UE", sim.power.on_max]);
            csv.push(["Power on duration", sim.power.on_time]);
            csv.push(["Power off duration", sim.power.off_time]);
        }
        if (sim.ue.count) {
            csv.push(["UE", sim.ue.count]);
        } else {
            csv.push(["UE", this._ue_ids.length]);
        }
        csv.push("");

        // Scripts
        csv.push("*** Scripts ***");
        csv.push(["UE ID", "Name", "Type", "Start", "Stop", "Status", "Result"]);
        for (var i = 0, length = this._scriptList.length; i < length; i++) {
            var script = this._scriptList[i];
            if (!script.ip) continue;

            csv.push([
                script.category,
                script.name,
                script.type,
                script.time,
                script.time + script.duration,
                script.status,
                script.ratio * 100
            ]);
        }
        csv.push("");

        // Stats
        var graph = this._graph;
        var ueSeries = lteLogs.ueSeries;

        csv.push("*** Stats ***");

        var line = ['Time'];
        var cells = this._cells;
        for (var cell_index in cells) {
            (['br', 'sched']).forEach(function (id) {
                for (var i in UEConfig.series[id]) {
                    line.push(UEConfig.series[id][i].title.replace(/<cell>/, cells[cell_index].pci));
                }
            });
        }
        csv.push(line);

        for (var i = 0; i < this._statsDB.length; i++) {
            var item = this._statsDB[i];
            var line = [item.time.toFixed(3)];
            for (var c in item.cells) {
                var cell = item.cells[c];

                (['br', 'sched']).forEach(function (id) {
                    for (var j in UEConfig.series[id]) {
                        line.push(cell[j] | 0);
                    }
                });
            }
            csv.push(line);
        }
        csv.push("");

        // UE
        csv.push("*** UEs ***");
        csv.push(['Time', 'UE id', 'CQI', 'RI', 'RSRP',
            'DL bitrate', 'DL rx', 'DL retx', 'DL mcs', 'DL RB',
            'UL bitrate', 'UL rx', 'UL retx', 'UL mcs', 'UL RB'
        ]);
        for (var i = 0; i < this._ueDB.length; i++) {
            var item = this._ueDB[i];
            for (var j = 0; j < item.ue_list.length; j++) {
                var ue = item.ue_list[j];
                var cell = ue.cells ? ue.cells[0] : ue;
                csv.push([
                    item.time.toFixed(3),
                    ue.ue_id,
                    cell.cqi,
                    cell.ri,
                    cell.rsrp.toFixed(1),
                    ue.dl_bitrate | 0,
                    ue.dl_rx_count,
                    ue.dl_retx_count,
                    (ue.dl_mcs || 0).toFixed(1),
                    ue.dl_rb !== undefined ? ue.dl_rb.toFixed(4) : '-',
                    ue.ul_bitrate | 0,
                    ue.ul_tx_count,
                    ue.ul_retx_count,
                    (ue.ul_mcs || 0).toFixed(1),
                    ue.ul_rb !== undefined ? ue.ul_rb.toFixed(4) : '-',
                ]);
            }
        }
        csv.push("");

        // Format
        for (var i = 0; i < csv.length; i++) {
            var line = csv[i];
            if (line instanceof Array) {
                line = line.join(";");
            }
            csv[i] = line;
        }

        var date = new Date(this._startTime);
        var filename = sim.name + '-' + 
                ("0" + date.getFullYear()).slice(-4) +
                ("0" + (date.getMonth() + 1)).slice(-2) +
                ("0" + date.getDate()).slice(-2) + "-" +
                ("0" + date.getHours()).slice(-2) + ":" +
                ("0" + date.getMinutes()).slice(-2) + ":" +
                ("0" + date.getSeconds()).slice(-2) +
                '.csv';

        lteLogs.exportFile(csv.join("\n"), filename, 'text/csv;charset=utf-8;');
    },

    _updateArea: function (canvas, width, height) {

        canvas.width = width - 3;
        canvas.height = height - 33; // HACK

        // Maximum canvas size
        var w1 = this._duration + this._timeMargin * 2;
        var w2 = this._wName + this._marginWidth * 2;
        var sWidth = w2 + w1 * this._tScale;
        var sHeight = this._hUE * this._ueList.length + this._marginHeight * 2 + this._graphHeight;

        var sx = sWidth > canvas.width;
        var sy = sHeight > canvas.height;

        // Horizontal scroll
        if (sx) {
            this._drawHeight = canvas.height - this._scrollSize;
            this._scrollMaxX = sWidth - canvas.width + (sy ? this._scrollSize : 0);
        } else {
            this._drawHeight = canvas.height;
            this._scrollMaxX = 0;
        }

        // Vertical scroll
        if (sy) {
            this._drawWidth = canvas.width - this._scrollSize;
            this._scrollMaxY = sHeight - canvas.height + (sx ? this._scrollSize : 0);
        } else {
            this._drawWidth = canvas.width;
            this._scrollMaxY = 0;
        }
    },

    _drawReport: function () {

        var canvas = this._canvas;
        if (!canvas || !this._graph) return;

        var t0 = new Date();
        
        var ctx    = canvas.getContext("2d");
        var hUE    = this._hUE - 0;
        var wName  = this._wName - 0;
        var tScale = this._tScale - 0;
        var tMargin = this._timeMargin - 0;
        var scrollX = this._scrollX - 0;
        var scrollY = this._scrollY - 0;

        ctx.fillStyle        = 'black';
        ctx.strokeStyle        = 'black';
        ctx.textBaseline    = 'middle';
        ctx.textAlign        = 'center';
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        ctx.save();
        ctx.beginPath();
        ctx.rect(0, 0, this._drawWidth, this._drawHeight);
        ctx.clip();

        var simWidth = (this._duration + tMargin * 2) * tScale;
        var simHeight = this._drawHeight - this._graphHeight;

        // Draw graph
        ctx.save();
        this._graph.draw(canvas, {
            x: this._marginWidth - scrollX,
            y: this._marginHeight,
            w: wName + simWidth,
            h: this._graphHeight,
            clip: {x: 0, y: 0, w: this._drawWidth - 1, h: this._drawHeight}
        });
        ctx.restore();

        // Scripts
        ctx.save();
        ctx.translate(this._marginWidth, this._marginHeight + this._graphHeight);
        ctx.beginPath();
        ctx.rect(0, 0, wName + simWidth, simHeight);
        ctx.clip();

        var i0 = Math.floor(scrollY / hUE);
        var i1 = Math.ceil((scrollY + simHeight) / hUE);

        // Headers
        for (var i = i0; i < this._ueList.length && i < i1; i++) {
            var ue = this._ueList[i];
            var y = i * hUE;

            //var ref = this._ueTab.getUE(ue.ue_id);

            ctx.save();
            ctx.translate(0, y - scrollY);
            /*switch (ref.emm_state) {
            case 'registering':
                ctx.fillStyle = '#8080FF';
                ctx.fillRect(0, 0, wName, hUE);
                break;
            case 'registered':
                ctx.fillStyle = '#C0FFC0';
                ctx.fillRect(0, 0, wName, hUE);
                break;
            default:
                break;
            }*/
            ctx.strokeRect(0, 0, wName, hUE);
            ctx.font = (hUE >> 1) + "px Arial";
            ctx.fillStyle = 'black';
            ctx.fillText(ue.ue_id, wName >> 1, hUE >> 1);
            ctx.restore();
        }

        ctx.beginPath();
        ctx.rect(wName, 0, simWidth, simHeight);
        ctx.clip();

        // Scripts
        for (var i = i0; i < this._ueList.length && i < i1; i++) {
            var ue = this._ueList[i];
            var y = i * hUE;

            ctx.save();
            ctx.fillStyle = '#B0C0D0';
            ctx.font = (hUE >> 2) + "px Arial";
            ctx.translate(wName - scrollX, y - scrollY);
            ctx.fillRect(0, 0, simWidth, hUE);

            for (var s = 0; s < ue.scripts.length; s++) {
                var script = ue.scripts[s];
                if (script.x0 < this._drawWidth - wName + this._scrollX && script.x1 > this._scrollX)
                    this._drawScript(ctx, script);
            }

            // Frame
            ctx.strokeStyle = 'black';
            ctx.strokeRect(0, 0, simWidth, hUE);
            ctx.restore();
        }
        ctx.restore(); // End of scripts

        // Time
        ctx.save();
        ctx.translate(this._marginWidth + wName, this._marginHeight);
        ctx.beginPath();
        ctx.rect(0, 0, simWidth, this._drawHeight);
        ctx.clip();

        var ts = Math.min(this._curTS / 1000, this._duration + tMargin);

        var x = Math.floor((ts + tMargin) * tScale - scrollX);
        ctx.beginPath();
        ctx.moveTo(x, 3);
        ctx.lineTo(x, this._ueList.length * hUE + this._graphHeight - 2);
        ctx.strokeStyle = 'rgba(0,0,0,0.7)';
        ctx.lineWidth = 5;
        ctx.lineCap = 'round';
        ctx.stroke();
        ctx.restore();

        ctx.restore();

        // Scroller
        var ss = this._scrollSize;
        ctx.save();
        ctx.translate(-0.5, -0.5);
        ctx.fillStyle = '#e0e0e0';
        ctx.strokeStyle = 'black';
        if (this._scrollMaxX) {
            ctx.save();
            ctx.beginPath();
            ctx.rect(1, this._drawHeight, this._drawWidth - 1, ss);
            ctx.fill();
            ctx.stroke();
            var x = (this._scrollX / this._scrollMaxX) * (this._drawWidth - ss - 5) >> 0;

            ctx.beginPath();
            ctx.rect(x + 3, this._drawHeight + 2, ss, ss - 4);
            ctx.fillStyle = '#c0c0c0';
            ctx.fill();
            ctx.stroke();
            ctx.restore();
        }
        if (this._scrollMaxY) {
            ctx.save();
            ctx.beginPath();
            ctx.rect(this._drawWidth, 1, ss, this._drawHeight - 1);
            ctx.fill();
            ctx.stroke();
            var y = (this._scrollY / this._scrollMaxY) * (this._drawHeight - ss - 5) >> 0;

            ctx.beginPath();
            ctx.rect(this._drawWidth + 2, y + 3, ss - 4, ss);
            ctx.fillStyle = '#c0c0c0';
            ctx.fill();
            ctx.stroke();
            ctx.restore();
        }
        ctx.restore();

        lteLogs.prof("Draw sim in", new Date() - t0, "ms");
        //console.log("Draw sim in", new Date() - t0, "ms");
    },

    _drawScript: function (ctx, script) {

        switch (script.type) {
        case 'power':
            if (script.x0 === undefined) return;
            ctx.fillStyle = '#F0F8FF';
            break;

        default:
            switch (script.status) {
            case 'start':
                if (!script.network) {
                    ctx.fillStyle = '#FF8000';
                    var text = 'Network down';
                } else {
                    ctx.fillStyle = '#0080FF';
                    var text = "...";
                }
                break;
            case 'done':
                ctx.fillStyle = script.color || 'white';
                var text = Math.floor(script.ratio * 100) + "%";
                if (!script.network) {
                    ctx.fillStyle = '#FF8000';
                    text = '! ' + text;
                }
                break;
            case 'timeout':
                ctx.fillStyle = '#808080';
                var text = 'Timeout';
                break;
            case 'cancel':
                ctx.fillStyle = '#C0C000';
                var text = 'Cancelled';
                break;
            case "wait":
                ctx.fillStyle = '#80C0FF';
                break;
            default:
                return;
            }
            break;
        }

        var x = script.x0;
        var y = script.y0;
        var w = script.x1 - script.x0;
        var h = script.y1 - script.y0;

        ctx.fillRect(x, y, w, h);
        ctx.strokeStyle = 'black';
        ctx.strokeRect(x, y, w, h);
        if (text) {
            ctx.fillStyle = lteLogs.getTextColor(ctx.fillStyle);
            ctx.fillText(text, x + (w >> 1), y + (h >> 1));
        }
    },

    _drawPowerOff: function (ctx, t0, t1) {
        var x = (t0 + this._timeMargin) * this._tScale;
        var w = (t1 + this._timeMargin) * this._tScale - x;

        ctx.fillStyle = '#C0C0C0';
        ctx.fillRect(x, 0, w, this._hUE);
        ctx.strokeStyle = 'black';
        ctx.strokeRect(x, 0, w, this._hUE);
    },

    _scriptToolTipUpdate: function (script) {
        if (script === this._toolTipRef) {
            var lines = [
                "<b>" + script.name + "</b>:",
                "From " + script.time + "s to " + (script.time + script.duration) + "s"
            ].concat(script.events);
            lines.push(script.log);
            this._toolTip.update(lteLogs.tooltip(lines.join("<br/>")));
        }
    },

    _scrollX: 0,
    _scrollY: 0,

    _setScroll: function (sx, sy) {

        sx = Math.max(0, Math.min(this._scrollMaxX, sx));
        sy = Math.max(0, Math.min(this._scrollMaxY, sy));

        if (sx !== this._scrollX || sy != this._scrollY) {
            this._scrollX = sx;
            this._scrollY = sy;
            return true;
        }
        return false;
    },

    _getTypeByPos: function (x, y) {

        if (this._scrollMaxX && y >= this._drawHeight && x <= this._drawWidth)
            return 'scrollX';

        if (this._scrollMaxY && x >= this._drawWidth && y <= this._drawHeight)
            return 'scrollY';

        if (y <= this._graphHeight + this._marginHeight)
            return 'graph';

        if (x <= this._drawWidth && y <= this._drawHeight)
            return 'script';

        return null;
    },

    _mouseGetPos: function (event) {
        var rect = event.target.getBoundingClientRect();
        var x = event.clientX - rect.left;
        var y = event.clientY - rect.top;
        return {
            x: x,
            y: y,
            type: this._getTypeByPos(x, y)
        };
    },

    _mouseScrollEvent: function (pos, type) {
        switch (type) {
        case 'scrollX':
            if (this._setScroll(((pos.x - this._scrollSize / 2) / (this._drawWidth - this._scrollSize)) * this._scrollMaxX, this._scrollY))
                this._drawReport();
            return true;
        case 'scrollY':
            if (this._setScroll(this._scrollX, ((pos.y - this._scrollSize / 2) / (this._drawHeight - this._scrollSize)) * this._scrollMaxY))
                this._drawReport();
            return true;
        }
        return false;
    },

    _mouseWheelEvent: function (event) {
        var delta = lteLogs.getMouseWheelDelta(event);
        var offset = delta / Math.abs(delta) * this._hUE;
        if (offset) {
            if (this._setScroll(this._scrollX, this._scrollY - offset))
                this._drawReport();
        }
    },

    _mouseDownEvent: function (event) {

        var move = this._mouseGetPos(event);
        
        var X = event.clientX;
        var Y = event.clientY;

        switch (move.type) {
        case 'scrollX':
        case 'scrollY':
            this._mouseScrollEvent(move, move.type);
            break;
        case 'graph':
        case 'script':
            var scrollX0 = this._scrollX;
            var scrollY0 = this._scrollY;
            break;
        default:
            return;
        }

        lteLogs.registerMouseMove((function (event1) {
            switch (event1.type) {
            case 'mouseup':
            case 'mousemove':
                switch (move.type) {
                case 'scrollX':
                case 'scrollY':
                    this._mouseScrollEvent({x: event1.clientX - X + move.x, y: event1.clientY - Y + move.y}, move.type);
                    break;
                case 'graph':
                    if (this._setScroll(X - event1.clientX + scrollX0, this._scrollY))
                        this._drawReport();
                    break;
                case 'script':
                    if (this._setScroll(X - event1.clientX + scrollX0, Y - event1.clientY + scrollY0))
                        this._drawReport();
                    break;
                }
                break;
            }
        }).bind(this));
    },

    _mouseUpEvent: function (event) {
    },

    _mouseMoveEvent: function (event) {

        var canvas = event.target;
        var pos = this._mouseGetPos(event);

        // Send to graph
        if (this._graph && this._graph.mouseMoveEvent(event))
            return;

        // Try to find script
        if (pos.type === 'script') {
            var x = pos.x - this._marginWidth - this._wName + this._scrollX;
            var y = pos.y - this._marginHeight - this._graphHeight + this._scrollY;
            var index = Math.floor(y / this._hUE);
            if (index >= 0 && index < this._ueList.length) {
                var ue = this._ueList[index];

                y -= index * this._hUE;
                for (var i = 0; i < ue.scripts.length; i++) {
                    var script = ue.scripts[i];
                    if (!script.ip) continue;
                    if (x >= script.x0 && x < script.x1 && y >= script.y0 && y < script.y1) {
                        var rect = canvas.getBoundingClientRect();
                        this._toolTipRef = script;
                        this._scriptToolTipUpdate(script);
                        this._toolTip.showAt([
                            //rect.left + this._wName + Math.max(0, script.x0 + this._marginWidth - this._scrollX),
                            event.clientX + 10,
                            rect.top + this._graphHeight + script.y1 + this._marginHeight + index * this._hUE - this._scrollY]);
                        return;
                    }
                }
            }
        }
        this._mouseOutEvent();
    },

    _onGraphOver: function (data, X, Y) {
        if (data) {
            var data0 = data[0];
            var graph = this._graph;
            var text = 'At ' + data0.x + ':<br/><table>' + data.map(function (d, i) {
                var color = graph.getSerieColor(data[i].serie);
                var rect = '<div style="width:10px;height:10px;border:1px solid #000;background:' + color + '">';
                return '<tr><td>' + rect + '</td><td>' + lteLogs.tooltip(d.title) + ':</td><td align=right><b>' + d.y + '<b></td></tr>';
            }).join('') + '</table>';

            this._toolTipRef = null;
            this._toolTip.update(text);
            this._toolTip.showAt([X + 10, Y + 10]);
        }
    },

    _mouseOutEvent: function (event) {
        this._toolTipRef = null;
        this._toolTip.hide();
    },

    _eventListener: function (event) {

        switch (event.type) {
        case 'stats':
            var graph = this._graph;
            if (!graph) return;

            var ts = event.data.time;
            switch (this._testState) {
            case 'start':
                this._startTS = ts + 1; // Start 1s later, let messages to arrive
                this._startTest3();
                // XXX: don't send all messages at once
                break;
            case 'run':
                break;
            default:
                return;
            }

            // Timestamp
            this._curTS = ts = (ts - this._startTS) * 1000;

            // For each cell
            if (this._curTS >= 0) {
                for (var cell_index in event.data.cells) {
                    var data = event.data.cells[cell_index];
                    for (var id in UEConfig.series.br) {
                        graph.addValues(id + '.' + cell_index, [{
                            x: ts,
                            y: data[id]
                        }]);
                    }
                    for (var id in UEConfig.series.count) {
                        graph.addValues(id + '.' + cell_index, [{
                            x: ts,
                            z: data[id]
                        }]);
                    }
                    for (var id in UEConfig.series.packets) {

                        switch (id) {
                        case 'dl_bler':
                            if (data.dl_rx_count) {
                                graph.addValues(id + '.' + cell_index, [{ x: ts, bler: data.dl_err_count / data.dl_rx_count }]);
                            }
                            break;
                        default:
                            graph.addValues(id + '.' + cell_index, [{ x: ts, z: data[id] }]);
                            break;
                        }
                    }
                }
                this._statsDB.push({time: (ts | 0) / 1000 , cells: event.data.cells});
            }

            // End ?
            clearTimeout(this._testTimeout);
            var limit = (this._duration + this._timeMargin) * 1000;
            if (ts >= limit) {
                this._curTS = limit;
                this._testTimeout = 0;
                this._endTest();
            } else {
                this._testTimeout = Ext.Function.defer(this._endTestTimeout, 10000, this);
                this._updater.update(true);
            }
            break;

        case 'ue':
            switch (this._testState) {
            case 'run':
                var time = event.time - this._startTS;
                if (time >= 0) {
                    this._ueDB.push({ time: time, ue_list: event.data });
                }
                break;
            }
            break;
        }
    },

});


