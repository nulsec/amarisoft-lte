/*
 * Copyright (C) 2020-2023 Amarisoft
 *
 * Amarisoft Web interface 2023-12-15
 */

LTELog.prototype._getDCI = function (logList, index, dci_dir, k)
{
    var cell = this.getCell();
    var nslots = cell.getSlotCount();

    // look in both sides
    for (var step = -1; step < 2; step += 2) {

        var limit = this.timestamp * step + 40;
        for (var i = index + step; ; i += step) {

            var log = logList[i];
            if (!log || log.timestamp * step >= limit) break;

            var c = log.getCell();
            if (c !== cell) continue;
            if (log.channel !== PDCCH) continue;
            if (log.ue_id !== this.ue_id) continue;
            if (!log[dci_dir]) continue;

            var slot = log.slot;
            var frame = log.frame;

            var so = log[k];
            if (so !== undefined) {
                slot += so;
                if (slot >= nslots) {
                    slot -= nslots;
                    frame++;
                }
            }

            //console.log(this.frame, this.slot, log.frame, log.slot, frame, slot, k, nslots, log, log[k]);
            if (this.frame === frame && this.slot === slot) {
                return log;
            }
            if (Math.abs(log.frame - frame) > 2) break;
        }
    }
    return null;
};

LTELog.prototype._getPDSCHpucch = function (logList, index, k1)
{
    var slot = this.slot + k1;
    var frame = this.frame;
    var cell = this.getCell();
    var nslots = cell.getSlotCount();
    if (slot >= nslots) {
        slot -= nslots;
        frame++;
    }

    var limit = this.timestamp + 40;
    for (var i = index + 1;; i++) {
        var log = logList[i];
        if (!log || log.timestamp >= limit) break;

        if (log.channel !== PUCCH) continue;
        if (log.ue_id !== this.ue_id) continue;
        if (log.getCell() !== cell) continue;

        if (log.frame === frame && log.slot === slot) {
            return log;
        }
        if (log.frame > frame) break;
    }
};

LTELog.prototype.getAssociatedLogs = function (logList, index)
{
    var aLogs = this._aLogs;
    if (aLogs !== undefined)
        return aLogs;

    if (index === undefined)
        index = logList.indexOf(this);

    this._aLogs = aLogs = [];

    switch (this.channel) {
    case PDSCH:
        var dci = this._getDCI(logList, index, 'dci_dl', 'k0');
        if (dci) {
            aLogs.push(dci);
            if (this.k1 !== undefined) {
                var pucch = this._getPDSCHpucch(logList, index, this.k1);
                if (pucch)
                    aLogs.push(pucch);
            }
        }
        break;
    case PUSCH:
        var dci = this._getDCI(logList, index, 'dci_ul', 'k2');
        if (dci) {
            aLogs.push(dci);
        }
        break;
    case PUCCH:
        for (var i = index; i--;) {
            var log = logList[i];
            if (log.channel === PDSCH) {
                var list = log.getAssociatedLogs(logList, i);
                if (list.indexOf(this) >= 0) {
                    aLogs.push(log);
                }
            }
        }
        break;
    }
    return aLogs;
};

