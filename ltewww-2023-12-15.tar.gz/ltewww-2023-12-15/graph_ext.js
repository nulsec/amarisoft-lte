/*
 * Copyright (C) 2017-2023 Amarisoft
 *
 * Amarisoft Web interface 2023-12-15
 */

Ext.define("lte.graph", {

    extend: 'Ext.panel.Panel',
    layout: 'border',

    items: [],
    seriesSide: 'west',

    constructor: function (config) {
        this._lockCount = 1;
        this._showValue = config.showValue;
        this._serieWidth = config.serieWidth || 250;
        this._serieStyle  = config.serieStyle || '';
        this._groups = config.groups || [];
        this._toolTipSort = config.toolTipSort;
        this.title = config.title;

        this.callParent(arguments);

        var graph = this.graph = new Graph(
            Ext.Object.merge({
                x: {},
                y: {},
                onOver: this.onOver.bind(this),
                title: this.title
            },
            config.graph));

        for (i in config.graph.series) {
            this._addSerie(i, config.graph.series[i]);
        }

    },

    initComponent: function () {
        this.callParent(arguments);

        var serieItems = [];

        if (this._groups.length) {
            this._groups.forEach(function (g) { g.on = true; });
            var groupsStrore = Ext.create('Ext.data.Store', {
                fields: ['title', 'on', 'groupId'],
                data: this._groups
            });

            var groupsGrid = Ext.create('Ext.grid.Panel', {
                store: groupsStrore,
                padding: 5,
                border: 0,
                flex: 1,
                bodyStyle: {
                    background: '#f0f0f0',
                },
                viewConfig:{
                    markDirty: false
                },
                width: '100%',
                hideHeaders: true,
                columns: [{
                    dataIndex: 'title',
                    flex: 1,
                    scope: this,
                    renderer: function (title, metaData, record, rowIndex, colIndex, store, view) {
                        var color = record.get('on') ? '#80C0ff' : '#ffffff';
                        metaData.style = 'background-color: ' + color + '; font-weight: bold;';
                        return title.trim();
                    }
                }],
                listeners: {
                    scope: this,
                    cellclick: function (grid, td, cellIndex, record, tr, rowIndex, e, eOpts) {
                        //var id = record.get('groupId');
                        var on = record.get('on');
                        on = !on;
                        record.set('on', on);
                        this.groupUpdate();
                    },
                }
            });
            serieItems.push(groupsGrid);
        }

        var serieStore = this._serieStore = Ext.create('Ext.data.Store', {
            fields: ['config', 'on', 'serieId'],
            data: []
        });

        var tbar = [];
        if (this.resetFunc) {
            tbar.push(Ext.create('Ext.button.Button', {
                width: 32,
                tooltip: lteLogs.tooltip("Reset"),
                iconCls: "icon-sync",
                listeners: {
                    scope: this,
                    click: function(filter, e, eOpts) {
                        this.resetFunc();
                        this.graph.reset();
                    }
                }
            }));
        }
        if (!tbar.length) tbar = null;

        var serieGrid = this._serieGrid = Ext.create('Ext.grid.Panel', {
            store: serieStore,
            padding: 5,
            border: 0,
            bbar: tbar,
            bodyStyle: {
                background: '#f0f0f0',
            },
            viewConfig:{
                markDirty: false
            },
            width: '100%',
            hideHeaders: true,
            columns: [{
                dataIndex: 'config',
                flex: 1,
                scope: this,
                renderer: function(config, metaData, record, rowIndex, colIndex, store, view) {
                    var id = record.get('serieId');
                    var color = record.get('on') ? this.graph.getSerieColor(id) : '#f0f0f0';
                    metaData.style = 'background-color: ' + color + '; font-weight: bold; color: ' + lteLogs.getTextColor(color) + '; ' + this._serieStyle;
                    return config.title || id;
                }
            }, {
                dataIndex: 'serieId',
                scope: this,
                align: 'right',
                hidden: !this._showValue,
                renderer: function(id, metaData, record, rowIndex, colIndex, store, view) {
                    var color = record.get('on') ? this.graph.getSerieColor(id) : '#f0f0f0';
                    metaData.style = 'background-color: ' + color + '; font-weight: bold; color: ' + lteLogs.getTextColor(color);
                    return this.graph.getLastValue(id);
                }
            }],
            listeners: {
                scope: this,
                cellclick: function(grid, td, cellIndex, record, tr, rowIndex, e, eOpts) {
                    var id = record.get('serieId');
                    var on = record.get('on');
                    on = !on;
                    record.set('on', on);
                    this.graph.setSerie(id, on);
                    this.update();
                },
                celldblclick: function (grid, td, cellIndex, record, tr, rowIndex, e, eOpts) {
                    var id0 = record.get('serieId');
                    for (var i = this._serieStore.getCount(); i--;) {
                        var rec = this._serieStore.getAt(i);
                        var id  = rec.get('serieId');
                        var on = id0 === id;
                        rec.set('on', on);
                        this.graph.setSerie(id, on);
                    }
                    this.update();
                },
            }
        });
        serieItems.push(serieGrid);

        if (this.toggleAxis) {
            var axis = Object.keys(this.config.graph.axis).filter((id) => {
                if (id === 'x') return false;
                if (!this.config.graph.axis[id].title) return false;
                return true;
            });
            if (axis.length > 1) {
                var axisStore = Ext.create('Ext.data.Store', {
                    fields: ['title', 'axisId', 'axis'],
                    data: axis.map((id) => {
                        var a = this.config.graph.axis[id];
                        return {
                            title: a.title,
                            axisId: id,
                            axis: a,
                            on: a.enabled === undefined ? true : a.enabled,
                        };
                    }),
                });
                var axisGrid = this._axisGrid = Ext.create('Ext.grid.Panel', {
                    store: axisStore,
                    padding: 5,
                    border: 0,
                    flex: 1,
                    bodyStyle: {
                        background: '#f0f0f0',
                    },
                    viewConfig:{
                        markDirty: false
                    },
                    width: '100%',
                    hideHeaders: true,
                    columns: [{
                        dataIndex: 'title',
                        scope: this,
                        renderer: function(title, metaData, record, rowIndex, colIndex, store, view) {
                            var on = record.get('on');
                            metaData.style = 'background-color: ' + (on ? '#c0c0ff' : '#f0f0f0') + ';';
                            return title;
                        }
                    }],
                    listeners: {
                        scope: this,
                        cellclick: function(grid, td, cellIndex, record, tr, rowIndex, e, eOpts) {
                            var id = record.get('axisId');
                            var on = !record.get('on');
                            record.set('on', on);
                            this.update();
                            this.graph.enableAxis(id, on);
                        },
                    },
                });
                serieItems.push(axisGrid);
            }
        }


        var graphPanel = Ext.create('Ext.panel.Panel', {
            html: '<canvas></canvas>',
            listeners: {
                scope: this,
                resize: function(cont, width, height) {

                    var canvas = graphPanel.el.down("canvas").dom;
                    if (this._canvas !== canvas) {
                        this._canvas = canvas;
                        var graph = this.graph;
                        this._addMouseListener(canvas, graph, lteLogs.getMouseWheelEvent(), 'mouseWheelEvent');
                        this._addMouseListener(canvas, graph, 'mouseout', 'mouseOutEvent');
                        this._addMouseListener(canvas, graph, 'contextmenu', 'menuContext');

                        var listener = this._mouseListener.bind(this, canvas, graph);
                        canvas.addEventListener('mousemove', listener, false);
                        canvas.addEventListener('mousedown', listener, false);
                        canvas.addEventListener('mouseup', listener, false);
                    }

                    lteLogs.setCanvasSize(canvas, width, height);
                    this.graph.invalidate();
                    this.update();
                }
            }
        });

        this.add({
            region: 'center',
            layout: 'fit',
            border: 0,
            items: [graphPanel],
        });
        this.add({
            region: this.seriesSide,
            layout: 'vbox',
            width: this._serieWidth,
            bodyStyle: {
                background: '#f0f0f0',
            },
            border: 0,
            items: serieItems,
        });
    },

    groupUpdate: function () {
        for (var i = this._serieStore.getCount(); i--;) {
            var record = this._serieStore.getAt(i);
            var serieId = record.get('serieId');
            var config = record.get('config');

            var on = true;
            for (var g = 0; g < config.groups.length && on; g++) {
                var groupId = config.groups[g];
                for (var j = 0; j < this._groups.length && on; j++) {
                    var group = this._groups[j];
                    if (group.groupId !== groupId) continue;
                    on = group.on;
                }
            }
            record.set('on', on);
            this.graph.setSerie(serieId, on);
        }
        this.update();
    },

    onOver: function (data, X, Y) {

        if (data) {

            data = data.filter((function (d) { return this._serieStore.findRecord('serieId', d.serie); }).bind(this))
            if (!data.length) return;

            var data0 = data[0];
            var graph = this.graph;

            switch (this._toolTipSort) {
            case 'asc':
                data.sort(function (a, b) { return a.Y - b.Y; });
                break;
            case 'desc':
                data.sort(function (a, b) { return b.Y - a.Y; });
                break;
            case 'title':
                data.sort(function (a, b) { return a.title > b.title ? -1 : 1; });
                break;
            }
            var text = 'At ' + data0.x + ':<br/><table>' + data.map(function (d, i) {
                var color = graph.getSerieColor(data[i].serie);
                var rect = '<div style="width:10px;height:10px;border:1px solid #000;background:' + color + '">';
                return '<tr><td>' + rect + '</td><td>' + lteLogs.tooltip(d.title) + ':</td><td align=right><b>' + d.y + '<b></td></tr>';
            }).join('') + '</table>';

            if (!this._tooltip) {
                this._tooltip = Ext.create('Ext.tip.ToolTip', {
                    target: this._canvas,
                    trackMouse: false,
                    autoHide: false,
                    html: text,
                });
            } else {
                this._tooltip.update(text);
            }
            this._tooltip.show([X + 10, Y + 10]);

        } else if (this._tooltip) {
            this._tooltip.hide();
        }
    },

    _addMouseListener: function (canvas, graph, eventName, funcName) {
        canvas.addEventListener(eventName, function (event) { graph[funcName](event); }, false);
    },

    _mouseListener: function (canvas, graph, event) {

        switch (event.type) {
        case 'mousemove':
            if (!this._mouseDown)
                graph.mouseMoveEvent(event);
            break;
        case 'mouseup':
            if (!this._mouseDown)
                graph.mouseUpEvent(event);
            break;
        case 'mousedown':
            lteLogs.registerMouseMove((function (event1) {
                switch (event1.type) {
                case 'mouseup':
                    graph.mouseUpEvent(event1);
                    this._mouseDown = false;
                    break;
                case 'mousemove':
                    graph.mouseMoveEvent(event1);
                    break;
                }
                event1.preventDefault();
            }).bind(this));
            graph.mouseDownEvent(event);
            this._mouseDown = true;
            break;
        }
    },

    listeners: {
        activate: function () {
            this.unlock();
        },

        deactivate: function() {
            this.lock();
        },
    },

    reset: function (keep) {

        if (keep) {
            this.lastSeries = this.getSeries();
        } else {
            this.lastSeries = null;
        }
        this._serieStore.loadData([]);
        this.graph.flushSeries();
        this.graph.reset();
    },

    addSerie: function (id, cfg) {

        if (cfg.enabled === undefined && this.lastSeries && this.lastSeries[id])
            cfg.enabled = this.lastSeries[id].enabled;

        if (this.graph.addSerie(id, cfg)) {
            this._addSerie(id, cfg);
        }
    },

    _addSerie: function (id, cfg) {
        this._serieStore.add([{config: cfg, on: cfg.enabled !== false, serieId: id}]);
    },

    addValues: function (id, values) {

        if (this.graph.addValues(id, values)) {
            if (!this._lockCount)
                this.update();
            return true;
        }
        return false;
    },

    getSeries: function () {
        var series = {};
        for (var i = this._serieStore.getCount(); i--;) {
            var record = this._serieStore.getAt(i);
            series[record.get('serieId')] = {
                enabled: record.get('on')
            };
        }
        return series;
    },

    lock: function () {
        this._lockCount++;
    },

    unlock: function () {
        if (!Math.max(0, --this._lockCount)) {
            this._lockCount = 0;
            this.update();
        }
    },

    _serieGridRefresh: function () {
        var view = this._serieGrid.getView();
        if (view)
            view.refresh();
    },

    update: function () {
        if (this._lockCount)
            return;

        if (!this._updateTimer && this._canvas) {
            this._updateTimer = setTimeout((function () {
                this._updateTimer = 0;

                this.graph.draw(this._canvas);
                if (this._showValue && !this._serieGrid.isDestroyed) {
                    this._serieGridRefresh();
                }
            }).bind(this), 100);
        }
    },
});


