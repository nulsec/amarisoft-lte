/*
 * Copyright (C) 2012-2023 Amarisoft
 *
 * Amarisoft Web interface 2023-12-15
 */
const MAX_DURATION = 3600 * 24 * 7;
const UE_SCENARIO_VERSION = 1;

var lteSim = {

    sections: {name: 'New scenario', ue: {}, chan: {}, power: {}, scripts: [], pdn: [], loop: 0},

    ipDefinitionList: [
        {type: 'ping',     name: 'ICMP PING',      msg: 'ping',    fields: {payload_len: 1000, delay: 1, dst_addr: '192.168.3.1', apn: ''}},
        {type: 'udp',      name: 'UDP',            msg: 'cbr',     fields: {payload_len: 1000, bit_rate: 1000000, dst_addr: '192.168.3.1', direction: 'dl', apn: ''}},
        {type: 'rtp',      name: 'RTP',            msg: 'cbr',     fields: {payload_len: 1000, bit_rate: 1000000, dst_addr: '192.168.3.1', direction: 'dl', apn: ''}},
        {type: 'voip',     name: 'VOIP',           msg: 'cbr',     fields: {payload_len: 31, bit_rate: 12400, dst_addr: '192.168.3.1', direction: 'all', mean_talking_duration: 2, vaf: 50, apn: ''}},
        {type: 'flood',    name: 'Flood',          msg: 'flood',   fields: {payload_len: 1000, dst_addr: '192.168.3.1', direction: 'dl', apn: ''}},
        {type: 'http',     name: 'HTTP transfert', msg: 'http',    fields: {url: 'http://192.168.3.1:8080/data?size=10000', max_delay: 1, max_cnx: 1000, apn: ''}},
        {type: 'ethernet', name: 'Ethernet',       msg: 'cbr',     fields: {payload_len: 1000, bit_rate: 1000000, dst_addr: '00:00:00:00:00:00', direction: 'dl', apn: 'ethernet'}},
        {type: 'app',      name: 'Application',    msg: 'ext_app', fields: {prog: 'ext_app.sh', args: "iperf -c 192.168.2.1 -i 1 -d -t $d", tag: 'iperf', apn: ''}},
        //{type: 'register', name: 'Registration', msg: 'register', fields: {}, noIp: true},
    ],

    getIpDefinition: function (type) {
        for (var i = 0; i < this.ipDefinitionList.length; i++) {
            var def = this.ipDefinitionList[i];
            if (type === def.type)
                return def;
        }
        return null;
    },

    // Random generation
    'random': {
        'gen': function gen(value, variability) {
            if (!variability) return value; // 0, null, undefined...
            return Math.random() * variability * 2 + value - variability;
        },

        'genInt': function (value, variability) {
            return this.gen(value, variability) >> 0;
        },

        'genIntRange': function (min, max) {
            return (Math.random() * (max - min) + min) >> 0;
        },

        'genTime': function (value, variability) {
            return Math.round(this.gen(value, variability) * 1000) / 1000;
        },

        'genByte': function (value, variability) {
            return Math.round(this.gen(value, variability) / 4) * 4;
        },

        /*'timeVar': function (value, variation) {
            if (!variation)
                return value;
            return this.genTime(value - variation, value + variation);
        },*/

        'position': function position(distance, variability) {
            var d = this.gen(distance, variability);
            var a = Math.random() * 2 * Math.PI;
            return [Math.floor(d * Math.cos(a)), Math.floor(d * Math.sin(a))];
        },

        'string': function genString(count, base) {
            var str = "";
            for (var i = 0; i < count; i++) {
                str += (Math.floor(Math.random() * base)).toString(base);
            }
            return str;
        },
    },

    setIPOnce: function (ue, sim) {
        this.setIP(ue, sim, [0, Number.POSITIVE_INFINITY]);
    },

    setIPAuto: function (ue, sim) {
        for (var time = 0; time < Number.POSITIVE_INFINITY; time = range[1]) {
            var range = this._getOnRange(ue, time);
            if (!range) break; // No more range

            this.setIP(ue, sim, range);
        }
    },

    genStringValidator: function (string, pattern, size) {

        var m = string.match(this.genStringRegExp);
        if (m) {
            // Replacement will generate at least one character
            string = string.replace(this.genStringRegExp, '0');

            if (size && string.length > size) return false;

        } else {
            if (size && string.length !== size) return false;
        }

        return !!string.match(pattern);
    },

    genStringRegExp: /\$({([^}]+)})?/,

    genStringUpdate: function(string, size, value, base) {

        var m = string.match(this.genStringRegExp);
        if (m) {
            var pattern = m[0];
            value >>= 0;

            // ${f(i)}
            if (m[2]) {
                try {
                    value = Math.abs(Function('"use strict"; return ' + m[2].replace(/i/g, value) + ';')() >> 0);
                    if (isNaN(value))
                        value = 0;
                } catch (e) {
                    value = 0;
                }
            }

            var len = size - string.length + pattern.length;
            value = value.toString(base);
            while (value.length < len) value = '0' + value;
            string = string.replace(pattern, value);
        }
        while (string.length < size) string = '0' + string;
        return string;
    },

    genString: function(string, size, value, base) {
        return this.genStringUpdate(string, size, value, base).substr(0, size);
    },

    genStringExec: function (string, vars) {

        for (;;) {
            var m = string.match(/\$([\w\d]+)\b/);
            if (!m)
                break;

            var value = vars[m[1]];
            if (value === undefined)
                return null;

            string = string.replace(m[0], value);
        }

        for (;;) {
            var m = string.match(/\${([^}]+)}/);
            if (!m)
                break;

            var exp = m[1];
            for (var v in vars)
                exp = exp.replace(new RegExp("\\b" + v + "\\b", "g"), vars[v]);

            try {
                value = Function('"use strict"; return ' + exp + ';')() - 0;
                if (isNaN(value))
                    return null;

            } catch (e) {
                return null;
            }
            string = string.replace(m[0], value);
        }
        return string;
    },

    _setIPMsg: function(msg, cfg) {

        var msg_type = this.getIpDefinition(cfg.type).msg;

        switch (cfg.direction) {
        case 'all':
            var msg1 = lteLogs.clone(msg);
            msg.message = msg_type + '_send';
            msg1.message = msg_type + '_recv';
            return [msg1, msg];

        case 'dl':
            msg.message = msg_type + '_recv';
            break;

        case 'ul':
            msg.message = msg_type + '_send';
            break;

        default:
            msg.message = msg_type;
            break;
        }

        return [msg];
    },

    setIP: function (ue, sim, range) {

        var random = lteSim.random;
        var rangeSize  = range[1] - range[0];
        var rangeStart = range[0];
        var rangeEnd   = range[1];

        this.info("Range:", rangeStart, rangeEnd);

        var apnConnected = {}; // Avoid multiple pdn_connect on same apn

        // Create final script
        sim.scripts.forEach((function (cfg) {

            if (Math.random() > cfg.probability) return;

            // Mandatory part
            var start_time = random.genTime(rangeStart + cfg.start_delay, cfg.start_delay_var);
            var end_time   = random.genTime(start_time + cfg.duration, cfg.duration_var);

            var msg = {
                ue_id:        ue.ue_id,
                start_time:    start_time,
                end_time:    end_time,
            };
            var script = {
                type:        cfg.type,
                time:        start_time,
                duration:    end_time - start_time,
                ip:          !cfg.noIp,
            };

            this.info(ue.imsi, "Add script", start_time.toFixed(3), end_time.toFixed(3));
            if (end_time > rangeEnd) {
                this.warn(ue.imsi, "Script too long for power on period:", end_time, rangeEnd);
                script.overflow = true;
            }

            // Specific part
            switch (cfg.type) {
            case 'udp':
                if (ue.tun_setup_script) return;
                msg.dst_addr                = cfg.dst_addr;
                msg.payload_len                = random.genByte(cfg.payload_len, cfg.payload_len_var);
                msg.bit_rate                = random.genInt(cfg.bit_rate, cfg.bit_rate_var);
                msg.type = 'udp';
                break;
            case 'rtp':
                if (ue.tun_setup_script) return;
                msg.dst_addr                = cfg.dst_addr;
                msg.payload_len                = random.genByte(cfg.payload_len, cfg.payload_len_var);
                msg.bit_rate                = random.genInt(cfg.bit_rate, cfg.bit_rate_var);
                msg.type = 'rtp';
                break;
            case 'voip':
                if (ue.tun_setup_script) return;
                msg.dst_addr                = cfg.dst_addr;
                msg.payload_len                = random.genByte(cfg.payload_len, cfg.payload_len_var);
                msg.bit_rate                = random.genInt(cfg.bit_rate, cfg.bit_rate_var);
                msg.vaf                        = random.gen(cfg.vaf, cfg.vaf_var);
                msg.mean_talking_duration    = random.gen(cfg.mean_talking_duration, cfg.mean_talking_duration_var);
                msg.type = 'voip';
                break;
            case "flood":
                if (ue.tun_setup_script) return;
                msg.dst_addr                = cfg.dst_addr;
                msg.payload_len                = random.genByte(cfg.payload_len, cfg.payload_len_var);
                break;
            case "ping":
                if (ue.tun_setup_script) return;
                msg.dst_addr                = cfg.dst_addr;
                msg.payload_len                = random.genByte(cfg.payload_len, cfg.payload_len_var);
                msg.delay                    = cfg.delay;
                msg.id                        = cfg.id || random.genIntRange(1, 65535);
                break;
            case "http":
                if (ue.tun_setup_script) return;
                msg.url                        = cfg.url;
                msg.max_delay                = cfg.max_delay;
                msg.max_cnx                    = cfg.max_cnx;
                break;
            case 'app':
                if (!ue.tun_setup_script) return;
                msg.prog                    = cfg.prog;
                msg.delay                    = cfg.delay;
                msg.tag                        = cfg.tag;
                msg.args                    = [this.genStringExec(cfg.args, {d: cfg.duration, i: ue.ue_id})];
                break;
            case 'ethernet':
                if (ue.tun_setup_script) return;
                msg.dst_addr                = cfg.dst_addr;
                msg.payload_len             = random.genByte(cfg.payload_len, cfg.payload_len_var);
                msg.bit_rate                = random.genInt(cfg.bit_rate, cfg.bit_rate_var);
                msg.type = 'ethernet';
                break;

            case 'register':
                var msg1 = lteLogs.clone(msg);
                msg1.start_time = msg.end_time;
                msg.message = 'register';
                msg1.message = 'deregister';
                delete msg.end_time;
                delete msg1.end_time;
                script.msg = [msg, msg1];
                break;

            default:
                break;
            }
            if (!script.msg)
                script.msg = this._setIPMsg(msg, cfg);
            script.name = cfg.name || this.getIpDefinition(cfg.type).name;
            script.category = 'UE #' + ue.ue_id;
            ue.scripts.push(script);

            // PDN
            var apn = cfg.apn;
            if (apn) {
                if (!apnConnected[apn]) {
                    for (var i = 0; i < sim.pdn.length; i++) {
                        var pdn = sim.pdn[i];
                        if (pdn.name === apn && pdn.connect === 'demand') {
                            script.msg.unshift(this._getPDNConnectMsg(pdn, ue.ue_id, start_time));
                            break;
                        }
                    }
                    apnConnected[apn] = true;
                }
            }

        }).bind(this));
    },

    _getPDNConnectMsg: function (pdn, ue_id, time) {
        return {
            message: 'pdn_connect',
            ue_id: ue_id,
            apn: pdn.name,
            pdn_type: pdn.type,
            start_time: time
        };
    },

    adjustTime: function(t) {
        return Math.round(t * 1000) / 1000;
    },

    _getOnRange: function _getOnRange(ue, time) {

        for (var i = 0; i < ue.scripts.length; i++) {
            var script = ue.scripts[i];
            if (script.type !== 'power') continue;

            if (time < script.time || (time >= script.time && time < script.time + script.duration))
                return [script.time, script.time + script.duration];
        }
        return null;
    },

    // On/off
    setOnOff: function (ueList, sim) {
        var cfg = sim.power;

        // Merge default properties
        cfg = lteLogs.merge(lteLogs.clone(cfg), {
            duration:    [20, 20],
            on_time:    [10, 10], // On between 10 and 15s
            off_time:    [5, 10],
            caps:        2,
            on_max:        10,
        });

        var ue_count    = ueList.length;
        var min_delay    = 1 / cfg.caps;
        var caps_var    = cfg.caps_var / cfg.caps / 2;

        // Each UE:
        var ue_state = ueList.map(function (ue, id) { return {
            on_time:    0,
            off_time:    Number.NEGATIVE_INFINITY,
            id:            id,
            events:        []
        };});

        // Add and remove
        var duration = lteSim.random.genTime(cfg.duration);
        this.info("Generate power script for " + duration + "s");
        for (time = 0; time < duration;) {

            // Get powered on UE
            var on_list = ue_state.filter(function (ue) { return time < ue.off_time; });

            var available_list = ue_state.filter(function (ue) { return time >= ue.on_time; });

            this.info("[" + time.toFixed(2) + "] Check, on = " + on_list.length + ", available = " + available_list.length);
            if (available_list.length > 0 && on_list.length < cfg.on_max) {
                // Select off UE
                var id = lteSim.random.genIntRange(0, available_list.length - 1);
                var ue = available_list[id];

                // Power on time
                var start = time;
                if (caps_var)
                    start += lteSim.random.genTime(0, caps_var);

                // Power off time
                var end = start + lteSim.random.genTime(cfg.on_time, cfg.on_time_var);
                if (caps_var)
                    end += lteSim.random.genTime(0, caps_var);

                // Add power on/off event
                if (end <= duration) {
                    if (start < 0) start = 0; // In case of caps_var

                    ue.events.push({
                        id:        id,
                        start:    lteSim.adjustTime(start),
                        end:    lteSim.adjustTime(end)
                    });
                    this.info("[" + time.toFixed(2) + "] Add " + ueList[id] + ", from " + start.toFixed(3) + " to " + end.toFixed(3));
                }

                // Next power off/on events
                ue.off_time = end + min_delay;
                ue.on_time  = end + lteSim.random.genTime(cfg.off_time, cfg.off_time_var);

                // Update
                time += min_delay;

            } else {
                this.info("[" + time.toFixed(2) + "] No space left");

                // No slot available, look for next time
                var next_time = Number.POSITIVE_INFINITY;
                ue_state.forEach(function (ue) {
                    if (ue.off_time > time)
                        next_time = Math.min(next_time, ue.off_time);
                    if (ue.on_time > time)
                        next_time = Math.min(next_time, ue.on_time);
                });
                time = next_time;
            }
        }

        // Add scripts
        ue_state.forEach((function (ue) {
            ue.events.forEach((function (event) {
                var ue_id = ueList[ue.id].ue_id;

                var msgList = [{
                    message:    'power_on',
                    ue_id:        ue_id,
                    start_time: event.start
                }, {
                    message:    'power_off',
                    ue_id:        ue_id,
                    start_time: event.end
                }];
                sim.pdn.forEach((function (pdn) {
                    if (pdn.connect === 'attach') {
                        msgList.push(this._getPDNConnectMsg(pdn, ue_id, event.start));
                    }
                }).bind(this));

                ueList[ue.id].scripts.push({
                    type:        'power',
                    name:        'Power on/off',
                    category:    'UE #' + ue_id,
                    time:        event.start,
                    duration:    event.end - event.start,
                    msg:        msgList,
                });
            }).bind(this));
        }).bind(this));
    },

    ue2db: function (def, chan, i, cfg) {

        var ue = {
            ue_id:      i,
            imsi:       lteSim.genString(def.imsi, 15, i),
            imeisv:     lteSim.genString(cfg.imeisv || "01234567$01", 16, i),
            sim_algo:   def.sim_algo,
            scripts:    [],
        };

        if (chan.type !== 'none') {
            var angle = Math.random();
            var dist = Math.random() * (chan.max_distance - chan.min_distance) + chan.min_distance;
            ue.max_distance = chan.max_distance;
            ue.min_distance = chan.min_distance;
            ue.noise_spd = chan.noise_spd;
            ue.position = [dist * Math.cos(angle), dist * Math.sin(angle)];
            ue.direction = Math.random() * 360;
            ue.speed = Math.max(0, this.random.gen(chan.speed, chan.speed_var));
            ue.channel = {type: chan.type};
            ue.channel_sim = true;
            if (chan.type !== 'awgn') {
                ue.channel.freq_doppler = chan.freq_doppler;
                if (chan.mimo_corr !== 'none')
                    ue.channel.mimo_correlation = chan.mimo_corr;
                ue.channel.A = chan.A;
                ue.channel.B = chan.B;
                switch (chan.type) {
                case 'tdla':
                case 'tdlb':
                case 'tdlc':
                case 'tdld':
                case 'tdle':
                    ue.channel.delay_spread = chan.delay_spread;
                    break;
                }
            }
        } else {
            ue.channel_sim = false;
        }

        switch (def.sim_algo) {
        case 'milenage':
            if (def.opc !== '') {
                ue.opc = lteSim.genString(def.opc, 32, i, 16);
            } else {
                ue.op = lteSim.genString(def.op, 32, i, 16);
            }
            ue.K = lteSim.genString(def.K, 32, i, 16);
            break;
        case 'tuak':
            ue.top = lteSim.genString(def.top, 64, i, 16);

            ue.K = lteSim.genStringUpdate(def.K, 32, i, 16);
            if (ue.K.length > 32)
                ue.K = lteSim.genString(def.K, 64, i, 16);
            break;
        case 'external':
            ue.external_sim = true;
            delete ue.imsi;
            delete ue.sim_algo;
            break;
        default:
            ue.K = lteSim.genString(def.K, 32, i, 16);
            break;
        }
        if (def.res_len)
            ue.res_len = def.res_len;

        if (def.apn)
            ue.apn = def.apn;

        switch (def.type) {
        case 'sim':
            break;
        case 'tun':
            ue.tun_setup_script = def.tun_setup_script;
            break;
        case 'rue':
            ue.tun_setup_script = def.tun_setup_script;
            ue.rue_addr = def.remote_addr;
            break;
        }
        // NEWPARAM: set json
        if (def.forced_cqi >= 0)
            ue.forced_cqi = def.forced_cqi;
        if (def.forced_ri > 0)
            ue.forced_ri = def.forced_ri;
        ue.spec_tolerance = def.spec_tolerance;
        ue.as_release = def.as_release;

        // UE rat
        var ratInfo = this.getRatInfo(def.rat);
        if (ratInfo.eutra) {
            switch (def.category) {
            case 'custom':
                ue.dl_category = def.dl_category;
                ue.ul_category = def.ul_category;
                break;
            case -1:
                ue.ue_category = 'm1';
                break;
            case -2:
                ue.ue_category = 'nb1';
                break;
            case -3:
                ue.ue_category = 'nb2';
                break;
            default:
                ue.ue_category = def.category;
                break;
            }
            if (ratInfo.eutra === 'endc') ue.en_dc_support = true;
            ue.pdsch_max_its = def.pdsch_max_its;
        }
        if (ratInfo.nr) {
            ue.ldpc_max_its = def.ldpc_max_its;
            if (ratInfo.rats[0] === 'nr') {
                if (ratInfo.eutra) {
                    if (!ue.dl_category) ue.dl_category = ue.ue_category;
                    if (!ue.ul_category) ue.ul_category = ue.ue_category;
                    ue.s1_support = true;
                }
                ue.ue_category = 'nr';
            } else {
                ue.n1_support = true;
            }
        }

        var cells = this.getCellIndexes(def.cell_index);
        if (cells) {
            var total = cells.reduce(function (w, cell) { return w + cell.weight; }, 0);

            var weight = Math.random() * total;
            for (var i = 0; i < cells.length; i++) {
                weight -= cells[i].weight;
                if (weight <= 0) {
                    ue.cell_index = cells[i].index;
                    break;
                }
            }
        }
        if (def.preferred_plmn_list)
            ue.preferred_plmn_list = def.preferred_plmn_list.split(/,/);

        if (def.mnc_3digits)
            ue.mnc_nb_digits = 3;

        return ue;
    },

    /*
     * sim: config generated by lte.sim.window
     * ue_ids: in cas of !sim.ue.enabled, apply scripts to this list of UEs
     */
    generateScripts: function (sim, ue_ids, cfg) {

        // Create UE ?
        if (sim.ue.count > 0) {
            var ueList = [];
            for (var i = 0; i < sim.ue.count; i++) {
                ueList.push(this.ue2db(sim.ue, sim.chan, i + 1, cfg));
            }

        // Use UE
        } else {
            var ueList = ue_ids.map((function (ue_id) {
                return {
                    "ue_id": ue_id,
                    "scripts":    [],
                };
            }).bind(this));
        }

        // Power on/off
        if (sim.power.enabled) {
            this.setOnOff(ueList, sim);
            var ipFunc = "setIPAuto";
        } else {
            var ipFunc = "setIPOnce";
        }

        // IP
        ueList.forEach((function (ue) {
            this[ipFunc](ue, sim);
        }).bind(this));

        // Update ue_id and create full script list
        var scriptList = [];
        var duration = 0;
        ueList.forEach((function (ue) {
            ue.scripts.forEach(function (script) {
                scriptList.push(script);
                duration = Math.max(duration, script.time + script.duration);
            });
        }).bind(this));

        // Sort scripts
        scriptList.sort(function (a, b) { return a.time - b.time; });

        return {
            list:        ueList,
            scripts:    scriptList,
            duration:    duration
        };
    },

    getRatInfo: function (rat) {
        var rats = (rat || '').split('|');
        var ratInfo = {
            eutra: false,
            endc: false,
            nr: false,
            multi: rats.length > 1,
            rat: rat,
            rats: rats,
        };
        rats.forEach( (r) => {
            switch (r) {
            case 'nbiot':
            case 'lte':
                ratInfo.eutra = r;
                break;
            case 'nsa':
                ratInfo.eutra = 'endc';
                ratInfo.multi = true;
                break;
            case 'nr':
                ratInfo.nr = true;
                break;
            }
        });
        return ratInfo;
    },

    updateSimConfig: function (sim) {

        for (var id in this.sections) {
            if (!sim.hasOwnProperty(id))
                sim[id] = lteLogs.clone(this.sections[id]);
        }

        // NEWPARAM: place default legacy value here
        lteLogs.merge(sim.ue, {
            type: 'sim',
            count: 0,
            category: 4,
            forced_ri: 0,
            forced_cqi: -1,
            as_release: 8,
            dl_category: 10,
            ul_category: 10,
            pdsch_max_its: sim.ue.category > 1 ? 1 : 6,
            ldpc_max_its: 6,
            spec_tolerance: false,
            res_len: 0,
            imsi: "001010123456789",
            sim_algo: 'xor',
            K: "00112233445566778899aabbccddeeff",
            op: '',
            opc: '',
            top: '',
            tun_setup_script: "ue-ifup",
            rue_addr: "127.1.0.0",
            enabled: false,
            cell_index: '',
            preferred_plmn_list: '',
        });

        if (sim.chan.max_speed) {
            sim.chan.speed = sim.chan.speed_var = sim.chan.max_speed >> 1;
            delete sim.chan.max_speed;
        }

        lteLogs.merge(sim.chan, {
            max_distance:     500,
            min_distance:     0,
            speed:            50,
            speed_var:        10,
            noise_spd:        -174,
            type:             'none',
            mimo_corr:        'none',
            delay_spread:     0,
            freq_doppler:     0,
            A:                15.3,
            B:                37.6,
        });
        lteLogs.merge(sim.power, {
            caps:            10,
            caps_var:        0,
            on_max:            10,
            on_time:        10,
            on_time_var:    0,
            off_time:        10,
            off_time_var:    0,
            duration:        30,
            enabled:    false
        });

        if (sim.loop === undefined) sim.loop = 0;

        var ue = sim.ue;
        switch (ue.rat) {
        case undefined:
            if (ue.category >= -1) {
                ue.rat = 'lte';
            } else {
                ue.rat = 'nbiot';
            }
            break;
        case 'lte-endc':
            ue.rat = 'nsa';
            break;
        }

        for (var i in sim.scripts) {
            var script = sim.scripts[i];

            var def = this.getIpDefinition(script.type);
            if (def) {
                lteLogs.merge(script, def.fields);
                lteLogs.merge(script, {
                    duration: 5,
                    duration_var: 0,
                    start_delay: 0,
                    start_delay_var: 0,
                    probability: 1,
                    apn: '',
                });
            }

            switch (script.type) {
            case 'cbr_send':
                script.type = 'udp';
                script.direction = 'ul';
                break;
            case 'cbr_recv':
                script.type = 'udp';
                script.direction = 'dl';
                break;
            case 'flood_send':
                script.type = 'flood';
                script.direction = 'ul';
                break;
            case 'flood_recv':
                script.type = 'flood';
                script.direction = 'dl';
                break;
            }
        }
        return sim;
    },

    getCellIndexes: function (val) {
        if (!val)
            return null;

        var indexes = val.split(',');
        for (var i = 0; i < indexes.length; i++) {
            var m = indexes[i].replace(/\s/g, '').match(/^([\d]+)(\/([\d\.]+))?$/);
            if (!m)
                return false;
            indexes[i] = {
                index: m[1] - 0,
                weight: parseFloat(m[3]) || 1
            };
        }
        return indexes;
    },

    init: function () {
        if (localStorage.simLists !== undefined)
            this._enableTab();
    },

    _enableTab: function () {
        if (!this._simTab) {
            this._simTab = Ext.create('lte.sim.tab', {});
            lteLogs.addTab(this._simTab);
        }
    },

    _tabs: [],

    hasTabs: function () {
        return this._tabs.length > 0;
    },

    runOnAllTabs: function (sim) {
        this._tabs.forEach(function (tab) {
            tab.createUESimTab(sim);
        });
    },

    registerTab: function (tab) {
        this._enableTab();
        this._tabs.push(tab);
        this._simTab.updateButtons();
    },

    unregisterTab: function (tab) {
        var i = this._tabs.indexOf(tab);
        if (i >= 0) {
            this._tabs.splice(i, 1);
            this._simTab.updateButtons();
        }
    },

    get: function () {
        if (!this._simTab)
            return [];

        var list = [];
        var store = this._simTab._simStore;
        for (var i = 0, length = store.getCount(); i < length; i++) {
            list.push(store.getAt(i));
        }
        return list;
    },
};

lteLogs.setLogger("SIM", lteSim);



Ext.define("lte.sim.tab", {

    extend: 'Ext.panel.Panel',
    layout: 'border',

    title: 'UE Scenario',

    tbar: {},

    constructor: function (config) {
        this.callParent(arguments);
    },

    initComponent: function () {

        var newSimButton = Ext.create('Ext.Button', {
            text: 'Add',
            iconCls: 'icon-plus',
            scope: this,
            handler: function () {
                var cfg = lteSim.updateSimConfig({});
                simStore.add(cfg);
                simStore.sync();
            }
        });
        this._delSimButton = Ext.create('Ext.Button', {
            text: 'Remove',
            iconCls: 'icon-moins',
            scope: this,
            disabled: true,
            handler: function () {
                var record = simGrid.getSelection();
                simStore.remove(record[0]);
                simStore.sync();
            }
        });
        this._copySimButton = Ext.create('Ext.Button', {
            text: 'Copy',
            iconCls: 'icon-copy',
            scope: this,
            disabled: true,
            handler: function () {
                var sim = simGrid.getSelection()[0];
                var copy = lteLogs.clone(sim.getData());
                delete copy.id;
                copy.name = copy.name + " (copy)";
                simStore.add(copy);
            }
        });
        this._exportUESimButton = Ext.create('Ext.Button', {
            text: 'UE export',
            iconCls: 'icon-file',
            scope: this,
            tooltip: lteLogs.tooltip("Export scenario for UE configuration"),
            disabled: true,
            handler: function () {
                this._exportUESim(simGrid.getSelection()[0].getData());
            }
        });
        this._exportSimButton = Ext.create('Ext.Button', {
            text: 'Export',
            iconCls: 'icon-download',
            scope: this,
            disabled: true,
            tooltip: lteLogs.tooltip("Export scenario"),
            handler: function () {
                this._exportSim(simGrid.getSelection());
            }
        });
        this._importSimButton = Ext.create('Ext.Button', {
            text: 'Import',
            iconCls: 'icon-save',
            scope: this,
            tooltip: lteLogs.tooltip("Import scenario"),
            handler: function () {
                this._importSim();
            }
        });
        this._runSimButton = Ext.create('Ext.Button', {
            text: 'Run',
            iconCls: 'icon-play',
            tooltip: 'Run on all clients',
            disabled: true,
            scope: this,
            handler: function () {
                lteSim.runOnAllTabs(simGrid.getSelection()[0].getData());
            }
        });

        this.tbar = Ext.create('Ext.toolbar.Toolbar', {
            items: [
                newSimButton,
                this._delSimButton,
                this._copySimButton,
                this._exportSimButton,
                this._importSimButton,
                '|',
                this._exportUESimButton,
                this._runSimButton,
            ]
        });

        this.callParent(arguments);

        // Store: from local data
        var simStore = this._simStore = Ext.create('Ext.data.Store', {
            fields: ['name', 'scripts'].concat(Object.keys(lteSim.sections)),
            proxy: {
                type: 'localstorage',
                id  : 'simLists'
            },
            listeners: {
                scope: this,
                load: function (s, records, success, eOpts) {
                    if (success) {
                        for (var i in records) {
                            var rec = records[i];
                            var data = rec.getData();
                            lteSim.updateSimConfig(data);
                            for (var id in lteSim.sections)
                                rec.set(id, data[id]);
                        }
                        simStore.sync();
                    }
                }
            }
        });

        var simGrid = this._simGrid = Ext.create('Ext.grid.Panel', {
            store: simStore,
            allowDeselect: true,
            multiSelect: false,
            columns: [{
                text: "Name",
                dataIndex: "name",
                flex: 1
            }, {
                text: "Dur.",
                dataIndex: "power",
                align: 'right',
                width: 60,
                renderer: function(power, metaData, record, rowIndex, colIndex, store, view) {
                    if (power.enabled)
                        return power.duration;
                    var scripts = record.get("scripts");
                    return scripts.reduce(function (d, s) { return Math.max(d, s.start_delay + s.duration); }, 0) || "&nbsp;";
                }
            }, {
                text: "UE",
                dataIndex: "ue",
                align: 'right',
                renderer: function(ue, metaData, record, rowIndex, colIndex, store, view) {
                    return ue.count > 0 ? ue.count : "&nbsp;";
                },
                width: 50
            }, {
                text: "IP",
                dataIndex: "scripts",
                align: 'right',
                renderer: function(scritps, metaData, record, rowIndex, colIndex, store, view) {
                    return scritps.length;
                },
                width: 50
            }, {
                text: "Power",
                dataIndex: "power",
                renderer: function(power, metaData, record, rowIndex, colIndex, store, view) {
                    if (power.enabled)
                        return power.caps + " caps, " + power.on_time + "/" + power.off_time + " on/off";
                    return "&nbsp;";
                },
                flex: 1,
            }],
            listeners: {
                scope: this,
                selectionchange: function(view, selected, eOpts) {

                    simPanel.removeAll();
                    var script = selected.pop();
                    setTimeout((function () {
                        if (script) {
                            simPanel.add(Ext.create('lte.sim.panel', {
                                simRef: script,
                                simStore: simStore,
                                updateParent: (function () { this.updateButtons(); }).bind(this)
                            }));
                        }
                        this.updateButtons();
                    }).bind(this), 0);
                },
            }
        });

        // Load
        Ext.Function.defer(function () { simStore.load();}, 100);

        this.add({
            region: 'center',
            layout: 'fit',
            items: [simGrid],
        });
        
        var simPanel = this.add({
            region: 'east',
            layout: 'fit',
            width: 600,
            items: [],
            split: true,
        });
    },

    updateButtons: function () {

        var script = this._simGrid.getSelection();
        if (script && script.length) {
            var data = script[0].getData();
            this._delSimButton.setDisabled(false);
            this._copySimButton.setDisabled(false);
            this._exportSimButton.setDisabled(false);
            this._exportUESimButton.setDisabled(data.ue.count <= 0);
            this._runSimButton.setDisabled(!lteSim.hasTabs());
        } else {
            this._delSimButton.setDisabled(true);
            this._copySimButton.setDisabled(true);
            this._exportSimButton.setDisabled(true);
            this._exportUESimButton.setDisabled(true);
            this._runSimButton.setDisabled(true);
        }
    },

    _exportSim: function (selection) {

        Ext.Msg.prompt('Export scenario', 'Enter export name:', function (btn, name) {

            if (btn !== 'ok')
                return;

            var exp = {
                version: UE_SCENARIO_VERSION,
                date: new Date() * 1,
                scenario: [],
                name: name,
            };

            var count = selection.length;
            for (var i = 0; i < count; i++) {
                var sim = selection[i].getData();
                sim = lteLogs.clone(sim);
                delete sim.id;
                exp.scenario.push(sim);
            }

            var id = name.replace(/[^\w]/g, '');
            lteLogs.exportFile(JSON.stringify(exp), 'ue-scenario-' + id + '.cfg', 'application/json;charset=utf-8;');
        });
    },

    _importSim: function () {
        lteLogs.loadFile({
            cb: function (files) {
                if (!files)
                    return;

                try {
                    var exp = JSON.parse(new TextDecoder().decode(files[0].data));
                    if (!(exp.scenario instanceof Array) ||
                        typeof exp.version !== 'number' ||
                        typeof exp.date !== 'number' ||
                        typeof exp.name !== 'string' ||
                        !exp.version ||
                        !exp.date ||
                        !exp.name)
                        throw('Bad file format');

                    exp.scenario.forEach((function (sim) {
                        sim.name = '[' + exp.name + '] ' + sim.name;
                        this._simStore.add(lteSim.updateSimConfig(sim))
                    }).bind(this));

                } catch (e) {
                    lteLogs.warnBox('Can\'t load file', 'Bad file format');
                    return;
                }
            },
            scope: this
        });
    },

    _exportUESim: function (sim, cfg) {
        var gen = lteSim.generateScripts(sim, cfg, {imeisv: ((Math.random() * 1000000) >>> 0) + '$01'});

        // UE config
        gen.list.forEach(function (ue) {
            // Generate events from message
            var events = [];
            for (var i = 0; i < ue.scripts.length; i++) {
                var script = ue.scripts[i];
                for (var j = 0; j < script.msg.length; j++) {
                    var msg = script.msg[j];
                    msg.event = msg.message;
                    delete msg.message;
                    delete msg.ue_id;
                    events.push(msg);
                }
            }
            events.sort(function (a, b) { return a.start_time - b.start_time; });
            ue.sim_events = events;
            delete ue.scripts;
        });
        var mme_db = [];
        gen.list.forEach(function (ue) {
            if (ue.external_sim) return;

            var mme = {
                imsi: ue.imsi,
                K: ue.K,
                amf: 0x9001, // XXX
                sqn: "000000000000", // XXX
                sim_algo: ue.sim_algo,
            };
            (['opc', 'op', 'top', 'res_len']).forEach(function (id) {
                if (ue[id]) mme[id] = ue[id];
            });
            mme_db.push(mme);
        });

        gen.list.sort(function (a, b) {
            if (!a.sim_events.length)
                return 1;
            if (!b.sim_events.length)
                return -1;
            return a.sim_events[0].start_time - b.sim_events[0].start_time;
        });

        // Export
        var file = sim.name.replace(/[ \/]/g, '-');
        lteLogs.exportFile('ue_list: ' + JSON.stringify(gen.list, null, 2), file + '.ue.cfg', 'text/json;charset=utf-8;');
        lteLogs.exportFile('ue_db: ' + JSON.stringify(mme_db, null, 2), file + '.mme.cfg', 'text/json;charset=utf-8;');

    },

});


