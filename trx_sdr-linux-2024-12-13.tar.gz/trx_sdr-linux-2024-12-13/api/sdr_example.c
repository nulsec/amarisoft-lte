/*
 * SDR example version ##VERSION##
 *
 * Copyright (C) 2020-2024 Amarisoft
 */

#define _GNU_SOURCE

#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <stddef.h>
#include <inttypes.h>
#include <unistd.h>
#include <time.h>
#include <sys/types.h>
#include <signal.h>
#include <getopt.h>
#include <string.h>
#include <pthread.h>
#include <errno.h>

#include "libsdr.h"

typedef struct Complex {
    float re, im;
} Complex;


#define DEFAULT_ARGS "dev0=/dev/sdr0"
#define DEFAULT_TX_FREQ ((int64_t)2400000000)
#define DEFAULT_SAMPLE_RATE 23040000
#define DEFAULT_TX_GAIN 70


static const char *sync_source_str[] = { "none", "internal", "gps", "external" };
static const char *clock_source_str[] = { "internal", "external" };

/* IQ buffers needs to be aligned */
static inline void *vec_malloc(int size)
{
    void *ptr;
    if (posix_memalign(&ptr, 32, size))
        return NULL;
    return ptr;
}



void msdr_tx_gain_adjust(MultiSDRState *s, float *tx_gain)
{
    double min_txgain, max_txgain;
    
    msdr_get_tx_gain_min_max(s, 0, &min_txgain, &max_txgain);

    if (*tx_gain < min_txgain)
        *tx_gain = min_txgain;
    if (*tx_gain > max_txgain)
        *tx_gain = max_txgain;

    msdr_set_tx_gain(s, 0, *tx_gain);
    msdr_set_tx_gain(s, 1, *tx_gain);
}

sig_atomic_t keep_running;
void intHandler(int dummy) {
    keep_running = 0;
}

#define SDR_MAX_CHANNELS  16

typedef struct {
    MultiSDRState   *sdr_state;
    pthread_t        tx_thread_id;
    pthread_t        rx_thread_id;
    int              port_index;
    int              first_timestamp;

    pthread_mutex_t  mutex;
    pthread_cond_t   cond;
    int              sample_count;
    Complex         *rx_buf[SDR_MAX_CHANNELS];
    Complex         *tx_buf[SDR_MAX_CHANNELS];
    int              buf_len;

    int              disc;
    int64_t          tx_timestamp;

} RFPort;

static void thread_configure(const char *fmt, ... )
{
    va_list ap;
    char name[64];
    struct sched_param sp;
    int policy;

    policy = SCHED_RR;
    sp.sched_priority = 50;
    if (pthread_setschedparam(pthread_self(), policy, &sp))
        fprintf(stderr, "Warning, can't set real time scheduling: %s.\n"
                        "Please check process privileges.\n",
                        strerror(errno));

    va_start(ap, fmt);
    vsnprintf(name, sizeof(name), fmt, ap);
    va_end(ap);

    pthread_setname_np(pthread_self(), name);
}


static void* rx_thread_func(void *opaque)
{
    RFPort *rfp = opaque;
    int64_t timestamp, rx_timestamp = 0;
    int ret;
    MultiSDRReadMetadata mdr;

    thread_configure("RX%d", rfp->port_index);

    mdr.timeout_ms = 1000;
    while (keep_running) {
        ret = msdr_read(rfp->sdr_state, &timestamp,
                        (void**)rfp->rx_buf, rfp->buf_len,
                        rfp->port_index, &mdr);
        if (ret < 0) {
            fprintf(stderr, "mread_read: timeout\n");
            exit(1);
        }
        if (ret > 0) {
            pthread_mutex_lock(&rfp->mutex);
            if (rfp->first_timestamp) {
                /* On first received data, we position the TX timestampe 4ms in the future */
                rfp->first_timestamp = 0;
                //rfp->tx_timestamp = timestamp + rfp->buf_len * 60;
                rfp->tx_timestamp = timestamp + rfp->buf_len * 15;

            } else if (rx_timestamp != timestamp) {
                /* If any discontinuity on RX side, we also propagate it on TX */
                fprintf(stderr, "Discontinuity\n");
                rfp->disc += rx_timestamp - timestamp;
            }
            rx_timestamp = timestamp + ret;

            rfp->sample_count += ret;

            /* Wake up TX thread as new data are available */
            pthread_cond_signal(&rfp->cond);
            pthread_mutex_unlock(&rfp->mutex);
        }
    }
    return NULL;
}

static void* tx_thread_func(void *opaque)
{
    RFPort *rfp = opaque;
    int ret;
    MultiSDRWriteMetadata mdw;

    memset(&mdw, 0, sizeof(mdw));
           
    thread_configure("TX%d", rfp->port_index);

    while (keep_running) {
        pthread_mutex_lock(&rfp->mutex);
        while (rfp->sample_count < rfp->buf_len && keep_running) {
            pthread_cond_wait(&rfp->cond, &rfp->mutex);
        }        
        rfp->sample_count -= rfp->buf_len;
        rfp->tx_timestamp += rfp->disc;
        rfp->disc = 0;
        pthread_mutex_unlock(&rfp->mutex);
        
        if (!keep_running)
            break;

        ret = msdr_write(rfp->sdr_state, rfp->tx_timestamp,
                         (const void**)rfp->tx_buf, rfp->buf_len, rfp->port_index, &mdw);
        if (ret > 0) {
            rfp->tx_timestamp += ret;
        }
    }
    return NULL;
}

void help(void)
{
    printf("SDR sample playback utility version ##VERSION##\n"
           "usage: sdr_example [options] [files]\n"
           "\n"
           "Options:\n"
           "-h                     help\n"
           "-args str              set the device arguments (default=\"%s\")\n"
           "-tx_freq freq          set the TX frequency in Hz (default=%" PRId64 ")\n"
           "-rate rate             set the sample rate to 'rate' Hz (default=%d)\n"
           "-tx_gain gain          set the TX gain in dB (default=%d)\n"
           "-channels c            set the number of channels to 'c' (default=%d)\n"
           "-tx_bw bw              set the analog transmit bandwidth in Hz (default=same as sample rate)\n"
           "-sync source           set the sync source to 'source' (none, internal, gps, external) (default=none)\n"
           "-clock source          set the clock source to 'source' (internal, external) (default=internal)\n"
           "\n"
           ,
           DEFAULT_ARGS,
           DEFAULT_TX_FREQ,
           DEFAULT_SAMPLE_RATE,
           DEFAULT_TX_GAIN,
           1);
    exit(1);
}

static struct option options[] = {
    { "help", no_argument, NULL, 'h' },
    { "args", required_argument },
    { "tx_freq", required_argument },
    { "tx_gain", required_argument },
    { "channels", required_argument },
    { "rate", required_argument },
    { "tx_bw", required_argument },
    { "sync", required_argument },
    { "clock", required_argument },
    { "port", required_argument },
    { NULL },
};


int main(int argc, char **argv)
{
    int64_t tx_freq;
    MultiSDRState *s;
    const char *args;
    int option_index, c, tx_channel_count, rx_channel_count, sample_rate, rf_port_count;
    int i, p, idx, tx_bw;
    float tx_gain;
    SDRStartParams params_s, *params = &params_s;
    SDRSyncSourceEnum sync_source;
    SDRClockSourceEnum clock_source;
    RFPort *rf_ports;
    int ret;

    args = DEFAULT_ARGS;
    tx_freq = DEFAULT_TX_FREQ;
    sample_rate = DEFAULT_SAMPLE_RATE;
    tx_gain = DEFAULT_TX_GAIN;
    tx_channel_count = 1;
    rx_channel_count = 1;
    rf_port_count = 1;
    tx_bw = 0;
    sync_source = SDR_SYNC_NONE;
    clock_source = SDR_CLOCK_INTERNAL;

    for(;;) {
        c = getopt_long_only(argc, argv, "h", options, &option_index);
        if (c == -1)
            break;
        switch(c) {
        case 0:
            switch(option_index) {
            case 1: /* args */
                args = optarg;
                break;
            case 2: /* tx_freq */
                tx_freq = (int64_t)strtod(optarg, NULL);
                break;
            case 3: /* tx_gain */
                tx_gain = strtod(optarg, NULL);
                break;
            case 4: /* channels */
                tx_channel_count = rx_channel_count = strtol(optarg, NULL, 0);
                if (tx_channel_count < 1 ||
                    tx_channel_count > SDR_MAX_CHANNELS) {
                    fprintf(stderr, "Invalid number of channels\n");
                    exit(1);
                }
                break;
            case 5: /* rate */
                sample_rate = (int)strtod(optarg, NULL);
                break;
            case 6: /* tx_bw */
                tx_bw = (int)strtod(optarg, NULL);
                break;
            case 7: /* sync */
                if (!strcmp(optarg, "none"))
                    sync_source = SDR_SYNC_NONE;
                else if (!strcmp(optarg, "internal"))
                    sync_source = SDR_SYNC_INTERNAL;
                else if (!strcmp(optarg, "gps"))
                    sync_source = SDR_SYNC_GPS;
                else if (!strcmp(optarg, "external"))
                    sync_source = SDR_SYNC_EXTERNAL;
                else {
                    fprintf(stderr, "Allowed sync sources are: internal, gps, external\n");
                    exit(1);
                }
                break;
            case 8: /* clock */
                if (!strcmp(optarg, "internal"))
                    clock_source = SDR_CLOCK_INTERNAL;
                else if (!strcmp(optarg, "external"))
                    clock_source = SDR_CLOCK_EXTERNAL;
                else {
                    fprintf(stderr, "Allowed clock sources are: internal, external\n");
                    exit(1);
                }
                break;
            case 9:
                rf_port_count = (int)strtod(optarg, NULL);
                break;
            default:
                fprintf(stderr, "unknown option index: %d\n", option_index);
                exit(1);
            }
            break;
        case 'h':
            help();
            break;
        default:
            exit(1);
        }
    }

    if (tx_bw == 0)
        tx_bw = sample_rate;

    s = msdr_open(args);
    if (!s) {
        fprintf(stderr, "msdr_open: could not open SDR device\n");
        exit(1);
    }
    msdr_set_default_start_params(s, params, sizeof(*params), tx_channel_count,
                                  rx_channel_count, rf_port_count);

    /* Global parameters */
    params->clock_source = clock_source;
    params->sync_source = sync_source;
    params->rf_port_count = rf_port_count;

    /* Per rf port */
    rf_ports = malloc(params->rf_port_count * sizeof(*rf_ports));
    memset(rf_ports, 0, params->rf_port_count * sizeof(*rf_ports));

    for (p = 0; p < params->rf_port_count; p++) {
        RFPort *rfp = &rf_ports[p];

        rfp->port_index = p;
        rfp->sdr_state = s;

        params->sample_rate_num[p] = sample_rate;
        params->sample_rate_den[p] = 1;

        /* 1 hyper frame at a time */
        rfp->buf_len = sample_rate / 15000;
        if (rfp->buf_len < 100)
            rfp->buf_len = 100;
        rfp->first_timestamp = 1;

        params->rx_port_channel_count[p] = rx_channel_count;
        for(i = 0; i < rx_channel_count; i++) {
            idx = params->rx_channel_count++;

            params->rx_freq[idx] = tx_freq;
            params->rx_gain[idx] = 0;
            params->rx_bandwidth[idx] = tx_bw;
            params->rx_antenna[idx] = 1;

            rfp->rx_buf[i] = vec_malloc(rfp->buf_len * sizeof(Complex));
        }

        params->tx_port_channel_count[p] = tx_channel_count;
        for (i = 0; i < tx_channel_count; i++) {
            idx = params->tx_channel_count++;

            params->tx_freq[idx] = tx_freq;
            params->tx_gain[idx] = tx_gain;
            params->tx_bandwidth[idx] = tx_bw;

            rfp->tx_buf[i] = vec_malloc(rfp->buf_len * sizeof(Complex));
        }
    }

    /* Start */
    ret = msdr_set_start_params(s, params, sizeof(*params));
    if (ret < 0) {
        fprintf(stderr, "msdr_set_start_params: invalid SDR parameters\n");
        exit(1);
    }
    ret = msdr_start(s);
    msdr_release_start_params(params, sizeof(*params));
    /* Stop using params after this */
    if (ret < 0) {
        fprintf(stderr, "msdr_start: error\n");
        exit(1);
    }
    msdr_tx_gain_adjust(s, &tx_gain);

    printf("tx_freq=%0.3f MHz sample_rate=%0.3f MHz channels=%d\n"
           "tx_gain=%0.1f dB tx_bandwidth=%0.3f MHz\n"
           "sync_source=%s clock_source=%s\n",
           tx_freq / 1e6, sample_rate / 1e6, tx_channel_count,
           tx_gain, tx_bw / 1e6,
           sync_source_str[sync_source],
           clock_source_str[clock_source]);

    keep_running = 1;
    signal(SIGINT, intHandler);

    /* TX */
    for (p = 0; p < rf_port_count; p++) {
        RFPort *rfp = &rf_ports[p];

        pthread_mutex_init(&rfp->mutex, NULL);
        pthread_cond_init(&rfp->cond, NULL);
        pthread_create(&rfp->rx_thread_id, NULL, rx_thread_func, rfp);
        pthread_create(&rfp->tx_thread_id, NULL, tx_thread_func, rfp);
    }

    for (p = 0; p < rf_port_count; p++) {
        RFPort *rfp = &rf_ports[p];

        pthread_join(rfp->rx_thread_id, NULL);
        pthread_join(rfp->tx_thread_id, NULL);
    }

    msdr_close(s);
    return 0;
}
