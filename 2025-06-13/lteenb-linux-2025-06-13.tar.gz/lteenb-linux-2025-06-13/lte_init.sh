#!/bin/bash
# Copyright (C) 2021-2025 Amarisoft
# lte_init.sh.head system config version 2025-06-13

# Run once as root after the boot

# Check root access
if [ `id -u` != 0 ] ; then
    echo -e "\033[33mWarning, script must be run with root permissions\033[0m"
    exit 1
fi

function Log
{
    echo "$1: $2"
}

# Disable on demand service on Ubuntu
if [ -e "/etc/lsb-release" ] ; then
    grep -i Ubuntu /etc/lsb-release 1>/dev/null
    if [ "$?" = "0" ]; then
        service ondemand stop
    fi
fi

########################################################################
# set the "performance" governor for all CPUs to have the highest
# clock frequency
if [ -e "/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor" ] ; then
    CPUS0=$(ls /sys/devices/system/cpu/ | grep -oP "cpu\K\d+")
    CPUS1=""
    for cpu in $CPUS0 ; do
        if [ -e "/sys/devices/system/cpu/cpu${cpu}/online" ] ; then
            if [ "$(cat /sys/devices/system/cpu/cpu${cpu}/online)" = "0" ] ; then continue; fi
        fi
        CPUS1="$CPUS1 $cpu"
    done
    echo "Set performance scaling governor for cpus$CPUS1"
    for cpu in $CPUS1 ; do
        echo performance > /sys/devices/system/cpu/cpu${cpu}/cpufreq/scaling_governor
    done
fi

########################################################################
# With some video drivers (DRM KMS drivers), the cable polling blocks
# one CPU during a few tens of ms every few seconds. We disable it
# here.
if [ -f /sys/module/drm_kms_helper/parameters/poll ] ; then
  echo N > /sys/module/drm_kms_helper/parameters/poll
fi

########################################################################
# increase network buffers
sysctl -w net.core.rmem_max=50000000
sysctl -w net.core.wmem_max=5000000

########################################################################
# Product specific
function ParseProduct
{
    ResetProduct
    if [[ $1 =~ ([A-Z]+)-([0-9]{8})([0-9]{2}) ]] ; then
        PROD_MODEL="${BASH_REMATCH[1]}"
        PROD_DATE="${BASH_REMATCH[2]}"
        PROD_REV="${BASH_REMATCH[3]}"
    fi
}

function ResetProduct
{
    PROD_MODEL=""
    PROD_DATE=""
    PROD_REV=""
    PROD_NAME=""
}

function UpdateProduct
{
    if [ "$MOTHERBOARD" = "" ] ; then
        DMIDECODE=$(which dmidecode)
        if [ "$DMIDECODE" ] ; then
            MOTHERBOARD=$($DMIDECODE -t 2 2>/dev/null | grep -P "Manufacturer:|Product Name:" | cut -d ':' -f2 | sed -e 's/^\s*//' | xargs echo)
        else
            MOTHERBOARD="Unknown"
        fi
    fi

    # Amarisoft products
    if [ "$PROD_REF" = "" ] ; then
        if [ -e "/etc/.amarisoft-product/hostname" ] ; then
            PROD_REF="$(cat /etc/.amarisoft-product/hostname)"
        else
            PROD_REF="$(hostname)"
        fi
        if [ -e "/etc/.amarisoft-product/host-id" ] ; then
            PROD_HOSTID="$(cat /etc/.amarisoft-product/host-id)"
        fi
        if [ -e "/etc/.amarisoft-product/dongle-id" ] ; then
            PROD_DONGLEID="$(cat /etc/.amarisoft-product/dongle-id)"
        fi
    fi

    ParseProduct "$PROD_REF"
    if [ "$PROD_MODEL" = "" ] ; then return; fi

    case "$PROD_MODEL" in
    UESB)
        PROD_NAME="UE Simbox"
        SDR_COUNT="4"
        if [ "$MOTHERBOARD" = "ASRockRack X299 WS/IPMI" ] ; then
            SDR_MAP="0 1 2 3"
        elif [ "$MOTHERBOARD" = "ASRockRack X299 Creator" ] ; then
            SDR_MAP="3 1 0 2"
        fi
        ;;
    UESBE)
        PROD_NAME="UE Simbox E"
        SDR_COUNT="2"
        if [ "$MOTHERBOARD" = "ASRockRack X299 WS/IPMI" ] ; then
            SDR_MAP="0 1 2 3"
        elif [ "$MOTHERBOARD" = "ASRockRack X299 Creator" ] ; then
            SDR_MAP="0 1 2 3"
        fi
        ;;
    UESBNG|UEMBS|UESBMBS)
        PROD_MODEL="UESBMBS"
        PROD_NAME="UE Simbox Macro Base Station"
        SDR_COUNT="3"
        if [ "$MOTHERBOARD" = "ASRockRack WRX80D8-2T" ] ; then
            SDR_MAP="2 3 0 1 4 5"
        fi
        ;;
    CBM)
        PROD_NAME="Callbox Mini"
        SDR_COUNT="1"
        if [ "$MOTHERBOARD" = "Shuttle Inc. XH410G" ] ; then
            SDR_MAP="0"
        elif [ "$MOTHERBOARD" = "Shuttle Inc. XH510G" ] ; then
            SDR_MAP="0"
        fi
        ;;
    CBC)
        PROD_NAME="Callbox Classic"
        SDR_COUNT="3"
        if [ "$MOTHERBOARD" = "ASRock Z790M-PLUS" ] ; then
            SDR_MAP="0 1 2"
        elif [ "$MOTHERBOARD" = "ASRock Z590M-PRO4" ] ; then
            SDR_MAP="0 2 1"
        elif [ "$MOTHERBOARD" = "ASRock Z590M-PLUS/Z490M-PLUS" ] ; then
            SDR_MAP="0 1 2"
        fi
        ;;
    CBP)
        PROD_NAME="Callbox Pro"
        SDR_COUNT="6"
        if [ "$MOTHERBOARD" = "ASRockRack OC Formula" ] ; then
            SDR_MAP="5 0 4 3 2 1"
        fi
        ;;
    CBU)
        PROD_NAME="Callbox Ultimate"
        SDR_COUNT="4"
        if [ "$MOTHERBOARD" = "ASRockRack X299 WS/IPMI" ] ; then
            SDR_MAP="0 1 2 3 4 5 6 7"
        elif [ "$MOTHERBOARD" = "ASRockRack OC Formula" ] ; then
            SDR_MAP="4 5 2 3 0 1 6 7"
        elif [ "$MOTHERBOARD" = "ASRockRack X299 Creator" ] ; then
            SDR_MAP="2 3 6 7 0 1 4 5"
        fi
        ;;
    CBX|CBE)
        PROD_MODEL="CBX"
        PROD_NAME="Callbox Extreme"
        SDR_COUNT="6"
        if [ "$MOTHERBOARD" = "ASRockRack WRX80D8-2T" ] ; then
            SDR_MAP="2 3 0 1 10 11 8 9 4 5 6 7"
        fi
        ;;
    CBA)
        PROD_NAME="Callbox Advanced"
        SDR_COUNT="2"
        if [ "$MOTHERBOARD" = "ASRockRack X299 WS/IPMI" ] ; then
            SDR_MAP="0 1 2 3"
        fi
        ;;
    XXX)
        ResetProduct
        if [ "$SCRIPT_SILENT" != "1" ] ; then
            echo -e "\033[94mRecovery image found\033[0m"
        fi
        return
        ;;
    *)
        PROD_NAME="$PROD_MODEL"
        ;;
    esac
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94m$PROD_NAME model found\033[0m"
    fi
}
UpdateProduct

RT_CPUSET=""
function RTCPUInit
{
    local BID=$(cat /proc/sys/kernel/random/boot_id)
    local FILE="/etc/.amarisoft-product/cpuset"
    local RT_CPUSET0="$RT_CPUSET"

    if [ -e "$FILE" ] ; then
        source "$FILE"
        if [ "$BOOT_ID" != "$BID" ] ; then
            RT_CPUSET=""
        elif [ "$RT_CPUSET0" = "" ] ; then
            Log "OTS" "Recover cpuset: $RT_CPUSET"
        fi
    fi

    local CT=$(which cyclictest)
    if [ "$CT" = "" ] ; then return; fi

    local tries="0"
    while [ "$RT_CPUSET" = "" ] ; do
        RT_CPUSET="0x0"
        local NB_LAT="0"
        Log "OTS" "Detecting CPU latency"
        while read -r line ; do
            P=$(echo "$line" | grep -Po "T:\s*\K\d+")
            if [ "$P" != "" ] ; then
                MAX=$(echo "$line" | grep -Po "Max:\s+\K\d+")
                if [[ $MAX -lt 450 ]] ; then
                    RT_CPUSET=$(perl -e "printf '0x%x', $RT_CPUSET | (1<<$P);")
                else
                    Log "OTS" "High latency detected on core $P ($MAX us)"
                    NB_LAT=$(( $NB_LAT + 1 ))
                    RT_SKIP_CORE=$P
                fi
            fi
        done < <($CT --smp -p50 -i200 -d0 -m -D8s -q)
        if [ "$NB_LAT" != "1" ] ; then
            RT_CPUSET=""
            if [[ $tries -gt 4 ]] ; then
                Log "OTS" "Can't detect high latency CPU: $NB_LAT"
                break
            fi
            tries=$(( $tries + 1 ))
            sleep 5
        else
            rm -f $FILE
            echo "# Generated on $(date -u)" > $FILE
            echo "BOOT_ID=$BID" >> $FILE
            echo "RT_CPUSET=$RT_CPUSET # !$RT_SKIP_CORE" >> $FILE
        fi
    done
}


function SetHP
{
    if [ -e "/sys/kernel/mm/hugepages/hugepages-2048kB/nr_hugepages" ] ; then
        echo "$1" > /sys/kernel/mm/hugepages/hugepages-2048kB/nr_hugepages
    fi
    echo never > /sys/kernel/mm/transparent_hugepage/enabled
    echo 0 > /sys/kernel/mm/ksm/run
    echo 0 > /proc/sys/kernel/numa_balancing
    echo 0 > /proc/sys/kernel/nmi_watchdog
}

case "$PROD_MODEL" in
CBM)
    SetHP 600
    ;;
CBP|CBU|CBC)
    SetHP 1000
    ;;
CBX|CBE|UESBMBS|UESBNG)
    RTCPUInit
    SetHP 1500
    ;;
UESB|UESBE)
    SetHP 1200
    ;;
esac

exit 0;
