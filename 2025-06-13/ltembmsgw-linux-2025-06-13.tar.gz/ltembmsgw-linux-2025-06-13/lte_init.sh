#!/bin/bash
# Copyright (C) 2012-2025 Amarisoft
# LTEMBMSGW system config version 2025-06-13

# Run once as root after the boot to init the network for LTEMBMSGW.
# Configuration
ipv6=0

# Check root access
if [ `id -u` != 0 ] ; then 
    echo -e "\033[33mWarning, script must be run with root permissions\033[0m"
    exit 1
fi

function GetDefIF()
{
    if [ "$defif" = "" ] ; then
        # Try IPv4 first
        defif=$(netstat -rn | grep UG | awk '{print $8}')
        if [ "$ipv6" = "1" ] ; then
            defif6=$(netstat -rn -A inet6 | grep UG | awk '{print $7}')
            if [ "$defif" != "$defif6" ] ; then
                defif+=" $defif6"
            fi
        fi
        NormalizeIfList "defif"
    fi
}

function NormalizeIfList()
{
    local name="$1"
    local list=$(echo "${!name}" | sed -e "s/\s/\n/g" | sort | uniq | xargs -r echo)
    eval "$name=\"$list\""
}

function ListIf()
{
    echo "Available interfaces:"
    for f in $allif ; do
        if [[ $defif =~ $f ]] ; then
            echo -e "  - \033[32m$f\033[0m (default)"
        else
            echo "  - $f"
        fi
    done
}

# Name of the network interfaces which are used to access to the local
# network (and Internet)
# If not set, default gateway interface will be used
iflist=""
defif=""
while [ "$1" != "" ] ; do
  case $1 in
    -h|--help)
      echo "Usage:"
      echo "> $0 [options] [<ifname0> [<ifname1> ...]]";
      echo "  ifname: interface name of the network connect to the outside world"
      echo "    If set to default or omitted, script will use default gateway interface(s)"
      echo "    If set to lo, configuration will be discarded"
      echo "  options:"
      echo "    -6: configure ipv6"
      exit 1;
      ;;
    -6)
      echo "Use IPv6 configuration"
      ipv6=1
      ;;
    *)
      if [ "$1" = "default" ] ; then
        GetDefIF
        iflist+=" $defif"
        echo "Select $defif default interface(s)";
      else
        iflist+=" $1"
        echo "Select $1 interface";
      fi
      ;;
  esac
  shift
done

# May be ipv6
allif=$(ifconfig -a | sed 's/[: \t].*//;/^$/d')

NormalizeIfList "iflist"
if [ "$iflist" = "" ] ; then
    GetDefIF
    if [ "$defif" = "" ] ; then
        echo "Can't find default interface"
        ListIf
        exit 2
    fi
    iflist="$defif"
    echo "Select $defif default interface";
fi

# Interface lookup
for ifname in $iflist ; do
    if [ "$ifname" = "lo" ] ; then continue; fi # Skip lo

    # Interface present ?
    found=0;
    for i in $allif; do
        if [ "$i" = "$ifname" ] ; then
            found=1;
            break
        fi
    done
    if [ "$found" = "0" ] ; then
        echo -e "\033[33mWarning, $ifname interface not found\033[0m"
        GetDefIF
        ListIf
        echo "You may edit this script to force interface and/or to edit iptables rules"
        exit 1
    fi
done

for ifname in $iflist ; do
    if [ "$ifname" = "lo" ] ; then continue; fi # Skip lo

    # Set multicast default route
    # XXX: ipv6
    if [ "$(route | grep 224.0.0.0)" = "" ] ; then
        route add -net 224.0.0.0 netmask 224.0.0.0 $ifname
    fi
done

exit 0;
