#!/bin/bash
# Copyright (C) 2015-2025 Amarisoft/LimeMicroSystems
# Install script version 2025-06-13

function Help
{
    HelpTRX
}

function HelpTRX
{
    local MSG="$1"
    if [ "$MSG" != "" ] ; then
        echo "$MSG"
    fi

    echo "Usage:"
    local types=$(cd $DIR && ls | grep "config" | cut -d "." -f2 | xargs echo | tr ' ' '|')
    echo "> $0 [--no-upgrade] <path> $types [<frontend name>]"
    exit 1
}

UPGRADE="y"
DIR=$(cd $(dirname $0) && pwd)

while [ "$1" != "" ] ; do
    case "$1" in
    --no-upgrade)
        UPGRADE="n"
        ;;
    --force-upgrade)
        UPGRADE="f"
        ;;
    --dma32)
        if [ "$DMA32" = "" ] ; then
            Help "Unknown argument: $1"
        fi
        DMA32="y"
        ;;
    --no-package)
        LINUX_PACKAGE=""
        ;;
    *)
        if [ "$DST" = "" ] ; then
            DST=$(cd $1 && pwd)
            if [ ! -d "$DST" ] ; then
                Help "Directory '$DST' not found"
            fi
        else
            if [ "$TYPE" = "" ] ; then
                TYPE="$1"
            else
                if [ "$FE" = "" ] ; then
                    FE="$1"
                else
                    Help "Unknown argument: $1"
                fi
            fi
        fi
        ;;
    esac
    shift
done

if [ "$DST" = "" -o "$TYPE" = "" ] ; then
    Help
fi

if [ ! -d "${DIR}/config.${TYPE}/" ] ; then
    Help "No configuration files for $TYPE"
fi

function Install
{
    local ID="$1"
    shift

    rm -Rf ${DST}/config/${ID}
    cp -r ${DIR}/config.${TYPE}/ ${DST}/config/${ID}
    ${DST}/config/rf_select.sh ${ID} 1>/dev/null

    for i in $@; do
        rm -f ${DST}/$i
        if [ -e ${DIR}/$i ] ; then
            ln -s ${DIR}/$i ${DST}
        fi
    done
}

LINUX_SERVICE=""
LINUX_PACKAGE=""
LINUX_DISTRIB="<unknown>"
LINUX_VERSION=""

if [ -e "/etc/os-release" ] ; then
    LINUX_DISTRIB=$(cat /etc/os-release | grep "^ID=" | cut -d '=' -f2 | sed -e 's/"//g')
    LINUX_VERSION=$(cat /etc/os-release | grep "^VERSION_ID=" | cut -d '=' -f2 | sed -e 's/"//g')
    LINUX_NAME=$(cat /etc/os-release | grep "^PRETTY_NAME=" | cut -d '=' -f2 | sed -e 's/"//g')
fi
if [ "$LINUX_VERSION" = "" -o "$LINUX_DISTRIB" = "" ] ; then
    if [ -e "/etc/lsb-release" ] ; then
        LINUX_DISTRIB=$(cat /etc/os-release | grep "^DISTRIB_ID=" | cut -d '=' -f2 | sed -e 's/"//g')
        LINUX_VERSION=$(cat /etc/os-release | grep "^DISTRIB_RELEASE=" | cut -d '=' -f2 | sed -e 's/"//g')
        LINUX_NAME=$(cat /etc/os-release | grep "^DISTRIB_DESCRIPTION=" | cut -d '=' -f2 | sed -e 's/"//g')
    elif [ -e "/etc/fedora-release" ]; then
        LINUX_DISTRIB="fedora"
        LINUX_VERSION=$(cat /etc/fedora-release | cut -d " " -f3)
        LINUX_NAME="Fedora"
    fi
fi

if [ "$TARGET" = "" ] ; then
    TARGET="$(uname -m)"
    if [ "$TARGET" = "x86_64" ] ; then
        TARGET="linux"
    fi
fi

LINUX_VERSION=$(echo "$LINUX_VERSION" | cut -d '.' -f1)
LINUX_DISTRIB=$(echo "$LINUX_DISTRIB" | tr '[:upper:]' '[:lower:]')

case "$LINUX_DISTRIB" in
fedora)
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94mFedora $LINUX_VERSION found\033[0m"
    fi
    if [ "$LINUX_VERSION" -gt 20 ] ; then
        LINUX_PACKAGE="dnf"
    else
        LINUX_PACKAGE="yum"
    fi
    LINUX_SERVICE="systemd"
    ;;
rhel)
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94m$LINUX_NAME found\033[0m"
    fi
    LINUX_PACKAGE="dnf"
    LINUX_SERVICE="systemd"
    ;;
ubuntu)
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94mUbuntu $LINUX_VERSION found\033[0m"
    fi
    if [ "$LINUX_VERSION" -lt "15" ] ; then
        LINUX_SERVICE="initd"
    else
        LINUX_SERVICE="systemd"
    fi
    LINUX_PACKAGE="apt"
    ;;
centos)
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94mCent OS $LINUX_VERSION found\033[0m"
    fi
    LINUX_SERVICE="systemd"
    LINUX_PACKAGE="yum"
    ;;
raspbian)
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94mRaspbian OS $LINUX_VERSION found\033[0m"
    fi
    LINUX_SERVICE="systemd"
    LINUX_PACKAGE="apt"
    ;;
debian)
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94mDebian OS $LINUX_VERSION found\033[0m"
    fi
    LINUX_SERVICE="systemd"
    LINUX_PACKAGE="apt"
    ;;
*)
    echo "Sorry, $LINUX_DISTRIB distribution not supported only available on Fedora, Ubuntu and CentOS distributions."
    exit 1
    ;;
esac

function service_cmd
{
    local name="$1"
    local cmd="$2"

    case $LINUX_SERVICE in
    systemd)
        if [ -e "/lib/systemd/system/${name}.service" ] ; then
            if [ "$VERBOSE" = "" ] ; then
                systemctl -q ${cmd} ${name} 1>/dev/null
            else
                systemctl -q ${cmd} ${name}
            fi
        fi
        ;;
    initd)
        if [ -e "/etc/init/${name}.conf" ] ; then
            if [ "$VERBOSE" = "" ] ; then
                service ${name} ${cmd} 1>/dev/null
            else
                service ${name} ${cmd}
            fi
        fi
        ;;
    esac
}

function service_install
{
    local name="$1"
    local path="$2"
    local user="$3"
    local enable="$4"

    case $LINUX_SERVICE in
    systemd)
        rm -f /lib/systemd/system/${name}.service
        cat ${path}/${name}.service | sed -e "s/<USER>/$user/" | sed -e "s'<PATH>'$path'" > /lib/systemd/system/${name}.service
        systemctl -q --system daemon-reload

        if [ "$enable" = "y" ] ; then
            systemctl -q enable ${name}
            #systemctl -q enable NetworkManager-wait-online.service
        else
            systemctl -q disable ${name}
        fi
        ;;
    initd)
        # Remove legacy
        local deamon="/etc/init.d/${name}.d"
        if [ -e "$deamon" ]; then
            $deamon stop
            update-rc.d ${name}.d disable
            rm -f $deamon
        fi

        if [ "$enable" = "y" ] ; then
            rm -f /etc/init/${name}.conf
            cat ${path}/${name}.conf | sed -e "s/<USER>/$user/" | sed -e "s'<PATH>'$path'" > /etc/init/${name}.conf
        else
            rm /etc/init/${name}.conf
        fi
        ;;
    esac
}

# Package manager state
LINUX_PACKAGE_READY="y"
function check_package_manager
{
    # Disable error
    if [[ $- =~ e ]] ; then
        ERR="1"
    fi
    set +e

    case "$LINUX_PACKAGE" in
    yum|dnf)
        # XXX
        ;;
    apt)
        LOCKED=$(lsof /var/lib/dpkg/lock 2>/dev/null)
        if [ "$LOCKED" != "" ] ; then
            LINUX_PACKAGE_READY="n"
        fi
        ;;
    esac

    # Re-enable error ?
    if [ "$ERR" = "1" ] ; then
        set -e
    fi
}
check_package_manager

function install_package
{
    if [ "$LINUX_PACKAGE" = "" ] ; then return; fi

    if [ "$(whoami)" != "root" ] ; then
        echo "\031[93mRoot access needed to install package.[0m"
        exit 1
    fi

    # Disable error
    if [[ $- =~ e ]] ; then
        ERR="1"
    fi
    set +e

    while [ "$1" != "" ] ; do
        case "$LINUX_PACKAGE" in
        yum|dnf)
            $LINUX_PACKAGE list installed $1 &>/dev/null
            if [ "$?" != "0" ] ; then
                echo "  Install package $1 (this may take a while)..."
                if [ "$VERBOSE" = "" ] ; then
                    $LINUX_PACKAGE -qq -y install $1
                else
                    $LINUX_PACKAGE -y install $1
                fi
            fi
            ;;
        apt)
            apt-cache --quiet=0 policy $1 | grep "Installed" | grep -v none &>/dev/null
            if [ "$?" != "0" ] ; then
                echo "  Install package $1 (this may take a while)..."
                if [ "$VERBOSE" = "" ] ; then
                    apt-get -qq install -y $1 &>/dev/null
                else
                    apt-get install -y $1
                fi
            fi
            ;;
        esac

        if [ "$?" != "0" ] ; then
            echo -e "  \033[93mCan't install package $1\033[0m"
            break
        fi
        shift;
    done

    # Re-enable error ?
    if [ "$ERR" = "1" ] ; then
        set -e
    fi
}

function GetHTState
{
    if [ "$HT_SYS_STATE" = "" ] ; then
        if [ -e "/sys/devices/system/cpu/smt/control" ] ; then
            HT_SYS_STATE=$(cat "/sys/devices/system/cpu/smt/control")
            if [ "$HT_SYS_STATE" = "on" ] ; then
                # Control on but only 1 thread per core
                TPC=$(lscpu | grep -oP "Thread.+per core:.+\K\d+")
                if [ "$TPC" = "1" ] ; then
                    HT_SYS_STATE="off"
                fi
            fi
        fi
    fi
}

function SetHTState
{
    echo "$1" > "/sys/devices/system/cpu/smt/control" 2>&1
}

FE_LIST=$(cat $DIR/fe_list)
make_opt=""

echo -e "\033[33mWarning, LimeSDR driver is not maintained by Amarisoft, please check\033[0m"
echo -e "\033[33mLime Microsystems official driver @ https://github.com/myriadrf/trx-lms7002m\033[0m"
echo -e "\033[33mto upgrade it.\033[0m"

case $LINUX_DISTRIB in
fedora|centos)
    install_package libusb-devel openssl-devel gcc
    ;;
ubuntu)
    install_package libssl-dev libusb-1.0-0-dev
    ;;
raspbian)
    make_opt="TARGET=ARM"
    install_package libssl-dev libusb-1.0-0-dev
    ;;
*)
    echo "Distribution $LINUX_DISTRIB not compatible"
    exit 1
    ;;
esac

# Compil
make -s -C ${DIR} $make_opt
if [ "$?" = "0" ] ; then
    strip ${DIR}/trx_lms7002m.so
    rm -f ${DST}/trx_lms7002m.so
    ln -s ${DIR}/trx_lms7002m.so ${DST}/trx_lms7002m.so
else
    echo "Error while compiling trx driver"
    exit 1
fi

# Delete default files and copy configs
for i in ${FE_LIST} ; do
    cp -r ${DIR}/config.${TYPE}/${i} ${DST}/config/${i}
done
if [ "$TYPE" == "enb" ] ; then 
    mv ${DST}/config/limeSDR/mimo-2x2-20mhz_limesdr.cfg ${DST}/config/
fi
${DST}/config/rf_select.sh ${FE}

exit 0

