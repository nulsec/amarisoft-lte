/*
 * Copyright (C) 2012-2025 Amarisoft
 *
 * Amarisoft Web interface 2025-06-13
 */

Ext.define("lte.client.config", {

    extend: 'Ext.window.Window',
    layout: {
        type: 'fit',
        align: 'stretch',
    },
    iconCls: 'icon-config',
    width: 550,
    modal: true,

    constructor: function (config) {

        if (config.client) {
            this._applyMsg = 'Update';
            this.clientClass = Ext.getClassName(config.client);
            this.clientModel = config.client.getModel();
        } else {
            this._applyMsg = 'Create';
            this.clientClass = config.class;
            this.clientModel = 'unknown';
            delete config.class;
        }

        this.callParent(arguments);
    },

    initComponent: function () {
        this.callParent(arguments);

        var client = this.client;
        lteLogs.client = client;

        if (client) {
            var name = client.getName();
            var disabled = false;

            switch (this.clientClass) {
            case 'lte.client.server':
                var logsConfig = client.getLogsConfig();
                if (logsConfig) {
                    if (this.firstConnection)
                        disabled = true;

                } else {
                    // Client has never been connected
                    if (client.getState() === 'connecting') {
                        client.toggleState();
                        this._restartClient = true;
                    }
                }
                break;
            }

        } else {
            var name = 'Server';
            var disabled = false;
        }

        var fields = [Ext.create("Ext.form.field.Text", {
            xtype: 'textfield',
            value: name,
            allowBlank: false,
            name: 'name',
            fieldLabel: 'Name',
            disabled: disabled,
            width: '100%',
        })];

        switch (this.clientClass) {
        case 'lte.client.server':
            if (client) {
                var address = client.getAddress();
                var ssl = !!client.getConfig('ssl');
                var lock = client.logsLocked();
            } else {
                var address = { ip: '127.0.0.1', port: 9000 };
                var ssl = false;
                var lock = true;
            }

            this._roCheckBox = Ext.create('Ext.form.field.Checkbox', {
                name: 'readonly',
                fieldLabel: 'Keep config',
                tooltip: "Don't override configuration on connection",
                disabled: lock === 'locked',
                checked: !!lock,
                listeners: {
                    scope: this,
                    change: function (cb, newValue, oldValue, eOpts) {
                        this._roUpdate();
                    }
                },
            });

            fields.unshift(this._roCheckBox);

            fields.push({
                xtype: 'fieldcontainer',
                layout: 'hbox',
                fieldLabel: 'Address',
                disabled: disabled,
                width: '100%',
                items: [
                    Ext.create("Ext.form.field.Text", {
                        value: address.ip,
                        allowBlank: false,
                        name: 'addr',
                        disabled: disabled,
                        flex: 3,
                    }),
                    Ext.create("Ext.form.field.Number", {
                        name: 'port',
                        value: address.port,
                        fieldLabel: ':',
                        labelWidth: 5,
                        labelSeparator: '',
                        padding: '0 5',
                        allowDecimals: false,
                        minValue: 1,
                        maxValue: 65535,
                        disabled: disabled,
                        width: 90,
                        step: 1
                    }),
                    Ext.create('Ext.form.field.Checkbox', {
                        name: 'ssl',
                        boxLabel: 'SSL',
                        checked: ssl,
                        disabled: disabled,
                    })
                ]
            });
            break;

        case 'lte.client.url':
            fields.push(Ext.create("Ext.form.field.Text", {
                value: client ? client.getUrl() : window.location.href,
                allowBlank: false,
                name: 'url',
                fieldLabel: 'URL',
                width: '100%',
                disabled: disabled,
            }));
            break;
        }

        if (logsConfig)
            this._addLogsConfig(fields, logsConfig);

        var form = Ext.create('Ext.form.Panel', {
            bodyPadding: 5,
            items: fields,
            autoScroll:true,
            buttons: [{
                text: this._applyMsg,
                scope: this,
                handler: function() {
                    if (form.isValid()) {
                        var config = form.getForm().getFieldValues();

                        if (client) {
                            this._modifyClient(config);
                        } else {
                            this._addClient(config);
                        }
                        this.close();
                    }
                }
            }]
        });

        this.add(form);

        lteLogs.setWindowAutoHeight(this);
    },

    _modifyClient: function (config) {

        if (config.name)
            this.client.setName(config.name);

        switch (this.clientClass) {
        case 'lte.client.server':
            if (config.addr && config.port)
                this.client.setAddress(config.addr + ':' + config.port, config.ssl);

            if (this.client.logsLocked() !== 'locked')
                this.client.setConfig('readonly', config.readonly);
            this._logsSave(config);

            if (this._restartClient)
                this.client.toggleState();
            break;
        case 'lte.client.url':
            if (config.url)
                this.client.setUrl(config.url);
            break;
        }
        lteLogs.saveConfig();
        lteLogs.refreshClientGrid();
    },

    _addClient: function (config) {
        switch (this.clientClass) {
        case 'lte.client.server':
            var cfg = {
                type: 'server',
                name: config.name,
                address: config.addr + ':' + config.port,
                ssl: config.ssl,
                readonly: config.readonly,
                skipLogMenu: false,
                enabled: true,
            };
            break;
        case 'lte.client.url':
            var cfg = {
                type: 'url',
                name: config.name,
                url: config.url,
                enabled: true,
                locked: false,
            };
            break;
        default:
            return false;
        }

        lteLogs.addClient(cfg, ['removable', 'persistent']);
        lteLogs.saveConfig();
        return true;
    },

    _addLogsConfig: function (fields, config) {

        this._logsFields = [];

        // Log max count
        this._logsFields.push(Ext.create('Ext.form.field.Number', {
            fieldLabel:    'Log buffer count',
            name:        'logCount',
            value:        config.count,
            minValue:    128,
            maxValue:    128 * 1024,
            step:        10000,
            width:        '100%',
        }));

        switch (this.clientClass) {
        case 'lte.client.server':
            var phy = config.layers.PHY;
            if (phy === undefined) phy = config;
            var rrc = config.layers.RRC;
            if (rrc === undefined) rrc = config;
            var nas = config.layers.NAS;
            var mac = config.layers.MAC;

            switch (this.clientModel) {
            case 'UE':
                this._logsFields.push(Ext.create('Ext.form.CheckboxGroup', {
                    xtype: 'checkboxgroup',
                    fieldLabel: 'Flags',
                    columns: 4,
                    vertical: true,
                    items: [{
                        name: 'flags.phy.signal',
                        boxLabel: 'Signal',
                        checked: phy.signal,
                    }, {
                        name: 'flags.phy.cch',
                        boxLabel: 'CCH',
                        checked: phy.cch,
                    }, {
                        name: 'flags.phy.csi',
                        boxLabel: 'CSI',
                        checked: phy.csi,
                    }, {
                        name: 'flags.phy.rep',
                        boxLabel: 'Repetitions',
                        checked: phy.rep,
                    }, {
                        name: 'flags.phy.cell_meas',
                        boxLabel: 'Cell meas.',
                        checked: phy.cell_meas,
                    }, {
                        name: 'flags.phy.dci_size',
                        boxLabel: 'DCI size',
                        checked: phy.dci_size,
                    }, {
                        name: 'flags.phy.ntn',
                        boxLabel: 'NTN',
                        checked: phy.ntn,
                    }]
                }));
                this._logsFields.push(Ext.create('Ext.form.CheckboxGroup', {
                    xtype: 'checkboxgroup',
                    fieldLabel: 'RRC flags',
                    columns: 3,
                    vertical: true,
                    items: [{
                        name: 'flags.rrc.cell_meas',
                        boxLabel: 'Cell meas.',
                        checked: rrc.cell_meas,
                    }]
                }));
                this._logsFields.push(Ext.create('Ext.form.CheckboxGroup', {
                    xtype: 'checkboxgroup',
                    fieldLabel: 'NAS flags',
                    columns: 3,
                    vertical: true,
                    items: [{
                        name: 'flags.nas.plmn',
                        boxLabel: 'PLMN sel.',
                        checked: nas.plmn,
                    }]
                }));
                break;
            case 'ENB':
                this._logsFields.push(Ext.create('Ext.form.CheckboxGroup', {
                    xtype: 'checkboxgroup',
                    fieldLabel: 'Flags',
                    columns: 3,
                    vertical: true,
                    items: [{
                        name: 'main.mib',
                        boxLabel: 'MIB',
                        checked: config.mib,
                    }, {
                        name: 'main.bcch',
                        boxLabel: 'BCCH',
                        checked: config.bcch,
                    }, {
                        name: 'flags.mac.sched',
                        boxLabel: 'Sched',
                        checked: mac.sched,
                    }]
                }));
                this._logsFields.push(Ext.create('Ext.form.CheckboxGroup', {
                    xtype: 'checkboxgroup',
                    fieldLabel: 'PHY flags',
                    columns: 3,
                    vertical: true,
                    items: [{
                        name: 'flags.phy.signal',
                        boxLabel: 'Signal',
                        checked: phy.signal,
                    }, {
                        name: 'flags.phy.rep',
                        boxLabel: 'Repetitions',
                        checked: phy.rep,
                    }, {
                        name: 'flags.phy.csi',
                        boxLabel: 'CSI',
                        checked: phy.csi,
                    }, {
                        name: 'flags.phy.ntn',
                        boxLabel: 'NTN',
                        checked: phy.ntn,
                    }, {
                        name: 'flags.phy.ici',
                        boxLabel: 'iCiC',
                        checked: phy.ici,
                    }]
                }));
                break;
            }
            break;
        }
        fields.push.apply(fields, this._logsFields);

        // Create layer store
        var store = this._logsStore = Ext.create('Ext.data.Store', {
            fields: ['layer', 'filter', 'level', 'max_size', 'payload'],
            data: Object.keys(config.layers).map(function (l) {
                var layer = config.layers[l];
                return {
                    layer:      l,
                    level:      layer.level,
                    filter:     layer.filter,
                    max_size:   layer.max_size,
                    payload:    layer.payload,
                };
            }).sort(function (a, b) {
                return a.layer.toLowerCase() < b.layer.toLowerCase() ? -1 : 1;
            })
        });

        var setLogs = function (rec, type) {
            switch (type) {
            case 'max':
                var layer = layerConfig[rec.getData().layer];
                rec.set('level', 'debug');
                rec.set('filter', 'debug');
                rec.set('payload', true);
                if (layer && layer.max) {
                    rec.set('max_size', layer.max.max_size || 1);
                } else {
                    rec.set('max_size', 1);
                }
                break;
            case 'debug':
                var layer = layerConfig[rec.getData().layer];
                if (layer && layer.debug) {
                    rec.set('level', layer.debug.level || 'debug');
                    rec.set('filter', layer.debug.level || 'debug');
                    rec.set('payload', !!layer.debug.payload);
                    rec.set('max_size', layer.debug.max_size || 0);
                } else {
                    rec.set('level', 'warn');
                    rec.set('filter', 'warn');
                    rec.set('payload', false);
                    rec.set('max_size', 0);
                }
                break;
            case 'warn':
                rec.set('level', 'warn');
                rec.set('filter', 'warn');
                rec.set('payload', false);
                rec.set('max_size', 0);
                break;
            case 'min':
                rec.set('level', 'error');
                rec.set('filter', 'error');
                rec.set('payload', false);
                rec.set('max_size', 0);
                break;
            }
        };

        var grid = this._logsGrid = Ext.create('Ext.grid.Panel', {
            store: store,
            selType: 'cellmodel',
            bbar: {
                items: [{
                    wtype: 'button',
                    iconCls: 'icon-debug',
                    tooltip: 'Set all layers to recommended debug level',
                    handler: function(g) {
                        for (var i = 0; i < store.getCount(); i++)
                            setLogs(store.getAt(i), 'debug');
                    }
                }, {
                    wtype: 'button',
                    iconCls: 'icon-minus',
                    tooltip: 'Set all layers to minimum level',
                    handler: function(g) {
                        for (var i = 0; i < store.getCount(); i++)
                            setLogs(store.getAt(i), 'min');
                    }
                }, {
                    wtype: 'button',
                    iconCls: 'icon-warn',
                    tooltip: 'Set all layers to warn level',
                    handler: function(g) {
                        for (var i = 0; i < store.getCount(); i++)
                            setLogs(store.getAt(i), 'warn');
                    }
                }, {
                    wtype: 'button',
                    iconCls: 'icon-plus',
                    tooltip: 'Set all layers to maximum level',
                    handler: function(g) {
                        for (var i = 0; i < store.getCount(); i++)
                            setLogs(store.getAt(i), 'max');
                    }
                }]
            },
            plugins: [Ext.create('Ext.grid.plugin.CellEditing', {clicksToEdit: 1})],
            columns: [{
                text: 'Layer',
                dataIndex: 'layer',
                flex: 1
            }, {
                text: 'Filter',
                dataIndex: 'filter',
                flex: 1,
                editor: {
                    xtype: 'combobox', store: lteLogs.levels, editable: false
                }
            }, {
                text: 'Level',
                dataIndex: 'level',
                flex: 1,
                editor: null,
                scope: this,
                renderer: function (value, metaData, record, rowIndex, colIndex, store, view) {
                    if (this._roCheckBox.getValue())
                        metaData.style = "color: #666666;";
                    return value;
                },
            }, {
                text: 'Max size',
                dataIndex: 'max_size',
                flex: 1,
                editor: null,
                scope: this,
                renderer: function (value, metaData, record, rowIndex, colIndex, store, view) {
                    if (this._roCheckBox.getValue())
                        metaData.style = "color: #666666;";
                    return value;
                },
            }, {
                text: 'Payload',
                dataIndex: 'payload',
                flex: 1,
                xtype:'checkcolumn',
                editor: null,
            }, {
                xtype:'actioncolumn',
                width: 110,
                items: [{
                    iconCls: 'icon-debug1',
                    tooltip: 'Set layer to recommended debug level',
                    handler: function(grid, rowIndex, colIndex) {
                        setLogs(grid.getStore().getAt(rowIndex), 'debug');
                    }
                }, {
                    iconCls: 'icon-minus1',  // Use a URL in the icon config
                    tooltip: 'Set selected layer to minimum level',
                    handler: function(grid, rowIndex, colIndex) {
                        setLogs(grid.getStore().getAt(rowIndex), 'min');
                    }
                }, {
                    iconCls: 'icon-warn1',  // Use a URL in the icon config
                    tooltip: 'Set selected layer to warn level',
                    handler: function(grid, rowIndex, colIndex) {
                        setLogs(grid.getStore().getAt(rowIndex), 'warn');
                    }
                }, {
                    iconCls: 'icon-plus1',
                    tooltip: 'Set selected layer to maximum level',
                    handler: function(grid, rowIndex, colIndex) {
                        setLogs(grid.getStore().getAt(rowIndex), 'max');
                    }
                }]
            }],
            listeners: {
                scope: this,
                viewready: function () {
                    this._roUpdate();
                }
            },
        })

        fields.push(grid);
    },

    _roUpdate: function () {

        var grid = this._logsGrid;
        if (!grid)
            return;

        var ro = this._roCheckBox.getValue();
        var editor = [null, null, null];

        if (!ro) {
            editor[0] = {
                xtype: 'combobox',
                store: lteLogs.levels,
                editable: false
            };
            editor[1] = {
                xtype: 'numberfield',
                maxValue: 65535,
                minValue: 0,
            };
            editor[2] = {
                xtype: 'checkboxfield',
            };
        }
        for (var i = 0; i < 3; i++) {
            var col = grid.columns[i+2];
            col.setDisabled(ro);
            col.setEditor(editor[i]);
        }
        this._logsFields.forEach( (f) => { f.setDisabled(ro); });
        grid.view.refresh();
    },

    _logsSave: function (config) {

        var store = this._logsStore;
        if (!store)
            return;

        var layers = {};
        var logs = {
            count: config.logCount,
            layers: layers,
        };

        for (var i = 0, length = store.getCount(); i < length; i++) {
            var data = store.getAt(i).getData();

            layers[data.layer] = {
                level:     data.level,
                max_size:  data.max_size,
                filter:    data.filter,
                payload:   data.payload,
            }
        };

        // Flags
        for (id in config) {
            var ids = id.split('.');
            switch (ids[0]) {
            case 'flags':
                var layer = layers[ids[1].toUpperCase()];
                if (layer)
                    layer[ids[2]] = config[id];
                break;
            case 'main':
                logs[ids[1]] = config[id];
                break;
            }
        }

        this.client.setLogsConfig(logs, true);
    },

});


