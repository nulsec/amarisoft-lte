/*
 * Copyright (C) 2017-2025 Amarisoft
 */

Ext.define('lte.license.model', {
    extend: 'Ext.data.TreeModel',
    fields: [
        {name: 'name'},
        {name: 'value', type: 'auto'},
        {name: 'license', type: 'auto'}
    ],
});


Ext.define("lte.license.tab", {

    extend: 'lte.client.tab',

    _chartList: [],
    layout: 'fit',

    constructor: function (config) {
        this.callParent(arguments);
    },

    initComponent: function () {
        this.callParent(arguments);

        var listUpdate = function (list) {
            licenseStore.setRootNode({
                name: 'Licenses',
                expanded: true,
                children: list.map(function (l) {
                    return {
                        name: l.origin,
                        expanded: true,
                        children: [
                            { name: 'UID',          value: l.uid,           leaf: true},
                            { name: 'Products',     value: l.products,      leaf: true},
                            { name: 'Version',      value: l.version,       leaf: true},
                            { name: 'Max',          value: l.max,           leaf: true},
                            { name: 'Connections',  expanded: true, value: l.connections.length, children: l.connections.map(function (c) {
                                    return {
                                        name: c.name,
                                        expanded: true,
                                        children: [
                                            {name: 'Product', value: c.product, leaf: true},
                                            {name: 'Address', value: c.client || c.address, leaf: true},
                                            {name: 'Address (local)', value: c.local_address || '?', leaf: true},
                                        ]};
                                })}
                        ]
                    };
                })
            });
        };

        // Catch update events
        this.client.setMessageHandler('users_update', (function (msg) {
            this._updater.update(true);
        }).bind(this));

        // Update UE list
        this._updater = Ext.create("lte.updater", {
            scope:            this,
            updateDelay:    1000,
            dirty:            true,
            lock:            1,
            handler:        function () {
                this.client.sendMessage({message: 'list'}, function (msg) {
                    listUpdate(msg.licenses);
                });
            }
        });

        var licenseStore = Ext.create('Ext.data.TreeStore', {
            model: 'lte.license.model',
            root: {name: 'Licenses', expanded: true, children: []}
        });

        var licenseGrid = Ext.create('Ext.tree.Panel', {
            store: licenseStore,
            viewConfig:{
                markDirty: false
            },
            columns: [{
                xtype: 'treecolumn',
                dataIndex: 'name',
                width: 300,
            }, {
                text: '',
                dataIndex: 'value',
                flex: 1,
            }],
            listeners: {
                scope: this,
            }
        });

        this.add(licenseGrid);
    },
});



