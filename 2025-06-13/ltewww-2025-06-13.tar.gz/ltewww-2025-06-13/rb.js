/*
 * Copyright (C) 2012-2025 Amarisoft
 *
 * Amarisoft Web interface 2025-06-13
 */

Ext.define("lte.stats.rb", {

    _createCell: function (clientCell, label, id, dir) {

        return {
            cell_id: id,
            label: label,
            mode: clientCell.mode,
            n_rb: dir === 'dl' ? clientCell.n_rb_dl : clientCell.n_rb_ul,
            slotCount: clientCell.getSlotCount(dir === 'ul'),
            logs: [],
            rb_list: [],
            state: true,
            clientCell: clientCell,
            dir: dir,
            ssb: clientCell.ssb || [],
            rb_list_draw: [],
        };
    },

    _cellCheck: function (clientCell) {
        return clientCell.n_rb_dl > 0 &&
            clientCell.mode &&
            clientCell.getSlotCount();
    },


    _nbIoT_sfType: function (f) {
        var sf = f % 10;
        if (sf === 0) return 'NPBCH';
        if (sf === 5) return 'NPSS';
        if (sf === 9 && !((f / 10) & 1)) return 'NSSS';

        return false;
    },

    constructor: function (config) {

        lteLogs.setLogger("rb", this);
        this.initData(config.log);
    },

    initData: function (selectLog) {

        var cellHash = {};
        var cells = this.cells = [];
        var clients = {};

        this._drawPos = {
            keep_x: false,
            rb_x: 0,
            keep_y: false,
            cell_y: null,
            rb_y: 0,
        };

        // Parse logs and found cells
        var logs  = lteLogs.getLogs();

        for (var i = 0, length = logs.length; i < length; i++) {
            var log = logs[i];
            if (log.layer !== 'PHY') continue;
            if (log.filtered) continue;
            if (log.dir === DIR_NONE) continue;

            var cell_id = log.cell;
            if (cell_id === undefined) continue;

            var client = log.client;
            var clientId = client.clientId;
            cell_id = clientId + '.' + cell_id;
            var cell = cellHash[cell_id];

            // Cell not defined, try to get it from client config
            if (!cell) {
                var clientCells = clients[clientId];
                if (!clientCells)
                    clientCells = clients[clientId] = client.getParams('cells');

                // Create cell from client
                var name = client.getName();
                for (var id in clientCells) {
                    var clientCell = clientCells[id];
                    var cell_id1 = clientId + "." + id;
                    if (cell_id !== cell_id1) continue;

                    if (!this._cellCheck(clientCell)) {
                        break;
                    }

                    var label = name + '/' + clientCell.getName();
                    switch (clientCell.mode) {
                    case 'TDD':
                        cell = cellHash[cell_id1] = this._createCell(clientCell, label + ' DL/UL', cell_id, 'both');
                        cells.push(cell);
                        break;
                    case 'FDD':
                        var cell_dl = cellHash[cell_id1 + '.dl'] = this._createCell(clientCell, label + ' DL', cell_id, 'dl');
                        var cell_ul = cellHash[cell_id1 + '.ul'] = this._createCell(clientCell, label + ' UL', cell_id, 'ul');
                        cell = cellHash[cell_id1] = {fdd: true, dl: cell_dl, ul: cell_ul};
                        cells.push(cell_dl);
                        cells.push(cell_ul);
                        break;
                    }
                    break;
                }

                if (!cell) {
                    var win = Ext.create('lte.cell.config', {
                        title: 'Configure cell ' + log.cell + ' (' + name + ')',
                        client: client,
                        cell_id: log.cell,
                        logs: logs,
                        listeners: {
                            scope: this,
                            close: function () {
                                if (win.cellConfigured)
                                    this.initData(selectLog);
                            }
                        }
                    });
                    win.show();
                    return;
                }
            }

            if (cell.fdd) {
                if (log.dir === DIR_DL) {
                    cell = cell.dl;
                } else if (log.dir === DIR_UL) {
                    cell = cell.ul;
                } else {
                    continue;
                }
            }

            cell.logs.push(log);

            var sCount = cell.slotCount;
            this._addRb(cell, log, log.frame * sCount + log.slot, log.hfn * 1024 * sCount);
        }

        // Max slot per frame (Should use lcm but slot count is always a multiple of 10)
        this.maxSlotCount = 0;
        for (var id in cells) {
            var cell = cells[id];
            this.maxSlotCount = Math.max(this.maxSlotCount, cell.slotCount);
        }

        // Boundaries
        var max_x = 0;
        var min_x = Infinity;
        var min_ts;
        for (var id in cells) {
            var cell = cells[id];

            var cr = cell.slotRatio = this.maxSlotCount / cell.slotCount;

            cell.rb_list.forEach(function (rb) {
                var x = Math.floor(rb.x0) * cr;
                if (x < min_x) {
                    min_x = x;
                    min_ts = rb.log.timestamp;
                }
                max_x = Math.max(max_x, Math.ceil(rb.x1) * cr);
            });
        }

        this.max_x = max_x;
        this.start_x = Math.floor(min_x / this.maxSlotCount) * this.maxSlotCount;
        this.start_ts = min_ts + (this.start_x - min_x) * 10 / this.maxSlotCount;
        this.start_offset = this.start_ts % 1;

        var win = this._win = this._createWindow();
        win.show();
        if (selectLog)
            this.setLog(selectLog, true);

        this._selectLogEventId = lteLogs.registerEventListener('selectLog', this._selectLogEvent.bind(this));
    },

    _addRb: function (cell, log, x, dx) {

        var rb_x0 = x + dx;
        var rb_x1 = rb_x0 + 1;

        var prb = log.getPRB();
        if (prb) {
            if (log.symb) {
                var s = log.symb.split(':');
                rb_x1 = rb_x0 + ((s[0] | 0) + (s[1] === undefined ? 1 : s[1] | 0)) / 14;
                rb_x0 += (s[0] | 0) / 14;
            }

            cell.rb_list.push(...prb.map( (rb) => {
                return {
                    x0: rb_x0,
                    x1: rb_x1,
                    y0: rb.start,
                    y1: rb.start + rb.len,
                    log: log,
                };
            }));

            return;
        }

        // Legacy
        var clientCell = cell.clientCell;
        var channel = lteLogs.channelsDef[log.channel];
        var name = channel ? channel.name : '';

        switch (name) {
        case "PRACH":
            if (cell.mode !== "TDD" && clientCell.prach_freq_offset) {

                // Get x
                var cfg = this._prachConfig[clientCell.prach_config_index % 16];
                var sub = cfg[1];
                var x1  = Infinity;
                var s   = sub.length;
                var f   = log.frame & cfg[0];
                while (x1 >= x) {
                    if (--s < 0) {
                        s = sub.length - 1;
                        f = (f - 1) & cfg[0];
                    }
                    x1 = f * cell.slotCount + sub[s];
                }
                x = x1;

                // First entry
                rb_x0 = x + dx;
                var format = Math.floor(clientCell.prach_config_index / 16);
                var n = ([1, 2, 2, 3])[format];
                cell.rb_list.push({
                    x0: rb_x0,
                    x1: rb_x0 + n,
                    y0: clientCell.prach_freq_offset,
                    y1: clientCell.prach_freq_offset + 6,
                    log: log,
                    slot: [0, 1]
                });
            }
            break;

        case "PUCCH":
            var n = log.n - 0;
            switch (log.format) {
            case '1':
            case '1A':
            case '1B':
                var c = clientCell.cyclic_prefix ? 2 : 3;
                var mod  = (c * clientCell.n_cs_an / clientCell.delta_pucch_shift) | 0;
                var mod1 = (c * 12 / clientCell.delta_pucch_shift) | 0;
                if (n < mod)
                    n = clientCell.n_rb_cqi;
                else
                    n = (((n - mod) / mod1) | 0) + clientCell.n_rb_cqi + (clientCell.n_cs_an ? 1 : 0);
                break;
            case '2':
            case '2A':
            case '2B':
                n = (n / 12) | 0;
                break;
            case '3':
                n = (n / 5) | 0;
                break;
            default:
                n = 0;
                break;
            }

            var n1 = n & 1;
            n = n >> 1;

            if (log.br) {
                var sf = log.slot;
                n1 ^= sf & 1;
                if (n1 == 0) {
                    cell.rb_list.push({x0: rb_x0, x1: rb_x1, y0: n, y1: n + 1, log: log});
                } else {
                    cell.rb_list.push({x0: rb_x0, x1: rb_x1, y0: clientCell.n_rb_ul - n - 1, y1: clientCell.n_rb_ul - n, log: log});
                }
            } else {
                var n2 = (1 - n1) / 2;
                var n1 = n1 / 2;
                cell.rb_list.push({x0: rb_x0 + n1, x1: rb_x0 + n1 + 0.5, y0: n, y1: n + 1, log: log});
                cell.rb_list.push({x0: rb_x0 + n2, x1: rb_x0 + n2 + 0.5, y0: clientCell.n_rb_ul - n - 1, y1: clientCell.n_rb_ul - n, log: log});
            }
            break;

        case 'NPDCCH':
            if (!log.n_rep) break; // Filter
            
            var rb = {x0: rb_x0, x1: rb_x1, y0: 0, y1: 2, log: log};
            if (log.L === 1) {
                rb.y1 = 1;
                if (log.cce_index) {
                    rb.y0++;
                    rb.y1++;
                }
            }
            cell.rb_list.push(rb);
            break;

        case 'NPDSCH':
            if (!log.n_sf) break; // Filter
            var rb = {x0: rb_x0, x1: rb_x1, y0: 0, y1: 2, log: log};
            cell.rb_list.push(rb);
            break;

        case 'NPUSCH':
            if (log.n_sc_start === undefined) break; // Filter

            var rb = {x0: rb_x0, x1: rb_x1, y0: log.n_sc_start, log: log};

            var coef = log.sc_sp ? 1 : 0.25;
            if (log.ack) {
                rb.y1 = rb.y0 + 1;
            } else {
                rb.y1 = rb.y0 + log.n_sc;
            }
            rb.y0 *= coef;
            rb.y1 *= coef;
            cell.rb_list.push(rb);
            break;

        case 'NPRACH':
            if (log.n_sf === undefined) break;
            var factor = 0.25;
            if (log.fmt == 2)
                factor /= 3.0;
            /* XXX: should show the gap if 128 repetitions */
            var rb= {x0: rb_x0, x1: rb_x0 + log.n_sf, y0: log.n_sc_start*factor, y1: log.n_sc_start*factor + 3, log : log};
            cell.rb_list.push(rb);
            break;

        case 'PUSCH':
        case 'PDSCH':
        case 'EPDCCH':
        case 'PMCH':
            var list = [];
            var rb_start = log.rb_start;
            if (rb_start >= 0) {
                list.push({x0: rb_x0, x1: rb_x1, y0: rb_start, y1: rb_start + log.l_crb, log: log});
            }

            if (log.bitmap) {
                var rb_count = cell.n_rb;
                var P, n_bits, n;
                /* XXX: compute once */
                if (rb_count <= 10)
                    P = 1;
                else if (rb_count <= 26)
                    P = 2;
                else if (rb_count <= 63)
                    P = 3;
                else
                    P = 4;

                n_bits = Math.ceil(rb_count / P);

                var rb_p = log.rb_p;
                if (rb_p >= 0 && log.rb_shift >= 0) {
                    /* type 1 alloc */
                    var n_bits_1, P, j1, delta;
                    n_bits_1 = n_bits - 1;
                    if (P <= 2)
                        n_bits_1--;
                    else
                        n_bits_1 -= 2;
                    if (log.rb_shift) {
                        /* XXX: compute once */
                        delta = Math.floor((rb_count - 1) / (P * P)) * P;
                        j1 = Math.floor((rb_count - 1) / P) % P;
                        if (rb_p < j1)
                            delta += P;
                        else if (rb_p == j1)
                            delta += 1 + (rb_count - 1) % P;
                        delta -= n_bits_1;
                    } else {
                        delta = 0;
                    }
                    for (var j = 0; j < n_bits_1; j++) {
                        if (log.bitmap & (1 << (n_bits_1 - 1 - j))) {
                            j1 = j + delta;
                            n = Math.floor(j1 / P) * P * P + rb_p * P + (j1 % P);
                            list.push({x0: rb_x0, x1: rb_x1, y0: n, y1: n + 1, log: log});
                        }
                    }
                } else {
                    /* type 0 alloc */
                    for (var j = n_bits - 1, n = 0; n < rb_count; j--, n = next) {
                        var next = n + P;
                        if (log.bitmap & (1 << j)) {
                            list.push({x0: rb_x0, x1: rb_x1, y0: n, y1: Math.min(next, rb_count), log: log});
                        }
                    }
                }
            }

            cell.rb_list.push.apply(cell.rb_list, list);
            break;

        case 'SRS':
            var rb_start = log.rb_start;
            if (rb_start >= 0) {
                cell.rb_list.push({x0: rb_x0 + 0.8, x1: rb_x1, y0: rb_start, y1: rb_start + log.l_crb, log: log});
            }
            break;
        }
    },

    _pattern: {},
    _createPatterns: function (ctx) {

        // Hash
        var hashSize = 4;
        var hashCanvas = document.createElement('canvas');
        hashCanvas.width  = hashSize;
        hashCanvas.height = hashSize;
        var hashCtx = hashCanvas.getContext('2d');
        hashCtx.strokeStyle = '#F0F0F0';
        hashCtx.beginPath();
        hashCtx.moveTo(0, hashSize);
        hashCtx.lineTo(hashSize, 0);
        hashCtx.stroke();
        this._pattern.hash = hashCtx.createPattern(hashCanvas, "repeat");

        // Point
        var pointSize = 4;
        var pointCanvas = document.createElement('canvas');
        pointCanvas.width  = pointSize;
        pointCanvas.height = pointSize;
        var pointCtx = pointCanvas.getContext('2d');
        pointCtx.fillStyle = '#000000';
        pointCtx.fillRect(pointSize >> 1, pointSize >> 1, 2, 2);
        this._pattern.point = hashCtx.createPattern(pointCanvas, "repeat");

        // Circle
        var circleSize = 8;
        var circleCanvas = document.createElement('canvas');
        circleCanvas.width  = circleSize;
        circleCanvas.height = circleSize;
        var circleCtx = circleCanvas.getContext('2d');
        circleCtx.strokeStyle = '#F0F0F0';
        circleCtx.beginPath();
        circleCtx.arc(circleSize >> 1, circleSize >> 1, (circleSize >> 1) - 2, 0, 1.5 * Math.PI);
        circleCtx.stroke();
        this._pattern.circle = hashCtx.createPattern(circleCanvas, "repeat");

        this._legends = [{
            label: 'Retx',
            color: '#202020',
            pattern: 'hash',
        }, {
            label: 'ACK',
            color: '#D0D0D0',
            pattern: 'point',
        }];
    },

    _updateChannels: function () {

        // Channels
        var channels = {};
        for (var cell_id in this.cells) {
            var cell = this.cells[cell_id];
            if (cell.state) {
                cell.rb_list.forEach((rb) => {
                    var cid = rb.log.channel;
                    var chan = lteLogs.channelsDef[cid];
                    if (chan === undefined) {
                        console.error(lteLogs.id2string(cid), ' channel not defined for RB');
                        return;
                    }
                    var c = channels[cid] = chan;
                    if (cid === PDSCH && typeof rb.log.harq === 'string') {
                        switch (rb.log.harq) {
                        case 'mtch':
                        case 'mcch':
                            var sid = cid + '.mbs';
                            break;
                        default:
                            var sid = cid + '.broadcast';
                            break;
                        }
                        c = channels[sid];
                        if (!c) {
                            switch (rb.log.harq) {
                            case 'mtch':
                            case 'mcch':
                                c = {
                                    label: 'MCCH, MTCH',
                                    index: chan.index + 0.3,
                                    pattern: 'circle',
                                    color: this.lightenColor(chan.color, 0.5)
                                };
                                break;
                            default:
                                c = {
                                    label: chan.name + ' broadcast',
                                    index: chan.index + 0.2,
                                    color: this.lightenColor(chan.color, 0.5),
                                };
                                break;
                            }
                            channels[sid] = c;
                        }
                    }
                    if (rb.log.rep) {
                        var rid = cid + '.rep';
                        c = channels[rid];
                        if (!c) {
                            c = channels[rid] = {
                                label: chan.name + ' rep.',
                                index: chan.index + 0.5,
                                color: this.lightenColor(chan.color, 0.75),
                            };
                        }
                    }
                    rb.chanDef = c;
                });
            }

            if (cell.ssb.length > 0)
                channels.SSB = lteLogs.channelsDef.SSB;

            if (this.showDlValidSf) {
                var def = lteLogs.getChannelDefByName('INV');
                channels[def.id] = def;
            }
        }

        var data = Object.keys(channels).map(function (c) { return channels[c]; })
        data.sort(function (a, b) { return a.index - b.index; });

        this.legendStore.loadData(data.concat(this._legends));
    },

    _selectLogEvent: function (event) {
        this.setLog(event.log);
    },

    setLog: function (log) {
        if (log === this._selectedLog) return; // No change

        var ts = log.timestamp;

        this._selectedLog = log;

        // Check log is visible
        for (var cell_id in this.cells) {
            var cell = this.cells[cell_id];
            if (!cell.state) continue;

            var rb_list_draw = cell.rb_list_draw;
            for (var i = 0; i < rb_list_draw.length; i++) {
                if (log === rb_list_draw[i].log) {
                    this._update();
                    return;
                }
            }
        }

        // Try by SFN
        if (log.frame !== undefined && log.slot !== undefined) {
            var cell_id = log.cell;

            for (var id in this.cells) {
                var cell = this.cells[id];
                if (!cell.clientCell || cell.clientCell.cell_id !== cell_id) continue;

                var rb_x = (log.hfn * 1024 + log.frame) * cell.slotCount + log.slot - cell.slotCount;
                this._slider.setValue(rb_x * cell.slotRatio);
                return;
            }
        }

        // Try by time
        this.setTime(Math.floor(ts / 10) * 10 - 10);
    },

    setTime: function (ts) {
        var rb_x = Math.round((ts - this.start_ts) / 10 * this.maxSlotCount) + this.start_x;
        this._slider.setValue(rb_x);
    },

    rb2time: function (rb) {
        return lteLogs.ts2time((rb - this.start_x) * 10 / this.maxSlotCount + this.start_ts);
    },

    // Area config
    grid_x:        0,
    grid_y:        0,
    grid_z:        0,

    // Cells
    inter_cell:    8,

    // Legend
    legend_size:   15,

    // Time
    time_height: 35,
    time_font_size: 12,
    rbc_width:   25, // Width of RB #

    // Block value
    rb_w:        14,
    rb_w_min:    4,
    rb_w_max:    25,
    rb_h:        10,
    rb_h_min:    1,
    rb_h_max:    15,


    //Display parameters
    showDlValidSf: false,
    mergeCells: false,

    _createWindow: function () {

        // Create slider
        var slider = this._slider = Ext.create('Ext.slider.Single', {
            flex: 1,
            value: 0,
            increment: 1,
            minValue: Math.floor(this.start_x / this.maxSlotCount) * this.maxSlotCount,
            maxValue: Math.ceil(this.max_x / this.maxSlotCount) * this.maxSlotCount,
            useTips: false,
            /*tipText: Ext.Function.bind(function (thumb) {
                var value = slider.getValue();
                var hfn   = (value / 10240) >> 0;
                var frame = ((value % 10240) / 10) >> 0;
                var subf  = value % 10;
                var time = this.rb2time(value);
                if (hfn)
                    return 'HFN ' + hfn + '<br/>Frame #' + frame + ', sub frame ' + subf + '<br/>Time: ' + time;
                return "Frame #" + frame + ", sub frame " + subf + "<br/>Time: " + time;
            }, this),*/
            listeners: {
                scope: this,
                change: function(slider, newValue, thumb, eOpts) {
                    this.grid_x = newValue * this.rb_w;
                    this._update();
                }
            }
        });

        var cellGrid = Ext.create('Ext.grid.Panel', {
            frameHeader: false,
            store: {
                fields: ['cell_id', 'label', 'logs', 'state'],
                data: Object.keys(this.cells).map( (cell_id) => { return { cell: this.cells[cell_id] }; })
            },
            viewConfig:{
                markDirty: false
            },
            columns: [{
                text: "Cell",
                dataIndex: "cell",
                flex: 1,
                renderer: function (cell, metaData, record, rowIndex, colIndex, store, view) {
                    var color = cell.state ? '#80C0ff' : '#ffffff';
                    metaData.style = 'background-color: ' + color + '; font-weight: bold;';
                    return cell.label;
                }
            }],
            listeners: {
                scope: this,
                cellclick: function (grid, td, cellIndex, record, tr, rowIndex, e, eOpts) {
                    //var on = record.get('on');
                    var cell = record.get('cell');
                    cell.state = !cell.state;
                    this._drawPos.keep_y = true;
                    this._updateDrawCells();
                    this._update();
                    cellGrid.getView().refresh();
                },
            },
            width: '100%',
            hideHeaders: true,
        });


        this.legendStore = Ext.create('Ext.data.Store', {
            fields: ['label', 'color'],
            data: []
        });

        var legendGrid = Ext.create('Ext.grid.Panel', {
            frameHeader: false,
            width: '100%',
            flex: 1,
            store: this.legendStore,
            columns: [{
                text: 'Legend',
                dataIndex: 'label',
                flex: 1
            }, {
                text: '',
                dataIndex: 'color',
                width: 50,
                align: 'center',
                scope: this,
                renderer: function (value, metaData, record, rowIndex, colIndex, store, view) {
                    var data = record.getData();

                    var size = this.legend_size;
                    var canvas = document.createElement('canvas');
                    canvas.width  = size;
                    canvas.height = size;
                    var ctx = canvas.getContext('2d');

                    // Channel
                    this._drawRb(ctx, data, 0, 0, size, size);
                    ctx.strokeRect(0, 0, size, size);

                    return '<img src="' + canvas.toDataURL() + '">';
                },
            }]
        });

        this.zoomRBInButton = Ext.create('Ext.button.Button', {
            width: 24,
            tooltip: lteLogs.tooltip("Zoom in RB (y axis)"),
            iconCls: "icon-plus",
            listeners: {
                scope: this,
                click: function(filter, e, eOpts) {
                    this._zoom(1);
                }
            }
        });
        this.zoomRBOutButton = Ext.create('Ext.button.Button', {
            width: 24,
            tooltip: lteLogs.tooltip("Zoom out (y axis)"),
            iconCls: "icon-moins",
            listeners: {
                scope: this,
                click: function(filter, e, eOpts) {
                    this._zoom(-1);
                }
            }
        });
        this.zoomRBAutoButton = Ext.create('Ext.button.Button', {
            width: 24,
            tooltip: lteLogs.tooltip("Adjust RB zoom (y axis)"),
            iconCls: "icon-zoom",
            listeners: {
                scope: this,
                click: function(filter, e, eOpts) {
                    this._autoSize = true;
                    this._update();
                }
            }
        });

        this.zoomTimeInButton = Ext.create('Ext.button.Button', {
            width: 24,
            tooltip: lteLogs.tooltip("Zoom time in (x axis)"),
            iconCls: "icon-plus",
            listeners: {
                scope: this,
                click: function(filter, e, eOpts) {
                    this._zoom(1, true);
                }
            }
        });
        this.zoomTimeOutButton = Ext.create('Ext.button.Button', {
            width: 24,
            tooltip: lteLogs.tooltip("Zoom time out (x axis)"),
            iconCls: "icon-moins",
            listeners: {
                scope: this,
                click: function(filter, e, eOpts) {
                    this._zoom(-1, true);
                }
            }
        });

        var timeFormater = function (value) {
            var sign = 1;
            if (value[0] === '-') {
                sign = -1;
                value = value.substr(1);
            }
            value = value.match(/^(((\d+):)?(\d+):)?(\d+)(\.(\d+))?$/);
            if (value) {
                var h = value[3] >> 0;
                var m = value[4] >> 0;
                var s = value[5] >> 0;
                var ms = value[7] || "0";
                ms = ((ms - 0) * Math.pow(10, 3 - ms.length)) >> 0;
                return (h * 3600000 + m * 60000 + s * 1000 + ms) * sign;
            }
            return null;
        };

        var timeSelector = this.timeSelector = Ext.create("Ext.form.field.Text", {
            fieldLabel: 'Time',
            labelWidth: 35,
            value: "0:00:00",
            width: 150,
            validateOnChange: true,
            validator: function (value) {
                return timeFormater(value) !== null;
            },
            listeners: {
                scope: this,
                blur: function (filter, event, eOpts) {
                    var ts = timeFormater(filter.getValue());
                    this.setTime(ts + this.start_offset);
                },
            }
        });

        this._createPatterns();
        this._updateChannels();


        var dockedItems = [
            Ext.create('Ext.toolbar.Toolbar', {
                items: [
                    timeSelector,
                    this.zoomTimeOutButton,
                    this.zoomTimeInButton,
                ]
            }),
            Ext.create('Ext.toolbar.Toolbar', {
                items: [
                    'RB:',
                    this.zoomRBOutButton,
                    this.zoomRBInButton,
                    this.zoomRBAutoButton,
                ]
            }),
        ];

        dockedItems.push(Ext.create('Ext.toolbar.Toolbar', { items: [
            Ext.create("Ext.form.field.Checkbox", {
                boxLabel: 'Show non-DL SF (BL/CE or NB-IoT)',
                checked: false,
                listeners: {
                    scope: this,
                    change: function (field, newValue, oldValue, eOpts) {
                        this.showDlValidSf = newValue;
                        this._update();
                    },
                }
            }),
        ]}));

        this.mergeCells = true;
        this._updateDrawCells();
        if (this.mainCells.length !== this.drawCells.length) {

            dockedItems.push(Ext.create('Ext.toolbar.Toolbar', { items: [
                Ext.create("Ext.form.field.Checkbox", {
                    boxLabel: 'Merge cells',
                    checked: false,
                    listeners: {
                        scope: this,
                        change: function (field, newValue, oldValue, eOpts) {
                            this.mergeCells = newValue;
                            this._updateDrawCells();
                            this._update();
                        },
                    }
                }),
            ]}));
            this.mergeCells = false;
            this._updateDrawCells();
        }

        // Create draw container
        var container = Ext.create('Ext.panel.Panel', {
            html: '<canvas></canvas>',
            border: 0,
            listeners: {
                scope: this,
                afterlayout: function(me, newValue, thumb, eOpts) {
                    var canvas = this._canvas;

                    canvas.addEventListener(lteLogs.getMouseWheelEvent(), this._mouseWheelEvent.bind(this), {passive: true});
                    canvas.addEventListener("mousedown", this._mouseDownEvent.bind(this));
                    canvas.addEventListener("mousemove", this._mouseMoveEvent.bind(this));
                    canvas.addEventListener("mouseout", this._mouseOutEvent.bind(this));
                    canvas.addEventListener("mouseup", this._mouseUpEvent.bind(this));

                    // First
                    this.rb_w = Math.floor((canvas.width - this.rbc_width - 5) / this.maxSlotCount);

                    this._toolTip = Ext.create('Ext.tip.ToolTip', {
                        target: canvas,
                        trackMouse: true,
                        autoHide: true,
                    });
                },
                resize: function(cont, width, height) {
                    var canvas = this._canvas = container.el.down("canvas").dom;
                    lteLogs.setCanvasSize(canvas, width, height);
                    this._update();
                }
            }
        });


        this._autoSize = true;
        var height = document.body.clientHeight || window.innerHeight;

        //cellCombo.select(Object.keys(this.cells)[0]);
        return  Ext.create('Ext.window.Window', {
            title: lteLogs.getHTMLIcon('icon-comp') + ' Ressource Block Allocation',
            width: 1200,
            minWidth: 500,
            minHeight: Math.min(500, height),
            maxHeight: height,
            height: height,
            constraint: true,
            maximizable: true,
            layout: 'border',
            maximizable: true,
            items: [{
                region: 'west',
                layout: 'vbox',
                width: 250,
                dockedItems: dockedItems,
                split: true,
                items: [cellGrid, legendGrid],
            }, {
                region: 'center',
                id: 'rb',
                layout: 'fit',
                tbar: {items: [slider]},
                border: 0,
                items: [container]
            }],
            listeners: {
                scope: this,
                close: function(panel, eOpts) {
                    lteLogs.unregisterEventListener(this._selectLogEventId);
                }
            }
        });
    },

    _prachConfig: [
        [~1, [1]],
        [~1, [4]],
        [~1, [7]],
        [~0, [1]],
        [~0, [4]],
        [~0, [7]],
        [~0, [1, 6]],
        [~0, [2, 7]],
        [~0, [3, 8]],
        [~0, [1, 4, 7]],
        [~0, [2, 5, 8]],
        [~0, [3, 6, 9]],
        [~0, [0, 2, 4, 6, 8]],
        [~0, [1, 3, 5, 7, 9]],
        [~0, [1, 2, 3, 4, 5, 6, 7, 8, 9]],
        [~1, [9]]
    ],

    blendColors: function(c0, c1, alpha) {
        var m0 = c0.match(/#([\da-fA-F]{2})([\da-fA-F]{2})([\da-fA-F]{2})/);
        var m1 = c1.match(/#([\da-fA-F]{2})([\da-fA-F]{2})([\da-fA-F]{2})/);
        if (m0 && m1) {
            c0 = m0.slice(1, 4).map( (c) => parseInt(c, 16) * (1 - alpha) );
            c1 = m1.slice(1, 4).map( (c) => parseInt(c, 16) * alpha );
            c0 = '#' + c0.map( (c, i) => ('0' + ((c + c1[i]) >> 0).toString(16)).slice(-2) ).join('');
        }
        return c0;
    },

    lightenColor: function (color, alpha) {
        return this.blendColors(color, '#ffffff', alpha);
    },

    clamp: function (value, min, max) {
        return Math.max(min, Math.min(value, max));
    },

    _cmpCells: function (c1, c2) {

        if (c1.dir !== c2.dir || c1.clientCell.rat !== c2.clientCell.rat)
            return false;

        switch (c1.clientCell.rat) {
        case 'lte':
            if (c1.clientCell.earfcn === c2.clientCell.earfcn)
                return true;
            break;
        case 'nr':
            // Not tested
            if (c1.clientCell.arfcn === c2.clientCell.arfcn)
                return true;
            break;
        }
        return false;
    },

    _updateDrawCells: function () {

        // Check boundaries
        var cell0 = null;
        this.drawCells = [];
        var cells = this.mainCells = [];
        for (var cell_id in this.cells) {
            var cell = this.cells[cell_id];

            if (this.mergeCells)
                cell0 = cells.find(this._cmpCells.bind(this, cell));

            if (!cell0) {
                this.mainCells.push(cell);
                cell.toDraw = [cell];
            } else if (cell.state) {
                cell0.toDraw.push(cell);
            }
            this.drawCells.push(cell);
        }

        // Disable cells have been added to keep order, let's remove them now
        this.drawCells = this.drawCells.filter( (c) => c.state );
        for (var i = this.mainCells.length; i--;) {
            var cell = this.mainCells[i];
            if (!cell.state) {
                if (cell.toDraw.length === 1) {
                    this.mainCells.splice(i, 1);
                } else {
                    var cell0 = cell.toDraw.shift();
                    cell0.toDraw = cell.toDraw;
                    this.mainCells[i] = cell0;
                }
            }
        }
    },

    _update: function() {
        if (!this.drawPending) {
            this.drawPending = true;
            window.requestAnimationFrame(this.drawFrame.bind(this));
        }
    },

    _drawRb: function (ctx, c, x, y, w, h, pattern) {

        if (!pattern)
            pattern = c.pattern;

        ctx.fillStyle = c.color;
        if (pattern) {
            ctx.fillRect(x, y, w, h);
            ctx.fillStyle = this._pattern[pattern];
        }
        ctx.fillRect(x, y, w, h);
    },

    drawFrame: function () {

        this.drawPending = false;
        var canvas = this._canvas;
        if (!canvas) return;

        /* XXX: update it depending on enabled cells */
        var maxSlotCount = this.maxSlotCount;

        // Available drawing height (rb + axes)
        var rbc_width = this.rbc_width;
        var width  = canvas.width - rbc_width - 5;
        var height = canvas.height - this.time_height - 2;

        var cells = this.mainCells;
        var cell_count = cells.length;
        var rb_count = 0;
        cells.forEach( (cell) => { rb_count += cell.n_rb });

        // Reset
        this.drawCells.forEach( (cell) => { cell.rb_list_draw = []; });

        // Resource block size
        var rb_w = this.clamp(this.rb_w, this.rb_w_min, this.rb_w_max);
        var rb_h = this.clamp(this.rb_h, this.rb_h_min, this.rb_h_max);

        if (this._autoSize) {
            this._autoSize = false;
            rb_h = this.rb_h_min;
        }

        if (rb_count) {
            for (var i = rb_h;; i++) {
                var height1 = (cell_count - 1) * this.inter_cell + rb_count * i;
                if (height1 > height)
                    break;
                rb_h = i;
                if (rb_h === this.rb_h_max)
                    break;
            }
        }
        var max_height = (cell_count - 1) * this.inter_cell + rb_count * rb_h;
        this.rb_h = rb_h;
        this.rb_w = rb_w;

        this.zoomRBInButton.setDisabled(rb_h === this.rb_h_max);
        this.zoomRBOutButton.setDisabled(rb_h === this.rb_h_min);
        this.zoomTimeInButton.setDisabled(rb_w === this.rb_w_max);
        this.zoomTimeOutButton.setDisabled(rb_w === this.rb_w_min);

        var dp = this._drawPos;
        if (dp.keep_x) {
            dp.keep_x = false;
            this.grid_x = Math.floor(dp.rb_x * rb_w);
        }

        if (dp.keep_y) {
            dp.keep_y = false;
            this.grid_y = 0;
            var n_rb1 = 0;
            for (var cell_id in cells) {
                var cell = cells[cell_id];
                if (!cell.state) {
                    if (dp.cell_y === cell) {
                        dp.cell_y = null;
                        dp.rb_y = 0;
                    }
                    continue;
                }
                if (dp.cell_y !== null && dp.cell_y !== cell) {
                    this.grid_y += cell.n_rb * rb_h + this.inter_cell;
                    continue;
                }

                this.grid_y += dp.rb_y * rb_h;
                break;
            }
        }

        // Grid offset
        var grid_x = this.grid_x = Math.max(this.start_x * rb_w, Math.min(this.grid_x, this.max_x * rb_w - width));
        var grid_y = this.grid_y = Math.max(0, Math.min(this.grid_y, max_height - height));

        dp.rb_x = grid_x / rb_w;

        var t0 = new Date();

        // Init context
        var ctx = canvas.getContext("2d");
        ctx.setTransform(1, 0, 0, 1, 0, 0); // Reset transform
        ctx.fillStyle    = 'black';
        ctx.strokeStyle  = 'black';
        ctx.textBaseline = 'middle';
        ctx.textAlign    = 'center';
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        ctx.save();
        ctx.translate(0.5, 0.5);

        ctx.save();
        ctx.fillStyle = '#f0f0f0';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.restore();

        var rb_x0 = Math.floor(grid_x / rb_w);
        var rb_x1 = Math.min(Math.ceil((grid_x + width) / rb_w), this.max_x);

        // Draw frame/sub frame/time
        var time_height = this.time_height - (this.inter_cell >> 1);
        ctx.save();
        ctx.beginPath();
        ctx.rect(0, 0, rbc_width + width, time_height);
        ctx.clip();

        var frame_x0 = Math.floor(rb_x0 / maxSlotCount) * maxSlotCount;
        var frame_x1 = Math.floor(rb_x1 / maxSlotCount) * maxSlotCount;
        for (var rb_x = frame_x0; rb_x <= frame_x1; rb_x += maxSlotCount) {
            var x = rb_x * rb_w - grid_x + rbc_width;
            var f = rb_x / maxSlotCount;

            var hfn = (f / 1024) >> 0;
            var fn = (f - hfn * 1024) >> 0;
            ctx.save();
            if (x >= 0) {
                ctx.beginPath();
                ctx.moveTo(x, 0);
                ctx.lineTo(x, time_height);
                ctx.stroke();
            }

            var xt = Math.floor(x + maxSlotCount * rb_w / 2);

            // Time
            ctx.font = this.time_font_size + "px Arial";
            ctx.fillText(this.rb2time(rb_x), xt, time_height / 4);

            // hfn.fn.sfn
            ctx.font = Math.floor(this.time_font_size * 0.9) + "px Arial";
            ctx.fillText(hfn ? hfn + '.' + fn : fn, xt, time_height * 3 / 4);
            ctx.restore();
        }
        ctx.beginPath();
        ctx.rect(0, 0, rbc_width + width, time_height);
        ctx.moveTo(0, time_height);
        ctx.lineTo(rbc_width + width, time_height);
        ctx.stroke();
        ctx.restore();

        // Time
        var time = this.rb2time(frame_x0);
        this.timeSelector.setValue(time);

        var selectedLog = this._selectedLog;

        var stroke = rb_w > 3 && rb_h > 3;
        var font_rb_h = Math.max(7, Math.min(rb_w, rb_h, 16)) >> 0;

        var dy = -grid_y;

        // Draw each cell
        var cell_y = dy;
        dp.cell_y = null;
        ctx.save();
        ctx.translate(0, this.time_height);
        var displayed = 0;
        for (var c = 0; c < cell_count; c++, cell_y += cell_height + this.inter_cell) {
            var cell0 = cells[c];

            var nbiot = cell0.clientCell.rat === 'nbiot' && cell0.dir === 'dl';
            var nonanchor = cell0.clientCell.nonanchor == 1;
            var n_rb = cell0.n_rb;
            var cell_height = n_rb * rb_h;

            cell0.y0 = Math.max(0, cell_y);
            cell0.y1 = Math.min(cell_y + cell_height, height);
            if (cell0.y1 <= 0 || cell0.y0 >= height) {
                dy += cell_height + this.inter_cell;
                continue;
            }
            if (dp.cell_y === null) {
                dp.cell_y = cell0;
                dp.rb_y = Math.max(-cell_y / rb_h, 0);
            }

            // Cell draw
            ctx.save();
            ctx.beginPath();
            ctx.rect(0, cell0.y0, rbc_width + width, cell0.y1 - cell0.y0);
            ctx.clip();

            // Draw rb #
            if (rb_h > 2) {
                ctx.save();
                ctx.font = font_rb_h + "px Arial";
                ctx.strokeStyle = 'white';
                for (var rb_y = 0; rb_y < n_rb; rb_y++) {
                    var y = cell_y + rb_y * rb_h;
                    ctx.beginPath();
                    ctx.moveTo(rbc_width, y);
                    ctx.lineTo(rbc_width + width, y);
                    ctx.stroke();
                    if (rb_y % Math.ceil(font_rb_h / rb_h) === 0)
                        ctx.fillText(n_rb - rb_y - 1, rbc_width >> 1, y + rb_h / 2);
                }
                ctx.restore();
            }

            // Clip on RB area
            ctx.beginPath();
            ctx.rect(rbc_width, cell0.y0, width, cell0.y1 - cell0.y0);
            ctx.stroke();
            ctx.clip();

            // Draw vert lines
            ctx.save();
            var cell_x0 = Math.floor(rb_x0 / cell0.slotRatio) * cell0.slotRatio;
            var cell_x1 = Math.ceil(rb_x1 / cell0.slotRatio) * cell0.slotRatio;
            for (var rb_x = cell_x0; rb_x <= cell_x1; rb_x += cell0.slotRatio) {
                var x = rb_x * rb_w - grid_x + rbc_width;
                var f = rb_x / cell0.slotRatio;

                ctx.beginPath();
                ctx.moveTo(x, cell_y);
                ctx.lineTo(x, cell_y + cell_height);
                if (rb_x % maxSlotCount) {
                    ctx.strokeStyle = 'white';
                } else {
                    ctx.strokeStyle = 'black';
                }
                ctx.stroke();
            }
            ctx.restore();

            //Draw invalid SF in the background
            if ((((cell0.dir === 'dl'  || cell0.dir === 'both') && cell0.clientCell.br_dl_sf_bitmap !== undefined)
                 || nbiot)
                && this.showDlValidSf) {

                ctx.save();
                ctx.fillStyle = lteLogs.getChannelDefByName('INV').color;
                for (var rb_x = rb_x0; rb_x <= rb_x1; rb_x++) {
                    var x = rb_x * rb_w - grid_x + rbc_width;
                    var f = rb_x / cell0.slotRatio;
                    
                    if (nbiot) {
                        var type = this._nbIoT_sfType(f);
                        var invalid = false;
                        if (cell0.clientCell.nb_dl_sf_bitmap !== undefined)
                            invalid = cell0.clientCell.nb_dl_sf_bitmap.charAt(f % 40) === '0';
                    
                        if ((!nonanchor && type) || invalid) {
                            ctx.fillRect(x+1, cell_y + 1, rb_w-1, cell_height-1);
                        }
                    }
                    else if (cell0.clientCell.br_dl_sf_bitmap.charAt(f%40) === '0') {
                        ctx.beginPath();
                        ctx.fillRect(x+1, cell_y + 1, rb_w-1, cell_height-1);
                    }
                }
                ctx.restore();
            }

            // Draw RB
            ctx.save();

            ctx.textBaseline = 'top';
            ctx.globalAlpha = 1 / cell0.toDraw.length;
            var rbs = [];

            cell0.toDraw.forEach( (cell) => {
                var rb_list = cell.rb_list.slice();

                var rb_list_draw = cell.rb_list_draw;

                cell.y0 = cell0.y0;
                cell.y1 = cell0.y1;

                if (cell.dir === 'dl' || cell.dir === 'both') {
                    cell.ssb.forEach( (ssb) => {
                        /* convert ssb.period and ssb.offset (ms) to unified slots */
                        var period = ssb.period * maxSlotCount / 10;
                        var offset = ssb.offset * maxSlotCount / 10;
                        var base = Math.floor(rb_x0 / period) * period;
                        var ssb_ratio = (1 << cell.clientCell.dl_mu) / (1 << ssb.mu);
                        var y0 = ssb.prb[0]; /* Note: could use k_ssb but more complicated */
                        var y1 = y0 + ssb.prb[1];
                        for (var rb_x = base + offset; rb_x <= rb_x1; rb_x += period) {
                            for (var i = 0; i < ssb.symb.length; i++) {
                                var symb = ssb.symb[i];
                                rb_list.push({
                                    x0: rb_x / cell.slotRatio + (symb / 14) * ssb_ratio,
                                    x1: rb_x / cell.slotRatio + ((symb + 4) / 14) * ssb_ratio,
                                    y0: y0,
                                    y1: y1,
                                    chanDef: lteLogs.channelsDef.SSB,
                                    ssb: ssb,
                                });
                            }
                        }
                    });
                }

                ctx.beginPath();
                ctx.rect(rbc_width, cell_y, width, cell_height);
                ctx.stroke();
                ctx.clip();
                for (var i = 0; i < rb_list.length; i++) {
                    var rb = rb_list[i];
                    var x0 = rb.x0 * cell.slotRatio;
                    var x1 = rb.x1 * cell.slotRatio;

                    if (x0 > rb_x1 || x1 <= rb_x0)
                        continue;

                    var x0 = Math.max(rb_x0, x0) * rb_w - grid_x + rbc_width;
                    var x1 = Math.min(rb_x1, x1) * rb_w - grid_x + rbc_width;
                    var y0 = cell_y + (n_rb - rb.y1) * rb_h;
                    var y1 = cell_y + (n_rb - rb.y0) * rb_h;

                    // Skip
                    if (x0 >= x1 || y0 >= y1) continue;

                    rb_list_draw.push(rb);
                    rb.draw_x0 = x0;
                    rb.draw_x1 = x1;
                    rb.draw_y0 = y0;
                    rb.draw_y1 = y1;

                    var pattern = rb.pattern;
                    var log = rb.log;
                    if (log) {
                        if (log.ack)
                            pattern = 'point';
                        if (log.hasError())
                            pattern = 'hash';
                        if (log === selectedLog)
                            rbs.push(rb);
                        else
                            rbs.unshift(rb);
                    }
                    this._drawRb(ctx, rb.chanDef, x0, y0, x1 - x0, y1 - y0, pattern);
                }
            });
            ctx.restore();

            ctx.save();
            rbs.forEach(function (rb) {
                if (rb.log === selectedLog) {
                    ctx.strokeStyle = 'black';
                    ctx.lineWidth = 2;
                } else if (stroke) {
                    ctx.lineWidth = 1;
                    ctx.strokeStyle = '#606060';
                }
                ctx.strokeRect(rb.draw_x0, rb.draw_y0, rb.draw_x1 - rb.draw_x0, rb.draw_y1 - rb.draw_y0);
            });
            ctx.restore();
            // Draw RB end

            ctx.restore();
        }
        ctx.restore();

        ctx.restore();

        //console.log("Update", 'rb', rb_count, 'width:', width, 'height:', height, '/', max_height, 'x:', grid_x, 'y:', grid_y, 'w:', rb_w, 'h:', rb_h, 'render', new Date() - t0, "ms");
        this.prof("Draw RB in", new Date() - t0, "ms");
    },

    _getRBs: function (event) {
        var canvas = event.target;
        var rect = canvas.getBoundingClientRect();
        var x = event.clientX - rect.left - 1;
        var y = event.clientY - rect.top - this.time_height - 2;

        var list = [];
        for (var c = 0; c < this.drawCells.length; c++) {
            var cell = this.drawCells[c];

            if (y < cell.y0 || y > cell.y1) continue;

            var rb_list_draw = cell.rb_list_draw;
            for (var i = 0; i < rb_list_draw.length; i++) {
                var rb = rb_list_draw[i];
                if (x >= rb.draw_x0 && x < rb.draw_x1 && y >= rb.draw_y0 && y < rb.draw_y1)
                    list.push(rb);
            }
        }
        return list;
    },

    // Scroll
    _zoom: function (offset, w) {

        offset = offset / Math.abs(offset);
        if (w) {
            this.rb_w += offset;
            this._drawPos.keep_x = true;
        } else {
            this.rb_h += offset;
            this._drawPos.keep_y = true;
        }
        this._update();
    },

    // Wheel: zoom in/out
    _mouseWheelEvent: function (event) {
        this._zoom(lteLogs.getMouseWheelDelta(event), event.shiftKey);
    },

    // Down
    _mouseDownEvent: function (event) {
        if (event.button === 0) {
            this._move = {
                x:    event.clientX + this.grid_x,
                y:    event.clientY + this.grid_y,
                x0:   event.clientX,
                y0:   event.clientY,
            };
            lteLogs.registerMouseMove((function (event1) {
                switch (event1.type) {
                case 'mouseup':
                    this._move = undefined;
                    break;
                case 'mousemove':
                    if (this._mouseMoveTest(event1)) {
                        this.grid_x = this._move.x - event1.clientX;
                        this.grid_y = this._move.y - event1.clientY;
                        this._update();
                    }
                    break;
                }
                event1.preventDefault();
            }).bind(this));
        }
        event.preventDefault();
    },

    // Move
    _mouseMoveEvent: function (event) {
        if (!this._move) {
            var rbs = this._getRBs(event);
            if (rbs.length) {
                var info = rbs.map( (rb) => {
                    if (rb.log)
                        return rb.log.getToolTip();
                    if (rb.ssb)
                        return 'SSB #' + rb.ssb.id;
                    return '?';
                });
                if (info.length > 5) {
                    this._toolTip.update(info.slice(0, 5).join('<br/><br/>') + '<br/>...');
                } else {
                    this._toolTip.update(info.join('<br/><br/>'));
                }
                this._toolTip.show([event.clientX, event.clientY]);
            } else {
                this._toolTip.hide();
            }
        }
    },

    // Out
    _mouseOutEvent: function (event) {
        //this._move = undefined;
        this._toolTip.hide();
    },

    _mouseMoveTest: function (event) {
        return Math.abs(event.clientX - this._move.x0) > 2 || Math.abs(event.clientY - this._move.y0) > 2;
    },

    // Up
    _mouseUpEvent: function (event) {
        if (event.button === 0 && (!this._move || !this._mouseMoveTest(event))) {
            var rbs = this._getRBs(event);
            for (var i = 0; i < rbs.length; i++) {
                var log = rbs[i].log;
                if (log) {
                    if (this._selectedLog !== log) {
                        this._selectedLog = log;
                        this._update();
                    }
                    lteLogs.selectLog(log);
                    break;
                }
            }
        }
    },

    show3D: function () {
    
        var x = [];
        var y = [];
        var z = [];

                var cx = Array(25);
                for (var j = 0; j < 25; j++) {
                    cx[j] = j;
                }

        var cells = this.cells;
        for (var cell_id in cells) {
            var cell = cells[cell_id];
            if (!cell.state) continue;

            var rb_list = cell.rb_list;
            for (var i = 0; i < rb_list.length; i++) {
                var rb = rb_list[i];

                var cz = Array(25);
                for (var j = 0; j < 25; j++) {
                    cz[j] = 0;
                }

                for (var j = rb.y0; j < rb.y1; j++) {
                    cz[j] = 1;
                }

                x.push(cx);
                y.push(rb.x0);
                z.push(cz);
            }
            break;
        }

        Plotly.newPlot('myDiv', [{
            x: x,
            y: y,
            z: z,
            type: 'surface',
            showscale: false
        }], {
            autosize: true,
            //showlegend: false,
            /*scene: {
            xaxis: {title: 'Sample #'},
            yaxis: {title: 'Wavelength'},
            zaxis: {title: 'OD'}
              }*/
        });
    }
});


Ext.define('lte.cell.config', {

    title: 'Configure cell',
    extend: 'Ext.window.Window',
    layout: 'fit',
    resizeable: false,
    width: 600,
    modal: true,

    cellConfigured: false,

    constructor: function () {
        this.callParent(arguments);
    },

    initComponent: function () {
        this.callParent(arguments);

        var cell_id = this.cell_id;
        var cell = this.client.getCell(cell_id);

        if (!cell.mode)
            cell.mode = 'FDD';

        // Try to guess
        var logs = this.logs;
        var mu = cell.dl_mu;
        var rb = cell.n_rb_dl;
        for (var i = 0, length = logs.length; i < length; i++) {
            var log = logs[i];
            if (log.layer !== 'PHY') continue;
            if (log.dir === DIR_NONE) continue;
            if (log.cell !== cell_id) continue;

            if (log.slot > 80) mu = Math.max(mu, 160);
            else if (log.slot > 40) mu = Math.max(mu, 3);
            else if (log.slot > 20) mu = Math.max(mu, 2);
            else if (log.slot > 10) mu = Math.max(mu, 1);

            var prb = log.getPRB();
            if (prb) {
                prb.forEach(function (rb1) { rb = Math.max(rb, rb1.start + rb1.len); });
            } else if (log.rb_start !== undefined && log.l_crb) {
                rb = Math.max(rb, log.rb_start + log.l_crb);
            }
        }

        var fields = [{
            fieldLabel: 'Mode',
            xtype: 'radiogroup',
            name: 'mode',
            items: [
                { boxLabel: 'FDD', name: 'mode', inputValue: 'FDD', checked: cell.mode === 'FDD' },
                { boxLabel: 'TDD', name: 'mode', inputValue: 'TDD', checked: cell.mode === 'TDD' },
            ],
        }, {
            xtype: 'numberfield',
            name: 'n_rb',
            fieldLabel: 'RBs',
            value: rb,
            allowDecimals: false,
            minValue: 6,
            maxValue: 275,
            width: '100%',
            step: 1,
        }, {
            xtype: 'combobox',
            value: mu,
            fieldLabel: 'Subcarrier spacing',
            name: 'dl_mu',
            queryMode: 'local',
            valueField: 'value',
            displayField: 'text',
            store: Ext.create('Ext.data.Store', {
                data: [
                    { value: 0, text: '15 KHz' },
                    { value: 1, text: '30 KHz' },
                    { value: 2, text: '60 KHz' },
                    { value: 3, text: '120 KHz' },
                    { value: 4, text: '240 KHz' },
                ],
                fields: ['value', 'text']
            }),
        }];

        var form = Ext.create('Ext.form.Panel', {
            bodyPadding: 5,
            items: fields,
            buttons: [{
                text: 'OK',
                scope: this,
                handler: function() {
                    if (form.isValid()) {
                        var config = form.getForm().getFieldValues();


                        this.cellConfigured = true,

                        cell.dl_mu = cell.ul_mu = config.dl_mu;
                        cell.mode = config.mode;
                        cell.n_rb_dl = cell.n_rb_ul = config.n_rb;
                        this.client.saveCell(cell);

                        this.close();
                    }
                }
            }]
        });

        this.add(form);
    },
});

