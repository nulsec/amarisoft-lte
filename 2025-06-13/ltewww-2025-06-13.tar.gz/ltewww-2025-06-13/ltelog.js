/*
 * Copyright (C) 2020-2025 Amarisoft
 *
 * Amarisoft Web interface 2025-06-13
 */

LTELog.prototype._getDCI = function (logList, index, dci_dir, k)
{
    var cell = this.getCell();
    var nslots = cell.getSlotCount();
    var maxFrameDiff = 10;

    // look in both sides
    for (var step = -1; step < 2; step += 2) {

        var limit = this.timestamp * step + maxFrameDiff*10;
        for (var i = index + step; ; i += step) {

            var log = logList[i];
            if (!log || log.timestamp * step >= limit) break;

            var c = log.getCell();
            if (c !== cell) continue;
            if (log.channel !== PDCCH) continue;
            if (log.ue_id !== this.ue_id) continue;
            if (!log[dci_dir]) continue;

            var slot = log.slot;
            var frame = log.frame;

            var so = log[k];
            /* LTE DCI 0 grant */
            if (so === undefined && dci_dir === 'dci_ul')
                so = 4;
            if (so !== undefined) {
                slot += so;
                while (slot >= nslots) {
                    slot -= nslots;
                    frame++;
                }
            }

            //console.log(this.frame, this.slot, log.frame, log.slot, frame, slot, k, nslots, log, log[k]);
            if (this.frame === frame && this.slot === slot) {
                return log;
            }
            if (Math.abs(log.frame - frame) > maxFrameDiff) break;
        }
    }
    return null;
};

LTELog.prototype._getAckNackLog = function (logList, index, k1)
{
    var slot = this.slot + k1;
    var frame = this.frame;
    var cell = this.getCell();
    var nslots = cell.getSlotCount();
    var maxFrameDiff = 10;
    while (slot >= nslots) {
        slot -= nslots;
        frame++;
    }

    var limit = this.timestamp + maxFrameDiff*10;
    for (var i = index + 1;; i++) {
        var log = logList[i];
        if (!log || log.timestamp >= limit) break;

        if (log.channel !== PUCCH && log.channel !== PUSCH) continue;
        if (log.ue_id !== this.ue_id) continue;
        if (log.getCell() !== cell) continue;
        if (log.ack === undefined) continue;

        if (log.frame === frame && log.slot === slot) {
            return log;
        }
        if (log.frame > frame) break;
    }
};

LTELog.prototype._addPDSCHForAckNack = function (logList, index, aLogs)
{
    var maxFrameDiff = 10;
    var limit = this.timestamp - maxFrameDiff*10;
    var cell = this.getCell();

    for (var i = index; i--;) {
        var log = logList[i];
        if (!log || log.timestamp < limit) break;

        if (log.channel !== PDSCH) continue;
        if (log.ue_id !== this.ue_id) continue;
        if (log.getCell() !== cell) continue;
        if (log.k1 === undefined) continue;

        var an_log = log._getAckNackLog(logList, i, log.k1);
        if (an_log && an_log.index == index)
            aLogs.push(log);
        if (an_log && an_log.frame < this.frame)
            break;
    }
};
    
LTELog.prototype.getAssociatedLogs = function (logList, index)
{
    var aLogs = this._aLogs;
    if (aLogs !== undefined)
        return aLogs;

    if (index === undefined)
        index = logList.indexOf(this);

    this._aLogs = aLogs = [];

    switch (this.channel) {
    case PDSCH:
        var dci = this._getDCI(logList, index, 'dci_dl', 'k0');
        if (dci) {
            aLogs.push(dci);
            if (this.k1 !== undefined) {
                var an_log = this._getAckNackLog(logList, index, this.k1);
                if (an_log)
                    aLogs.push(an_log);
            }
        }
        break;
    case PUSCH:
        var dci = this._getDCI(logList, index, 'dci_ul', 'k2');
        if (dci) {
            aLogs.push(dci);
            if (this.ack !== undefined) {
                this._addPDSCHForAckNack(logList, index, aLogs);
            }
        }
        break;
    case PUCCH:
        if (this.ack !== undefined) {
            this._addPDSCHForAckNack(logList, index, aLogs);
        }
        break;
    }
    return aLogs;
};

