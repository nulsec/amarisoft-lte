/*
 * Copyright (C) 2017-2025 Amarisoft
 */
Ext.define('lte.monitor.tab', {

    extend: 'lte.client.tab',
    layout: 'fit',

    _chartList: [],

    noMonitor: true,

    constructor: function (config) {
        this.callParent(arguments);
    },

    initComponent: function () {
        this.callParent(arguments);

        this._updater = Ext.create("lte.updater", {
            scope:            this,
            updateDelay:    1000,
            dirty:            true,
            lock:            1,
            handler:        function () {
                if (!this.compGrid) {
                    this.client.sendMessage({message: 'state_get'}, (function (msg) {
                        this.hostname = msg.hostname;
                        this.createGrid(msg.custom_definition || []);
                        this.setComponents(msg.components);
                    }).bind(this));
                }
            }
        });

        this.client.setMessageHandler(['components'], (function (msg) {
            this.setComponents(msg.components);
        }).bind(this));

    },

    createGrid: function (custom) {

        this.nodeList = [];
        this.groupNodes = {};

        var createButton = function (action, icon, title) {
            return "<span style='float: left; background-size: 10px;' data-action='" + action + "' class='x-btn x-tree-icon icon-" + icon + "' title='" + title + "'></span>";
        };

        var commonRenderer = (function (value) {
            if (this.rendererRegExp) {
                value = ('' + value).replace(this.rendererRegExp, '<highlight>$1</highlight>');
            }

            return value;
        }).bind(this);

        var columns = [{
            xtype: 'treecolumn',
            text: 'Name',
            width: 220,
            dataIndex: 'name',
            renderer: commonRenderer,
        }, {
            text: 'State',
            width: 40,
            dataIndex: 'state',
            getClass: function (state, meta, rec, rowIndex, colIndex, store) {
                return state ? 'icon-ok' : 'icon-off';
            },
            renderer: function (state, md) {
                var icon = ({
                    connected: 'ok',
                    disconnected: 'no',
                    started: 'lightning-green',
                    starting: 'lightning',
                    stopped: 'lightning-red',
                    disabled: 'off',
                    error: 'error',
                })[state];
                if (!icon) return '&nbsp;';
                return "<center><img src='data:image/gif;base64,R0lGODlhAQABAID/AMDAwAAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==' class='x-tree-icon icon-" + icon + "' title='" + state + "'></center>";
            },
        }, {
            text: 'Version',
            width: 110,
            dataIndex: 'version',
            renderer: commonRenderer,
        }, {
            text: 'Address',
            width: 110,
            dataIndex: 'address',
            renderer: commonRenderer,
        }, {
            text: 'Info',
            flex: 1,
            minWidth: 100,
            dataIndex: 'info',
            renderer: commonRenderer,
        }];

        var fields = [
            'comp', 'state', 'name', 'version', 'info',
            {
                name: 'address',
                sortType: function (addr) {
                    var ip = addr.split('.');
                    return (ip[0] | 0) * 16777216 +
                           (ip[1] | 0) * 65536 +
                           (ip[2] | 0) * 256 +
                           (ip[3] | 0);
                },
            },
        ];

        var groups = [
            { value: '',        text: 'None' },
            { value: 'state',   text: 'State' },
            { value: 'version', text: 'Version' },
            { value: 'info',    text: 'Info' },
        ];

        if (custom instanceof Array) {
            var customFields = this.customFields = [];
            custom.forEach(function (c) {
                if (c.id) {
                    var text = c.title || c.id;
                    columns.push({
                        text: text,
                        flex: 1,
                        minWidth: 100,
                        dataIndex: c.id,
                        renderer: function (txt) {
                            if (typeof txt === 'string') {
                                txt = commonRenderer(txt);
                                return txt.replace(/(https?:\/\/[^\s]+)/g,"<a href='$1' target='_blank' >$1</a>");
                            }
                            return '&nbsp;';
                        },
                    });
                    fields.push(c.id);
                    customFields.push(c.id);
                    groups.push({ value: c.id, text: text });
                }
            });
        }

        // Toolbar
        this.groupByWidget = Ext.create('Ext.form.field.ComboBox', {
            fieldLabel: 'Group by',
            queryMode: 'local',
            valueField: 'value',
            displayField: 'text',
            multiSelect: false,
            forceSelection: true,
            width: 200,
            labelWidth: 80,
            labelAlign: 'right',
            labelSeparator: '',
            store: Ext.create('Ext.data.Store', {
                fields: ['value', 'text'],
                data: groups
            }),
            listeners: {
                scope: this,
                change: function(combo, newValue, oldValue, eOpts) {
                    if (combo.isValid()) {
                        this.updateComponents();
                    }
                },
            }
        });

        this.filterWidget = Ext.create('Ext.form.field.Text', {
            fieldLabel: 'Filter',
            labelWidth: 50,
            labelAlign: 'right',
            labelSeparator: '',
            validator: function (value) {
                try {
                    var re = new RegExp(value);
                    return true;
                } catch (e) {
                    return false;
                }
            },
            listeners: {
                scope: this,
                change: function(combo, newValue, oldValue, eOpts) {
                    try {
                        this.filterNodes(newValue);
                    } catch (e) {
                        this.filterNodes(null);
                    }
                },
            }
        });

        this.tbar.add(this.groupByWidget, this.filterWidget);

        var store = Ext.create('Ext.data.TreeStore', {
            fields: fields,
            root: {name: 'Hosts', children: []},
        });

        this.hStatsPanel = Ext.create('Ext.panel.Panel', {
            border: 0,
            padding: 2,
            bodyStyle: 'font-size:14px;',
            html: ''
        });
        this.cStatsPanel = Ext.create('Ext.panel.Panel', {
            border: 0,
            padding: 2,
            bodyStyle: 'font-size:14px;',
            html: ''
        });

        this.compGrid = Ext.create('Ext.tree.Panel', {
            store: store,
            rootVisible: false,
            useArrows: true,
            tbar: [this.hStatsPanel, '|', this.cStatsPanel],
            viewConfig: {
                markDirty: false,
                enableTextSelection: true,
            },
            columns: columns,
            listeners: {
                scope: this,
                cellcontextmenu: function(myGrid, td, cellIndex, record, tr, rowIndex, e, eOpts) {
                    var comp = record.get('comp');
                    if (!comp) return;

                    var items = [];
                    var host = comp.host;
                    if (host) {
                        // Component
                        if (comp.address) {
                            this.createMenuContext(items, comp, 'Show logs', 'logs', 'logs');
                        }
                        this.createMenuContext(items, comp, 'Download config file', 'download', 'config-file-get');
                        this.createMenuContext(items, comp, 'Upload config file', 'save', 'config-file-set');
                        if (comp.state === 'disabled')
                            this.createMenuContext(items, comp, 'Enable', 'ok', 'comp-enable');
                        else
                            this.createMenuContext(items, comp, 'Disable', 'off', 'comp-disable');
                    } else {
                        this.createMenuContext(items, comp,
                            comp.alarmMuted ? 'Enable alarms' : 'Disable alarms',
                            comp.alarmMuted ? 'nomail' : 'mail', 'alarm-toggle');
                        switch (comp.state) {
                        case 'disconnected':
                            this.createMenuContext(items, comp, 'Remove host', 'delete', 'remove-host');
                            break;
                        case 'connected':
                            this.createMenuContext(items, comp, 'Upload license', 'save', 'license-set');
                            items.push({xtype: 'menuseparator'});
                            this.createMenuContext(items, comp, 'Restart service', 'refresh', 'restart-service');
                            this.createMenuContext(items, comp, 'Restart monitor', 'refresh', 'restart-host');
                            this.createMenuContext(items, comp, 'Reboot host', 'off', 'reboot-host');
                            this.createMenuContext(items, comp, 'Software upgrade (experimental)', 'sync', 'software-upgrade');

                            items.push({xtype: 'menuseparator'});
                            var comp = this.components[comp.id];
                            var disable = false;
                            var enable  = false;
                            for (var id in comp) {
                                if (id === '_info_') continue;
                                if (comp[id].state === 'disabled') disable = true;
                                else                               enable = true;
                            }
                            if (disable) this.createMenuContext(items, comp, 'Enable all components', 'ok', 'comp-enable');
                            if (enable)  this.createMenuContext(items, comp, 'Disable all components', 'off', 'comp-disable');
                            break;
                        }

                        lteLogs.comp = this;
                    }

                    var menu = new Ext.menu.Menu({items: items});
                    var position = e.getXY();
                    e.stopEvent();
                    menu.showAt(position);
                },
            }
        });

        this.add(this.compGrid);
    },

    createMenuContext: function (items, comp, text, icon, action) {
        items.push({
            text: text,
            scope: this,
            iconCls: 'icon-' + icon,
            handler: this.compAction.bind(this, comp, action),
        });
    },

    compAction: function (comp, action) {

        switch (action) {
        case 'logs':
            var storeId = comp.host.id + '-' + comp.id;
            var client = lteLogs.getClientById(storeId);
            if (client) {
                client.setEnabled(true);
            } else {
                lteLogs.addClient({
                    name: comp.host.id + '/' + comp.name,
                    address: comp.address + ':' + comp.port,
                    type: 'server',
                    storeId: storeId,
                    locked: true,
                    enabled: true,
                }, ['removable', 'persistent']);
                lteLogs.saveConfig();
            }
            break;
        case 'remove-host':
            this.sendMessage({message: action, host: comp.id});

            var root = this.compGrid.getRootNode();
            for (var hostNode = root.firstChild; hostNode; hostNode = hostNode.nextSibling) {
                if (hostNode.get('comp') === comp) {
                    hostNode.remove();
                    return;
                }
            }
            break;
        case 'alarm-toggle':
        case 'restart-host':
            this.sendMessage({message: action, host: comp.id});
            break;
        case 'comp-disable':
            if (comp.host) this.sendMessage({message: 'comp-autostart', autostart: 'n', comp: comp.id, host: comp.host.id});
            else           this.sendMessage({message: 'comp-autostart', autostart: 'n', host: comp._info_.id});
            break;
        case 'comp-enable':
            if (comp.host) this.sendMessage({message: 'comp-autostart', autostart: 'y', comp: comp.id, host: comp.host.id});
            else           this.sendMessage({message: 'comp-autostart', autostart: 'y', host: comp._info_.id});
            break;
        case 'restart-service':
            Ext.Msg.show({
                title: 'Restart service',
                icon: Ext.Msg.WARNING,
                message: 'Do you want to restart service on ' + comp.id + ' ?',
                scope: this,
                buttons: Ext.Msg.YESNO,
                callback: function (btn) {
                    if (btn === 'yes')
                        this.sendMessage({message: action, host: comp.id});
                }
            });
            break;
        case 'reboot-host':
            Ext.Msg.show({
                title: 'Reboot system',
                icon: Ext.Msg.WARNING,
                message: 'Do you want to reboot ' + comp.id + ' ?',
                scope: this,
                buttons: Ext.Msg.YESNO,
                callback: function (btn) {
                    if (btn === 'yes')
                        this.sendMessage({message: action, host: comp.id});
                }
            });
            break;
        case 'license-set':
            lteLogs.loadFile({
                cb: function (files) {
                    if (!files)
                        return;

                    var msg = {
                        message: 'license-set',
                        host: comp.id,
                        licenses: files,
                    };
                    this.sendMessage(msg, function (msg) {
                        if (!msg.files || !msg.files.length) {
                            Ext.Msg.alert('Licenses not uploaded', 'No license found');
                        } else {
                            Ext.Msg.alert('Licenses uploaded', msg.files.join('<br/>'));
                        }
                    });
                },
                scope: this,
                type: 'base64',
                multiple: true
            });
            break;
        case 'software-upgrade':
            this.softwareUpgradePrepare(comp.id);
            break;
        case 'config-file-get':
            this.sendMessage({message: 'config-file-get', host: comp.host.id, comp: comp.id}, function (msg) {
                var file = msg.file || (comp.host.id + '-' + comp.id + '-' + comp.name + '.cfg');
                lteLogs.exportFile(msg.config, file, 'text/plain');
            });
            break;
        case 'config-file-set':
            lteLogs.loadFile({
                cb: function (files) {
                    if (!files) return;

                    Ext.Msg.show({
                        title: 'Upload new configuration on ' + comp.host.name,
                        icon: Ext.Msg.WARNING,
                        message: 'Do you want to use ' + files[0].name + ' as new configuration for ' + comp.name + ' ?',
                        scope: this,
                        buttons: Ext.Msg.YESNO,
                        callback: function (btn) {
                            if (btn !== 'yes') return;

                            var msg = {
                                message: 'config-file-set',
                                host: comp.host.id,
                                comp: comp.id,
                                file: files[0].name,
                                config: new TextDecoder().decode(files[0].data),
                            };
                            this.sendMessage(msg);
                        }
                    });
                },
                scope: this
            });
            break;
        default:
            return;
        }
        this.compGrid.view.refresh();
    },

    softwareUpgradePrepare: function (host) {
        lteLogs.loadFile({
            cb: function (files) {
                if (!files)
                    return;

                this.setLoading(true);
                this.client.sendMessageBin(
                    {
                        file: 'tmp-' + files[0].name,
                        message: 'software-upgrade-prepare',
                        host: host,
                    },
                    files[0].data,
                    (function (msg) {
                        this.setLoading(false);
                        if (msg.error)
                            return Ext.Msg.alert('Error', msg.error.replace(/\n/g, '<br/>'));

                        this.softwareUpgradeConfigure(msg, host);
                    }).bind(this),
                    true
                );
            },
            scope: this
        });
    },

    softwareUpgradeConfigure: function (msg, host) {

        var argsField = Ext.create('Ext.form.field.Text', {
            fieldLabel: 'Arguments:',
            width: '100%',
            labelAlign: 'left',
            labelSeparator: '',
            autoScroll: true,
            bodyPadding: 5,
            border: false,
        });

        var term;

        var cancel = Ext.create('Ext.Button', {
            tooltip: lteLogs.tooltip('Cancel upgrade'),
            text: 'Cancel',
            handler: function () {
                win.close();
            }
        });

        var check = Ext.create('Ext.Button', {
            tooltip: lteLogs.tooltip('Check command line arguments'),
            text: 'Check',
            scope: this,
            handler: function () {
                var args = argsField.getValue().split(/\s+/);
                win.setLoading(true);
                this.client.sendMessage({ message: 'software-upgrade-check', args: args, host: host }, (function (msg) {
                        win.setLoading(false);
                        term.reset();
                        if (msg.error)
                            term.write(msg.error);
                        else
                            term.write(msg.output);
                    }).bind(this),
                    true);
            }
        });

        var start = Ext.create('Ext.Button', {
            tooltip: lteLogs.tooltip('Start upgrade'),
            text: 'Start',
            scope: this,
            handler: function () {
                var args = argsField.getValue().split(/\s+/);
                win.setLoading(true);
                this.client.sendMessage({ message: 'software-upgrade-start', args: args, host: host }, (function (msg) {
                        if (msg.error)
                            term.write(msg.error);
                        else
                            win.close();
                    }).bind(this),
                    true);
            }
        });

        var win = Ext.create('Ext.window.Window', {
            title: 'Upgrade to ' + msg.version,
            width: 800,
            height: 700,
            layout: 'fit',
            modal: true,
            bbar: [
                cancel,
                '->',
                check,
                start,
            ],
            listeners: {
                scope: this,
                close: function () {
                    this.client.removeComponent('software-upgrade', true);
                },
            }
        });
        win.add({
            bbar: [argsField],
            layout: 'fit',
            bodyCls: 'term',
            border: false,
            listeners: {
                scope: this,
                resize: function(cont, width, height) {
                    if (!term) {
                        term = new Term({
                            buffer_size: 1000,
                            handler: function (str) {
                            }
                        });
                        term.setParent(cont.body.el.dom);
                        term.resize(width, height);
                        term.write(msg.output);
                        term.show();
                        term.setScroll(true);
                    } else {
                        term.resize(width, height);
                    }
                },
            }
        });
        win.show();

        this.client.addComponent('software-upgrade', win);
    },

    sendMessage: function (msg, cb) {

        this.setLoading(true);
        this.client.sendMessage(msg, (function (msg) {
            this.setLoading(false);
            if (msg.error)
                Ext.Msg.alert('Error', msg.error);
            else if (cb)
                cb.call(this, msg);
        }).bind(this), true);
    },

    // Transform host from remote API to store format
    updateHost: function (host0, id) {

        var host = host0._info_ || {};

        host.id = id;
        host.host = null; // Host
        if (!host.name)
            host.name = id;
        if (!host.address)
            host.address = this.client.config.address.replace(/:\d+$/,'');

        // Info
        var info = [];
        if (host.osname)
            info.push(host.osname);
        host.info = info.join(', ');

        return host;
    },

    updateNode: function (node, comp, host) {

        if (host) {
            comp.address = host.address;
            comp.host = host;
        }

        var values = {
            comp: comp,
            state: comp.state,
            version: comp.version || '',
            address: comp.address || '',
        };

        var info = comp.info;
        if (typeof info === 'object' && info !== null) {
            values.info = Object.keys(info).map(function (id) { return id + '="' + info[id] + '"'; }).join(', ');
        } else {
            values.info = info || '';
        }

        if (this.customFields) {
            this.customFields.forEach(function (id) {
                var v = comp.custom && comp.custom[id] ? comp.custom[id] : '';
                values[id] = v;
                comp[id] = v;
            });
        }
        node.set(values, { silent: true });
    },

    filterNodes: function (filter) {
        if (filter) {
            this.componentsFilter = new RegExp(filter);
            this.rendererRegExp = new RegExp("(" + filter + ")", 'g');
        } else {
            this.componentsFilter = null;
            this.rendererRegExp = null;
        }
        this.updateComponents();
    },

    setComponents: function (components) {
        this.components = components;
        this.updateComponents();
    },

    filterComponent: function (comp) {
        return !this.checkValues(comp, ['name', 'info', 'state', 'version', 'address']) &&
            !this.checkValues(comp, this.customFields);
    },

    filterHost: function (host) {
        var custom = host._info_.custom;
        if (custom) {
            if (this.checkValues(custom, Object.keys(custom)))
                return false;
        }
        return !this.checkValues(host._info_, ['name', 'info', 'state', 'version', 'address']) &&
            !this.checkValues(host._info_, this.customFields);
    },

    checkValues: function (o, list) {
        for (var i = 0; i < list.length; i++) {
            var v = o[list[i]];
            switch (typeof v) {
            case 'string':
                if (v.match(this.componentsFilter)) {
                    return true;
                }
                break;
            }
        }
        return false;
    },

    updateComponents: function () {

        var grid = this.compGrid;
        if (!grid) return;

        var root = grid.getRootNode();

        // Filter
        if (this.componentsFilter) {
            var components = {};
            for (var h in this.components) {
                var host0 = this.components[h];
                var host1 = {};

                for (var c in host0) {
                    if (!this.filterComponent(host0[c]))
                        host1[c] = host0[c];
                }

                if (Object.keys(host1).length || !this.filterHost(host0)) {
                    host1._info_ = host0._info_;
                    components[h] = host1;
                }
            }
        } else {
            var components = this.components;
        }

        // Remove/Update hosts
        var hostFound = {};

        this.nodeList = this.nodeList.filter( (hostNode) => {

            var host0 = hostNode.get('comp');
            var id    = host0.id;
            var host1 = components[id];

            var hostNode1 = hostNode;
            hostNode = hostNode.nextSibling; // May be removed

            if (!host1) {
                hostNode1.remove();
                return false;
            }

            host1 = hostFound[id] = this.updateHost(host1, id)

            // Auto expand/collapse
            if (host1.state !== host0.state) {
                setTimeout( (function (h, n) {
                    if (h.state === 'connected') {
                        if (!n.isExpanded()) n.expand();
                    } else {
                        if (n.isExpanded()) n.collapse();
                    }
                }).bind(this, host1, hostNode1), 10);
            }

            // Update
            this.updateNode(hostNode1, host1);
            return true;
        });

        // Add hosts
        for (var id in components) {
            if (hostFound[id]) continue; // Already exists

            var host = this.updateHost(components[id], id);
            var node = root.appendChild({
                expanded: host.state === 'connected',
                iconCls: 'icon-home',
                name: host.name,
                comp: host,
            }, true);
            this.updateNode(node, host);
            this.nodeList.push(node);
        }

        var groupBy = this.groupByWidget.getValue();

        // Update components
        this.nodeList.forEach( (hostNode) => {

            var host0 = hostNode.get('comp');
            var host1 = components[host0.id];
            var found = {};

            // Remove/Update components
            for (var compNode = hostNode.firstChild; compNode;) {

                var comp0 = compNode.get('comp');
                var id    = comp0.id;
                var comp1 = host1[id];

                var compNode1 = compNode;
                compNode = compNode.nextSibling;

                if (!comp1) {
                    compNode1.remove();
                } else {
                    found[id] = true;
                    this.updateNode(compNode1, comp1, host0);
                }
            }

            // Add missing components
            for (var id in host1) {
                if (found[id]) continue;
                var comp1 = host1[id];
                if (id === '_info_') continue;

                var model = modelConfig[comp1.type];
                var node = hostNode.appendChild({
                    leaf: true,
                    iconCls: model ? model.icon : null,
                    name: comp1.name,
                    comp: comp1,
                }, true);
                this.updateNode(node, comp1, host0);
            }

            var gNode = root;
            if (groupBy) {
                var value = hostNode.get('comp')[groupBy];
                if (value) {
                    gNode = this.groupNodes[value];
                    if (!gNode && value) {
                        gNode = this.groupNodes[value] = root.appendChild({
                            name: value,
                            comp: null,
                            expanded: true,
                        });
                    }
                }
            }
            if (gNode !== hostNode.parentNode) {
                gNode.appendChild(hostNode);
            }
        });

        for (var i in this.groupNodes) {
            var gNode = this.groupNodes[i];
            if (!gNode.firstChild) {
                delete this.groupNodes[i];
                gNode.remove();
            }
        }


        // Stats
        var hStats = { total: 0, connected: 0, disconnected: 0, total: 0 };
        var cStats = { total: 0, started: 0, starting: 0, stopped: 0, error: 0, disconnected: 0 };
        var tStats = {};

        this.nodeList.forEach( (hostNode) => {
            var host0 = hostNode.get('comp');

            hStats.total++;
            hStats[host0.state]++;
            for (var compNode = hostNode.firstChild; compNode; compNode = compNode.nextSibling) {
                var comp0 = compNode.get('comp');
                cStats.total++;
                cStats[comp0.state]++;
                tStats[comp0.type] = (tStats[comp0.type] | 0) + 1;
            }

        });

        var stats = [hStats.total + ' hosts'];
        for (var s in hStats) {
            if (s !== 'total' && hStats[s])
                stats.push(hStats[s] + ' ' + s);
        }
        this.hStatsPanel.update(stats.join(', '));

        var stats = [cStats.total + ' components'];
        for (var s in cStats) {
            if (s !== 'total' && cStats[s])
                stats.push(cStats[s] + ' ' + s);
        }
        for (var t in tStats)
            stats.push(tStats[t] + ' ' + t);
        this.cStatsPanel.update(stats.join(', '));

        this.compGrid.getView().refresh();
    },
});



