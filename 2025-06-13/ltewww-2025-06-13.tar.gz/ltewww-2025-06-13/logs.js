/*
 * Copyright (C) 2012-2025 Amarisoft
 *
 * Amarisoft Web interface 2025-06-13
 * Icons from
 * - http://icocentre.com/
 * - https://www.iconfinder.com/iconsets/24x24-free-pixel-icons (https://creativecommons.org/licenses/by/3.0/legalcode)
 */

const DIR_NONE = 0;
const DIR_UL   = 1;
const DIR_DL   = 2;
const DIR_FROM = 3;
const DIR_TO   = 4;

Ext.define('4GLogs.data.Client', {
    extend: 'Ext.data.TreeModel',
    fields: [
        {name: 'name'},
        {name: 'type'},
        {name: 'client', type: 'auto'},
        {name: 'tags'},
    ],
});


Ext.define('4GLogs.view.Viewport', {
    extend: 'Ext.container.Viewport',
    layout: 'fit'
});

// Order is important
var modelList = ['RUE', 'UE', 'PROBE', 'ENB', 'N3IWF', 'MBMSGW', 'MME', 'IMS', 'LICENSE', 'MONITOR', 'MCC'];


var modelConfig = {
    'RUE':      { icon: 'icon-ue2'},
    'UE':       { icon: 'icon-ue'},
    'PROBE':    {},
    'ENB':      { icon: 'icon-air', modelHint: /enb|gnb|bbu/i, title: 'RAN' },
    'N3IWF':    { icon: 'icon-air', modelHint: /n3iwf/i, title: 'N3IWF' },
    'SAT':      { icon: 'icon-sat', modelHint: /sat/i, title: 'Sat' },
    'MME':      { icon: 'icon-server', modelHint: /epc|mme|amf/i, title: 'CN' },
    'MBMSGW':   { icon: 'icon-download', modelHint: /mbms/i },
    'IMS':      { icon: 'icon-dial'},
    'VIEW':     { icon: 'icon-view', modelHint: /view/i },
    'MONITOR':  { icon: 'icon-monitor' },
    'LICENSE':  { icon: 'icon-file' },
    'MCC':      { icon: 'icon-sat' },
};


var layerConfig = {
    'PHY':  {color: '#606070', dir: {UE: 2, PROBE: 3, ENB: 1}, debug: {level: 'debug', max_size: 1}},
    'MAC':  {color: '#10A0FF', dir: {UE: 2, PROBE: 3, ENB: 1}, debug: {level: 'debug', max_size: 1}},
    'RLC':  {color: '#FFFF80', dir: {UE: 2, PROBE: 3, ENB: 1}},
    'PDCP': {color: '#B0D0B0', dir: {UE: 2, PROBE: 3, ENB: 1}},
    'RRC':  {color: '#00FF60', dir: {UE: 2, PROBE: 3, ENB: 1}, debug: {level: 'debug', max_size: 1}},
    'NAS':  {color: '#90FFC0', dir: {UE: 2, PROBE: 3, ENB: 3, N3IWF:3, MME: 1}, debug: {level: 'debug', max_size: 1}},
    'GTPU': {color: '#FF80FF', dir: {ENB: 2, N3IWF: 2, MME: 1, MBMSGW: 1, UE: 1, RUE: 2}, bidir: true, max: {max_size: 64}},
    'GTPC': {color: '#FFC0FF', dir: {MME: 2}, bidir: true},
    'IP':   {color: '#E0E0E0', dir: {RUE: 2, UE: 2, N3IWF: 3, PROBE: 3, MME: 3}, max: {max_size: 48}},
    'S1AP': {color: '#80FF00', dir: {ENB: 2, MME: 1}, bidir: true, debug: {level: 'debug', max_size: 1}},
    'NGAP': {color: '#5DD122', dir: {ENB: 2, MME: 1, N3IWF: 2}, bidir: true, debug: {level: 'debug', max_size: 1}},
    'X2AP': {color: '#FF8000', dir: {ENB: 2}},
    'XnAP': {color: '#FFB020', dir: {ENB: 2}},
    'M2AP': {color: '#7F675B', dir: {ENB: 2, MBMSGW: 1}, bidir: true},
    'IMS':  {color: '#C0FF80', dir: {MME: 2, IMS: 1}, debug: {level: 'debug', max_size: 1}, bidir: true},
    'CX':   {color: '#F49542', dir: {MME: 2, IMS: 1}, bidir: true},
    'RX':   {color: '#D4A190', dir: {MME: 2, IMS: 1}, bidir: true},
    'N5':   {color: '#D4A190', dir: {MME: 2, IMS: 1}, bidir: true},
    'COM':  {color: '#C000FF', dir: {'*': 2}, bidir: true, debug: {level: 'debug', max_size: 1}},
    'SIP':  {color: '#C080FF', dir: {IMS: 1}, bidir: true, debug: {level: 'debug', max_size: 1}},
    'MEDIA':{color: '#800040', dir: {IMS: 1}, bidir: true},
    'RTP':  {color: '#FF00C0', dir: {IMS: 1}, bidir: true}, // To be removed
    'PROD': {color: '#80C0FF', dir: {}},
    'S6':   {color: '#F44B42', dir: {MME: 2}, bidir: true},
    'S13':  {color: '#D6F953', dir: {MME: 2}, bidir: true},
    'SGsAP':{color: '#FF7DB8', dir: {MME: 2}, bidir: true},
    'SBcAP':{color: '#8FA00F', dir: {MME: 2}, bidir: true},
    'N8':   {color: '#106020', dir: {MME: 2}, bidir: true},
    'N12':  {color: '#602020', dir: {MME: 2}, bidir: true},
    'N13':  {color: '#202060', dir: {MME: 2}, bidir: true},
    'N14':  {color: '#0dd5cf', dir: {MME: 2}, bidir: true},
    'N17':  {color: '#D6F953', dir: {MME: 2}, bidir: true},
    'N50':  {color: '#8FA00F', dir: {MME: 2}, bidir: true},
    'N20':  {color: '#106020', dir: {MME: 2}, bidir: true},
    'N62':  {color: '#106020', dir: {MME: 2}, bidir: true},
    'MMS':  {color: '#B4D98F', dir: {MME: 2}, bidir: true},
    'HTTP2':{color: '#644824', dir: {MME: 2}, bidir: true},
    'LCSAP':{color: '#cfd50d', dir: {MME: 2}, bidir: true},
    'LPPa': {color: '#0dcfd5', dir: {ENB: 2, MME: 3}, bidir: true},
    'NL1':  {color: '#d040cf', dir: {MME: 2}, bidir: true},
    'NRPPa':{color: '#0dd5cf', dir: {ENB: 2, MME: 3}, bidir: true},
    'LPP':  {color: '#F04010', dir: {UE: 2, MME: 3}, epc: true},
    'GTPC': {color: '#F04010', dir: {MME: 2}, bidir: true},
    'LMF':  {color: '#E0E0E0', dir: {MME: 2}, bidir: true},
    'eSMLC':{color: '#E0E0E0', dir: {MME: 2}, bidir: true},

    'IKEV2': {color: '#C0B732', dir: {UE: 2, MME: 1, N3IWF: 1}},
    'SWU':   {color: '#101080', dir: {UE: 2, MME: 1}},
    'NWU':   {color: '#2080B8', dir: {UE: 2, MME: 1}},
    'IPSEC': {color: '#F04010', dir: {UE: 2, IMS: 1, N3IWF: 1, MME: 1}, bidir: true, max: {max_size: 80}},
    'N3IWF': {color: '#C080C0', dir: {UE: 2, N3IWF: 1}},

    'TRX':    {color: '#42C0a0', dir: {UE: 2, ENB: 1}, debug: {level: 'debug'}},
    'S72':    {color: '#42C0a0', dir: {UE: 2, ENB: 1}, debug: {level: 'info'}, bidir: true},

    'UECP': {color: '#400080', dir: {UE: 1}},

    // Monitor
    'MON':    {color: '#C0C080', dir: {}},
    'EVENT':  {color: '#80C0FF', dir: {}},
    'ALARM':  {color: '#FF8040', dir: {}},

    // License server
    'LIC':  {color: '#ff80c0', dir: {LICENSE: 1}},

    // OTS (lte.log)
    'OTS': {color: '#8080FF', dir: {}},

    'ERROR': {color: '#ff0000', dir: {}},
};



Ext.application({
    name: '4GLogs',
    
    launch: function() {

        this.viewport = this.getView('Viewport').create();

        // Log filters
        var createSrcFilter = Ext.Function.bind(function(label, type) {
            return Ext.create('Ext.button.Button', {
                pressed: true,
                width: 32,
                tooltip: lteLogs.tooltip("Enable/Disable " + label),
                iconCls: "icon-" + type,
                enableToggle: true,
                listeners: {
                    scope: this,
                    click: function(filter, e, eOpts) {
                        lteLogs.updateFilter();
                    }
                }
            });
        }, this);

        var createListFilter = function (label, type, data, cfg1) {
             var cfg0 = {
                fieldLabel: label,
                queryMode: 'local',
                valueField: 'value',
                displayField: 'text',
                multiSelect: true,
                width: 140,
                labelWidth: 50,
                padding: { right: 15, left: 0 },
                labelAlign: 'right',
                labelSeparator: '',
                store: Ext.create('Ext.data.Store', {
                    fields: ['value', 'text'],
                    data: data
                }),
                tpl: Ext.create('Ext.XTemplate',
                    '<tpl for=".">',
                    '{value:this.valueRenderer}</div>',
                    '</tpl>', {
                        valueRenderer: function (v) {
                            var format = filterValueFormater(type, v);
                            return '<div class="x-boundlist-item" style="' + format.style + '">' + format.display + '</div>';
                        }
                    }),
                listeners: {
                    scope: this,
                    change: function(combo, newValue, oldValue, eOpts) {
                        // Protect and default
                        if (!newValue) newValue = [];
                        else if (typeof newValue === 'string') newValue = newValue.split(/,/);

                        switch (type) {
                        case 'dir':
                            if (newValue.length) {
                                filterData[type] = [true, true, true];
                                newValue.forEach(function (i) { filterData[type][i] = false; });
                            } else {
                                filterData[type] = [false, false, false];
                            }
                            break;
                        case 'cell':
                        case 'rnti':
                            filterData[type] = newValue.map(function (v) { return v === undefined ? undefined : v - 0 });
                            break;
                        case 'imsi':
                            if (!filterComponentsData.imsi) type = 'imei';
                            filterData[type] = newValue;
                            break;
                        default:
                            filterData[type] = newValue;
                            break;
                        }
                        if (!filterData.updating) {
                            lteLogs.updateFilter();
                        }
                    },
                    collapse: function () {
                        gridLocker.unlock(label);
                    },
                    expand: function () {
                        gridLocker.lock(label);
                    }
                }
            }
            return Ext.create('Ext.form.field.ComboBox', Object.assign(cfg0, cfg1));
        };

        var getTimeOriginOffset = function () {
            var log = logState.logs[0];
            if (!log) return 0;
            return lteLogs.tsDayOffset(log.timestamp);
        };

        var filterStartTime = 0;
        var filterEndTime = Infinity;
        var filterComponents = lteLogs.filterComponents = {
            "time": Ext.create("Ext.form.field.Text", {
                fieldLabel: 'Time origin',
                labelWidth: 70,
                value: "00:00:00.000",
                width: 175,
                align: 'right',
                validateOnChange: true,
                validator: function (value) {
                    value = lteLogs.str2ts(value);
                    if (value !== false) {
                        logListPanel.setTimeOrigin(value + getTimeOriginOffset());
                        return true;
                    }
                    return false;
                },
                listeners: {
                    scope: this,
                    blur: function (filter, event, eOpts) {
                        filter.setValue(lteLogs.ts2time(logListPanel.getTimeOrigin() - getTimeOriginOffset()));
                    },
                }
            }),
            'ue_gid': Ext.create('Ext.form.field.Checkbox', {
                fieldLabel: 'Group UE ID',
                labelWidth: 80,
                width: 100,
                value: LTELog.prototype.use_global_ue_id,
                handler: function (comp, checked) {
                    LTELog.prototype.use_global_ue_id = checked;
                    logListPanel.refresh(true);
                    lteLogs.updateFilter();
                }
            }),
            'global_ue_id': createListFilter("UE ID", 'global_ue_id', [], {width: 100, labelWidth: 35}),
            'imsi': createListFilter('IMSI', 'imsi', [], {width: 180, labelWidth: 0, fieldLabel: '', hidden: true}),
            "cell": createListFilter("Cell ID", "cell", [], {width: 120, labelWidth: 40, hidden: true}),
            "rnti": createListFilter("RNTI", "rnti", [], {width: 120, labelWidth: 30, hidden: true}),
            "info": createListFilter("Info", "info", [], {width: 130, labelWidth: 25}),
            "layer": createListFilter("Layer", "layer", [], {width: 110, labelWidth: 35}),
            "level": createListFilter("Level", "level", lteLogs.mapFilter(lteLogs.levels, function (l, i) { if (i > 0) return {value: i, text: l}; }), {width: 100, labelWidth: 30, disabled: true}),
            "dir": createListFilter("UL/DL", "dir", [
                {value: DIR_NONE, text: '-'},
                {value: DIR_DL, text: 'DL'},
                {value: DIR_UL, text: 'UL'}
            ], {width: 95, labelWidth: 35}),
        };
        filterComponents.imei = filterComponents.imsi;

        var filterData = lteLogs.filterData = {
            global_ue_id: [],
            cell: [],
            rnti: [],
            imsi: [],
            imei: [],
            info: [],
            layer: [],
            level: [],
            sibs_mib: false,
            dir: [false, false, false]
        };
        var filterLog = function(log) {

            var f = filterData;

            // Filter errors
            var e = f.error;
            if (e && (log.level !== 1)) {
                log.filtered = true;
                return true;
            }

            if (f.dir[log.dir]) {
                log.filtered = true;
                return true;
            }

            for (var i in filterComponentsData) {
                var data = f[i];
                if (data.length && data.indexOf(log[i]) < 0) {
                    log.filtered = true;
                    return true;
                }
            }

            if (log.timestamp < filterStartTime || log.timestamp > filterEndTime) {
                log.filtered = true;
                return true;
            }

            if (log.hints) {
                log.filtered = true;
                return true;
            }

            if (f.sibs_mib &&
                (log.rnti === 0xffff || log.info === BCCH || log.info === BCCH_NB || log.info === BCCH_NR ||
                 log.info === BCCH_BCH || log.info === BCCH_BCH_NB || log.info === BCCH_BCH_NR)) {
                log.filtered = true;
                return true;
            }

            // Filter message
            var textRegExp = f.textRegExp;
            if (textRegExp && !log.msg.match(textRegExp)) {
                if (!log.data || !log.data.find( (line) => { return line.match(textRegExp); })) {
                    log.filtered = true;
                    return true;
                }
            }

            log.filtered = log.client.filtered;
            return log.filtered;
        };

        this.switchIMSIButton = Ext.create('Ext.Button', {
            text: 'IMSI',
            scope: this,
            handler: function(button, b) {
                if (filterComponentsData.imsi) {
                    filterComponentsData.imei = filterComponentsData.imsi;
                    delete filterComponentsData.imsi;
                    button.setText('IMEI');
                } else {
                    filterComponentsData.imsi = filterComponentsData.imei;
                    delete filterComponentsData.imei;
                    button.setText('IMSI');
                }
                lteLogs.updateFilter();
            }
        });


        this.clearFiltersButton = Ext.create('Ext.Button', {
            text: 'Clear',
            tooltip: lteLogs.tooltip('Clear filters'),
            scope: this,
            handler: function() {
                lteLogs.lockFilter(true);
                filterData.sibs_mib = false;
                filterStartTime = 0;
                filterEndTime = Infinity;
                filterComponents.time.setValue("00:00:00.000");
                filterComponents.dir.clearValue();
                for (var i in filterComponentsData) {
                    filterComponents[i].clearValue();
                }
                clientList.clients.forEach(function (c) { c.filtered = false; });
                search.update(false);
                filterData.text = null;
                lteLogs.lockFilter(false);

                this.filtersListCombo.clearValue();
            }
        });

        this.filtersStore = Ext.create('Ext.data.Store', {
            fields: ['name', 'filters'],
            proxy: {
                type: 'localstorage',
                id  : 'logFilters'
            },
            listeners: {
                scope: this,
                load: function (s, records, success, eOpts) {
                }
            }
        });

        this.filtersCreateButton = Ext.create('Ext.button.Button', {
            tooltip: lteLogs.tooltip('Create filter'),
            iconCls: 'icon-plus',
            listeners: {
                scope: this,
                click: function(filter, e, eOpts) {
                    Ext.Msg.prompt('Create filter', 'Please enter filter name:', (function (btn, text) {
                        if (btn === 'ok') {
                            var filters = {
                                startTime: filterStartTime,
                                endTime: filterEndTime === Infinity ? null : filterEndTime,
                            };
                            if (search.pattern)
                                filters.searchPattern = search.pattern;
                            if (search.filter)
                                filters.searchFilter = true;
                            for (var i in filterComponents) {
                                switch (i) {
                                case 'info':
                                    filters[i] = filterComponents[i].getValue().map(function (id) { return lteLogs.id2string(id); });
                                    break;
                                default:
                                    filters[i] = filterComponents[i].getValue();
                                    break;
                                }
                            }
                            var r = this.filtersStore.add({
                                name: text,
                                filters: filters
                            });
                            this.filtersStore.sync();
                            this.filtersListCombo.select(r);
                        }
                    }).bind(this));
                }
            }
        });

        this.filtersDeleteButton = Ext.create('Ext.button.Button', {
            tooltip: lteLogs.tooltip('Delete filter'),
            iconCls: 'icon-minus',
            disabled: true,
            listeners: {
                scope: this,
                click: function(filter, e, eOpts) {
                    var record = this.filtersListCombo.getSelectedRecord();
                    if (record) {
                        this.filtersStore.remove(record);
                        this.filtersStore.sync();
                        this.filtersListCombo.clearValue();
                    }
                }
            }
        });

        this.filtersListCombo = Ext.create('Ext.form.field.ComboBox', {
            fieldLabel: '',
            queryMode: 'local',
            valueField: 'filters',
            displayField: 'name',
            width: 140,
            editable: false,
            triggerAction: 'all',
            store: this.filtersStore,
            listeners: {
                scope: this,
                change: function(combo, newValue, oldValue, eOpts) {
                    var record = this.filtersListCombo.getSelectedRecord();
                    if (record) {
                        var filters = record.getData().filters;

                        lteLogs.lockFilter(true);
                        filterStartTime = filters.startTime;
                        filterEndTime = filters.endTime;
                        if (filterEndTime === null)
                            filterEndTime = Infinity;
                        for (var i in filterComponentsData) {
                            var value = filters[i];
                            switch (i) {
                            case 'info':
                                value = value.map(function (string) { return lteLogs.string2id(string); });
                                break;
                            default:
                                break;
                            }
                            filterComponents[i].setValue(value);
                        }
                        search.update(!!filters.searchFilter, filters.searchPattern);
                        search.searchInput.setValue(filters.searchPattern || '');
                        lteLogs.lockFilter(false);
                    }
                    this.filtersDeleteButton.setDisabled(!record);
                },
            }
        });

        Ext.Function.defer((function () { this.filtersStore.load();}).bind(this), 100);


        // Log navigation
        this.gotoLogOffsetByParam = function (param, n) {

            var log = logListPanel.getSelectedLog();
            if (log)
                gotoLogByParam(param, log[param], n);
        }

        var gotoLogByParam = function (param, value, n) {

            var log = logListPanel.getSelectedLog();
            var index = log ? logState.logs.indexOf(log) + n : 0;
            while (index >= 0) {
                var log = logState.logs[index];
                if (!log)
                    break;

                if (!log.filtered && log[param] === value) {
                    lteLogs.selectLog(log);
                    break;
                }
                index += n;
            }
        };
        this.gotoNextLogByLayer = Ext.Function.bind(this.gotoLogOffsetByParam, this, ["layer", 1]);
        this.gotoPrevLogByLayer = Ext.Function.bind(this.gotoLogOffsetByParam, this, ["layer", -1]);

        this.gotoTimeButton = Ext.create('Ext.Button', {
            iconCls: 'icon-clock',
            tooltip: lteLogs.tooltip('Goto desired time'),
            handler: function () {
                Ext.Msg.prompt('Goto time', 'Please enter time:', function(btn, text) {
                    if (btn === 'ok')
                        logListPanel.gotoTime(lteLogs.str2ts(text));
                });
            }
        });
        this.nextTypeButton = Ext.create('Ext.Button', {
            iconCls: 'icon-right',
            tooltip: lteLogs.tooltip('Goto next log (n)'),
            handler: this.gotoNextLogByLayer
        });
        this.prevTypeButton = Ext.create('Ext.Button', {
            tooltip: lteLogs.tooltip('Goto previous log (b)'),
            iconCls: 'icon-left',
            handler: this.gotoPrevLogByLayer
        });

        var showChartButton = Ext.create('Ext.Button', {
            text: 'Analytics',
            scope: this,
            disabled: true,
            tooltip: lteLogs.tooltip('Show PHY layer charts'),
            iconCls: 'icon-chart',
            handler: function() {
                var win = Ext.create('lte.analytics.win');
                win.open(getVisibleLogs());
            }
        });

        var showRBButton = Ext.create('Ext.Button', {
            text: 'RB',
            scope: this,
            disabled: true,
            tooltip: lteLogs.tooltip('Show resource blocks'),
            iconCls: 'icon-comp',
            handler: function() {
                Ext.create("lte.stats.rb", { log: logListPanel.getSelectedLog() });
            }
        });

        var showCapsButton = Ext.create('Ext.Button', {
            text: 'UE Caps',
            scope: this,
            disabled: true,
            tooltip: lteLogs.tooltip('Show UE capabilities'),
            iconCls: 'icon-question2',
            handler: function() {
                var log = logListPanel.getSelectedLog();
                if (!log) return;

                caps = log.getUECaps();
                if (caps) {
                    var win = new Ext.create('lte.capabilities.win', {
                        title: 'UE ' + caps.ue_id + ' capabilities',
                        caps: caps,
                        log: log,
                    });
                    win.show();
                }
            }
        });

        errorInfoButton = Ext.create('Ext.Button', {
            scope: this,
            hidden: true,
            iconCls: 'icon-error',
            tooltip: lteLogs.tooltip('Goto next error'),
            handler: function() {
                gotoLogByParam('level', 1, 1);
            }
        });

        warnInfoButton = Ext.create('Ext.Button', {
            scope: this,
            hidden: true,
            iconCls: 'icon-warn',
            tooltip: lteLogs.tooltip('Goto next warning'),
            handler: function() {
                gotoLogByParam('level', 2, 1);
            }
        });

        // Search
        var search = {
            filter: false,
            pattern: null,
            highlightRegExp: null,
            highlight: function (text) {
                if (text && this.highlightRegExp)
                    return text.replace(this.highlightRegExp, '<highlight>$1</highlight>');
                return text || '';
            },
            setPattern: function (pattern) {

                this.pattern = null;
                filterData.textRegExp = null;
                if (pattern) {
                    var re = (pattern || '').match(/^\/(.+)\/([gi]*)$/);
                    if (!re)
                        re = [pattern, 'gi'];
                    try {
                        this.highlightRegExp = new RegExp("(" + re[0] + ")", re[1]);
                        this.pattern = pattern;
                        if (this.filter) {
                            filterData.textRegExp = new RegExp(this.pattern, 'i');
                            lteLogs.updateFilter();
                        }

                    } catch (e) {
                    }
                } else {
                    this.highlightRegExp = null;
                }
                logListPanel.setHighlightPattern(this.highlightRegExp);

                var buttons = !this.filter && this.pattern;
                this.nextSearchButton.setDisabled(!buttons);
                this.prevSearchButton.setDisabled(!buttons);
                infoPanelUpdate();
            },
            update: function (filter, pattern) {
                filter = !!filter;
                if (this.filter !== filter) {
                    this.filter = filter;
                    if (pattern === undefined) pattern = this.pattern;
                    this.setPattern(pattern);
                    if (!filter) {
                        lteLogs.updateFilter();
                        this.searchType.setText('Search');
                        this.searchType.setTooltip('Switch to filter mode');
                        this.searchInput.emptyText = 'Enter text to highlight';
                    } else {
                        this.searchType.setText('Filter');
                        this.searchType.setTooltip('Switch to search mode');
                        this.searchInput.emptyText = 'Enter filter text';
                    }
                    this.searchInput.applyEmptyText();
                }
            },
            nextSearchButton: Ext.create('Ext.Button', {
                iconCls: 'icon-right',
                tooltip: lteLogs.tooltip('Goto next'),
                disabled: true,
                scope: this,
                handler: function () { this.gotoSearch(1); },
            }),
            prevSearchButton: Ext.create('Ext.Button', {
                tooltip: lteLogs.tooltip('Goto previous'),
                iconCls: 'icon-left',
                disabled: true,
                scope: this,
                handler: function () { this.gotoSearch(-1); },
            }),
            searchType: Ext.create('Ext.Button', {
                text: 'Search',
                tooltip: 'Switch to filter mode',
                width: 60,
                handler: function () {
                    search.update(!search.filter);
                }
            }),
            searchInput: Ext.create('Ext.form.field.Text', {
                labelWidth: 0,
                labelAlign: 'right',
                labelSeparator: '',
                width: 300,
                emptyText: 'Enter text to highlight/search',
                triggers: {
                    foo: {
                        cls: 'icon-search',
                        handler: () => { this.gotoSearch(1) },
                    }
                },
                listeners: {
                    scope: this,
                    change: function(combo, newValue, oldValue, eOpts) {
                        search.setPattern(newValue);
                    },
                }
            }),
        };
        this.gotoSearch = function (n) {
            var log   = logListPanel.getSelectedLog();
            var index = logState.logs.indexOf(log);

            for (;;) {
                index += n;
                var log = logState.logs[index];
                if (!log)
                    break;

                if (log.filtered) continue;

                if (log.msg.match(search.highlightRegExp))
                    break;

                var ue_id = log.global_ue_id;
                if (ue_id !== undefined && ue_id.toString(16).match(search.highlightRegExp))
                    break;

                if (log.info) {
                    var info = lteLogs.id2string(log.info);
                    if (info && info.match(search.highlightRegExp))
                        break;
                }

                if (log.findData(search.highlightRegExp))
                    break;

                if (log.frame !== undefined && log.getFrameString().match(search.highlightRegExp))
                    break;
            }
            if (log)
                lteLogs.selectLog(log);
        };

        new Ext.util.KeyMap({
            target: Ext.getBody(),
            key: "n", //Ext.event.Event.RIGHT,
            fn: this.gotoNextLogByLayer,
            ignoreInputFields: true
        });
        new Ext.util.KeyMap({
            target: Ext.getBody(),
            key: "b", //Ext.event.Event.LEFT,
            fn: this.gotoPrevLogByLayer,
            ignoreInputFields: true
        });
        // Page down
        new Ext.util.KeyMap({
            target: Ext.getBody(),
            key: 34,
            fn: function () { logListPanel.scrollStep(1, 'page'); },
            ignoreInputFields: true
        });
        // Page up
        new Ext.util.KeyMap({
            target: Ext.getBody(),
            key: 33,
            fn: function () { logListPanel.scrollStep(-1, 'page'); },
            ignoreInputFields: true
        });
        // Up
        new Ext.util.KeyMap({
            target: Ext.getBody(),
            key: 38,
            fn: function () { logListPanel.moveSel(-1); },
            ignoreInputFields: true
        });
        // Down
        new Ext.util.KeyMap({
            target: Ext.getBody(),
            key: 40,
            fn: function () { logListPanel.moveSel(1); },
            ignoreInputFields: true
        });

        this.logToolbar = Ext.create('Ext.toolbar.Toolbar', {
            items: [
                this.gotoTimeButton, this.prevTypeButton, this.nextTypeButton, this.showLogButton, errorInfoButton, warnInfoButton,
                '|',
                search.searchType, search.searchInput, search.prevSearchButton, search.nextSearchButton,
                '|',
                showChartButton,
                showRBButton,
                showCapsButton,
                ]
        });

        lteLogs.gridColumnsUpdate = function () {

            var found = {};
            modelList.forEach(function (t) { found[t] = null; });

            clientList.clients.forEach(function (c) {
                switch (c.getState()) {
                case 'start':
                case 'connected':
                    found[c.getModel()] = c;
                    break;
                }
            });

            var idx = 2;
            for (var idx = 2, i = 0, lastModel = null; i < modelList.length; i++) {
                var model = modelList[i];
                if (found[model]) {
                    if (i > 0)
                        logListPanel.setDirColumnState(idx++, true, lastModel, model);
                    logListPanel.setColumnState(idx++, true);
                    lastModel = model;
                } else {
                    if (i > 0)
                        logListPanel.setColumnState(idx++, false);
                    logListPanel.setColumnState(idx++, false);
                }
            }
            if (lastModel) {
                logListPanel.setDirColumnState(idx, true, lastModel, null);
            } else {
                logListPanel.setColumnState(idx, false);
            }
        };

        var signalHide = function () {
            if (signalPanel) {
                var dataPanel = logsTab.getComponent('logsPanel').getComponent('dataPanel');
                dataPanel.hide();
                signalPanel.destroy();
                signalPanel = null;
            }
        };

        var getVisibleLogs = function () {
            return logState.logs.filter(function (l) { return !l.filtered; });
        };

        lteLogs.registerEventListener('selectLog', function (event) {

            var log = event.log;

            var dataPanel = logsTab.getComponent('logsPanel').getComponent('dataPanel');
            if (log && log.signalRecord && Object.keys(log.signalRecord).length) {
                if (!signalPanel) {
                    signalPanel = Ext.create('lte.signal.panel', {logList: getVisibleLogs()});
                    logsTab.getComponent('logsPanel').getComponent('dataPanel');
                    dataPanel.add(signalPanel);
                }
                signalPanel.setLog(log, function (show) {
                    if (show)
                        dataPanel.show();
                    else
                        signalHide();
                });
            } else {
                signalHide();
            }

            showCapsButton.setDisabled(!log || !log.getUECaps());

            infoPanelUpdate();
        });

        var signalPanel = null;

        lteLogs.contextMenu = function (items, log) {

            for (var id in filterComponentsData) {
                var param = log[id];
                if (!param) continue;

                var comp = filterComponents[id];
                var cur  = comp.getValue();
                var disp = filterValueFormater(id, param).display;
                var subItems = [];

                if (cur.length) {
                    subItems.push({
                        text: 'No filter',
                        iconCls: 'icon-filter2',
                        scope: this,
                        handler: comp.setValue.bind(comp, []),
                    });
                }
                if (cur.indexOf(param) < 0) {
                    subItems.push({
                        text: 'Only ' + disp,
                        iconCls: 'icon-filter1',
                        scope: this,
                        handler: comp.setValue.bind(comp, param),
                    });
                }

                var all = [];
                var store = comp.getStore();
                for (var i = 0, count = store.getCount(); i < count; i++) {
                    var param1 = store.getAt(i).get('value');
                    if (param1 !== param)
                        all.push(param1);
                }
                subItems.push({
                    text: 'Everything but ' + filterValueFormater(id, param).display,
                    iconCls: 'icon-filter1',
                    scope: this,
                    handler: comp.setValue.bind(comp, all),
                });

                items.push({
                    iconCls: 'icon-filter3',
                    text: id[0].toUpperCase() + id.slice(1),
                    menu: {
                        items: subItems,
                    }
                });
            }
            if (filterData.sibs_mib)
                items.push({
                    text: 'Unfilter SIBs and MIB',
                    iconCls: "icon-filter2",
                    scope: this,
                    handler: function(i, f, d) { filterData.sibs_mib = false; lteLogs.updateFilter(); }
                });
            else
                items.push({
                    text: 'Filter SIBs and MIB',
                    iconCls: "icon-filter1",
                    scope: this,
                    handler: function(i, f, d) { filterData.sibs_mib = true; lteLogs.updateFilter(); }
                });

            if (clientList.clients.length > 1) {
                var client = log.client;
                var filtered = true;
                clientList.clients.forEach(function (c) { if (c !== client && c.filtered === false) filtered = false; });

                items.push({
                    text: (filtered ? 'Clear filter' : 'Filter') + ' ' + client.getName(),
                    iconCls: filtered ? "icon-filter2" : "icon-filter1",
                    scope: this,
                    handler: function() {
                        clientList.clients.forEach(function (c) { if (c !== client) c.filtered = !filtered; });
                        lteLogs.updateFilter();
                    }
                });
            }

            var ts = log.timestamp;
            items.push({
                text: "Set time origin",
                iconCls: 'icon-clock',
                scope: this,
                handler: function() {
                    filterComponents.time.setValue(lteLogs.ts2time(ts));
                }
            });
            items.push({
                text: "Filter previous logs",
                iconCls: 'icon-clock',
                scope: this,
                handler: function() {
                    filterStartTime = ts;
                    lteLogs.updateFilter();
                }
            });
            items.push({
                text: "Filter next logs",
                iconCls: 'icon-clock',
                scope: this,
                handler: function() {
                    filterEndTime = ts;
                    lteLogs.updateFilter();
                }
            });
            if (log.client.isRealTime()) {
                items.push({
                    text: "Flush logs",
                    iconCls: 'icon-cut',
                    scope: this,
                    handler: function() {
                        log.client.resetLogs();
                    }
                });
            }
        };

        var infoPanelUpdate = function () {
            var log = logListPanel.getSelectedLog();
            if (log) {
                var data = log.exportInfoPanel(function (error) {
                    if (!error) infoPanelUpdate();
                    else console.log(error);
                });

                infoPanel.removeAll();
                if (infoPanelBrowseOn && log.isBrowsable()) {
                    infoPanel.add(JSONBrowser.create(log.getBrowseData(), 2));
                    infoPanel.update('');

                } else {
                    var text = [];
                    text.push('From: ' + log.client.getName() + (log.index > 0 ? ' #' + log.index : ''));
                    text.push('Info: ' + log.client.getInfo());
                    text.push('Time: ' + lteLogs.ts2time(log.timestamp, true));
                    if (log.idx !== undefined)
                        text.push('Index: ' + log.idx);

                    var ue_id = log.global_ue_id;
                    if (ue_id !== log.ue_id)
                        text.push('Original UE ID: ' + log.ue_id);

                    var ue = log.getUE();
                    if (ue.errors)
                        text.push.apply(text, ue.errors);

                    text.push('Message: ' + search.highlight(log.msg));

                    infoPanelCopy.setVisible(true);
                    infoPanelPayload.setVisible(log.hasPayload());

                    if (data) {
                        data = data.replace(/</g, '&lt;').replace(/>/g, '&gt;');
                        text.push('', 'Data:', '<pre>' + search.highlight(data) + '</pre>');
                    }

                    infoPanel.update('<div style="padding: 7px;">' + text.join('<br />') + '</div>');
                }
                lteLogs.log = log;
            } else {
                infoPanel.update('&nbsp;');
                infoPanelCopy.setVisible(false);
                infoPanelPayload.setVisible(false);
            }
        };

        var exportLogButton = Ext.create('Ext.Button', {
            text: 'Export',
            scope: this,
            tooltip: lteLogs.tooltip('Export logs'),
            disabled: true,
            handler: function () {

                var nextClient = function (index, success) {

                    var client = clientList.clients[index];
                    if (!client) return;

                    var logs = [];

                    logState.logs.forEach(function (log) {
                        if (log.filtered && !log.hints && !log.skip) return;
                        if (log.client !== client) return;

                        logs.push(log);
                    });

                    client.exportLogs(logs, this.exportMode, nextClient.bind(this, index + 1));
                };
                nextClient.call(this, 0, true);
            },
        });

        var connectClientsButton = Ext.create('Ext.Button', {
            iconCls: 'icon-refresh',
            tooltip: lteLogs.tooltip('Connect all servers'),
            disabled: true,
            listeners: {
                scope: this,
                click: function(button, e, eOpts) {
                    clientList.clients.forEach( (client) => {
                        if (client.getState() === 'error') {
                            client.toggleState();
                            client.toggleState();
                        }
                    });
                }
            }
        });

        var resetAllLogsButton = Ext.create('Ext.Button', {
            iconCls: 'icon-cut',
            tooltip: lteLogs.tooltip('Reset all logs'),
            disabled: true,
            listeners: {
                scope: this,
                click: function(button, e, eOpts) {
                    clientList.clients.forEach(function (client) {
                        client.resetLogs();
                    });
                }
            }
        });

        var infoPanelBrowseOn = false;
        var infoPanelBrowseButton = Ext.create('Ext.Button', {
            text: 'Browse',
            scope: this,
            iconCls: 'icon-folder',
            tooltip: lteLogs.tooltip('Switch plain/browse modes'),
            handler: function (button) {
                infoPanelBrowseOn = !infoPanelBrowseOn;
                if (infoPanelBrowseOn) {
                    button.setText('Plain');
                    infoPanelBrowseButton.setIconCls('icon-info');
                } else {
                    button.setText('Browse');
                    infoPanelBrowseButton.setIconCls('icon-folder');
                }
                infoPanelUpdate();
            }
        });

        var infoPanelCopy = Ext.create('Ext.Button', {
            text: 'Copy',
            scope: this,
            hidden: true,
            tooltip: 'Copy clipboard',
            iconCls: 'icon-copy',
            handler: function () {
                lteLogs.log.clipboardCopy();
            }
        });

        var infoPanelPayload = Ext.create('Ext.Button', {
            text: 'Payload',
            tooltip: 'Copy payload to clipboard',
            scope: this,
            hidden: true,
            iconCls: 'icon-copy',
            handler: function () {
                lteLogs.log.clipboardCopy('payload');
            }
        });

        // Info panel: right side
        var infoPanel = Ext.create('Ext.panel.Panel', {
            autoScroll: true,
            layout: 'fit',
            bodyPadding: 0,
            border: false,
            html: 'Click on a row to see it\'s content here.',
            tbar: [
                infoPanelCopy,
                infoPanelPayload,
                infoPanelBrowseButton
            ],
        });

        // Client panel on left side: list of sources
        this.clientToolbar = Ext.create('Ext.toolbar.Toolbar', {
            width: '100%',
            border: false,
            items: [
                Ext.create('Ext.Button', {
                    text: 'URL',
                    scope: this,
                    handler: function () {
                        Ext.create('lte.client.config', {class: 'lte.client.url', title: 'Create URL client'}).show();
                    },
                }),
                Ext.create('Ext.Button', {
                    //iconCls: 'icon-plus',
                    text: 'Server',
                    scope: this,
                    handler: function () {
                        Ext.create('lte.client.config', {class: 'lte.client.server', title: 'Create server client'}).show();
                    },
                }),
                {
                    xtype: 'filefield',
                    name: 'file',
                    buttonOnly: true,
                    allowBlank: false,
                    buttonText: 'File',
                    width : 50,
                    scope: this,
                    listeners: {
                        boxready: function (myObj, width, height, eOpts) {
                            myObj.fileInputEl.set({multiple: 'multiple'});
                        },
                        change: function (myObj, value, eOpts) {
                            if (value) {
                                var files = myObj.extractFileInput().files;
                                for (var i = 0; i < files.length; i++) {
                                    lteLogs.addClient({type: "file", name: files[i].name, file: files[i], enabled: true}, ['removable']);
                                }
                                myObj.fileInputEl.set({multiple: 'multiple'});
                            }
                        }
                    }
                },
                '->',
                exportLogButton,
                connectClientsButton,
                resetAllLogsButton,
            ],
        });

        var clientStoredConfigs = {}; // Stored

        var addClient = function (node, cfg, tags) {

            var me;
            if (!node) node = clientGrid.getRootNode();
            if (!tags) tags = [];
            
            // Leaf
            var list = cfg.list;
            if (!list) {
                // Get saved config
                if (cfg.storeId) {
                    var cfg1 = clientStoredConfigs[cfg.storeId];
                    if (cfg1) {
                        if (cfg1.readonly !== undefined)
                            cfg.readonly = cfg1.readonly;
                        cfg = Object.assign(cfg1, cfg);
                    }
                }

                var client = Ext.create('lte.client.' + cfg.type, cfg);

                var nodeCfg = {
                    client:  client,
                    name:    cfg.name,
                    leaf:    true,
                    tags:    tags,
                    iconCls: client.clientIcon
                };
                if (tags.indexOf('first') >= 0) {
                    me = node.insertChild(0, nodeCfg);
                } else {
                    me = node.appendChild(nodeCfg);
                }

            } else {
                me = node.appendChild({
                    name:       cfg.name,
                    type:       cfg.type,
                    expanded:   !!cfg.expanded,
                });
                for (var i in list) {
                    addClient(me, list[i], tags);
                };
            }

            return me;
        }

        var mainClientNodes = {};
        lteLogs.addClient = function (cfg, save) {
            var node = mainClientNodes[cfg.type];

            addClient(node, cfg, save, true);
        };

        lteLogs.getClientById = function (storeId) {

            for (var i = clientStore.getCount(); i--;) {
                var record = clientStore.getAt(i);
                var client = record.get('client');
                if (client && client.getConfig('storeId') === storeId)
                    return client;
            }
            return null;
        };

        lteLogs.removeClient = function (client) {
            logState.logs = logState.logs.filter(function (log) { return log.client !== client; });
            lteLogs.updateLogs(true);
        };

        // Save config to local storage
        var saveConfig = lteLogs.saveConfig = function () {

            var persistent = [];
            var ids = clientStoredConfigs;

            var parseNode = function (node) {
                if (node.isLeaf()) {
                    var config = node.getData().client.config;
                    if (config.storeId) {
                        ids[config.storeId] = config;
                    }
                    if (node.getData().tags.indexOf('persistent') >= 0)
                        persistent.push(config);
                } else {
                    node.eachChild( parseNode );
                }
            }
            parseNode(clientGrid.getRootNode());

            localStorage.clients = JSON.stringify({ persistent: persistent, ids: ids});
        };

        var clientStore = Ext.create('Ext.data.TreeStore', {
            model: '4GLogs.data.Client',
            root: {name: 'root', children: []}
        });

        // Client toolbar
        var selectedClientRecord = null;
        var clientButtons = {
            config: Ext.create('Ext.Button', {
                iconCls: 'icon-config',
                tooltip: lteLogs.tooltip('Configure'),
                listeners: {
                    scope: this,
                    click: function(button, e, eOpts) {
                        var client = selectedClientRecord.get("client");
                        if (client && client.isConfigurable()) {
                            Ext.create('lte.client.config', {
                                client: client,
                                title: 'Configure ' + client.getName(),
                            }).show();
                        }
                    }
                }
            }),
            enable: Ext.create('Ext.Button', {
                iconCls: 'icon-ok',
                tooltip: lteLogs.tooltip("Enable/disable this log"),
                listeners: {
                    scope: this,
                    click: function(button, e, eOpts) {
                        selectedClientRecord.get("client").toggleState();
                        clientGridUpdate(selectedClientRecord);
                    }
                }
            }),
            del: Ext.create('Ext.Button', {
                iconCls: 'icon-delete',
                tooltip: lteLogs.tooltip('Delete'),
                    listeners: {
                    scope: this,
                    click: function(button, e, eOpts) {
                        var client = selectedClientRecord.get("client");
                        selectedClientRecord.parentNode.removeChild(selectedClientRecord);
                        client.destroy();
                        saveConfig();
                    }
                }
            }),
            playPause: Ext.create('Ext.Button', {
                iconCls: 'icon-play',
                tooltip: lteLogs.tooltip('Play/Pause'),
                    listeners: {
                    scope: this,
                    click: function(button, e, eOpts) {
                        selectedClientRecord.get("client").playPause();
                        clientGridUpdate(selectedClientRecord);
                    }
                }
            }),
            cut: Ext.create('Ext.Button', {
                iconCls: 'icon-cut',
                tooltip: lteLogs.tooltip('Reset logs'),
                listeners: {
                    scope: this,
                    click: function(button, e, eOpts) {
                        selectedClientRecord.get("client").resetLogs();
                    }
                }
            }),
            refresh: Ext.create('Ext.Button', {
                iconCls: 'icon-refresh',
                tooltip: lteLogs.tooltip('Connect'),
                listeners: {
                    scope: this,
                    click: function(button, e, eOpts) {
                        var client = selectedClientRecord.get("client");
                        client.toggleState();
                        client.toggleState();
                    }
                }
            })
        };

        var clientGridUpdate = function (record) {

            var states = {};
            selectedClientRecord = record;
            var client = record ? record.get('client') : null;
            if (client) {
                states.config   = client.isConfigurable();
                states.enable   = true;
                states.del      = record.get('tags').indexOf('removable') >= 0;
                states.cut      = client.getState() === 'connected' && client.hasLogs();
                states.refresh  = client.getState() === 'error';

                if (client.isRealTime()) {
                    clientButtons.playPause.setIconCls(client.isPaused() ? 'icon-play' : 'icon-pause');
                    states.playPause = true;
                } else {
                    states.playPause = false;
                }

                clientButtons.enable.setIconCls(client.isEnabled() ? 'icon-off' : 'icon-ok');
            }
            for (var i in clientButtons) clientButtons[i].setDisabled(!states[i]);

            var connect = false;
            var reset = false;
            clientList.clients.forEach( (client) => {
                if (client.getState() === 'error') connect = true;
                if (client.hasLogs()) reset = true;
            });
            connectClientsButton.setDisabled(!connect);
            resetAllLogsButton.setDisabled(!reset);

            clientGrid.getView().refresh();
        };

        // Client grid:
        // - List of client sources to fill log grid
        var clientGrid = this.clientGrid = Ext.create('Ext.tree.Panel', {
            rootVisible: false,
            tbar: {items: [
                clientButtons.config,
                clientButtons.enable,
                clientButtons.refresh,
                clientButtons.playPause,
                clientButtons.cut,
                '->',
                clientButtons.del
            ]},
            useArrows: true,
            store: clientStore,
            hideHeaders: true,
            columns: [{
                xtype: 'treecolumn',
                dataIndex: 'name',
                flex: 1,
                renderer: function(value, metaData, record, rowIndex, colIndex, store, view) {
                    var client = record.get("client");
                    if (client) {
                        metaData.tdAttr = 'data-qtip="' + lteLogs.tooltip(client.getInfo()) + '"';
                        record.data.iconCls = client.getModelIcon();

                        value = client.getName();
                        if (client.isEnabled()) {
                            var iconList = [];

                            iconList.push({icon: "ok", tip: "Enabled"});
                            var cs = client.getState();
                            if (cs === "connected")        iconList.push({icon: "lightning-green", tip: "Connected"});
                            if (cs === "connecting")    iconList.push({icon: "lightning-red", tip: "Connecting"});
                            if (cs === "error")            iconList.push({icon: "problem", tip: "Error"});
                            if (cs === "loading")        iconList.push({icon: "lightning", tip: "Loading"});
                            if (client.isRealTime()) {
                                iconList.push(client.isPaused() ?
                                    {icon: "pause", tip: "Paused"} :
                                    {icon: "play", tip: "Play"});
                            }
                            if (client.parsing)
                                iconList.push({icon: "sync", tip: "Parsing"});


                            var cliCol = client.getColor();
                            if (cliCol) {
                                iconList.push({
                                    style: 'background-image: url("' + lteLogs.createColorIcon(cliCol) + '"); background-size: contain; background-repeat: no-repeat',
                                    tip: '',
                                });
                            }

                            if (iconList.length) {
                                value += "&nbsp;&nbsp;&nbsp;" + iconList.map( (item) => {
                                    return "<img src='data:image/gif;base64,R0lGODlhAQABAID/AMDAwAAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==' class='x-tree-icon" + (item.icon ? " icon-" + item.icon : '') + "' style='" + (item.style || '') + "' title='" + item.tip + "'>";
                                }).join("&nbsp;");
                            }
                        }
                    } else {
                        var type = record.get('type');
                        switch (type) {
                        case 'ots':
                            record.data.iconCls = 'icon-ama';
                            record.data.icon = 'amarisoft.png';
                            break;
                        case 'server':
                            var icon = 'network2';
                            break;
                        case 'file':
                            var icon = 'file';
                            break;
                        case 'live':
                            var icon = 'live';
                            break;
                        case 'backup':
                            var icon = 'backup';
                            break;
                        case 'store':
                        case 'url':
                            var icon = 'url';
                            break;
                        }
                        if (icon) {
                            if (!record.data.icon)
                                record.data.icon = 'resources/images/' + icon + '.png';
                            record.data.iconCls = 'icon-' + icon;
                        }
                    }
                    return value;
                }
            }],
            listeners: {
                scope: this,
                selectionchange: function(view, selected, eOpts) {
                    clientGridUpdate(selected[0]);
                },
                celldblclick: function(grid, td, cellIndex, record, tr, rowIndex, e, eOpts) {
                    var client = record.get("client");
                    if (client) client.toggleState();
                },
                itemcontextmenu: function (me, record, item, index, event) {

                    event.stopEvent();
                    event.preventDefault();

                    var client = record.get('client');
                    if (!client) return;

                    var items = [];

                    var cliCol = client.getColor();
                    items.push({
                        text: 'Set color',
                        icon: cliCol ? lteLogs.createColorIcon(cliCol) : '',
                        menu: {
                            xtype: 'colormenu',
                            scope: this,
                            handler: function (cp, value) {
                                client.setColor(value === 'FFFFFF' ? null : value);
                                lteLogs.refreshClientGrid();
                                logListPanel.refresh(true);
                                saveConfig();
                            }
                        }
                    });

                    var prev = record.previousSibling;
                    var next = record.nextSibling;
                    var parent = record.parentNode;
                    if (parent && (prev || next)) {
                        items.push({xtype: 'menuseparator'});

                        if (prev) {
                            items.push({
                                text: 'Move up',
                                scope: this,
                                iconCls: 'icon-up',
                                handler: function (item) {
                                    parent.removeChild(record);
                                    parent.insertBefore(record, prev);
                                    saveConfig();
                                }
                            });
                        }
                        if (next) {
                            items.push({
                                text: 'Move down',
                                scope: this,
                                iconCls: 'icon-down',
                                handler: function (item) {
                                    parent.removeChild(record);
                                    parent.insertBefore(record, next.nextSibling);
                                    saveConfig();
                                }
                            });
                        }
                    }

                    var menu = new Ext.menu.Menu({items: items});
                    menu.showAt(event.getXY());
                }
            },
        })
        
        lteLogs.refreshClientGrid = function () {
            clientGridUpdate(selectedClientRecord);
        };

        lteLogs.load = Ext.Function.bind(function (l) {
            this.viewport.setLoading(l);
        }, this);

        // **************************************************************
        // * Logs update
        // **************************************************************
        var logState = {
            logs:               [],
            resetMetadata:      false,
            minLevelDetected:   10,
            newLogs:            [],
            filter:             false,
            updateGrid:         false,
        };

        // External API
        lteLogs.updateLogs = function (force) {

            logState.force = logState.force || force;
            logsUpdater.update(true);
        };

        lteLogs.getLogs = function (client) {
            if (!client)
                return logState.logs;
            return logState.logs.filter(function (log) { return log.client === client; });
        },

        // Shortcuts
        lteLogs.updateFilter = function () {
            if (logState.filter !== 'lock') {
                logState.filter = true;
                logsUpdater.updateNow();
            }
        };
        lteLogs.lockFilter = function (state) {
            if (state)
                logState.filter = 'lock';
            else {
                logState.filter = true;
                logsUpdater.updateNow();
            }
        };

        lteLogs.selectLog = function (log) {
            if (!log.filtered)
                logListPanel.selectLog(log);
        };

        lteLogs.gotoTime = function (time) {
            switch (typeof time) {
            case 'string':
                logListPanel.gotoTime(lteLogs.str2ts(time));
                break;
            case 'number':
                logListPanel.gotoTime(time);
                break;
            }
        };

        // Logs state
        var gridLocker = lteLogs.gridLocker = Ext.create("lte.updater", {
            name:            "Grid.locker",
            scope:            this,
            updateDelay:    100,
            async:            true,
            handler:        function () {

                // Update metadata
                _updateMetadata();

                logState.newLogs.length = 0;
                logListPanel.setLogs(logState.logs, logState.follow);
                exportLogButton.setDisabled(!logListPanel.hasLogs());
            }
        });

        var logsUpdater = Ext.create("lte.updater", {
            name:            "Logs.updater",
            scope:            this,
            updateDelay:    1000,
            async:            true,
            handler:        function () {

                logsUpdater.lock();
                lteLogs.logStateUpdate(logState, function () {

                    logsUpdater.unlock();

                    // Update grid ?
                    if (logState.updateGrid) {
                        logsTab.setTitle('Logs: ' + logState.logs.length);
                        if (logState.updateGrid === "now")
                            gridLocker.updateNow();
                        else
                            gridLocker.update(true);
                    }

                });

            }
        });

        var _updateMetadata = function () {

            var minLevel = logState.minLevelDetected;
            if (logState.resetMetadata) {
                logState.minLevelDetected = 10;
                for (var i in filterComponentsData) {
                    if (filterComponentsData[i].cur) {
                        var cur = filterComponentsData[i].cur = {};
                    }
                }
                var logList = logState.logs;
                logState.resetMetadata = false;
            } else {
                var logList = logState.newLogs;
            }

            var l = logList.length;
            while (l--) {
                var log = logList[l];
                if (log.hints) continue;
                for (var j in filterComponentsData) {
                    var type = log[j];
                    if (type !== undefined) {
                        var cur = filterComponentsData[j].cur;
                        if (cur !== undefined) cur[type] = true;
                    }
                }
                logState.minLevelDetected = Math.min(logState.minLevelDetected, log.level);
            }

            // Update filters and logs
            filtersUpdate(logList);

            // Less
            if (minLevel < logState.minLevelDetected) {
                if (minLevel <= 1)
                    errorInfoButton.setVisible(false);
                if (minLevel <= 2)
                    warnInfoButton.setVisible(false);
            } else if (minLevel > logState.minLevelDetected) {
                if (logState.minLevelDetected <= 1)
                    errorInfoButton.setVisible(true);
                if (logState.minLevelDetected <= 2)
                    warnInfoButton.setVisible(true);
            }

            /* Update specific columns */
            var data      = false;
            var phy       = false;
            var rb        = false;
            var signal    = false;
            var us        = false;
            var level     = false;
            clientList.clients.forEach(function (c) {
                phy = phy || c.hasPhy();
                data = data || c.hasData();
                rb = rb || c.hasRB();
                signal = signal || c.hasSignal();
                us = us || c.hasUs();
                level = level || c.hasLevel();
            });
            if (us) {
                logListPanel.setColumnSize(0, 110);
                logListPanel.setColumnSize(1, 100);
                logListPanel.setUs(true);
            } else {
                logListPanel.setColumnSize(0, 90);
                logListPanel.setColumnSize(1, 80);
                logListPanel.setUs(false);
            }

            var cid = modelList.length * 2 + 3;

            if (filterComponentsData.imsi) {
                var imsi = Object.keys(filterComponentsData.imsi.cur).length > 0;
                logListPanel.setColumnState(cid++, imsi);
                logListPanel.setColumnState(cid++, false);
                filterComponents.imsi.setVisible(imsi);
            } else {
                var imei = Object.keys(filterComponentsData.imei.cur).length > 0;
                logListPanel.setColumnState(cid++, false);
                logListPanel.setColumnState(cid++, imei);
            }

            var cell = Object.keys(filterComponentsData.cell.cur).length > 0;
            filterComponents.cell.setVisible(cell);
            logListPanel.setColumnState(cid++, cell);

            logListPanel.setColumnState(cid++, phy);

            var rnti = Object.keys(filterComponentsData.rnti.cur).length > 0;
            filterComponents.rnti.setVisible(rnti);
            logListPanel.setColumnState(cid++, rnti);

            showChartButton.setDisabled(!phy && !data);
            showRBButton.setDisabled(!rb);
            if (level) {
                filterComponents.level.setDisabled(false);
            } else {
                filterComponents.level.setValue();
                filterComponents.level.setDisabled(false);
            }
        }

        var filterComponentsData = {
            "layer": {"last": {}, "cur": {}},
            "level": {},
            "global_ue_id": {"last": {}, "cur": {}},
            "info":  {"last": {}, "cur": {}},
            "cell":  {"last": {}, "cur": {}},
            "rnti":  {"last": {}, "cur": {}},
            "imsi":  {"last": {}, "cur": {}},
        };
        var filterValueFormater = lteLogs.filterValueFormater = function (type, value, highLight) {
            var text, display, style;

            // Default
            text = display = value;

            switch (type) {
            case 'global_ue_id':
                if (value !== undefined) {
                    value = value - 0;
                    if (isNaN(value))
                        value = display;
                } else {
                    display = 'None';
                }
                break;
            case "layer":
                if (layerConfig[value] !== undefined) {
                    style = 'border: 1px solid; border-color: ' + layerConfig[value].color + ';';
                } else {
                    style = 'border: 1px solid; border-color: #8080FF;';
                }
                break;
            case "level":
                text = lteLogs.levels[value];
                display = '<img src="resources/images/' + text + '.png" height="13"> ' + text;
                break;
            case 'info':
                if (value === undefined) {
                    display = text = 'None';
                } else {
                    value = value - 0;
                    text = lteLogs.id2string(value);
                    display = (highLight ? search.highlight(text) : text);
                }
                break;
            case 'imsi':
            case 'imei':
                if (value === undefined) {
                    display = text = 'None';
                } else {
                    display = (highLight ? search.highlight(text) : text);
                }
                break;
            case 'dir':
                if (value === DIR_NONE) display = 'None';
                else if (value === DIR_DL) display = 'DL';
                else if (value === DIR_UL) display = 'UL';
                break;
            case 'cell':
                if (value === undefined) {
                    display = 'None';
                } else {
                    display = (highLight ? search.highlight(value) : value);
                }
                break;
            case 'rnti':
                if (value === undefined) {
                    display = 'None';
                } else {
                    text = '0x' + (value - 0).toString(16);
                    display = (highLight ? search.highlight(text) : text);
                }
                break;
            default:
                display = (highLight ? search.highlight(value) : value);
                break;
            }
            if (display === 'None' && ! style)
                style = 'color: #8080FF;';

            return {
                style: style || '',
                text: text,
                display: display,
                value: value
            };
        }

        var filtersUpdate = function (logList) {

            filterData.updating = true;
            for (var i in filterComponentsData) {
                var data = filterComponentsData[i];
                // List has changed
                if (data.cur && !Ext.Object.equals(data.cur, data.last)) {

                    var list = Object.keys(data.cur).map(filterValueFormater.bind(this, i));

                    // Retrieve selection
                    var fData   = filterData[i];
                    var select  = [];
                    for (var j in list) {
                        if (fData.indexOf(list[j].value) >= 0) {
                            select.push(list[j].value);
                        }
                    }
                    switch (i) {
                    case 'cell':
                    case 'rnti':
                    case 'global_ue_id':
                        list.unshift(filterValueFormater(i, undefined));
                        break;
                    case 'layer':
                        list.sort(function (a, b) { return a.text.localeCompare(b.text); });
                        break;
                    case 'info':
                        list.sort(function (a, b) { return a.text.localeCompare(b.text); });
                        list.unshift(filterValueFormater(i, undefined));
                        break;
                    case 'imsi':
                    case 'imei':
                        list.sort(function (a, b) { return a.text.localeCompare(b.text); });
                        list.unshift(filterValueFormater(i, undefined));
                        break;
                    }
                    filterComponents[i].getStore().loadData(list);
                    filterComponents[i].select(select);
                    data.last = Ext.Object.merge({}, data.cur);
                }
            }
            filterData.updating = false;

            for (var i = 0; i < logList.length; i++) {
                var log = logList[i];
                filterLog(log);
            }
        };

        // **************************************************************
        // * Logs update end
        // **************************************************************


        var tabPanel = Ext.create('Ext.tab.Panel', {
            height: 400,
            border: false,
            items: [],
        });
        lteLogs.addTab = function (tab, active) {
            var tab = tabPanel.add(tab);
            if (active)
                tabPanel.setActiveTab(tab);
            return tab;
        };


        // Create draw container
        var logListSlider = Ext.create('Ext.slider.Single', {
            hideLabel: true,
            useTips: false,
            vertical: true,
            minValue: 0,
            maxValue: 0,
            increment: 1,
        });
        var logListPanel = lteLogs.logListPanel = Ext.create('lte.logsgrid', {slider: logListSlider});

        gridLocker.lock("tab");
        var logsTab = lteLogs.addTab({
            'title': 'No logs loaded yet',
            'iconCls': 'icon-logs',
            'layout': 'border',
            'items': [{
                region: 'east',
                width: 400,
                split: true,
                collapsible: true,
                collapsed: false,
                header: false,
                layout: 'fit',
                border: false,
                items: infoPanel
            }, {
                region: 'center',
                layout: 'border',
                itemId: 'logsPanel',
                dockedItems: [
                    Ext.create('Ext.toolbar.Toolbar', {
                        items: [
                            filterComponents.dir,
                            filterComponents.layer,
                            filterComponents.global_ue_id,
                            this.switchIMSIButton,
                            filterComponents.imsi,
                            filterComponents.cell,
                            filterComponents.rnti,
                            filterComponents.info,
                            filterComponents.level,
                            filterComponents.text,
                        ]
                    }),
                    Ext.create('Ext.toolbar.Toolbar', {
                        items: [
                            filterComponents.time,
                            filterComponents.ue_gid,
                            '->',
                            this.clearFiltersButton,
                            this.filtersListCombo,
                            this.filtersCreateButton,
                            this.filtersDeleteButton,
                        ]
                    }),
                    this.logToolbar
                ],
                border: 0,
                items: [{
                    region: 'south',
                    layout: 'fit',
                    itemId: 'dataPanel',
                    border: false,
                    split: true,
                    items: [],
                }, {
                    region: 'center',
                    layout: 'fit',
                    border: 0,
                    items: [logListPanel]
                }, {
                    region: 'east',
                    layout: 'fit',
                    border: 0,
                    items: [logListSlider]
                }]
            }],
            listeners: {
                activate: function () {
                    gridLocker.unlock("tab");
                },
                deactivate: function () {
                    gridLocker.lock("tab");
                }
            }
        });

        var leftPanel = Ext.create('Ext.panel.Panel', {
            title: "Amarisoft Web GUI 2025-06-13",
            tools: [/*{
                type: 'help',
                handler: function(e, toolEl, panel, tc) {
                    var win = new Ext.Window({
                        title: 'Documentation',
                        html: '<iframe src="doc/ltewww.html" width="100%" height="100%" />',
                        maximizable: true,
                        height: 500,
                        width: 900,
                        modal: true,
                        plain:true,
                    });
                    win.show();
                }
            }*/],
            tbar: this.clientToolbar,
            region: 'west',
            layout: 'fit',
            width: 320,
            border: false,
            split: true,
            collapsible: true,
            collapsed: lteLogs.mode === 'app',
            items: clientGrid,
        });

        this.borderContainer = Ext.create('Ext.container.Container', {
            height: 'auto',
            layout: 'border',
            border: false,
            items: [leftPanel, {
                region: 'center',
                layout: 'fit',
                border: false,
                items: tabPanel
            }]
        });

        this.viewport.add(this.borderContainer);


        mainClientNodes.file = addClient(null, { type: 'file', name: 'Files', list: [], expanded: true }),
        mainClientNodes.server = addClient(null, { type: 'server', name: 'Servers', list: [], expanded: true }),
        mainClientNodes.url = addClient(null, { type: 'url', name: 'URLs', list: [], expanded: true }),
        mainClientNodes.localfile = mainClientNodes.file;

        var addWSClient = function (url) {

            var ws = url.match(/ws:\/\/([0-9\.\w-]+):([0-9]+)$/);
            if (!ws)
                return false;

            var host = ws[1];
            var port = ws[2];
            lteLogs.addClient({
                type: 'server',
                name: url,
                address: host + ':' + port,
                readonly: true,
                skipLogMenu: true,
                enabled: true,
                active: true,
                reconnectDelay: 2500,
            });
            return true;
        };

        switch (lteLogs.mode) {
        case 'app':
            var gui = require('nw.gui');
            var fs = require('fs');
            var path = require('path');
            var title = [];
            var files = [];

            for (var i = 2; i < gui.App.argv.length; i++) {
                var arg = gui.App.argv[i];
                switch (arg) {
                case '--export-text':
                    this.exportMode = 'text';
                    break;
                case '--max':
                case '--info':
                case '--layer':
                    lteLogs.configure('logs' + arg.slice(1), gui.App.argv[++i]);
                    break;
                case '--range':
                    var a = gui.App.argv[++i];
                    var b = gui.App.argv[++i];
                    lteLogs.configure('logs-range', [a, b]);
                    break;
                case '--file':
                    files.push(gui.App.argv[++i]);
                    break;
                case '--export-time':
                    LTELog.prototype.exportTimeFormat = gui.App.argv[++i];
                    break;
                case '--inline-cache':
                    inlineCache.on = true;
                    break;
                }
            }

            for (var i = 0; i < files.length; i++) {
                var cli = files[i];

                // WS client
                if (addWSClient(cli)) {
                    title.push(cli);
                    continue;
                }

                // File
                if (!path.isAbsolute(cli))
                    cli = path.join(gui.App.argv[1], cli);

                if (fs.existsSync(cli)) {
                    lteLogs.addClient({type: 'localfile', name: cli, file: cli, enabled: true});
                    title.push(cli.replace(/(.+\/)([^\/]+)/, '$2 ($1)'));
                    leftPanel.collapse();
                    continue;
                }

                console.log('Bad client: ' + cli);
                process.exit(1);
            }
            document.title = title.join(', ');
            break;

        case 'web':
            Ext.Ajax.request({
                url: 'loglist.php',
                scope: this,
                success: function(response, opts) {
                    var list = Ext.decode(response.responseText);

                    for (var i in list) {
                        list[i].readonly = true;
                        addClient(null, list[i]);
                    }
                },
            });

            // Parse URL
            var parser = document.createElement('a');
            parser.href = location.href;
            parser.search.substr(1).split(/&/).forEach(function (p) {
                p = p.split(/=/);
                switch (p[0]) {
                case 'client':
                    var url = decodeURIComponent(p[1]);
                    if (url) {
                        if (!addWSClient(url))
                            lteLogs.addClient({name: url, type: 'url', url: url, locked: true, enabled: true});
                        leftPanel.collapse();
                    }
                    break;
                case 'export-time':
                    var format = decodeURIComponent(p[1]);
                    localStorage.exportTimeFormat = format;
                    LTELog.prototype.exportTimeFormat = format;
                    break;
                case 'logs-max':
                case 'logs-info':
                case 'logs-layer':
                    lteLogs.configure(p[0], p[1]);
                    break;
                case 'logs-range':
                    lteLogs.configure(p[0], p[1].split(/-/));
                    break;
                }

            });
            break;
        }

        // Load last known config
        if (localStorage.clients) {
            // Recover from local storage
            var config = JSON.parse(localStorage.clients);
            if (config instanceof Array) { // Legacy
                config = { persistent: config, ids: {} };
            }

            for (var i in config.persistent) {
                var cfg = config.persistent[i];
                lteLogs.addClient(cfg, ['removable', 'persistent']);
            }
            clientStoredConfigs = config.ids;
        }
        clientGridUpdate(null);

        lteSim.init();

    },

    exportMode: 'zip',

});

var process;

var lteLogs = {

    mode: 'web',

    fontDef: "13px helvetica, arial, verdana, sans-serif",

    lastClientId: 0,

    init: function () {
        var def = this.channelsDef = {};
        var ids = this.channelIds  = {};

        this._channelsDef.forEach( (chan, index) => {
            var id = this.string2id(chan.name);
            def[id] = def[chan.name] = chan;
            chan.id = id;
            chan.index = index;
            if (!chan.label)
                chan.label = chan.name;
            ids[chan.name] = id;
        });

        // NodeJS mode
        if (process !== undefined) {
            console = new (require('console').Console)(process.stdout, process.stderr);

            var gui = require('nw.gui');
            gui.Window.get().maximize();
            this.mode = gui.App.argv[0];
            //gui.Window.get().showDevTools(); // Windows debug
        }
    },

    // Config
    configure: function (param, value) {
        console.log('Configure', param, value);
        switch (param) {
        case 'logs-max':
            var v = lteLogs.string2size(value);
            if (isNaN(v) || v <= 0)
                return this.printError("Bad logs max", v, '/', value);

            this.LOGS_MAX = value;
            break;
        case 'logs-range':
            if (!this.LOGS_RANGE) this.LOGS_RANGE = [];
            var a = this.string2size(value[0]);
            var b = this.string2size(value[1]);
            if (isNaN(a) || a < 0 || isNaN(b) || b < 0)
                return this.printError("Bad logs range", a, b);

            this.LOGS_RANGE.push([a, b]);
            break;
        case 'logs-info':
            if (!this.LOGS_INFO) this.LOGS_INFO = [];
            this.LOGS_INFO.push(this.string2id(value));
            break;
        case 'logs-layer':
            value = value.toUpperCase();
            if (!this.LOGS_LAYERS) this.LOGS_LAYERS = [];
            this.LOGS_LAYERS.push(value);
            break;
        default:
            return this.printError("Unknown parameter", param);
        }
    },

    printError: function () {
        var args = Array.from(arguments);
        switch (lteLogs.mode) {
        case 'app':
            console.error.apply(console.error, args);
            process.exit(1);
            break;
        case 'web':
            Ext.Msg.alert('Error', args.join(' '));
            break;
        }
    },

    _channelsDef: [
        {name: "PRACH",  color: "#ffff00"},
        {name: "NPRACH", color: "#ffff00"},
        {name: "SRS",    color: "#ffff80"},
        {name: "PUCCH",  color: "#00ff00"},
        {name: "PUSCH",  color: "#ff0000"},
        {name: "NPUSCH", color: "#ff0000"},

        {name: "PDSCH",  color: "#0000ff"},
        {name: "NPDSCH", color: "#0000ff"},
        {name: "PDCCH",  color: "#00ffff"},
        {name: "EPDCCH", color: "#00ffff"},
        {name: "NPDCCH", color: "#00ffff"},

        {name: "SSB",    color: "#c040ff"},
        {name: "PRS",    color: "#808080"},
        {name: "CSIRS",  color: "#40c0b0", label: 'CSI-RS'},
        {name: "CSIIM",  color: "#404040", label: 'CSI-IM'},

        {name: "PMCH",   color: "#ff80ff"},
        {name: "INV",    color: "#D0D0D0"},
    ],

    getChannelDefByName: function (name) {
        return this.channelsDef[this.string2id(name)];
    },

    _logs: {},
    _logDefaultLevel: localStorage.debug >> 0,
    _logsMethods: ["error", "warn", "info", "debug", "prof"],
    _startDate: new Date() * 1,

    _log: function (module, id, log) {

        log.ts = new Date() - this._startDate;

        if (module.list.push(log) > 20)
            module.list.shift();

        if (log.level & module.level) {
            if (log.level & 0x1 && module.level === 0x1) {
                for (var i in module.list) {
                    this._logDisplay(id, module.list[i]);
                }
                module.list = [];
            } else {
                this._logDisplay(id, log);
            }
        }
    },

    _logDisplay: function(id, log) {
        var time  = this.ts2time(log.ts);
        if (log.level & 0x1) {                    // Error
            var style = "background: red";
            var index = 0;
        } else if (log.level & 0x2) {            // Warning
            var style = "background: yellow";
            var index = 1;
        } else if (log.level & 0x10) {            // Prof
            var style = "background: #00ff00";
            var index = 4;
        } else {
            var style = "";
            var index = Math.floor(Math.log2(log.level));
        }
        var args = ["%c[" + time + "][" + this._logsMethods[index].toUpperCase() + "][" + id + "]", style];
        args.push.apply(args, log.args);
        console.log.apply(console, args);
    },

    setLogger: function (name, instance) {
        var module = this._logs[name] = {level: this._logDefaultLevel, list: []};

        this._logsMethods.forEach((function (id, i) {
            instance[id] = (function () {
                this._log(module, name, {level: (1<<i), args: arguments});
            }).bind(this);
        }).bind(this));
    },

    tooltip: function (txt) {
        //return 'data-qtip="' + txt + '"';
        return txt ? txt.replace(/ /g, "&nbsp;") : '';
    },

    merge: function (dst, src, override) {
        for (var i in src) {
            if (override || !dst.hasOwnProperty(i))
                dst[i] = src[i];
        }
        return dst;
    },

    clone: function (o) {
        if (typeof o !== 'object' || o === null) return o;
        var clone = o instanceof Array ? [] : {};
        for (var i in o) {
            clone[i] = this.clone(o[i]);
        }
        return clone;
    },

    padLeft: function (txt, c, len) {
        txt = ""+txt;
        while (txt.length < len) txt = c + txt;
        return txt;
    },

    // ts is in milliseconds
    ts2time: function (ts, full, us) {
        // Duration (< 2000-01-01 00:00:00)
        if (ts < 946681200000)
            return this.ts2duration(ts);

        var prefix = '';
        var d = new Date(ts);
        if (full) {
            var day = d.getDate();
            var month = d.getMonth() + 1;
            var year = d.getFullYear();
            prefix = year + '-' + ('0' + month).slice(-2) + '-' + ('0' + day).slice(-2) + ' ';
        }
        var h = d.getHours();
        var m = d.getMinutes();
        var s = d.getSeconds();

        return prefix + ('0' + h).slice(-2) + ':'
            + ('0' + m).slice(-2) + ':'
            + ('0' + s).slice(-2) + '.'
            + ('00' + d.getMilliseconds()).slice(-3);
    },

    ts2duration: function (ts) {
        var prefix = '';
        if (ts < 0) {
            prefix = "-";
            ts = -ts;
        }
        var d = new Date(ts);
        var h = d.getUTCHours();
        var m = d.getUTCMinutes();
        var s = d.getUTCSeconds();
        return prefix + ('0' + h).slice(-2) + ':'
            + ('0' + m).slice(-2) + ':'
            + ('0' + s).slice(-2) + '.'
            + ('00' + d.getMilliseconds()).slice(-3);
    },

    ts2timeUs: function (ts, full) {
        return this.ts2time(Math.round(ts / 1000), full) + ((ts % 1000) + '00').slice(0, 3);
    },

    ts2durationUs: function (ts) {
        return this.ts2duration(Math.round(ts / 1000)) + ((ts % 1000) + '00').slice(0, 3);
    },

    tsDayOffset: function (ts) {
        if (ts < 946681200000)
            return 0;

        var d = new Date(ts);
        d.setMinutes(0);
        d.setSeconds(0);
        d.setHours(0);
        return d * 1;
    },

    str2ts: function (value) {
        value = value.match(/^(((\d+):)?(\d+):)?(\d+)(\.(\d+))?$/);
        if (value) {
            var h = value[3] >> 0;
            var m = value[4] >> 0;
            var s = value[5] >> 0;
            var ms = value[7] || "0";
            ms = ((ms - 0) * Math.pow(10, 3 - ms.length)) >> 0;
            return h * 3600000 + m * 60000 + s * 1000 + ms;
        }
        return false;
    },

    hash: function (str) {
        var h = 5381;

        for (var i = 0; i < str.length; i++) {
            var c = str[i] >>> 0;
            h = ((h << 5) + h) ^ c;
        }
        return (h >>> 0);
    },

    levels: ["none", "error", "warn", "info", "debug"],

    getLevel: function (str) {
        for (var i = 0; i < this.levels.length; i++) {
            if (this.levels[i] === str)
                return i;
        }
        return -1;
    },

    getHTMLIcon: function (c) {
        return "<img src='data:image/gif;base64,R0lGODlhAQABAID/AMDAwAAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==' class='x-tree-icon " + c + "'>";
    },

    mapFilter: function (array, func) {
        var res = [];
        for (var i = 0, length = array.length; i < length; i++) {
            var item = func(array[i], i);
            if (item !== undefined)
                res.push(item);
        }
        return res;
    },

    drawConstellation: function (canvas, constel) {
        var ctx = canvas.getContext("2d");
        ctx.fillStyle="black";
        ctx.fillRect(0, 0, 255, 255);
        ctx.fillStyle="#ffffff";
        ctx.globalAlpha=0.2;
        for (var i = 0; i < constel.byteLength; ) {
            var x = constel[i++] + 128;
            var y = constel[i++] + 128;
            ctx.fillRect(x, y, 1, 1);
        }
    },

    createIcon: function (icon, tooltip) {
        return '<img src="resources/images/' + icon + '.png" height=12 title="' + tooltip + '">';
    },

    getColLight: function (c) {
        var m = c.match(/#([\da-fA-F]{2})([\da-fA-F]{2})([\da-fA-F]{2})/);
        if (m) {
            var r = parseInt(m[1], 16);
            var g = parseInt(m[2], 16);
            var b = parseInt(m[3], 16);
            var h = (r * r * 0.299 + g * g * 0.587 + b * b * 0.114) / (255 * 255);
            return h;
        }
        return 1;
    },

    getTextColor: function (bgColor) {

        var h = this.getColLight(bgColor);
        if (h >= 0.15) return 'black';
        return 'white';
    },

    // Constants XXX: use global const
    DIR_NONE: DIR_NONE,
    DIR_UL:   DIR_UL,
    DIR_DL:   DIR_DL,
    DIR_FROM: DIR_FROM,
    DIR_TO:   DIR_TO,

    _stringIDs: {},
    _stringList: [],
    string2id: function (str) {

        var id = this._stringIDs[str];
        if (!id) {
            id = this._stringIDs[str] = this._stringList.push(str);
        }
        return id;
    },

    id2string: function (id) {
        if (id > 0) return this._stringList[id - 1] || '';
        return '';
    },

        arrayIntersect: function (a, b) {
            for (var i = a.length; i--;) {
                var index = b.indexOf(a[i]);
                if (index < 0)
                    a.splice(i, 1);
            }
        },

    string2size: function (str) {
        if (!str) return 0;
        var s = str.match(/^(\d+)([KMG])$/);
        if (s) {
            var size = s[1] - 0;
            if (s[2] === 'K') size *= 1e3;
            else if (s[2] === 'M') size *= 1e6;
            else if (s[2] === 'G') size *= 1e9;
            return size;
        }
        return parseInt(str);
    },

    splitArgs: function (args, cfg) {
        var hash = {};
        args.split(_regExpParams1).forEach( function (arg) {
            var a = arg.split('=');
            switch (typeof cfg[a[0]]) {
            case 'number':
                hash[a[0]] = a[1] - 0;
                break;
            case 'function':
                hash[a[0]] = cfg[a[0]](a[1]);
                break;
            default:
                hash[a[0]] = a[1];
                break;
            }
        });
        return hash;
    },

    // Events
    _eventListeners: {},
    _eventListenerId: 0,

    registerEventListener: function (type, cb) {
        var id = this._eventListenerId++;
        this._eventListeners[id] = {type: type, cb: cb};
        return id;
    },

    unregisterEventListener: function (id) {
        delete this._eventListeners[id];
    },

    sendEvent: function (event) {

        var type = event.type;
        for (var i in this._eventListeners) {
            var el = this._eventListeners[i];
            switch (el.type) {
            case type:
            case '*':
                el.cb(event);
                break;
            }
        }
    },

    getMouseWheelEvent: function () {
        return (/Firefox/i.test(navigator.userAgent)) ? "DOMMouseScroll" : "mousewheel";
    },

    getMouseWheelDelta: function (event) {
        if (event.detail)
            return event.detail * -120;
        else
            return event.wheelDelta;
    },

    fixFilename: function (filename) {
        return filename.replace(/ /g, '_').replace(/[\|\/]/g, '-');
    },

    exportFile: function (data, filename, mimetype) {

        filename = this.fixFilename(filename);

        if (!(data instanceof Array))
            data = [data];

        var blob = new Blob(data, { type: mimetype });
        if (navigator.msSaveBlob) { // IE 10+
            navigator.msSaveBlob(blob, filename);
        } else {
            var link = document.createElement("a");
            if (link.download !== undefined) { // feature detection
                // Browsers that support HTML5 download attribute
                var url = URL.createObjectURL(blob);
                link.setAttribute("href", url);
                link.setAttribute("download", filename);
                link.style = "visibility:hidden";
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            }
        }
    },

    _sortLogs: function (a, b) {
        return a.timestamp - b.timestamp || a.id - b.id;
    },

    _getLogIndexByTimestamp: function(list, timestamp) {
        var l = list.length;
        var b = l - 1;
        var a = 0;
        for (; a <= b;) {

            var i = (a + b) >> 1;
            var ts_i = list[i].timestamp;

            if (timestamp < ts_i) { // Before middle
                b = i - 1;
            } else if (timestamp > ts_i) { // After middle
                a = i + 1;
            } else {
                while (++i < l && list[i].timestamp === timestamp);
                return i;
            }
        }
        return a;
    },

    mergeLogs: function (srcList, dstList) {

        var srcLength = srcList.length;

        // Try to insert
        var t0 = new Date() - 0;
        var dstLength = dstList.length;
        if (dstLength > 500000 && srcLength < 50000) {
            // Sort new data
            srcList.sort(this._sortLogs);
            var t1 = new Date() - 0;

            // Insert
            var a = this._getLogIndexByTimestamp(dstList, srcList[0].timestamp);

            for (var i = 0; i < srcLength; i++) {
                var log = srcList[i];
                var ts  = log.timestamp;

                for (; a < dstLength; a++) {
                    var ts_a = dstList[a].timestamp;
                    if (ts < ts_a) break;
                }
                if (a === dstLength) {
                    while (i < srcLength) {
                        dstList.push(srcList[i++]);
                    }
                    break;
                }
                dstList.splice(a, 0, log);
                a++;
                dstLength++;
            }

        // Compute everything
        } else {
            dstList = dstList.concat(srcList);
            var t1 = new Date() - 0;
            dstList.sort(this._sortLogs);
            dstLength = dstList.length;
        }

        lteLogs.prof(srcLength + " log(s) added", (t1 - t0) + "ms", (new Date() - t1) + "ms", dstLength);
        return dstList;
    },

    registerMouseMove: function (cb) {

        var mouseUpCb = function (event) {
            window.removeEventListener('mouseup', mouseUpCb);
            window.removeEventListener('mousemove', mouseMoveCb);
            cb(event);
        };
        var mouseMoveCb = function (event) {
            cb(event);
        };
        window.addEventListener('mouseup', mouseUpCb, false);
        window.addEventListener('mousemove', mouseMoveCb, false);

    },

    storeUpdate: function (cache, store, list, id, addOnly, cb) {

        var found = {};

        list.forEach((item) => {
            var prop = item[id];
            var cur = cache[prop];
            if (!cur) {
                if (cb) cb(item, null);
                var index = store.getCount();
                store.add(item);
                cur = cache[prop] = store.getAt(index);
            } else {
                if (cb) cb(item, cur);
                cur.set(item);
            }
            found[prop] = true;
        });

        if (!addOnly) {
            for (var i = store.getCount(); i--;) {
                var record = store.getAt(i);
                var prop   = record.get(id);
                if (!found[prop]) {
                    store.removeAt(i);
                    cache[prop] = null;
                }
            }
        }
    },

    storeGetById: function (store, id, value) {
        for (var i = store.getCount(); i--;) {
            var record = store.getAt(i);
            if (record.get(id) === value)
                return record.getData();
        }
        return null;
    },

    logStateUpdate: function (logState, cb) {

        lteLogs.debug("Update logs");

        var logs = logState.logs;

        // Filter current
        if (logState.filter || logState.force) {
            logState.updateGrid    = "now";
            logState.resetMetadata = true;
            logState.filter        = false;
            logState.force         = false;
        } else {
            logState.updateGrid    = false;
        }

        // Get new logs from each client
        logState.follow = false;
        var newLogs = [];

        var clients = clientList.clients;
        var clientCount = 0;
        for (var i = clients.length; i--;) {
            var client = clients[i];

            var state = client.getLogs();

            if (client.isEnabled())
                clientCount++;

            // Reset current ?
            if (state.reset) {
                lteLogs.debug("Reset logs", client.getName());
                logs                   = logs.filter(function (log) { return log.client !== client; });
                logState.updateGrid    = logState.updateGrid || true;
                logState.resetMetadata = true;
            }

            lteLogs.debug("Add logs", client.getName());
            newLogs = newLogs.concat(state.logs);
            if (client.isRealTime())
                logState.follow = true;
        }

        if (!newLogs.length)
            return this.logStateUpdateEnd(logState, logs, cb);

        logState.newLogs = logState.newLogs.length ? logState.newLogs.concat(newLogs) : newLogs;

        //lteLogs.sendEvent({type: 'newLogs', logs: newLogs});

        logState.updateGrid = true;

        logs = logs.concat(newLogs);

        if (clientCount === 1)
            return this.logStateUpdateEnd(logState, logs, cb);

        var length = logs.length;
        var tabTS = new Int32Array(length);
        var tabID = new Int32Array(length);
        var ts0 = logs[0].timestamp;
        for (var i = 0; i < length; i++) {
            tabTS[i] = logs[i].timestamp - ts0;
            tabID[i] = logs[i].id;
        }
        this.logsSortWorker.postMessage({ts: tabTS, id: tabID}, [tabTS.buffer, tabID.buffer]);

        this.logsSortWorker.onmessage = (function (e) {

            var tabIdx = e.data;
            var logs1 = new Array(length);
            for (var i = 0; i < length; i++) {
                logs1[i] = logs[tabIdx[i]];
            }
            this.logStateUpdateEnd(logState, logs1, cb);

        }).bind(this);
    },

    logStateUpdateEnd: function (logState, logs, cb) {

        // Too much logs ?
        var toRemove = logs.length - lteLogs.LOGS_MAX;
        if (toRemove > 0) {
            lteLogs.info("Remove", toRemove, "logs");
            var remove = logs.splice(0, toRemove);
        }

        this.logs = logState.logs = logs;
        cb();
    },

    logsSortWorker: new Worker('logssort.js'),

    setCanvasSize: function (canvas, width, height) {

        canvas.width = width;
        canvas.height = height;

        if (Ext.isChrome && Ext.chromeVersion >= 83) {
            canvas.style['image-rendering'] = 'pixelated';
        }
        /*
        var style = window.getComputedStyle(canvas);
        var w = style.getPropertyValue('width').replace(/px/, '') - 0;
        var h = style.getPropertyValue('height').replace(/px/, '') - 0;
        console.log(width, w);
        console.log(height, h);
        //canvas.getContext('2d').imageSmoothingEnabled = false;
        */
    },

    loadFile: function (options) {
        var f = document.getElementById('bin-file');
        if (options.multiple) f.setAttribute('multiple', 'multiple');
        else                  f.removeAttribute('multiple');

        var cb = options.cb;
        var type = options.type || 'bin';
        var scope = options.scope;

        var timer = 0;
        var callCb = function (res) {
            if (timer)
                clearTimeout(timer);
            timer = 0;
            if (cb) {
                cb.call(options.scope, res);
                cb = null;
            }
        };

        f.onchange = function () {
            document.body.onfocus = null;

            var count = f.files.length;
            if (!count) {
                callCb(null);
                return;
            }

            var results = [];
            for (var i = 0; i < count; i++) {
                var file = f.files[i];

                var reader = new window.FileReader();
                reader.onload = (function fileRead(file, e) {
                    var data = e.target.result;
                    switch (type) {
                    case 'base64':
                        data = data.replace(/^data:.*;base64,/, '');
                        break;
                    }
                    results.push({data: data, name: file.name});
                    if (!(--count)) {
                        callCb(results);
                    }
                }).bind(this, file);

                switch (type) {
                case 'base64':
                    reader.readAsDataURL(file);
                    break;
                default:
                    reader.readAsArrayBuffer(file);
                    break;
                }
            }
            f.value = '';
        };

        document.body.onfocus = function () {
            // On windows onfocus seems to be called before onchange, so defer cb
            timer = setTimeout(callCb.bind(this, null), 1000);
            document.body.onfocus = null;
        };
        f.click();
    },

    warnBox: function (title, message, cb, scope) {
        Ext.Msg.show({
            title: title,
            icon: Ext.Msg.WARNING,
            message: message,
            buttons: Ext.Msg.OK,
            scope: scope,
            callback: cb
        });
    },

    setWindowAutoHeight: function (win, config) {

        var h0 = 0;
        config = config || {};

        var resize = function () {
            if (!h0)
                return;

            var h = window.innerHeight;
            if (h < h0) {
                win.setHeight(h);
                win.setY(0);
            } else {
                win.setHeight(h0);
                win.setY((h - h0) >> 1);
            }
        };

        win.on('resize', function (win, w, h) {
            if (h0 === 0) {
                if (config.height)
                    h0 = config.height;
                else if (config.minHeight && config.minHeight > h)
                    h0 = config.minHeight;
                else
                    h0 = h;
                resize();
            }
        });
        win.on('close', function () {
            window.removeEventListener('resize', resize);
        });
        window.addEventListener('resize', resize);
    },

    getRexExp: function (value) {

        var re = (value || '').match(/^\/(.+)\/([gi]*)$/);
        try {
            if (re) {
                return new RegExp("(" + info[1] + ")", info[2]);
            }
            return new RegExp("(" + value + ")", "gi");
        } catch (e) {
        }
        return null;
    },

    localStorageGet: function (name) {
        var data = localStorage[name];
        if (data) {
            try {
                return JSON.parse(data);
            } catch (e) {
            }
        }
        return null;
    },

    localStorageSet: function (name, value) {
        localStorage[name] = JSON.stringify(value);
    },

    testColor: function () {
        this.addClient({name: 'test', type: 'test', enabled: true, model: 'MME'});
        lteLogs.gridColumnsUpdate();
    },

    createColorIcon: function (color, size) {
        if (!size) size = 15;

        var canvas = document.createElement('canvas');
        canvas.width = canvas.height = size;
        var ctx = canvas.getContext('2d');
        ctx.fillStyle = color;
        ctx.fillRect(0, 0, size, size);
        ctx.strokeStyle = 'block';
        ctx.lineWidth = 1;
        ctx.strokeRect(0.5, 0.5, size - 1, size - 1);
        return canvas.toDataURL();
    },

    /* v: value
     * n: significative digits
     * u0: unit
     * u1: unit for 1000
     * ...
     */
    format1000: function (v, n, u0) {
        if (isNaN(v))
            return '?';
        if (!u0) u0 = '';
        if (!v)
            return '0' + u0;

        var v0 = Math.abs(v);
        if (v0 < 0) {
            var k = Math.ceil(-Math.log10(v0));
            return v.toFixed(k + n - 1).replace(/0+$/,'') + 'u';
        }

        for (var i = arguments.length; --i > 1;) {
            var v1 = v / Math.pow(10, (i - 2) * 3);
            var v2 = Math.round(v1);
            if (v2) {
                var k = Math.log10(Math.abs(v2)) + 1;
                if (k < n) {
                    v2 = v1.toFixed(n - k);
                }
                return v2 + arguments[i];
            }
        }
        return '!'; // Never happens
    },

    formatBytes(v) {
        return this.format1000(v, 3, '', 'KB', 'MB', 'GB');
    },

    htmlText: function (text) {
        if (!(text instanceof Array)) text = [text];
        return text.map( (t) => {
            var p = document.createElement("p");
            p.textContent = text;
            return p.innerHTML;
        }).join('<br/>');
    },
};

lteLogs.init();
lteLogs.setLogger("DEFAULT", lteLogs);

var globalLogId = 0;



Ext.define("lte.locker", {

    constructor: function (config) {
        this._lockCount = config.lock >>> 0;
        this._handler = config.handlerbind(config.scope);
    },

    lock: function () {
        if (++this._lockCount === 1) {
            this._handler(true);
        }
    },

    unlock: function () {
        if (--this._lockCount === 0) {
            this._handler(false);
            this._lockCount = 0; // Fail safe
        }
    },
});


Ext.define("lte.updater", {

    constructor: function (config) {

        this._name               = config.name || "Locker",
        this._updateHandler      = config.handler;
        this._updateScope        = config.scope;
        this._updateDelay        = config.updateDelay | 0;
        this._autoDelay          = config.autoDelay | 0;
        this._updateAsync        = !!config.async;
        this._dirty              = !!config.dirty;
        this._lockCount          = config.lock >> 0;
        this._lockers            = {};
    },

    destroy: function () {
        if (this._updateTimer)
            clearTimeout(this._updateTimer);
    },

    lock: function (locker) {
        if (locker) {
            if (this._lockers[locker])
                return false;

            this._lockers[locker] = true;
        }
        this._lockCount++;
        return true;
    },

    unlock: function (locker) {
        if (locker) {
            if (!this._lockers[locker])
                return false;

            delete this._lockers[locker];
        }

        this._lockCount--;

        if (!this._lockCount) {
            this.update();
        } else if (this._lockCount < 0) {
            lteLogs.error("Bad count for", this._name);
        }
        return true;
    },

    isPending: function () {
        return this._updateTimer;
    },

    isLocked: function () {
        return this._lockCount > 0;
    },

    update: function (dirty) {

        if (dirty) {
            this._dirty = true;
        } else if (!this._dirty) {
            return false;
        }

        if (this._lockCount || this._updateTimer || this._updating)
            return false;

        if (this._updateAsync)
            this._updateLater(1, false);
        else
            this._update(false);
    },

    updateNow: function () {
        if (this._updateTimer)
            clearTimeout(this._updateTimer);

        this._update(false);
    },

    _update: function (delayed) {

        this._dirty = false;
        this._updating = true;
        this._updateHandler.call(this._updateScope, delayed);
        this._updating = false;

        // Auto
        if (this._autoDelay) {
            if (this._autoTimer)
                clearTimeout(this._autoTimer);
            this._autoTimer = Ext.Function.defer(function () {
                this._autoTimer = 0;
                this.update(true);
            }, this._autoDelay, this);
        }

        if (this._updateDelay > 0)
            this._updateLater(this._updateDelay, true);
        return true;
    },

    _updateLater: function (delay, delayed) {
        this._updateTimer = Ext.Function.defer(function () {
            this._updateTimer = 0;
            if (this._dirty && !this._lockCount) {
                this._update(delayed);
            }

        }, delay, this);
    },
});


lteLogs.popup = function (type, config) {
    if (typeof config === 'function')
        config = { callback: config };
    Ext.create(type, config);
};

Ext.define('lte.popup', {

    title: '???',
    extend: 'Ext.window.Window',
    layout: 'fit',
    resizeable: false,
    width: 300,
    modal: true,
    noChange: true,

    constructor: function (options) {

        this.fields = [];
        this.data = null;
        this.callParent(arguments);
    },

    initComponent: function () {
        this.callParent(arguments);

        this.form = Ext.create('Ext.form.Panel', {
            bodyPadding: 5,
            items: this.fields,
            buttons: [{
                text: 'Cancel',
                scope: this,
                handler: function() {
                    this.close();
                },
            }, '->', {
                text: 'OK',
                scope: this,
                handler: function() {
                    if (this.form.isValid()) {
                        if (this.noChange || this.form.isDirty())
                            this.data = this.form.getForm().getFieldValues();
                        this.close();
                    }
                },
            }],
        });

        this.add(this.form);
        this.show();
    },

    listeners: {
        close: function () {
            if (this.data)
                this.onData(this.data);
            if (this.callback)
                this.callback(this.data);
        },
    },

    onData: function (data) {
    },
});

