/*
 * Copyright (C) 2023-2025 Amarisoft
 *
 * Amarisoft ASN.1 Common
 */
var ASN1 = {

    fromGSER: function (data) {
        var stack = [];
        var lines = [];

        /* Remove hex dump */
        for (var i = 0; i < data.length; i++) {
            var d = data[i];
            if (!d.match(_regExpHexDump))
                break;
        }

        /* Remove comments */
        var com = false;
        var line = '';
        for (; i < data.length; i++) {
            var d = data[i].replace(/^\s+/, '').replace(/\s+$/, '');
            for (;;) {
                if (!com) {
                    var idx = d.indexOf('/*');
                    if (idx < 0) {
                        line += d;
                        if (line) {
                            lines.push(line);
                            line = '';
                        }
                        break;
                    }

                    line += d.substr(0, idx);
                    d = d.substr(idx + 2);
                    com = true;
                }

                var idx = d.indexOf('*/');
                if (idx < 0) break;

                d = d.substr(idx + 2);
                com = false;
            }
        }

        for (var i = 0; i < lines.length; i++) {
            var d = lines[i].replace(/\s*$/, '');
            var node = stack[stack.length - 1];

            // Open
            if (m = d.match(/(.*)\{/)) {
                var path = m[1].replace(/\s+$/, '').split(/\s+/);

                var n = stack.length;
                for (var j = 0; j < path.length; j++) {
                    var id = path[j].replace(/:$/, '');

                    if (!j && id !== path[j])
                        stack.push({});
                    stack.push({ name: id });
                }
                stack[stack.length - 1].depth = stack.length - n;
                continue;
            }
            if (!stack.length) continue;

            // Close
            if (m = d.match(/^\},?$/)) {

                for (var j = node.depth; j--;) {
                    node = stack.pop();
                    if (!stack.length) {
                        //console.log(JSON.stringify(node.obj, null, 2));
                        return node.obj;
                    }

                    var parent = stack[stack.length - 1];
                    if (!node.name) {
                        if (!parent.obj) parent.obj = [];
                        parent.obj.push(node.obj);
                    } else {
                        if (!parent.obj) parent.obj = {};
                        parent.obj[node.name] = node.obj;
                    }
                }
                continue;
            }
            if (!stack.length) continue;

            if (m = d.match(/([^\s]+)\s+([^\s].*)$/)) {
                if (!node.obj) node.obj = {};
                node.obj[m[1]] = this.convertValue(m[2].replace(/\s*,$/, ''));
                continue;
            }

            var value = this.convertValue(d.replace(/,$/, ''));
            if (!node.obj) node.obj = [];
            node.obj.push(value);
        }
        return null;
    },

    convertValue: function (value) {
        var m;

        if (value === 'TRUE')
            return true;
        if (value === 'FALSE')
            return false;
        if (value === 'NULL')
            return null;

        // Choice
        if (m = value.match(/^([\w-\d]+):\s+(.+)$/)) {
            var choice = {};
            choice[m[1]] = this.convertValue(m[2]);
            return choice;
        }

        if (value.match(/^-?[\d\.]+$/))
            return value - 0;

        if (m = value.match(/^'([\da-fA-F]+)'H$/))
            return m[1];

        if (m = value.match(/^'([01]+)'B$/)) {
            var bin = m[1];
            var hex = this.bin2hex(bin);
            if (hex.length * 4 !== bin.length) {
                return {
                    length: bin.length,
                    value: hex,
                };
            }
            return hex;
        }

        return value;
    },

    bin2hex: function (bin) {

        hex = '';
        for (var i = 0; i < bin.length;) {
            var n = 0;
            for (var j = 0; j < 8; j++, i++) {
                if (bin[i] === '1')
                    n |=  1 << (7 - j);
            }
            hex += ('00' + n.toString(16)).slice(-2);
        }
        return hex;
    },

    dig: function (asn1) {

        if (asn1 === undefined || asn1 === null)
            return asn1;

        var count = 1;
        for (var i = 1, length = arguments.length; i < length; ) {
            var arg = arguments[i];
            if (typeof arg === 'number') {
                count = arg;
                i++;
            } else {
                asn1 = asn1[arg];
                if (asn1 === undefined)
                    break;
                if (!--count) {
                    i++;
                    count = 1;
                }
            }
        }
        return asn1;
    },

    map: function (asn1, cb) {
        if (!(asn1 instanceof Array))
            asn1 = [asn1];

        return asn1.map(cb);
    },
};

