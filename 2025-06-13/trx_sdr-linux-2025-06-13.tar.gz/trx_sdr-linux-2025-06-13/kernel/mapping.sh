#!/bin/bash
# Copyright (C) 2020-2025 Amarisoft
# SDR mapping configuration tool version 2025-06-13

set -e

if [ `whoami` != "root" ] ; then
    echo "Must be root"
    exit 1;
fi

SRV=""
FOUND=$(lsmod | grep sdr || echo '')
if [ "$FOUND" != "" ] ; then
    if [ "$(echo $FOUND | awk '{print $3;}')" != "0" ] ; then
        echo "* SDR driver already in use, try to stop lte service..."
        service lte stop 1>/dev/null 2>&1
        SRV="y"
    fi
    rmmod sdr
fi

# Move to script directory
cd $(readlink -f $(dirname $0))

echo "* Rebuild driver..."
make -s clean
make -s
insmod sdr.ko

DEV_MAX=$(grep -oP "#define SDR_MINOR_COUNT\s+\K\d+" main.c 2>/dev/null)
if [ "$DEV_MAX" = "" ] ; then DEV_MAX="16"; fi
LAST_DEV=$(( $DEV_MAX - 1 ))

major=$(awk '/ sdr$/{print $1}' /proc/devices)
mapping="$(seq 0 $LAST_DEV)"

d=0
for i in $mapping ; do
    rm -f "/dev/sdr$d"
    mknod -m 666 /dev/sdr$d c $major $i
    d=$(( $d + 1 ))
done

# Get sdr_util
SDR_UTIL=$(find .. -name "sdr_util")

# List cards
echo "* Detect cards"
CARDS=""
MASTER_DEV=""
DEV=""
while read -r line ; do

    dev=$(echo "$line" | grep -oP "/dev/sdr\d+" || echo '')
    if [ "$dev" != "" ] ; then
        DEV="$dev"
        ID=""
        TYPE=""
        continue
    fi
    if [ "$DEV" = "" ] ; then continue; fi

    if [[ $line =~ Board\ ID ]] ; then
        ID=$(echo "$line" | awk '{ print $3; }')
        continue
    fi
    if [ "$ID" = "" ] ; then continue; fi

    case "$ID" in
    0x4b21|0x4b31)
        T=$(echo "$line" | grep -oP "Board type:\s*\K.+")
        if [ "$T" != "" ] ; then TYPE=$(echo "$T" | tr '[:upper:]' '[:lower:]'); fi
        if [ "$TYPE" = "" ] ; then continue; fi

        case "$TYPE" in
        master)
            CARDS+=" $DEV"
            MASTER_DEV="$DEV"
            ;;
        slave)
            # XXX: check master
            CARDS+=",$DEV"
            ;;
        esac
        ;;
    *)
        CARDS+=" $DEV"
        MASTER_DEV=""
        ;;
    esac
    DEV=""

done < <($SDR_UTIL version)


echo "* Identify cards"
echo "  Check inside your casing and identify blinking led then"
echo "  Enter card position (start from 0, one for each slot)."
read -t 0.2 -n 1000 discard || true; # Flush STDIN

function Led
{
    $SDR_UTIL -c $1 led $2 1>/dev/null
}

function GetDev
{
    dev=$(echo "$1" | sed -e "s'/dev/sdr''g" | sed -e "s/,/ /g")
}

# Sort cards
OCARDS=()
for card in $CARDS ; do

    # Device list
    GetDev "$card"
    for d in $dev; do
        Led $d 1
    done

    while [ true ] ; do
        echo -n -e "    [\033[1m$card\033[0m] Enter the position of the blinking card: "
        read N
        if [[ $N =~ ^[0-9]+$ ]] ; then
            if [ "${OCARDS[$N]}" = "" ] ; then
                break
            else
                echo "    \033[93mBad card position, $N already set\033[0m"
            fi
        else
              echo "    \033[93mBad card position, must be an integer\033[0m"
        fi
    done

    for d in $dev; do
        Led $d 0
    done
    OCARDS[$N]="$card"
done

# From cards to devices
DEVICES=()
N="0"
for card in ${OCARDS[*]} ; do
    GetDev "$card"
    for d in $dev; do
        DEVICES[$N]="$d"
        echo "  Mapping device $d to /dev/sdr$N"
        N=$(( $N + 1 ))
    done
done

mapping=${DEVICES[*]}

MAPFILE="/etc/sdr-mapping"
if [ -e "$MAPFILE" ] ; then
    mv $MAPFILE $MAPFILE.bak
fi

echo -e "* Save mapping: \033[1m$mapping\033[0m"
echo "$mapping" > "$MAPFILE"

echo "* Mapping set, reload driver"

rmmod sdr
./init.sh

if [ "$SRV" = "y" ] ; then
    echo "* Restart lte service"
    service lte stop 1>/dev/null 2>&1
fi

