#!/bin/bash
# Copyright (C) 2015-2025 Amarisoft
# Install script version 2025-06-13

function Help
{
    HelpTRX
}

function ParseProduct
{
    ResetProduct
    if [[ $1 =~ ([A-Z]+)-([0-9]{8})([0-9]{2}) ]] ; then
        PROD_MODEL="${BASH_REMATCH[1]}"
        PROD_DATE="${BASH_REMATCH[2]}"
        PROD_REV="${BASH_REMATCH[3]}"
    fi
}

function ResetProduct
{
    PROD_MODEL=""
    PROD_DATE=""
    PROD_REV=""
    PROD_NAME=""
}

function UpdateProduct
{
    if [ "$MOTHERBOARD" = "" ] ; then
        DMIDECODE=$(which dmidecode)
        if [ "$DMIDECODE" ] ; then
            MOTHERBOARD=$($DMIDECODE -t 2 2>/dev/null | grep -P "Manufacturer:|Product Name:" | cut -d ':' -f2 | sed -e 's/^\s*//' | xargs echo)
        else
            MOTHERBOARD="Unknown"
        fi
    fi

    # Amarisoft products
    if [ "$PROD_REF" = "" ] ; then
        if [ -e "/etc/.amarisoft-product/hostname" ] ; then
            PROD_REF="$(cat /etc/.amarisoft-product/hostname)"
        else
            PROD_REF="$(hostname)"
        fi
        if [ -e "/etc/.amarisoft-product/host-id" ] ; then
            PROD_HOSTID="$(cat /etc/.amarisoft-product/host-id)"
        fi
        if [ -e "/etc/.amarisoft-product/dongle-id" ] ; then
            PROD_DONGLEID="$(cat /etc/.amarisoft-product/dongle-id)"
        fi
    fi

    ParseProduct "$PROD_REF"
    if [ "$PROD_MODEL" = "" ] ; then return; fi

    case "$PROD_MODEL" in
    UESB)
        PROD_NAME="UE Simbox"
        SDR_COUNT="4"
        if [ "$MOTHERBOARD" = "ASRockRack X299 WS/IPMI" ] ; then
            SDR_MAP="0 1 2 3"
        elif [ "$MOTHERBOARD" = "ASRockRack X299 Creator" ] ; then
            SDR_MAP="3 1 0 2"
        fi
        ;;
    UESBE)
        PROD_NAME="UE Simbox E"
        SDR_COUNT="2"
        if [ "$MOTHERBOARD" = "ASRockRack X299 WS/IPMI" ] ; then
            SDR_MAP="0 1 2 3"
        elif [ "$MOTHERBOARD" = "ASRockRack X299 Creator" ] ; then
            SDR_MAP="0 1 2 3"
        fi
        ;;
    UESBNG|UEMBS|UESBMBS)
        PROD_MODEL="UESBMBS"
        PROD_NAME="UE Simbox Macro Base Station"
        SDR_COUNT="3"
        if [ "$MOTHERBOARD" = "ASRockRack WRX80D8-2T" ] ; then
            SDR_MAP="2 3 0 1 4 5"
        fi
        ;;
    CBM)
        PROD_NAME="Callbox Mini"
        SDR_COUNT="1"
        if [ "$MOTHERBOARD" = "Shuttle Inc. XH410G" ] ; then
            SDR_MAP="0"
        elif [ "$MOTHERBOARD" = "Shuttle Inc. XH510G" ] ; then
            SDR_MAP="0"
        fi
        ;;
    CBC)
        PROD_NAME="Callbox Classic"
        SDR_COUNT="3"
        if [ "$MOTHERBOARD" = "ASRock Z790M-PLUS" ] ; then
            SDR_MAP="0 1 2"
        elif [ "$MOTHERBOARD" = "ASRock Z590M-PRO4" ] ; then
            SDR_MAP="0 2 1"
        elif [ "$MOTHERBOARD" = "ASRock Z590M-PLUS/Z490M-PLUS" ] ; then
            SDR_MAP="0 1 2"
        fi
        ;;
    CBP)
        PROD_NAME="Callbox Pro"
        SDR_COUNT="6"
        if [ "$MOTHERBOARD" = "ASRockRack OC Formula" ] ; then
            SDR_MAP="5 0 4 3 2 1"
        fi
        ;;
    CBU)
        PROD_NAME="Callbox Ultimate"
        SDR_COUNT="4"
        if [ "$MOTHERBOARD" = "ASRockRack X299 WS/IPMI" ] ; then
            SDR_MAP="0 1 2 3 4 5 6 7"
        elif [ "$MOTHERBOARD" = "ASRockRack OC Formula" ] ; then
            SDR_MAP="4 5 2 3 0 1 6 7"
        elif [ "$MOTHERBOARD" = "ASRockRack X299 Creator" ] ; then
            SDR_MAP="2 3 6 7 0 1 4 5"
        fi
        ;;
    CBX|CBE)
        PROD_MODEL="CBX"
        PROD_NAME="Callbox Extreme"
        SDR_COUNT="6"
        if [ "$MOTHERBOARD" = "ASRockRack WRX80D8-2T" ] ; then
            SDR_MAP="2 3 0 1 10 11 8 9 4 5 6 7"
        fi
        ;;
    CBA)
        PROD_NAME="Callbox Advanced"
        SDR_COUNT="2"
        if [ "$MOTHERBOARD" = "ASRockRack X299 WS/IPMI" ] ; then
            SDR_MAP="0 1 2 3"
        fi
        ;;
    XXX)
        ResetProduct
        if [ "$SCRIPT_SILENT" != "1" ] ; then
            echo -e "\033[94mRecovery image found\033[0m"
        fi
        return
        ;;
    *)
        PROD_NAME="$PROD_MODEL"
        ;;
    esac
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94m$PROD_NAME model found\033[0m"
    fi
}
UpdateProduct

RT_CPUSET=""
function RTCPUInit
{
    local BID=$(cat /proc/sys/kernel/random/boot_id)
    local FILE="/etc/.amarisoft-product/cpuset"
    local RT_CPUSET0="$RT_CPUSET"

    if [ -e "$FILE" ] ; then
        source "$FILE"
        if [ "$BOOT_ID" != "$BID" ] ; then
            RT_CPUSET=""
        elif [ "$RT_CPUSET0" = "" ] ; then
            Log "OTS" "Recover cpuset: $RT_CPUSET"
        fi
    fi

    local CT=$(which cyclictest)
    if [ "$CT" = "" ] ; then return; fi

    local tries="0"
    while [ "$RT_CPUSET" = "" ] ; do
        RT_CPUSET="0x0"
        local NB_LAT="0"
        Log "OTS" "Detecting CPU latency"
        while read -r line ; do
            P=$(echo "$line" | grep -Po "T:\s*\K\d+")
            if [ "$P" != "" ] ; then
                MAX=$(echo "$line" | grep -Po "Max:\s+\K\d+")
                if [[ $MAX -lt 450 ]] ; then
                    RT_CPUSET=$(perl -e "printf '0x%x', $RT_CPUSET | (1<<$P);")
                else
                    Log "OTS" "High latency detected on core $P ($MAX us)"
                    NB_LAT=$(( $NB_LAT + 1 ))
                    RT_SKIP_CORE=$P
                fi
            fi
        done < <($CT --smp -p50 -i200 -d0 -m -D8s -q)
        if [ "$NB_LAT" != "1" ] ; then
            RT_CPUSET=""
            if [[ $tries -gt 4 ]] ; then
                Log "OTS" "Can't detect high latency CPU: $NB_LAT"
                break
            fi
            tries=$(( $tries + 1 ))
            sleep 5
        else
            rm -f $FILE
            echo "# Generated on $(date -u)" > $FILE
            echo "BOOT_ID=$BID" >> $FILE
            echo "RT_CPUSET=$RT_CPUSET # !$RT_SKIP_CORE" >> $FILE
        fi
    done
}


LINUX_SERVICE=""
LINUX_PACKAGE=""
LINUX_DISTRIB="<unknown>"
LINUX_VERSION=""

if [ -e "/etc/os-release" ] ; then
    LINUX_DISTRIB=$(cat /etc/os-release | grep "^ID=" | cut -d '=' -f2 | sed -e 's/"//g')
    LINUX_VERSION=$(cat /etc/os-release | grep "^VERSION_ID=" | cut -d '=' -f2 | sed -e 's/"//g')
    LINUX_NAME=$(cat /etc/os-release | grep "^PRETTY_NAME=" | cut -d '=' -f2 | sed -e 's/"//g')
fi
if [ "$LINUX_VERSION" = "" -o "$LINUX_DISTRIB" = "" ] ; then
    if [ -e "/etc/lsb-release" ] ; then
        LINUX_DISTRIB=$(cat /etc/os-release | grep "^DISTRIB_ID=" | cut -d '=' -f2 | sed -e 's/"//g')
        LINUX_VERSION=$(cat /etc/os-release | grep "^DISTRIB_RELEASE=" | cut -d '=' -f2 | sed -e 's/"//g')
        LINUX_NAME=$(cat /etc/os-release | grep "^DISTRIB_DESCRIPTION=" | cut -d '=' -f2 | sed -e 's/"//g')
    elif [ -e "/etc/fedora-release" ]; then
        LINUX_DISTRIB="fedora"
        LINUX_VERSION=$(cat /etc/fedora-release | cut -d " " -f3)
        LINUX_NAME="Fedora"
    fi
fi

if [ "$TARGET" = "" ] ; then
    TARGET="$(uname -m)"
    if [ "$TARGET" = "x86_64" ] ; then
        TARGET="linux"
    fi
fi

LINUX_VERSION=$(echo "$LINUX_VERSION" | cut -d '.' -f1)
LINUX_DISTRIB=$(echo "$LINUX_DISTRIB" | tr '[:upper:]' '[:lower:]')

case "$LINUX_DISTRIB" in
fedora)
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94mFedora $LINUX_VERSION found\033[0m"
    fi
    if [ "$LINUX_VERSION" -gt 20 ] ; then
        LINUX_PACKAGE="dnf"
    else
        LINUX_PACKAGE="yum"
    fi
    LINUX_SERVICE="systemd"
    ;;
rhel)
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94m$LINUX_NAME found\033[0m"
    fi
    LINUX_PACKAGE="dnf"
    LINUX_SERVICE="systemd"
    ;;
ubuntu)
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94mUbuntu $LINUX_VERSION found\033[0m"
    fi
    if [ "$LINUX_VERSION" -lt "15" ] ; then
        LINUX_SERVICE="initd"
    else
        LINUX_SERVICE="systemd"
    fi
    LINUX_PACKAGE="apt"
    ;;
centos)
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94mCent OS $LINUX_VERSION found\033[0m"
    fi
    LINUX_SERVICE="systemd"
    LINUX_PACKAGE="yum"
    ;;
raspbian)
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94mRaspbian OS $LINUX_VERSION found\033[0m"
    fi
    LINUX_SERVICE="systemd"
    LINUX_PACKAGE="apt"
    ;;
debian)
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94mDebian OS $LINUX_VERSION found\033[0m"
    fi
    LINUX_SERVICE="systemd"
    LINUX_PACKAGE="apt"
    ;;
*)
    echo "Sorry, $LINUX_DISTRIB distribution not supported only available on Fedora, Ubuntu and CentOS distributions."
    exit 1
    ;;
esac

function service_cmd
{
    local name="$1"
    local cmd="$2"

    case $LINUX_SERVICE in
    systemd)
        if [ -e "/lib/systemd/system/${name}.service" ] ; then
            if [ "$VERBOSE" = "" ] ; then
                systemctl -q ${cmd} ${name} 1>/dev/null
            else
                systemctl -q ${cmd} ${name}
            fi
        fi
        ;;
    initd)
        if [ -e "/etc/init/${name}.conf" ] ; then
            if [ "$VERBOSE" = "" ] ; then
                service ${name} ${cmd} 1>/dev/null
            else
                service ${name} ${cmd}
            fi
        fi
        ;;
    esac
}

function service_install
{
    local name="$1"
    local path="$2"
    local user="$3"
    local enable="$4"

    case $LINUX_SERVICE in
    systemd)
        rm -f /lib/systemd/system/${name}.service
        cat ${path}/${name}.service | sed -e "s/<USER>/$user/" | sed -e "s'<PATH>'$path'" > /lib/systemd/system/${name}.service
        systemctl -q --system daemon-reload

        if [ "$enable" = "y" ] ; then
            systemctl -q enable ${name}
            #systemctl -q enable NetworkManager-wait-online.service
        else
            systemctl -q disable ${name}
        fi
        ;;
    initd)
        # Remove legacy
        local deamon="/etc/init.d/${name}.d"
        if [ -e "$deamon" ]; then
            $deamon stop
            update-rc.d ${name}.d disable
            rm -f $deamon
        fi

        if [ "$enable" = "y" ] ; then
            rm -f /etc/init/${name}.conf
            cat ${path}/${name}.conf | sed -e "s/<USER>/$user/" | sed -e "s'<PATH>'$path'" > /etc/init/${name}.conf
        else
            rm /etc/init/${name}.conf
        fi
        ;;
    esac
}

# Package manager state
LINUX_PACKAGE_READY="y"
function check_package_manager
{
    # Disable error
    if [[ $- =~ e ]] ; then
        ERR="1"
    fi
    set +e

    case "$LINUX_PACKAGE" in
    yum|dnf)
        # XXX
        ;;
    apt)
        LOCKED=$(lsof /var/lib/dpkg/lock 2>/dev/null)
        if [ "$LOCKED" != "" ] ; then
            LINUX_PACKAGE_READY="n"
        fi
        ;;
    esac

    # Re-enable error ?
    if [ "$ERR" = "1" ] ; then
        set -e
    fi
}
check_package_manager

function install_package
{
    if [ "$LINUX_PACKAGE" = "" ] ; then return; fi

    if [ "$(whoami)" != "root" ] ; then
        echo "\031[93mRoot access needed to install package.[0m"
        exit 1
    fi

    # Disable error
    if [[ $- =~ e ]] ; then
        ERR="1"
    fi
    set +e

    while [ "$1" != "" ] ; do
        case "$LINUX_PACKAGE" in
        yum|dnf)
            $LINUX_PACKAGE list installed $1 &>/dev/null
            if [ "$?" != "0" ] ; then
                echo "  Install package $1 (this may take a while)..."
                if [ "$VERBOSE" = "" ] ; then
                    $LINUX_PACKAGE -qq -y install $1
                else
                    $LINUX_PACKAGE -y install $1
                fi
            fi
            ;;
        apt)
            apt-cache --quiet=0 policy $1 | grep "Installed" | grep -v none &>/dev/null
            if [ "$?" != "0" ] ; then
                echo "  Install package $1 (this may take a while)..."
                if [ "$VERBOSE" = "" ] ; then
                    apt-get -qq install -y $1 &>/dev/null
                else
                    apt-get install -y $1
                fi
            fi
            ;;
        esac

        if [ "$?" != "0" ] ; then
            echo -e "  \033[93mCan't install package $1\033[0m"
            break
        fi
        shift;
    done

    # Re-enable error ?
    if [ "$ERR" = "1" ] ; then
        set -e
    fi
}

function GetHTState
{
    if [ "$HT_SYS_STATE" = "" ] ; then
        if [ -e "/sys/devices/system/cpu/smt/control" ] ; then
            HT_SYS_STATE=$(cat "/sys/devices/system/cpu/smt/control")
            if [ "$HT_SYS_STATE" = "on" ] ; then
                # Control on but only 1 thread per core
                TPC=$(lscpu | grep -oP "Thread.+per core:.+\K\d+")
                if [ "$TPC" = "1" ] ; then
                    HT_SYS_STATE="off"
                fi
            fi
        fi
    fi
}

function SetHTState
{
    echo "$1" > "/sys/devices/system/cpu/smt/control" 2>&1
}
function HelpTRX
{
    local MSG="$1"
    if [ "$MSG" != "" ] ; then
        echo "$MSG"
    fi

    echo "Usage:"
    local types=$(cd $DIR && ls | grep "config" | cut -d "." -f2 | xargs echo | tr ' ' '|')
    echo "> $0 [--no-upgrade] <path> $types [<frontend name>]"
    exit 1
}

UPGRADE="y"
DIR=$(cd $(dirname $0) && pwd)

while [ "$1" != "" ] ; do
    case "$1" in
    --no-upgrade)
        UPGRADE="n"
        ;;
    --force-upgrade)
        UPGRADE="f"
        ;;
    --dma32)
        if [ "$DMA32" = "" ] ; then
            Help "Unknown argument: $1"
        fi
        DMA32="y"
        ;;
    --no-package)
        LINUX_PACKAGE=""
        ;;
    *)
        if [ "$DST" = "" ] ; then
            DST=$(cd $1 && pwd)
            if [ ! -d "$DST" ] ; then
                Help "Directory '$DST' not found"
            fi
        else
            if [ "$TYPE" = "" ] ; then
                TYPE="$1"
            else
                if [ "$FE" = "" ] ; then
                    FE="$1"
                else
                    Help "Unknown argument: $1"
                fi
            fi
        fi
        ;;
    esac
    shift
done

if [ "$DST" = "" -o "$TYPE" = "" ] ; then
    Help
fi

if [ ! -d "${DIR}/config.${TYPE}/" ] ; then
    Help "No configuration files for $TYPE"
fi

function Install
{
    local ID="$1"
    shift

    rm -Rf ${DST}/config/${ID}
    cp -r ${DIR}/config.${TYPE}/ ${DST}/config/${ID}
    ${DST}/config/rf_select.sh ${ID} 1>/dev/null

    for i in $@; do
        rm -f ${DST}/$i
        if [ -e ${DIR}/$i ] ; then
            ln -s ${DIR}/$i ${DST}
        fi
    done
}


# Delete default files and copy configs
Install "sdr" "trx_sdr.so" "libsdr.so" "libc_wrapper_sdr.so"
ln -s ${DIR}/sdr_util ${DST}/config/sdr/
ln -s ${DIR}/kernel ${DST}/config/sdr/
ln -s ${DIR}/rrh_check.sh ${DST}/config/sdr/

function SetFifoTxTime
{
    perl -p -i -e "s/\/\/\\s*fifo_tx_time:.*/fifo_tx_time: $1,/" ${DST}/config/sdr/*.cfg
}

function SetRxLatency
{
    perl -p -i -e "s/\/\/\\s*rx_latency:.*/rx_latency: $1,/" ${DST}/config/sdr/*.cfg
}

# Product specific
case "$MOTHERBOARD" in
"ASUSTeK COMPUTER INC. PRIME X299-DELUXE"|"ASRock X299 OC Formula")
    SetFifoTxTime 50
    ;;
"ASRock X299 Creator") # CBU
    SetFifoTxTime 50
    ;;
"ASRockRack WC621D8A-2T")
    SetFifoTxTime 50
    ;;
"ASRockRack X299 WS/IPMI")
    SetFifoTxTime 50
    ;;
"ASRockRack WRX80D8-2T") # CBX, UESBNG
    SetFifoTxTime 30
    ;;
esac

case "$PROD_MODEL" in
CBX|CBU|UESBNG)
    SetRxLatency 30
    ;;
esac

if [ "$UPGRADE" != "n" ] ; then
    cd ${DIR}/kernel

    case $LINUX_DISTRIB in
    fedora|centos)
        if [ "$(uname -a | grep -w rt || echo '')" != "" ] ; then
            install_package kernel-rt-devel
        else
            install_package kernel-devel-$(uname -r)
        fi
        install_package make gcc elfutils-libelf-devel
        make -s
        ;;
    ubuntu)
        install_package build-essential linux-headers-$(uname -r)
        sudo -s make -s
        ;;
    debian)
        install_package build-essential linux-headers
        make -s
        ;;
    rhel)
        install_package kernel-devel
        make -s
        ;;
    *)
        echo "Distribution $LINUX_DISTRIB not compatible"
        exit 1
        ;;
    esac

    # Compil
    if [ "$?" != "0" ] ; then
        echo -e "Error while compiling kernel driver."
        echo -e "Your kernel may not be up to date."
        echo -e "Reboot your system and process install again."
        exit 1
    fi

    # Module
    MODULE=$(lsmod | grep sdr | awk '{print $3;}')
    if [ "$MODULE" != "" ] ; then
        if [ "$MODULE" = "0" ] ; then
            echo "Unload current SDR kernel module"
            rmmod sdr
            MODULE=""
        else
            echo "Warning, SDR kernel module in use"
        fi
    fi

    # Install
    echo "Initialize SDR kernel module"
    cd ${DST}/config/sdr/kernel
    ./init.sh

    INFO=""
    CMD="./sdr_util upgrade"
    case "$PROD_MODEL" in
    CBX|CBE|UESBNG|UESBMBS)
        CMD+=" -noreload"
        ;;
    esac

    # Upgrade
    cd ${DST}/config/sdr
    if [ "$UPGRADE" = "f" ] ; then
        INFO+=", force"
        CMD+=" -force"
    fi
    echo "Check firmwares$INFO"
    $CMD
fi

exit 0

