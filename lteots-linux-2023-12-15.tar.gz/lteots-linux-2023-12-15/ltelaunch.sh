#!/bin/bash
# Copyright (C) 2020-2023 Amarisoft
# LTE component launcher version 2023-12-15

COMP="$1"

source ".launch.$1"
rm -f ".launch.$1"

function Notify
{
    echo "$COMP|$1|$2" > $FIFO
}

# Wait a bit
if [ "$START_DELAY" != "" ] ; then
    echo "Wait ${START_DELAY}s"
    sleep $START_DELAY
fi

# Notify
Notify "starting" "$$"

case "$OUTPUT_TYPE" in
stdout)
    set -o pipefail
    $PROG $CONFIG 2>&1 | tee $OUTPUT_FILE
    RET="$?"
    ;;
stderr)
    set -o pipefail
    $PROG $CONFIG 3>&1 1>&2 2>&3 | tee $OUTPUT_FILE
    RET="$?"
    ;;
*)
    $PROG $CONFIG
    RET="$?"
    ;;
esac

if [ "$RET" = "0" ] ; then
    Notify "stop"
else
    Notify "error" "$RET"
fi


