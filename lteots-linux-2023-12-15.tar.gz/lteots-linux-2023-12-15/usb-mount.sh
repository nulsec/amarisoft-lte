#!/bin/bash
# Copyright (C) 2022-2023 Amarisoft
# Amarisoft USB mounter version 2023-12-15

# Default
FORMAT="n"
LABEL="Amarisoft"
VERBOSE="n"

function Help
{
    echo "Usage:"
    echo "usb-mount.sh [--label <label (default=Amarisoft)> [--format]]"
    echo "Mounts non mounted USB partitions:"
    echo "  If label is set, will only mount devices with matching label."
    echo "  If label is set and format as well, not mounted device with different label"
    echo "  will be reformated."
    exit 1
}

while [ "$1" != "" ] ; do
    case "$1" in
    --format)
        FORMAT="y"
        ;;
    --label)
        LABEL="$2"
        shift
        ;;
    -v)
        VERBOSE="y"
        ;;
    -h|--help)
        Help
        ;;
    esac
    shift
done

function USBMount
{
    local DEV="$1"
    local LABEL="$2"

    for j in '' $(seq 1 10) ; do
        DIR="/media/$LABEL$j"
        E=$(df | grep "$DIR")
        if [ "$?" != "0" ] ; then
            mkdir -p "$DIR"
            echo "Mount $DEV to $DIR"
            mount $DEV "$DIR"
            return
        fi
    done
}

if [ ! -e "/dev/disk/by-id" ] ; then
    exit 0
fi

LABEL1=$(echo "$LABEL" | tr '[:upper:]' '[:lower:]')
for id in $(ls /dev/disk/by-id | grep -oP "usb-.*-part1") ; do
    # Check device is mounted
    DEV=$(readlink -f /dev/disk/by-id/$id)
    MOUNTED=$(df | grep "$DEV" || echo '')
    if [ "$MOUNTED" = "" ] ; then
        # Device not mounted
        L=$(blkid | grep "$DEV" | grep -oP "LABEL=\"\K[^\"]+" || echo '')
        if [ "$VERBOSE" = "y" ] ; then
            echo "Found device $DEV [$L]"
        fi

        L=$(echo "$L" | tr '[:upper:]' '[:lower:]')
        if [ "$LABEL1" != "" -a "$L" != "$LABEL1" ] ; then
            if [ "$FORMAT" != "y" ] ; then continue; fi

            echo "Format $DEV"
            mkfs.ext4 -F -L "$LABEL" "$DEV"
            sleep 4
        fi
        USBMount "$DEV" "$LABEL"
    fi
done



