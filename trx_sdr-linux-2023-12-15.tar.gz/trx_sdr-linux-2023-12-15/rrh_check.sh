#!/bin/bash
# Copyright (C) 2015-2023 Amarisoft
# SDR board presence checker + init version 2023-12-15

set -e

CUR_DIR=$(pwd)
cd $(dirname $0)

FOUND=$(lsmod | grep sdr || echo "")
if [ "$FOUND" = "" ] ; then
    echo "Initialize SDR kernel module"
    cd kernel

    set +e
    ./init.sh
    RET="$?"
    set -e
    if [ "$RET" != "0" ] ; then
        echo "Error while initializing driver:" >&2
        dmesg | tail -n 5 >&2
        exit $RET
    fi

    cd ..
fi

while [ "$1" != "" ] ; do
    case "$1" in
    --ots)
        echo "OTS init"
        set +e
        ./sdr_util ots_init
        RET="$?"
        set -e
        if [ "$RET" != "0" ] ; then
            echo "Error while initializing ots:" >&2
            exit $RET
        fi
        ;;
    --temp)
        MAX_TEMP="$2"
        shift
        if [ "$MAX_TEMP" = "" ] ; then
            echo "Missing temperature" >&2
            exit 1
        fi
        for t in $(./sdr_util temp | grep -oP "temperature:\s+\K\d+"); do
            if [[ $t -ge $MAX_TEMP ]] ; then
                echo "Temperature too high (max=$MAX_TEMP):" >&2
                ./sdr_util temp | grep -P "Device|temperature" >&2
                exit 1
            fi
        done
        ;;
    --cfg)
        shift
        DEVS=$($CUR_DIR/json_util dump $1 rf_driver args | grep -oP "/dev/sdr\d+" | xargs -r echo)
        echo "Devices: $DEVS"
        ;;
    *)
        echo "Bad argument: $1" >&2
        exit 2
        ;;
    esac
    shift
done

exit 0
