/*
 * Javascript terminal
 * 
 * Copyright (c) 2011 Fabrice Bellard
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
"use strict";

function Term(config)
{
    this.tot_h = config.buffer_size;
    this.handler = config.handler;

    this.bg_colors = [
        "#000000",
        "#ff0000",
        "#00ff00",
        "#ffff00",
        "#0000ff",
        "#ff00ff",
        "#00ffff",
        "#ffffff" 
    ];
    this.fg_colors = [
        "#000000",
        "#ff0000",
        "#00ff00",
        "#ffff00",
        "#0000ff",
        "#ff00ff",
        "#00ffff",
        "#ffffff" 
    ];
    this.def_attr = (7 << 3) | 0;
    this.is_mac = (navigator.userAgent.indexOf("Mac") >=0 ) ? true : false;

    this.visible = false;
    this._keyDown = this.keyDownHandler.bind(this);
    this._keyPress = this.keyPressHandler.bind(this);
    this._wheel = this.wheelHandler.bind(this);
    this._paste = this.pasteHandler.bind(this);

    this.focus = false;
    this.cursorId = 'termCursor' + Term.cursorId++;
    this.cursorstate = 0;
    this.rows_el = [];
    this.h = 0; // Size of screen in lines

    this.reset();
}

Term.prototype.reset = function()
{
    for (var y = 0; y < this.rows_el.length; y++) {
        this.rows_el[y].innerHTML = '';
    }
    this.lines = [[]]; // Lines
    this.refreshLine = [];
    this.y_disp = 0; // position of the top displayed line in the scroll back buffer
    // Cursor position in buffer
    this.x = 0;
    this.y = 0;
    this.state = 0;
    this.output_queue = "";
    this.cur_attr = this.def_attr;
    this.key_rep_state = 0;
    this.key_rep_str = "";
    this.refreshScrollbar();
}

Term.cursorId = 0;

Term.prototype.scrollbarSize = 15;

Term.prototype.setParent = function(parent_el)
{
    this.term_el = parent_el;

    this.scrollbar = document.createElement('canvas');
    parent_el.appendChild(this.scrollbar);
    this.scrollbar.style.float = 'right';

    this.refreshScrollbar();

    this.scrollbar.addEventListener("mousedown", (function (event) {

        var rect = this.term_el.getBoundingClientRect();
        if (!rect.y) {
            var y0 = rect.bottom - rect.height;
        } else {
            var y0 = rect.y;
        }

        var move = (function (event) {
            var r = Math.min(1, Math.max(0, (event.clientY - y0) / this.scrollbar.height));
            var pos = (r * (this.lines.length - this.h)) >> 0;
            this.move(pos);
            this.refresh();
            event.stopPropagation();
        }).bind(this);

        var mouseUpCb = (function (event) {
            window.removeEventListener('mouseup', mouseUpCb);
            window.removeEventListener('mousemove', mouseMoveCb);
            move(event);
        }).bind(this);
        var mouseMoveCb = (function (event) {
            move(event);
        }).bind(this);

        window.addEventListener('mouseup', mouseUpCb, false);
        window.addEventListener('mousemove', mouseMoveCb, false);
        move(event);
        event.stopPropagation();
    }).bind(this));

    this.resize();
}

Term.prototype.refreshScrollbar = function ()
{
    var canvas = this.scrollbar;
    if (!canvas)
        return;

    if (this.lines.length <= this.h) {
        canvas.style.visibility = 'hidden';
        return;
    }
    canvas.style.visibility = '';

    var width = canvas.width - 1;
    var height = canvas.height - 1;
    var color = 'rgb(192,192,192)';

    var ctx = canvas.getContext('2d');
    ctx.save();
    ctx.strokeStyle = color;
    ctx.fillStyle = 'black';
    ctx.translate(0.5,0.5);
    ctx.beginPath();
    ctx.rect(0,0,width,height);
    ctx.fill();
    ctx.stroke();

    var h = Math.max(this.scrollbarSize, this.h / this.lines.length * height);
    var y = (this.y_disp + this.h / 2) / this.lines.length * height - h / 2;

    h >>= 0;
    h >>= 0;

    ctx.beginPath();
    ctx.rect(0, y, width, h);
    ctx.fillStyle = color;
    ctx.fill();

    ctx.restore();
}

Term.prototype.show = function ()
{
    if (!this.visible) {
        this.visible = true;
        this.invalidateAll();
        this.refresh();
    }
    return this;
}

Term.prototype.hide = function ()
{
    this.visible = false;
    return this;
}

Term.prototype.debug = function ()
{
    console.log('x', this.x, 'y', this.y, 'h', this.h);
    console.log('Disp', this.y_disp);
    console.log('Size', this.lines.length);
}

Term.prototype.follow_cursor_save = function ()
{
    this.follow_cursor_state = (this.y_disp + Math.max(1, this.h)) >= this.lines.length;
}

Term.prototype.follow_cursor_restore = function ()
{
    if (this.follow_cursor_state) {

        var y = Math.max(this.lines.length - this.h, 0);
        if (y !== this.y_disp) {
            this.y_disp = y;
            this.invalidateAll();
            return true;
        }
    }
    return false;
}

Term.prototype.invalidate = function (l)
{
    l -= this.y_disp;
    if (l >= 0 && l < this.h)
        this.refreshLine[l] = true;
}

Term.prototype.invalidateAll = function ()
{
    for (var i = 0; i < this.h; i++) {
        this.refreshLine[i] = true;
    }
}

Term.prototype.resize = function ()
{
    this.follow_cursor_save();

    var style = window.getComputedStyle(this.term_el);
    var dh = parseFloat(style.paddingTop) +
            parseFloat(style.paddingBottom) +
            parseFloat(style.borderTopWidth) +
            parseFloat(style.borderBottomWidth);
    var dw = parseFloat(style.paddingLeft) +
             parseFloat(style.paddingRight) +
             parseFloat(style.borderLeftWidth) +
             parseFloat(style.borderRightWidth);

    var lineHeight = parseInt(style.lineHeight);

    var height = parseFloat(style.height) - dh

    // Number of visible lines
    var h = Math.floor(height / lineHeight);
    if (h > this.h) {
        //c = 32 | (this.def_attr << 16);
        for (var y = this.h; y < h; y++) {
            var row_el = document.createElement("div");
            this.rows_el.push(row_el);
            this.term_el.appendChild(row_el);
        }
    } else if (h < this.h) {
        while (this.rows_el.length > h) {
            var row_el = this.rows_el.pop();
            row_el.remove();
        }
    }
    this.h = h;
    this.refreshLine.length = h;
    this.scrollbar.width = this.scrollbarSize;

    this.scrollbar.height = height;

    this.follow_cursor_restore();
    this.invalidateAll();
    this.refresh();
};

Term.prototype.setFocus = function ()
{
    if (!this.focus) {
        this.focus = true;

        document.addEventListener("keydown", this._keyDown, true);
        document.addEventListener("keypress", this._keyPress, true);
        document.defaultView.addEventListener("paste", this._paste, false);
        this.term_el.addEventListener(lteLogs.getMouseWheelEvent(), this._wheel, true);

        this.blink_cursor(true);
        this.show_cursor(true);
    }
}

Term.prototype.unsetFocus = function ()
{
    if (this.focus) {
        this.focus = false;

        document.removeEventListener("keydown", this._keyDown, true);
        document.removeEventListener("keypress", this._keyPress, true);
        document.defaultView.removeEventListener("paste", this._paste, false);
        this.term_el.removeEventListener(lteLogs.getMouseWheelEvent(), this._wheel, true);

        this.blink_cursor(false);
        this.cursor_state = 0;
        this.invalidate(this.y);
        this.refresh();
    }
}

Term.prototype.setScroll = function (on)
{
    if (on)
        this.term_el.addEventListener(lteLogs.getMouseWheelEvent(), this._wheel, true);
    else
        this.term_el.removeEventListener(lteLogs.getMouseWheelEvent(), this._wheel, true);
}

Term.prototype._getLine = function (y)
{
    var l = this.lines[y];
    if (!l)
        l = this.lines[y] = [];
    return l;
}

// Buffer coordinates
Term.prototype.refresh = function ()
{
    var el, y, c, i, j, cx, attr, last_attr, fg, bg;
    var http_link_len, http_link_str;

    if (!this.visible)
        return false;

    // Convert to screen coords
    var is_http_link_char = function(c)
    {
        var str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~:/?#[]@!$&'()*+,;=`.";
        return str.indexOf(String.fromCharCode(c)) >= 0;
    }

    for (y = 0; y < this.h; y++) {
        if (!this.refreshLine[y]) continue;
        this.refreshLine[y] = false;

        var y1 = y + this.y_disp;

        var line = this.lines[y1];
        if (!line) break; // No need to go further

        var outline = [];
        var w = line.length;

        if (y1 == this.y) {
            cx = this.x;
            w = Math.max(w, cx + 1);
        } else {
            cx = -1;
        }
        last_attr = this.def_attr;
        http_link_len = 0;
        for(i = 0; i < w; i++) {
            c = line[i];
            if (c === undefined) {
                c = 32;
                attr = this.def_attr;
            } else {
                attr = c >> 16;
                c &= 0xffff;
            }
            /* test for http link */
            if (c == 0x68 && (w - i) >= 8 && http_link_len == 0) {
                /* test http:// or https:// */
                if ((line[i + 1] & 0xffff) == 0x74 &&
                    (line[i + 2] & 0xffff) == 0x74 &&
                    (line[i + 3] & 0xffff) == 0x70 &&
                    (((line[i + 4] & 0xffff) == 0x3a &&
                      (line[i + 5] & 0xffff) == 0x2f &&
                      (line[i + 6] & 0xffff) == 0x2f) ||
                     ((line[i + 4] & 0xffff) == 0x73 &&
                      (line[i + 5] & 0xffff) == 0x3a &&
                      (line[i + 6] & 0xffff) == 0x2f &&
                      (line[i + 7] & 0xffff) == 0x2f))) {
                    http_link_str = "";
                    j = 0;
                    while ((i + j) < w &&
                           is_http_link_char(line[i + j] & 0xffff)) {
                        http_link_str += String.fromCharCode(line[i + j] & 0xffff);
                        j++;
                    }
                    http_link_len = j;
                    if (last_attr != this.def_attr) {
                        outline.push('</span>');
                        last_attr = this.def_attr;
                    }
                    outline.push("<a href='" + http_link_str + "'>");
                }
            }
            if (i == cx)  {
                attr = -1; /* cursor */
            }
            if (attr != last_attr) {
                if (last_attr != this.def_attr)
                    outline.push('</span>');
                if (attr != this.def_attr) {
                    if (attr == -1) {
                        /* cursor */
                        outline.push('<span id="' + this.cursorId + '" class="' + this.getCursorClass() + '">');
                    } else {
                        outline.push('<span style="');
                        fg = (attr >> 3) & 7;
                        bg = attr & 7;
                        if (fg != 7) {
                            outline.push('color:' + this.fg_colors[fg] + ';');
                        }
                        if (bg != 0) {
                            outline.push('background-color:' + this.bg_colors[bg] + ';');
                        }
                        outline.push('">');
                    }
                }
            }
            switch(c) {
            case 32:
                outline.push("&nbsp;");
                break;
            case 38: // '&'
                outline.push("&amp;");
                break;
            case 60: // '<'
                outline.push("&lt;");
                break;
            case 62: // '>'
                outline.push("&gt;");
                break;
            default:
                if (c < 32) {
                    outline.push("&nbsp;");
                } else {
                    outline.push(String.fromCharCode(c));
                }
                break;
            }
            last_attr = attr;
            if (http_link_len != 0) {
                http_link_len--;
                if (http_link_len == 0) {
                    if (last_attr != this.def_attr) {
                        outline.push('</span>');
                        last_attr = this.def_attr;
                    }
                    outline.push("</a>");
                }
            }
        }
        if (last_attr != this.def_attr) {
            outline.push('</span>');
        }

        this.rows_el[y].innerHTML = outline.length ? outline.join('') : '&nbsp;';
    }

    this.refreshScrollbar();
    return true;
};

Term.prototype.cursor_timer_cb = function()
{
    this.cursor_state ^= 1;

    var cursor_el = document.getElementById(this.cursorId);
    if (cursor_el) {
        cursor_el.className = this.getCursorClass();
    }
};

Term.prototype.getCursorClass = function ()
{
    return this.cursor_state ? 'term_cursor' : '';
};

Term.prototype.blink_cursor = function (state)
{
    if (this._cursorTimer)
        clearInterval(this._cursorTimer);

    this._cursorTimer = state ? setInterval(this.cursor_timer_cb.bind(this), 1000) : null;
}


Term.prototype.show_cursor = function()
{
    if (!this.cursor_state) {
        this.cursor_state = 1;
        this.blink_cursor(this.focus);
        var refresh = true;
    }

    if (!this.move(this.y - this.h + 1) && refresh)
        this.invalidate(this.y);

    this.refresh();
};

/* scroll down or up in the scroll back buffer by n lines */
Term.prototype.scroll = function(n)
{
    if (this.move(this.y_disp + n))
        this.refresh();
}

Term.prototype.move = function(y)
{
    y = Math.min(y, this.lines.length - this.h);
    y = Math.max(y, 0);

    if (y != this.y_disp) {
        this.y_disp = y;
        this.invalidateAll();
        return true;
    }
    return false;
}

Term.prototype.write = function(str)
{
    if (!str) return;

    var csi_colors = function (s, esc_params) {
        var j, n, fg, bg;

        if (esc_params.length == 0) {
            s.cur_attr= s.def_attr;
        } else {
            for(j = 0; j < esc_params.length; j++) {
                n = esc_params[j];
                if (n >= 30 && n <= 37) {
                    /* foreground */
                    fg = n - 30;
                    s.cur_attr = (s.cur_attr & ~(7 << 3)) | (fg << 3);
                } else if (n >= 40 && n <= 47) {
                    /* background */
                    bg = n - 40;
                    s.cur_attr = (s.cur_attr & ~7) | bg;
                } else if (n >= 90 && n <= 97) {
                    /* foreground (XXX: 16 color table) */
                    fg = n - 90;
                    s.cur_attr = (s.cur_attr & ~(7 << 3)) | (fg << 3);
                } else if (n >= 100 && n <= 107) {
                    /* background (XXX: 16 color table) */
                    bg = n - 100;
                    s.cur_attr = (s.cur_attr & ~7) | bg;
                } else if (n == 0) {
                    /* default attr */
                    s.cur_attr = s.def_attr;
                }
            }
        }
    }

    var TTY_STATE_NORM = 0;
    var TTY_STATE_ESC = 1;
    var TTY_STATE_CSI = 2;
    var TTY_STATE_CHARSET = 3;
    var n;

    this.follow_cursor_save();

    for(var i = 0; i < str.length; i++) {
        var c = str.charCodeAt(i);
        switch(this.state) {
        case TTY_STATE_NORM:
            switch(c) {
            case 10:
                this.invalidate(this.y);
                if (++this.y >= this.lines.length) {
                    // Increase and remove oldest line if necessary
                    if (this.lines.push([]) >= this.tot_h) {
                        this.lines.shift();
                        this.y--;
                        this.invalidateAll();
                    }
                }
                this.invalidate(this.y);
                this.x = 0;
                break;
            case 13:
                this.x = 0;
                break;
            case 8:
                if (this.x > 0) {
                    this.x--;
                }
                break;
            case 9: /* tab */
                this.x = (this.x + 8) & ~7;
                break;
            case 27:
                this.state = TTY_STATE_ESC;
                break;
            default:
                if (c >= 32) {
                    this.lines[this.y][this.x++] = (c & 0xffff) | (this.cur_attr << 16);
                    this.invalidate(this.y);
                }
                break;
            }
            break;
        case TTY_STATE_ESC:
            switch(c) {
            case 91: // '['
                this.esc_params = [];
                this.cur_param = 0;
                this.state = TTY_STATE_CSI;
                break;
            case 40: // '('
            case 41: // ')'
                this.state = TTY_STATE_CHARSET;
                break;
            default:
                this.state = TTY_STATE_NORM;
                break;
            }
            break;
        case TTY_STATE_CSI:
            if (c >= 48 && c <= 57) { // '0' '9'
                /* numeric */
                this.cur_param = this.cur_param * 10 + c - 48;
            } else {
                if (c == 63) // '?'
                    break; /* ignore prefix */
                /* add parsed parameter */
                this.esc_params[this.esc_params.length] = this.cur_param;
                this.cur_param = 0;
                if (c == 59) // ;
                    break;
                this.state = TTY_STATE_NORM;

                //                console.log("term: csi=" + this.esc_params + " cmd="+c);
                switch(c) {
                case 65: // 'A' up
                    n = Math.max(this.esc_params[0], 1);
                    this.y = Math.max(0, this.y - n);
                    break;
                case 66: // 'B' down
                    n = Math.max(this.esc_params[0], 1);
                    this.y = Math.max(this.y + n, this.tot_h - 1);
                    break;
                case 67: // 'C' right
                    n = Math.max(this.esc_params[0], 1);
                    this.x = Math.min(this.x + n, this.lines[this.y].length);
                    break;
                case 68: // 'D' left
                    n = Math.max(this.esc_params[0], 1);
                    this.x = Math.max(this.x - n, 0);
                    break;
                case 72: // 'H' goto xy
                    var y1 = this.esc_params[0] - 1;
                    var x1 = this.esc_params.length >= 2 ? this.esc_params[1] - 1 : 0;

                    this.y = Math.min(Math.max(0, y1), this.h - 1) + this.y_disp;
                    this.x = Math.min(Math.max(0, x1), this.lines[this.y].length);
                    break;
                case 74: // 'J' erase to end of screen
                    for (var j = this.y; j <= this.lines.length; j++)
                        this.invalidate(j);

                    this.lines.length = this.y + 1;
                    this.lines[this.y].x = this.x;
                    break;
                case 75: // 'K' erase to end of line
                    this.invalidate(this.y);
                    this.lines[this.y].length = this.x;
                    break;
                case 109: // 'm': set color
                    csi_colors(this, this.esc_params);
                    break;
                case 110: // 'n' return the cursor position
                    this.queue_chars("\x1b[" + (this.y - this.y_disp + 1) + ";" + (this.x + 1) + "R");
                    break;
                default:
                    break;
                }
            }
            break;
        case TTY_STATE_CHARSET:
            /* just ignore */
            this.state = TTY_STATE_NORM;
            break;
        }
    }
    this.invalidate(this.y);

    this.follow_cursor_restore();
    return this.refresh();
};

Term.prototype.writeln = function (str)
{
    this.write(str + '\r\n');
};

Term.prototype.keyDownHandler = function (ev)
{
    var str;

    switch(ev.keyCode) {
    case 8: /* backspace */
        str = "\x7f";
        break;
    case 9: /* tab */
        str = "\x09";
        break;
    case 13: /* enter */
        str = "\x0d";
        break;
    case 27: /* escape */
        str = "\x1b";
        break;
    case 37: /* left */
        str = "\x1b[D";
        break;
    case 39: /* right */
        str = "\x1b[C";
        break;
    case 38: /* up */
        if (ev.ctrlKey) {
            this.scroll(-1);
        } else {
            str = "\x1b[A";
        }
        break;
    case 40: /* down */
        if (ev.ctrlKey) {
            this.scroll(1);
        } else {
            str = "\x1b[B";
        }
        break;
    case 46: /* delete */
        str = "\x1b[3~";
        break;
    case 45: /* insert */
        str = "\x1b[2~";
        break;
    case 36: /* home */
        str = "\x1bOH";
        break;
    case 35: /* end */
        str = "\x1bOF";
        break;
    case 33: /* page up */
        if (ev.ctrlKey) {
            this.scroll(-(this.h - 1));
        } else {
            str = "\x1b[5~";
        }
        break;
    case 34: /* page down */
        if (ev.ctrlKey) {
            this.scroll(this.h - 1);
        } else {
            str = "\x1b[6~";
        }
        break;
    default:
        if (ev.ctrlKey) {
            /* ctrl + key */
            if (ev.keyCode >= 65 && ev.keyCode <= 90) {
                str = String.fromCharCode(ev.keyCode - 64);
            } else if (ev.keyCode == 32) {
                str = String.fromCharCode(0);
            }
        } else if ((!this.is_mac && ev.altKey) ||
                   (this.is_mac && ev.metaKey)) {
            /* meta + key (Note: we only send lower case) */
            if (ev.keyCode >= 65 && ev.keyCode <= 90) {
                str = "\x1b" + String.fromCharCode(ev.keyCode + 32);
            }
        }
        break;
    }
    //    console.log("keydown: keycode=" + ev.keyCode + " charcode=" + ev.charCode + " str=" + str + " ctrl=" + ev.ctrlKey + " alt=" + ev.altKey + " meta=" + ev.metaKey);
    if (str) {
        if (ev.stopPropagation)
            ev.stopPropagation();
        if (ev.preventDefault)
            ev.preventDefault();

        this.show_cursor();
        this.key_rep_state = 1;
        this.key_rep_str = str;
        this.handler(str);
        return false;
    } else {
        this.key_rep_state = 0;
        return true;
    }
};

Term.prototype.keyPressHandler = function (ev)
{
    var str, char_code;
    
    if (ev.stopPropagation)
        ev.stopPropagation();
    if (ev.preventDefault)
        ev.preventDefault();

    str="";
    if (!("charCode" in ev)) {
        /* on Opera charCode is not defined and keypress is sent for
         system keys. Moreover, only keupress is repeated which is a
         problem for system keys. */
        char_code = ev.keyCode;
        if (this.key_rep_state == 1) {
            this.key_rep_state = 2;
            return false;
        } else if (this.key_rep_state == 2) {
            /* repetition */
            this.show_cursor();
            this.handler(this.key_rep_str);
            return false;
        }
    } else {
        char_code = ev.charCode;
    }
    if (char_code != 0) {
        if (!ev.ctrlKey && 
            ((!this.is_mac && !ev.altKey) ||
             (this.is_mac && !ev.metaKey))) {
            str = String.fromCharCode(char_code);
        }
    }
    //    console.log("keypress: keycode=" + ev.keyCode + " charcode=" + ev.charCode + " str=" + str + " ctrl=" + ev.ctrlKey + " alt=" + ev.altKey + " meta=" + ev.metaKey);
    if (str) {
        this.show_cursor();
        this.handler(str);
        return false;
    } else {
        return true;
    }
};

Term.prototype.wheelHandler = function (ev)
{
    if (ev.deltaY < 0)
        this.scroll(-3);
    else if (ev.deltaY > 0)
        this.scroll(3);
    ev.stopPropagation();
}

Term.prototype.mouseUpHandler = function (ev)
{
    this.thumb_el.onmouseup = null;
    document.onmouseup = null;
    document.onmousemove = null;
    document.body.className = document.body.className.replace(" noSelect", "");
}

Term.prototype.pasteHandler = function (ev)
{
    var c = ev.clipboardData;
    if (c) {
        this.queue_chars(c.getData("text/plain"));
        return false;
    }
}

/* output queue to send back asynchronous responses */
Term.prototype.queue_chars = function (str)
{
    this.output_queue += str;
    if (this.output_queue)
        setTimeout(this.outputHandler.bind(this), 0);
};

Term.prototype.outputHandler = function ()
{
    if (this.output_queue) {
        this.handler(this.output_queue);
        this.output_queue = "";
    }
};

Term.prototype.getSize = function ()
{
    return [this.w, this.h];
};
