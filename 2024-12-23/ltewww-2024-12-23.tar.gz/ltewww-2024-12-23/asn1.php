<?php
/*
 * Copyright (C) 2024 Amarisoft
 * Amarisoft asn1 conversion API 2024-12-23
 */

$lte_path = '.';
$object = array();

function Decode($data, $format)
{
    global $type;
    global $object;
    global $lte_path;

    $descriptorspec = array(
        0 => array("pipe", "r"),
        1 => array("pipe", "w"),
    );
    $pipes = array();
    $cmd = $lte_path."/lte_toolbox asn1-convert - $type $format 2>&1";
    $proc = proc_open($cmd, $descriptorspec, $pipes);
    if (is_resource($proc)) {

        //error_log('Data: '.bin2hex($data));
        fwrite($pipes[0], $data);
        fclose($pipes[0]);

        $jer = stream_get_contents($pipes[1]);
        fclose($pipes[1]);

        $return_value = proc_close($proc);
        //error_log("Out:\n".$jer."Code = ".$return_value);

        if (!$return_value) {
            $object['data'] = json_decode($jer);
            Send();
        }
        if ($return_value != 255) {
            Error($jer, 1);
        }
    }
}

function Send()
{
    global $object;
    header('HTTP/1.1', true, 200);
    header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
    header('Last-Modified: '.gmdate("D, d M Y H:i:s").' GMT');
    header('Content-type: application/json; charset=UTF-8',true);
    header('Cache-Control: no-cache, must-revalidate');
    header('Pragma: no-cache');
    echo json_encode($object);
    die;
}

function Error($error)
{
    global $object;
    $object['error'] = $error;
    Send();
}

$method = $_SERVER['REQUEST_METHOD'];
if ($method != 'PUT')
    Error('Bad request');

if (!isset($_GET['type']) || !$_GET['type'])
    Error('Missing type');
$type = $_GET['type'];

if (!file_exists($lte_path."/lte_toolbox")) {
    $lte_path = '../../';
    if (!file_exists($lte_path."/lte_toolbox")) {
        Error('Format not supported: conversion unavailable');
    }
}

$data = file_get_contents('php://input');
Decode($data, "gser");
Decode($data, "hex");
Decode($data, "per");
Error('Format not supported: unknown format');

?>
