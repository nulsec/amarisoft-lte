<?php
/*
 * Copyright (C) 2012-2024 Amarisoft
 *
 * Amarisoft LTE Web interface 2024-12-23
 */

function FileCmp($a, $b)
{
    if ($a->type == $b->type) {
        return $a->name < $b->name ? -1 : 1;
    }
    if ($a->type == 'url')
        return 1;

    return -1;
}

function Parse(&$node, $name, $file, $url)
{
    if (!file_exists($file))
        return false;

    if (is_dir($file)) {
        $dh  = opendir($file);
        if (!$dh)
            return false;

        $list = array();
        while (false !== ($subfile = readdir($dh))) {
            if ($subfile[0] != "." && !is_link($file . "/" . $subfile)) {
                Parse($list, $subfile, $file . "/" . $subfile, $url . "/" . $subfile);
            }
        }

        if (count($list) > 0) {
            $obj = new stdClass;
            $obj->name = $name;
            $obj->type = 'url';
            $obj->list = $list;
            #echo $file.":\n".json_encode($obj, JSON_PRETTY_PRINT);
            $node[] = $obj;
        }

    # File
    } else {
        $obj = new stdClass;
        $obj->name = $name;
        $obj->url  = $url;
        $obj->type = $file;
        $obj->locked = true;
        $node[] = $obj;
    }

    usort($node, "FileCmp");

    return true;
}

// OTS
function ParseOTS(&$logs, $selComp)
{
    if (!file_exists('.ots'))
        return false;

    $file = file_get_contents('.ots');
    if (!$file)
        return false;

    $addr = $_SERVER['SERVER_ADDR'];
    if (strchr($addr, '%')) {
        # Link local address with if id
        $addr = explode('%', $addr)[0];
    }

    $ots = gethostname();
    $ws = null;
    $live = null;
    $lines = explode("\n", $file);
    foreach ($lines as $line) {

        $data = explode('#', $line);
        $comp = $data[0];
        if ($comp == '') continue;
        if ($comp == 'OTS') {
            $ots = $data[1];
            if (isset($data[2]) && $data[2] != '')
                $addr = $data[2];
            continue;
        }
        if ($selComp != '' && $selComp != $comp) continue;

        $type = $data[1];
        if ($type == 'ws') {
            $model = $data[2];
            $storeId = $data[3];
            $port = $data[4];
            $name = $comp;
            if (isset($data[5]))
                $name = $data[5];
            $info = '';
            if (isset($data[6]))
                $info = $data[6];

            $obj = new stdClass;
            $obj->name = $name;
            $obj->comp = $name;
            $obj->model = $model;
            $obj->address = $addr.':'.$port;
            $obj->storeId = $storeId;
            $obj->type = 'server';
            $obj->info = $info;
            $obj->readonly = true;
            $obj->locked = true;
            $obj->ots = true;

            if (!$ws) {
                $ws = new stdClass;
                $ws->name = $ots;
                $ws->type = 'ots';
                $ws->expanded = true;
                $ws->list = array();
            }
            $ws->list[] = $obj;

            if ($selComp != '') {
                echo json_encode($obj, JSON_PRETTY_PRINT);
                die;
            }

        } else if ($type == 'live') {
            $value = $data[2];

            $obj = new stdClass;
            $obj->name = $value;
            $obj->model = $comp;
            $obj->url  = 'live/' . $value;
            $obj->type = 'url';
            $obj->locked = true;

            if (!$live) {
                $live = new stdClass;
                $live->name = "Live";
                $live->type = "live";
                $live->expanded = true;
                $live->list = array();
            }
            $live->list[] = $obj;
        }
    }

    if ($ws)
        $logs[] = $ws;
    if ($live)
        $logs[] = $live;
}

$logs = array();
if (isset($_GET['comp'])) {
    ParseOTS($logs, $_GET['comp']);
} else {
    ParseOTS($logs, '');
    // All logs
    Parse($logs, "Backup", "backup", "backup");
    Parse($logs, "Store", "store", "store");
}
#echo json_encode($logs);
echo json_encode($logs, JSON_PRETTY_PRINT);

?>


