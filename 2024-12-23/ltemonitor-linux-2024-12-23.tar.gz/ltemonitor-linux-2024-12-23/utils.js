/*
 * Copyright (C) 2020-2024 Amarisoft
 * LTE Monitor utils version 2024-12-23
 */

const fs = require('fs');
const pathModule = require('path');
const configModule = global.loadLib('config');

module.exports.objectSame = function (o1, o2)
{
    if (typeof o1 !== typeof o2) return false;

    switch (typeof o1) {
    case 'object':
        if (o1 === o2) return true;
        if (o1 === null) return false;

        if (Object.keys(o1).length !== Object.keys(o2).length) return false;

        for (var i in o1) {
            if (!o2.hasOwnProperty(i)) return false;
            if (!this.objectSame(o1[i], o2[i])) return false;
        }
        return true;
    default:
        return o1 === o2;
    }
    return false;
}

/*
 * Persistent data
 */
module.exports.dataLoad = function (obj)
{
    var dataFile = COMP_SAVE_DIR + '/component.' + obj.id;
    var dataHash = obj.parseJSONFile(dataFile, false) || {};

    obj.dataSave = function () {
        this.timerStop('data');
        fs.writeFileSync(dataFile, JSON.stringify(dataHash));
    };

    obj.dataGet = function (name) {
        return dataHash[name];
    };

    obj.dataSet = function (name, value, force) {
        if (dataHash[name] !== value || force) {
            dataHash[name] = value;
            this.dataDirty();
        }
    };

    obj.dataDirty = function () {
        this.timerStart('data', 100); // Save async
    };

    obj.timerCreate('data', obj.dataSave, { restart: false });

};


module.exports.timerInit = function (obj)
{

    // Timers closure
    var enable = true;
    var timerList = {};
    obj.timerCreate = function (id, cb, options) {
        var t = timerList[id];
        if (!t) {
            var t = timerList[id] = {id: id, cb: cb, timer: 0, options: options || {}};
        }
    };

    obj.timerGet = function (id) {
        var t = timerList[id];
        if (!t) {
            if (this.log)
                this.log(LOG_ERROR, 'Unknown timer ' + id);
            process.exit(1);
        }
        return t;
    };

    obj.timerStart = function (id, delay) {

        var t = this.timerGet(id);
        if (delay === undefined) {
            delay = t.options.delay;
        }

        if (t.timer) {
            if (t.options.restart === false)
                return;

            clearTimeout(t.timer);
        }

        if (delay === undefined) {
            t.timer = 0;
            t.cb.call(obj);
            return;
        }
        t.timer = setTimeout(function () {
            t.timer = 0;
            t.cb.call(obj);
        }, delay);
    };

    obj.timerStop = function (id) {
        var t = this.timerGet(id);
        if (t.timer) {
            clearTimeout(t.timer);
            t.timer = 0;
            return true;
        }
        return false;
    };

    obj.timerPending = function (id) {
        var t = this.timerGet(id);
        return !!t.timer;
    };

    obj.timerKill = function () {
        for (var i in timerList) {
            var t = timerList[i];
            clearTimeout(t.timer);
            t.timer = 0;
        }
        this.timerStart = function () {}; // Dummy
    };
};



module.exports.linkStateUpdate = function (state, event, error)
{
    var text  = event;
    var level = LOG_INFO;

    switch (event) {
    case 'connected':
        if (state.error) {
            text  = 'recovered';
            level = LOG_WARN;
            state.error = false;
        }
        break;
    case 'disconnected':
        if (state.error) return null; // Already notified
        if (error) {
            text  = 'lost';
            level = LOG_WARN;
            state.error = true;
        }
        break;
    default:
        return null;
    }
    state.event = event;

    return {
        text: text,
        level: level,
    }
};


module.exports.initFs = function (obj)
{
    obj.writeFileSync = function (file, data, options) {
        if (!options) options = {};

        try {
            if (options.createDir) {
                var dir = pathModule.dirname(file);
                if (!fs.existsSync(dir)) {
                    this.mkdir(dir, options);
                }
            }

            fs.writeFileSync(file, data);

            // Change group
            if (options.group) {
                var uid = process.getuid();
                fs.chownSync(file, uid, options.group);
            }
            // Change permission
            if (options.mod !== undefined) {
                fs.chmodSync(file, options.mod);
            }

        } catch (e) {
            this.fsError = e;
            console.error(e);
            return false;
        }
        return true;
    };

    obj.parseJSONFile = function (filename, ext) {

        if (ext) {
            try {
                var data = require('child_process').execSync(global.path + '/json_util -i 0 dump "' + filename + '"', { maxBuffer: 32 * 1024 * 1024 });
            } catch (e) {
                this.fsError = e.stderr.toString();
                if (!this.fsError)
                    this.fsError = e;
                return null;
            }
        } else {
            try {
                var data = fs.readFileSync(filename);
            } catch (e) {
                this.fsError = e;
                return null;
            }
        }
        try {
            var events = JSON.parse(data);
        } catch (e) {
            this.fsError = e;
            return null;
        }
        return events;
    };

    obj.mkdir = function (dir, options) {
        if (!options) options = {};

        if (!fs.existsSync(dir)) {
            try {
                fs.mkdirSync(dir);
            } catch (e) {
                if (e.code === 'ENOENT') {
                    var root = dir.split(/\//);
                    if (root.pop() === '') root.pop();
                    this.mkdir(root.join('/'), options);
                    fs.mkdirSync(dir);
                }
            }
        }

        if (options.group) {
            var uid = process.getuid();
            fs.chownSync(dir, uid, options.group);
        }

        if (options.mod !== undefined) {
            var mod = options.mod;
            // Add execution rights for directory
            if (mod & 0x7) mod |= 1;
            if ((mod >> 3) & 0x7) mod |= 1 << 3;
            if ((mod >> 6) & 0x7) mod |= 1 << 6;
            fs.chmodSync(dir, mod);
        }
    };

    obj.unlink = function (file) {
        fs.unlink(file, (err) => {
            if (err && err.code !== 'ENOENT')
                this.log(LOG_ERROR, 'Can\'t delete ' + file + ': ' + err.toString(), err);
        });
    };
};


/*
 * CRON like time format: h:m:s
 */
module.exports.createCron = function (cfg)
{
    return new Cron(cfg);
};

var Cron = function (configNode)
{
    module.exports.timerInit(this);

    this.N = this.timeCfg.length;
    this.crons = [];

    // Check config
    this.utc = configNode.getBool('utc', { optional: true, default: true });

    configNode.getArrayExt('time').forEach( (time) => {
        this.crons.push(this.parseCron(time.split(/:/)));
    }, 'string');
};

Cron.prototype.parseCron = function (time)
{
     while (time.length < this.N)
        time.unshift('*');
    if (time.length > this.N)
        configNode.raiseError('time', 'Bad format');

    var cron = [];

    for (var c = 0; c < this.N; c++) {
        var list = cron[c] = [];
        var last = null;
        var cfg  = this.timeCfg[c];

        time[c].split(',').forEach(function (v) {
            var step = 1;
            var m = v.match(/(.+)\/(\d+)$/);
            if (m) {
                step = m[2] - 0;
                if (step <= 0) configNode.raiseError('time', 'Bad format for "' + v + '"');
                v = m[1];
            }

            m = v.match(/^(\d+)(-(\d+))?$/);
            if (!m) {
                if (v !== '*') configNode.raiseError('time', 'Bad format for "' + v + '"');
                var a = cfg.min;
                var b = cfg.max;

            } else if (m[3] === undefined) {
                var a = b = m[1] - cfg.offset;
                if (a < 0) configNode.raiseError('time', 'Inconsistent values: ' + v);
            } else {
                var a = m[1] - cfg.offset;
                var b = m[3] - cfg.offset
                if (a >= b) configNode.raiseError('time', 'Inconsistent values: ' + v);
                if (a < 0) configNode.raiseError('time', 'Inconsistent values: ' + v);
            }

            if (last !== null && last >= a) configNode.raiseError('time', 'Inconsistent values: ' + v);
            if (b > cfg.max) configNode.raiseError('time', 'Inconsistent values: ' + v);

            for (var i = a; i <= b; i += step) {
                list.push(i);
            }
            last = b;
        });
    };
    return cron;
};

Cron.prototype.timeCfg = [
    { min: 0, max: 6,  name: 'Day' /* Hugly */, offset: 0 },
    { min: 0, max: 11, name: 'Month', offset: 1 },
    { min: 1, max: 31, name: 'Date', offset: 0 },
    { min: 0, max: 23, name: 'Hours', offset: 0 },
    { min: 0, max: 59, name: 'Minutes', offset: 0 },
    { min: 0, max: 59, name: 'Seconds', offset: 0 },
];

Cron.prototype.getTime = function (d, index)
{
    var m = 'get' + (this.utc ? 'UTC' : '') + this.timeCfg[index].name;
    return d[m]();
}

Cron.prototype.getYear = function (d)
{
    var m = 'get' + (this.utc ? 'UTC' : '') + 'FullYear';
    return d[m]();
}

Cron.prototype.setTime = function (d, index, v)
{
    var m = 'set' + (this.utc ? 'UTC' : '') + this.timeCfg[index].name;
    if (index === 0) {
        // XXX
    } else {
        d[m](v);
    }
}

Cron.prototype.start = function (cb, time)
{
    if (!time) time = new Date();

    this.timerCreate('next', this.nextTimer);
    this.cb = cb;
    this.nextTime = time;
    this.nextTimer(true);
};

Cron.prototype.nextTimer = function (first)
{
    this.curTime = this.nextTime;
    this.nextTime = this.findDate(new Date(this.curTime * 1 + 1000));

    var now = new Date();
    if (first) {
        //console.log('CRON', 'CUR='+this.curTime, 'NEXT='+this.nextTime, 'NOW='+now);
        if (this.nextTime <= now) {
            this.curTime = now;
            this.nextTime = this.findDate(now);
        }
    } else {
        this.cb(this.curTime, this.nextTime);
    }

    this.timerStart('next', this.nextTime - now);
}

Cron.prototype.destroy = function ()
{
    this.timerKill();
}

Cron.prototype.findDate = function (time)
{
    var best = new Date("2100");

    this.crons.forEach( (cron) => {

        var t = this.findDate1(cron, time);
        if (t < best)
            best = t;
    });
    return best;
}

Cron.prototype.findDate1 = function (cron, time)
{
    var N    = this.N;
    var cfg  = this.timeCfg;
    var cMax = N - 1;

    var getDay = 'get' + (this.utc ? 'UTC' : '') + 'Day';
    time = new Date(time);

    for (var c = cMax; c >= 0; c--) {
        var value = this.getTime(time, c);

        // Max value
        if (c === 2) { // Month
            var max = new Date(this.getYear(time), this.getTime(time, 1) + 1, 0).getDate();
        } else {
            max = cfg[c].max;
        }

        for (var i = 0; i < cron[c].length; i++) {
            var v = cron[c][i];
            if (v >= value)
                break;
        }

        if (c === 0) {
            if (v !== value) {
                if (v > value)
                    this.setTime(time, 2, this.getTime(time, 2) + v - value);
                else {
                    this.setTime(time, 2, this.getTime(time, 2) + cron[c][0] - value + 7);
                }
                c = cMax - 2;
            }
        } else {

            if (v > max || i === cron[c].length) {
                v = max + 1 + cron[c][0] - cfg[c].min;
            }

            if (v > value) {
                if (c === 1) { // Month
                    var tmp = new Date(time);
                    this.setTime(tmp, 2, 1);
                    this.setTime(tmp, 1, v);
                    var jMax = new Date(this.getYear(tmp), this.getTime(tmp, 1) + 1, 0).getDate();
                    var jCur = Math.min(jMax, cron[2][0]);
                    this.setTime(time, 2, jCur);
                }
                for (j = cMax; j > c && j > 2; j--) {
                    this.setTime(time, j, cron[j][0]);
                }
            }
            this.setTime(time, c, v);
        }
    }

    time.setUTCMilliseconds(0);
    return time;
};

module.exports.testCron = function (cfg)
{
    var tests = [
        ['Dec 19 2021 10:10:10', '30', 'Dec 19 2021 10:10:30', false ],
        ['Dec 19 2021 23:10:10', '0:30', 'Dec 20 2021 0:0:30', false ],
        ['Dec 19 2021 23:10:10', '5:*:*:30', 'Jan 5 2022 0:0:30', false ],
        ['Dec 19 2021 10:00:00', '6:*:5:*:30', 'Jun 1 2022 5:0:30', false ],
        ['Dec 19 2021 10:00:00', '1:30:5:6:7', 'Jan 30 2022 5:6:7', false ],
        ['Dec 19 2021 10:00:00', '2:30:5:6:7', 'Feb 28 2022 5:6:7', false ],
        ['Dec 19 2021 10:00:00', '2:*:*:*:*:*', 'Tue Dec 21 2021 10:00:00', false ],
        ['Dec 19 2021 10:00:00', '2:*:2:10:*:*', 'Tue Aug 02 2022 10:00:00', false ],
        ['Dec 19 2021 10:00:00', '2:2:31:10:*:*', 'Tue Feb 28 2023 10:00:00', false ],
        ['Dec 19 2021 10:00:00', '3:4:28,30:10:*:*', 'Wed Apr 30 2025 10:00:00', false ],
    ];

    var pD = function (d) { return ('' + d).replace(/GMT.*/, ''); };


    tests.forEach( (t) => {

        var d0 = new Date(t[0]);
        var cr = t[1];
        var d1 = new Date(t[2]);
        var utc = t[3];

        var ctx = { log: console.log.bind(console) };
        cfg = new configModule.Node(ctx, { time: cr, utc: utc }, 'cron', '<xxx>');
        var cron = new Cron(cfg);

        var d2 = cron.findDate(d0);
        console.log('[' + cr + '] ' + pD(d0) + ' => ' + pD(d1) + ' / ' + pD(d2));
        if (pD(d2) != pD(d1)) {
            console.error('########## Error ##########');
            process.exit(1);
        }
    });
    process.exit(0);
}



/*
 * File store
 */
module.exports.createStore = function (cfg)
{
    return new FileStore(cfg);
};

var FileStore = function (cfg)
{
    module.exports.initFs(this);
    module.exports.timerInit(this);

    this.file = cfg.getFile('store', { type: 'dir', noexist: true });
    this.timeout = cfg.getNumber('timeout', { min: 1 });
    this.mod = cfg.getNumber('permission', { default: 0640 });
    this.group = cfg.getGroupId('group', { optional: true });

    if (!fs.existsSync(this.file)) {
        this.mkdir(this.file, {
            recursive: true,
            group: this.group,
            mod: this.mod,
        });
    }

    this.timerCreate('clean', this.clean);
    this.timerStart('clean', 100); // Async
}


FileStore.prototype.destroy = function ()
{
    this.timerKill();
};

FileStore.prototype.clean = function ()
{
    this.pollTime = Number.POSITIVE_INFINITY;
    this.cleanDir(this.file, false);
};


FileStore.prototype.cleanDir = function (path, freeEmpty)
{
    this.log(LOG_DEBUG, 'Parse directory: ' + path);
    fs.readdir(path, { withFileTypes: true }, (err, files) => {
        if (err) {
            this.statsLog(LOG_ERROR, "Can't parse directory " + path, err);
            return;
        }
        if (!files.length && freeEmpty) {
            fs.rmdir(path, (err) => {
                if (err)
                    this.log(LOG_ERROR, "Can't remove " + path + ': ' + err.code, err);
            });
            return;
        }

        files.forEach( (file) => {
            if (typeof file === 'string') {
                var stat = fs.statSync(path + file);
                var name = file;
            } else {
                var stat = file;
                var name = file.name;
            }
            if (stat.isDirectory()) {
                this.cleanDir(path + name + '/', true);
            } else if (stat.isFile()) {
                if (!this.checkFile(path, name)) {
                    fs.unlink(path + name, (err) => {
                        if (err)
                            this.log(LOG_ERROR, "Can't delete " + path + name + ': ' + err.code, err);
                    });
                }
            }
        });
    });
};

FileStore.prototype.checkFile = function (path, filename)
{
    var m = filename.match(/^(\d{4})(\d{2})(\d{2})-(\d+:\d+:\d+)-(\w+)\.(\w+)$/);
    if (m) {
        //var comp = m[5];
        //var type = m[6];
        var time = new Date(m[1] + '-' + m[2] + '-' + m[3] + ' ' + m[4] + 'Z') / 1000;

        var diff = this.checkExpired(time);
        if (diff > 0)
            return true;

        this.log(LOG_INFO, path.replace(this.file, '') + filename + ' has expired', 'Expired for ' + (-diff).toFixed(0) + 's');
    } else {
        this.log(LOG_WARN, 'Bad store file: ' + path + filename + ' #' + filename);
    }
    return false;
};

FileStore.prototype.checkExpired = function (time)
{
    var timeout = time + this.timeout;
    var diff = timeout - new Date() / 1000;
    if (diff <= 0)
        return diff;

    if (timeout < this.pollTime) {
        this.timerStart('clean', timeout * 1000 - new Date() + 1000);
        this.pollTime = timeout;
    }
    return diff;
};

FileStore.prototype.save = function (cfg)
{
    var filename = module.exports.formatDate(cfg.date || new Date()) + '-' + cfg.name + '.' + (cfg.ext || 'bin');
    if (cfg.dir) filename = cfg.dir + '/' + filename;

    this.log(LOG_INFO, 'Store ' + filename);

    if (!this.writeFileSync(this.file + filename, cfg.data, { createDir: true, mod: this.mod, group: this.group })) {
        this.log(LOG_ERROR, filename + " can't be saved: " + this.fsError.code, this.fsError);
        return false;
    }
    return true;
};

FileStore.prototype.log = function ()
{
};




module.exports.formatDate = function (time, ms, dateSeparator)
{
    var d = time.getUTCFullYear()
        + ('0' + (time.getUTCMonth() + 1)).slice(-2)
        + ('0' + time.getUTCDate()).slice(-2)
        + (dateSeparator || '-')
        + ('0' + time.getUTCHours()).slice(-2)
        + ':' + ('0' + time.getUTCMinutes()).slice(-2)
        + ':' + ('0' + time.getUTCSeconds()).slice(-2);
    if (ms)
        d += '.'  + ('00' + time.getUTCMilliseconds()).slice(-3);
    return d;
};

module.exports.setWSBinHandler = function (ws, cb)
{
    ws.on('binary', (data) => {

        var msg = null;
        var error = false;
        var chunks = [];

        data.on('data', (chunk) => {
            if (error)
                return;

            if (!msg) {
                var buf = new Int32Array(chunk);
                for (var i = 0; i < buf.length; i++) {
                    if (buf[i] !== 0) continue;

                    try {
                        var str = String.fromCharCode.apply(null, buf.slice(0, i));
                        chunk = chunk.slice(i + 1, chunk.length);
                        msg = JSON.parse(str);
                    } catch (e) {
                        error = true;
                        cb('error', e.toString());
                    }
                    break;
                }
                if (!msg) {
                    error = true;
                    cb('error', 'Not message found for binary data');
                }
            }

            cb('chunk', msg, chunk);
            chunks.push(chunk);
        });
        data.on('end', (chunk) => {
            if (msg) {
                if (chunk) {
                    cb('chunk', msg, chunk);
                    chunks.push(chunk);
                }
                cb('end', msg, Buffer.concat(chunks));
            }
        });
    });
};
