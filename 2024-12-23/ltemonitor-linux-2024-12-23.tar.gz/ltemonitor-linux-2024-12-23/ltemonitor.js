#!/usr/bin/node
/*
 * Copyright (C) 2020-2024 Amarisoft
 * LTE Monitor daemon version 2024-12-23
 */


/*
 * TODO:
 * - SSL
 * - Rotate event file
 */


/* Modules shortcuts */
const fs = require('fs');
const path = require('path');
const child_process = require('child_process');
const WebSocket = require('nodejs-websocket');

/* Load modules */
global.path = require('path').dirname(process.argv[1]);
global.loadLib = function (name) {
    return require(this.path + '/' + name + '.js');
};
const componentModule = global.loadLib('component');
const configModule = global.loadLib('config');
const utilsModule = global.loadLib('utils');
const proxyModule = global.loadLib('proxy');

const CWD = require('path').dirname(process.argv[1]);

/* Web sockets */
global.WS_DEFAULT_PORT = 9007;
global.WS_KEEPALIVE    = 60000;
global.WS_SEND_TIMEOUT = 20000;
global.WS_BIN_CHUNK_SIZE = 128 * 1024;

/* Globals */
global.MON_TYPE = 'MONITOR';
global.COMP_SAVE_DIR = '.save';
global.COMP_IMPORT_HIST_SIZE = 30;
global.LICENSE_PATH = '/root/.amarisoft/'
global.UPGRADE_PATH = '/tmp/'

/* Global timings */
global.STATS_POLL_DELAY             = 5; /* s */
global.PROXY_RETRY_DELAY            = 10000;
global.COMP_WS_CONNECT_RETRY_DELAY  = 500;

/*
 * Logs/event levels
 */
global.LOG_ERROR        = 1;
global.LOG_WARN         = 2;
global.LOG_INFO         = 3;
global.LOG_DEBUG        = 4;
global.LOG_LEVEL_STRING = ['?', 'ERROR', 'WARN', 'INFO', 'DEBUG'];

/*
 * Event:
 * - hostname: machine hostname
 * - level: string (cf LOG_LEVEL_STRING)
 * - comp: ENB|MME|IMS (cf ltestart.sh) ... MON|RPROXY|LPROXY
 * - section: Rx|Cx|STATE|AUTH|CONFIG
 * - title: connected|disconnected|internal error|failure
 * - msg: <any text>
 *
 */


const componentConfig = {
    link: ['MME', 'ENB', 'IMS'],

};


var Monitor = {

    // Default
    eventFD: null,
    alarms: [],
    emails: null,
    id: 'MON',
    hostname: '',
    host: null,
    osname: '',
    stopped: false,
    version: '2024-12-23',

    help: function (argv, index) {

        if (index) {
            console.error('Bad parameter', argv[index]);
        }

        console.error('Usage:');
        console.error('> ' + argv[1] + ' [options] <config file>');
        process.exit(1);
    },

    start: function (argv)  {

        this.logLayerAdd(this.id);
        this.logLayerAdd('EVENT');
        this.logLayerAdd('ALARM');
        this.logLayerAdd('COM');

        var comp = [];
        var testEmailID = undefined;
        var config = false;

        utilsModule.timerInit(this);
        utilsModule.initFs(this);
        utilsModule.dataLoad(this);

        process.on('SIGTERM', this.onSignal.bind(this));
        process.on('SIGINT', this.onSignal.bind(this));
        process.on('uncaughtException', this.onException.bind(this));

        for (var i = 2; i < argv.length; i++) {
            var arg = argv[i];

            switch (arg) {
            case '--fifo':
                this.fifoStart(argv[++i]);
                break;
            case '--ots-fifo':
                this.otsFifo = fs.createWriteStream(argv[++i]);
                break;
            case '--hostname':
                this.hostname = argv[++i];
                break;
            case '--osname':
                this.osname = argv[++i];
                break;
            case '--error':
                process.exit(45);
                break;
            case '--comp':
                comp.push({
                    id: argv[++i],
                    config: argv[++i],
                    state: argv[++i],
                    prog: argv[++i]
                });
                break;
            case '--host':
                this.host = argv[++i];;
                break;
            case '--log':
                this.logConfigureStart(argv[++i], 32);
                break;
            case '--test-email':
                testEmailID = argv[++i];
                if (testEmailID === undefined) {
                    console.error('email ID required');
                    process.exit(33);
                }
                break;
            case '--test-cron':
                utilsModule.testCron();
                process.exit(0);
                break;

            default:
                if (config)
                    this.help(argv, i);

                config = true;
                this.loadConfig(arg);
                break;
            }
        }

        if (!this.hostname) {
            try {
                var data = child_process.execSync('hostname');
                this.hostname = data.toString('utf8').trim();
            } catch (e) {
                this.hostname = process.env.HOSTNAME || 'HOSTNAME?';
            }
        }

        if (!config)
            this.help(argv);

        this.timerCreate('compUpdate', this.compUpdateAsync, { delay: 500, restart: false });

        this.startTime = new Date();
        this.logState('started');

        // Add components
        comp.forEach((c) => {
            this.log2(LOG_INFO, c.id, 'Add component, config=' + c.config);
            var comp = this.compList[c.id] = new componentModule.Instance(this, c);
        });

        if (testEmailID !== undefined) {
            if (!this.emails) {
                console.error('No email configuration defined');
                process.exit(1);
            }
            this.debug = true;
            if (!this.emailAdd(testEmailID, {
                    verbose: true,
                    level: 'Test level',
                    hostname: this.hostname,
                    time: new Date(),
                    comp: 'Test component',
                    section: 'Test section',
                    title: 'Test title',
                    msg: 'Test msg',
                }, function (result) {
                    process.exit(0);
                })) {
                // Error
                process.exit(1);
            }
        }

        // Components
        var localinfo = null;
        var compAll = this.compAll = this.dataGet('components') || {};
        for (var host in compAll) {
            var info = this.compGetInfo(host);
            if (!info.address) {
                // Local host, delete in case of name change
                localinfo = info;
                delete compAll[host];
            } else {
                info.state = 'disconnected';
            }
        }

        // Update local host parameters
        if (!localinfo) localinfo = {};
        localinfo.osname  = this.osname;
        localinfo.version = this.version;
        localinfo.port    = this.address.port;
        localinfo.state   = 'connected';
        if (this.customFields)
            localinfo.custom = this.customFields;
        if (this.host)
            localinfo.address = this.host;
        compAll[this.hostname] = {_info_: localinfo};

        this.compUpdate();

        if (this.system) {
            this.timerCreate('systemCheck', this.systemCheck.bind(this), { delay: this.system.poll_delay * 1000 });
            this.timerStart('systemCheck');
        }
    },

    stop: function () {

        if (this.stopped) return;
        this.stopped = true;

        this.timerKill();

        if (this.stats)
            this.statsTerminate();

        if (this.backup)
            this.backupTerminate();

        this.logState('stopped');

        // Stop current connections
        var connList = this.connList;
        this.connList = [];
        connList.forEach((conn) => {
            this.comConnClose(conn);
        });

        if (this.ws) {
            this.logCom(LOG_INFO, 'SERVER', 'Stopping');
            this.ws.close();
            this.ws = null;
        }

        if (this.proxy) {
            this.proxy.terminate();
            this.proxy = null;
        }

        if (this.otsFifo) {
            this.otsFifo.close();
            this.otsFifo = null;
        }

        if (this.fifoStop)
            this.fifoStop();

        for (var i in this.compList) {
            this.compList[i].terminate();
        }
        this.compList = null;

        for (var i in this.emails) {
            var email = this.emails[i];
            for (var id in email.timers)
                clearTimeout(email.timers[id]);
        }

        if (this.debug) {
            setTimeout(function () {
                console.log('Remaining tasks:');
                console.log(process._getActiveHandles());
                console.log(process._getActiveRequests());
            }, 1000);
        }
    },

    onSignal: function (signal) {

        this.log(LOG_DEBUG, 'Signal received: ' + signal);
        this.stop();
    },

    onException: function (error, origin) {

        console.error('Exception');
        this.log(LOG_ERROR, 'Fatal error: ' + error, error);
        if (this.debug)
            console.log(error);

        this.stop();
    },

    loadConfig: function (filename) {

        var config = this.parseJSONFile(filename, true);
        if (!config) {
            this.log(LOG_ERROR, 'Can\'t load config file: ' + this.fsError);
            process.exit(1);
        }

        // Convert to absolute
        if (!path.isAbsolute(filename)) {
            filename = global.path + '/' + filename;
        }
        filename = path.normalize(filename);

        try {
            this.parseConfig(new configModule.Node(this, config, 'config', filename), filename);
        } catch (msg) {
            console.error(msg);
            process.exit(1);
        }

    },

    parseConfig: function (config) {

        // Logs
        this.logFilename = config.getFile('log_filename', { noexist: true });
        var log_options = config.getString('log_options');
        this.logConfigureStart(log_options, 33);

        this.logFileFD = fs.openSync(this.logFilename, 'w');

        this.debug = config.getBool('debug', { optional: true, default: false });

        this.logHeader('ltemonitor version ' + this.version);

        // Event filename
        var event_filename = config.getString('event_filename', { optional: true });
        if (event_filename) {
            this.eventFD = fs.openSync(event_filename, 'a');
        }

        this.comInit(config);

        // Remote proxy
        var proxy = config.getObject('proxy', { optional: true });
        if (proxy) {
            this.proxy = new proxyModule.Instance(this, proxy);
        }

        // emails
        var emails = config.getArray('emails', { optional: true });
        if (emails) {
            this.emails = {};
            emails.forEach( (email) => {
                var id = email.getString('id', { optional: true });
                if (this.emails[id]) {
                    if (id === undefined)
                        email.raiseError('id', 'Default email already defined');
                    email.raiseError('id', 'email ' + id + ' already defined');
                }
                email.checkEMail('from');
                email.checkEMail('to');
                email.getFile('smtp');
                email.getFile('template', { load: true, comment: /\s*#.*/ });

                var aggrDef = email.getObject('aggregation', { optional: true });
                if (aggrDef) {
                    aggrDef.getNumber('delay', { min: 1 });
                    aggrDef.getNumber('count', { min: 1 });
                }

                this.emails[id] = email.getNode();
                this.emails[id].timers = {};
            });
            this.emailAggregateInit();
        }

        // Alarms
        var alarms = config.getArray('alarms', { optional: true });
        if (alarms) {
            alarms.forEach( (alarm) => {

                // Check filters
                alarm.getArray('filters').forEach( (f) => {
                    f.checkLevel('level');
                });

                alarm.getString('id');
                alarm.getNumber('priority', { optional: true, update: true, default: 0 });

                this.alarms.push(alarm.getNode());
            });
        }

        // Stats
        var stats = config.getObject('stats', { optional: true });
        if (stats)
            this.statsInit(stats);

        // Backup
        var backup = config.getObject('backup', { optional: true });
        if (backup)
            this.backupInit(backup);

        // Cutomer fields
        var customFields = config.getObject('custom_fields', { optional: true });
        if (customFields) {
            this.customFields = customFields.getNode();
        }
        var custom_def = config.getArray('custom_definition', { optional: true });
        if (custom_def) {
            this.customDef = custom_def.getNode();
        }

        // System
        var system = config.getObject('system', { optional: true });
        if (system) {
            this.system = {
                poll_delay: system.getNumber('poll_delay', { default: 60 }),
                disk_usage: system.getNumber('disk_usage', { default: 95 }),
            };
        }
    },

    otsFifoSend: function (cmd, comp, arg) {
        if (this.otsFifo) {
            this.otsFifo.write(['MON', cmd, comp, arg].join('|')  + "\n");
        }
    },

    fifoStart: function (filename) {

        var fifo = fs.createReadStream(filename, {flags : 'r+'});
        fifo.on('data', (data) => {
            data.toString('utf8').trim().split("\n").forEach( (line) => {
                this.fifoHandle(line)
            });
        });

        fifo.on('error', (error) => {
        });

        fifo.on('end', (error) => {
        });

        this.fifoStop = function () {
            var c = fs.createWriteStream(filename);
            c.write('\0');
            c.close();

            fifo.pause();
            fifo.close();
            fifo = null;
        };
    },

    fifoHandle: function (msg) {

        var args = msg.split('|');
        var cmd = args.shift();
        var id = args.shift();

        var comp = this.compList[id];
        if (!comp) {
            this.log2(LOG_ERROR, id, 'Unknwon component');
            return;
        }

        switch (cmd) {
        case 'state':
            // state
            var state = args.shift();
            switch (state) {
            case 'error':
                var section = args.shift();
                var error = args.shift();
                comp.setError(section, error, args.join("\n"));
                break;
            default:
                comp.setState(state);
                break;
            }
            break;
        default:
            this.log2(LOG_ERROR, comp, 'Unknwon command ' + cmd);
            break;
        }
    },

    compList: {},
    compAll: {},

    compUpdate: function () {

        var compAll = this.compAll;

        // Update remote
        this.connList.forEach( (conn) => {
            for (var host in conn.proxyComponents) {
                compAll[host] = conn.proxyComponents[host];
            }
        });

        // Set local
        var localinfo = this.compGetInfo(this.hostname);
        var comp = compAll[this.hostname] = {_info_: localinfo};
        for (var id in this.compList) {
            comp[id] = this.compList[id].export();
        }

        this.timerStart('compUpdate');
    },

    compGetInfo: function (host) {
        var comp = this.compAll[host];
        if (comp) return comp._info_;
        return null;
    },

    compUpdateAsync: function () {

        var compAll = this.compAll;

        // Notification
        this.comNotify({message: 'components', components: compAll});

        // Save info
        this.dataSet('components', compAll, true);

        // Proxy propagation
        if (this.proxy) {
            this.proxy.sendMsg('proxy-components', {components: compAll});
        }

        // Backup poll
        this.backupPoll();
    },

    remoteProxyConnected: function () {

        if (!this.timerPending('compUpdate')) {
            this.proxy.sendMsg('proxy-components', { components: this.compAll });
        }
    },

    logState: function (state) {
        this.eventSet(this.hostname, this.id, LOG_INFO, 'STATE', state);
    },

    /*
     * level: number
     */
    eventSet: function (hostname, comp, level, section, title, msg, version) {

        // Generate alarm ?
        var alarmId = [];
        var alarms = this.alarms;
        var prio   = Number.NEGATIVE_INFINITY;
        for (var a = 0; a < alarms.length; a++) {
            var alarm = alarms[a];

            for (var i = 0; i < alarm.filters.length; i++) {
                var f = alarm.filters[i];

                if (f.level !== undefined && level > f.level) continue;
                if (this.filterCheck(comp, f.component)) continue;
                if (this.filterCheck(section, f.section)) continue;
                if (this.filterCheck(title, f.title)) continue;

                if (alarm.priority === prio) {
                    alarmId.push(alarm.id);
                } else if (alarm.priority > prio) {
                    alarmId = [alarm.id];
                    prio = alarm.priority;
                }
                break;
            }
        }

        if (!alarmId.length)
            alarmId = null;

        this.eventProcess({
            time: new Date() * 1,
            hostname: hostname,
            comp: comp,
            section: section,
            level: LOG_LEVEL_STRING[level],
            title: title,
            msg: msg,
            alarmId: alarmId,
            count: 1,
            version: version || this.version,
        });
    },

    eventProcess: function (event) {

        var time = new Date(event.time);
        var line = ([
            utilsModule.formatDate(time, true),
            event.hostname,
            event.level,
            event.comp,
            event.section,
            event.title,
            event.msg ? event.msg.replace(/\n/g, '|') : ''
        ]).join('|');

        if (this.eventFD === null) {
            this.logDump(LOG_LEVEL_STRING.indexOf(event.level), 'EVENT', line);
        } else {
            fs.writeSync(this.eventFD, line + "\n");
        }

        if (this.proxy) {
            event.type = 'event';
            this.proxy.dataPush(event);
            return;
        }

        // Send alarm ?
        var info = this.compGetInfo(event.hostname);
        if (info && info.alarmMuted)
            return;

        if (this.emails && event.alarmId) {
            var alarmIds = event.alarmId;
            if (!(alarmIds instanceof Array)) // Handle legacy case
                alarmIds = [alarmIds];

            for (var i = 0; i < alarmIds.length; i++) {
                this.emailAdd(alarmIds[i], event);
            }
        }
    },

    emailGet: function (alarmId) {
        return this.emails[alarmId] || this.emails['undefined'];
    },

    emailAggregateInit: function () {

        var aggrList = this.dataGet('emailAggregation');
        if (!aggrList) return;

        var dirty = false;
        var now = new Date() * 1;
        for (var aggrId in aggrList) {
            var aggrEvt = aggrList[aggrId];
            var email = this.emailGet(aggrEvt.alarmId);
            if (!email || !email.aggregation) {
                delete aggrList[aggrId];
                dirty = true;
                continue;
            }

            var aggrDef = email.aggregation;
            var delay = aggrDef.delay * 1000 + aggrEvt.time - now;
            if (delay > 0) {
                this.emailAggregateStart(email, aggrDef, aggrEvt, aggrId, delay);
                continue;
            }

            if (aggrEvt.count >= aggrDef.count) {
                this.emailAggregateSend(email, aggrEvt);
                this.emailAggregateStart(email, aggrDef, aggrEvt, aggrId);
            }
            dirty = true;
        }

        if (dirty) {
            this.dataSet('emailAggregation', aggrList, true);
        }
    },

    emailAggregateSend: function (email, aggrEvt) {

        var event = aggrEvt.event;
        if (aggrEvt.msg.length) {
            var event = Object.assign({}, aggrEvt.event);
            event.msg += "\n\n" + aggrEvt.msg.join("\n\n");
        }
        event.count = aggrEvt.count;

        this.emailSend(email, aggrEvt.alarmId, event, null);
    },

    emailAggregateTrig: function (email, aggrDef, aggrEvt, aggrId) {

        var aggrList = this.dataGet('emailAggregation');

        if (aggrEvt.count >= aggrDef.count) {
            // Send email
            this.emailAggregateSend(email, aggrEvt);
            this.emailAggregateStart(email, aggrDef, aggrEvt, aggrId);
        } else {
            delete email.timers[aggrId];
            delete aggrList[aggrId];
        }
        this.dataSet('emailAggregation', aggrList, true);
    },

    emailAggregateStart: function (email, aggrDef, aggrEvt, aggrId, delay) {

        if (!delay) {
            delay = aggrDef.delay * 1000;
            aggrEvt.time = new Date() * 1;
            aggrEvt.count = 0;
        }
        email.timers[aggrId] = setTimeout(this.emailAggregateTrig.bind(this, email, aggrDef, aggrEvt, aggrId), delay);
    },

    emailAdd: function (alarmId, event, callback) {

        var email = this.emailGet(alarmId);
        if (!email) {
            this.logAlarm(LOG_ERROR, 'EMAIL', `Alarm ID ${alarmId} does not match any email configuration`, event);
            return false;
        }

        // Aggregation
        var aggrDef = email.aggregation;
        if (!aggrDef) {
            return this.emailSend(email, alarmId, event, callback);
        }

        // Pending aggregation ?
        var aggrId = ([event.hostname, event.comp, event.section, event.title]).join('#');
        var aggrList = this.dataGet('emailAggregation') || {};
        var aggrEvt = aggrList[aggrId];
        if (!aggrEvt) {
            aggrEvt = aggrList[aggrId] = {
                event: event,
                alarmId: alarmId,
                msg: [],
            };
            this.emailAggregateStart(email, aggrDef, aggrEvt, aggrId);
            this.dataSet('emailAggregation', aggrList, true);
            return this.emailSend(email, alarmId, event, null);
        }

        if (++aggrEvt.count == 1) {
            aggrEvt.event.time = event.time;
            aggrEvt.event.msg = event.msg;
            aggrEvt.msg = [];
        }
        if (event.msg !== aggrEvt.event.msg && aggrEvt.msg.length < 20 && aggrEvt.msg.indexOf(event.msg) < 0) {
            aggrEvt.msg.push(event.msg);
        }
        this.logAlarm(LOG_DEBUG, 'EMAIL', 'Postpone alarm ' + alarmId + ', count=' + aggrEvt.count, event);
        this.dataSet('emailAggregation', aggrList, true);
        return false;
    },

    emailSend: function (email, alarmId, event, callback) {

        this.logAlarm(LOG_DEBUG, 'EMAIL', 'Send alarm ' + alarmId, event);
        /*
         *  email: {
         *      smtp: <smtp config file>,
         *      to: <destination email>,
         *      from: <source email>,
         *      text: <email text (Including headers)>
         *  }
         */

        // Windows format
        var msg = event.msg.replace(/\r?\n/g, "\r\n");

        var data = {
            smtp: email.smtp,
            from: email.from,
            to: email.to,
            verbose: event.verbose,
            callback, callback,
            text: email.template
                .replace(/<LEVEL>/g, event.level)
                .replace(/<HOST>/g, event.hostname)
                .replace(/<DATE>/g, new Date(event.time))
                .replace(/<COMPONENT>/g, event.comp)
                .replace(/<SECTION>/g, event.section)
                .replace(/<TITLE>/g, event.title)
                .replace(/<MESSAGE>/g, msg)
                .replace(/<ALARM>/g, alarmId)
                .replace(/<VERSION>/g, event.version)
                .replace(/<COUNT>/g, event.count)
        };

        if (this.emailFifo.push(data) === 1)
            this.emailPoll();
        return true;
    },

    // e-mail
    emailFifo: [],
    emailCur: null,
    emailPoll: function () {

        if (this.emailCur || !this.emailFifo.length)
            return;

        var email = this.emailCur = this.emailFifo.shift();

        var to = email.to;
        if (to instanceof Array)
            to = to.join(',');

        // Create process
        var args = ['-t', '-C', email.smtp];
        if (email.verbose)
            args.push('-v');
        var smtp = child_process.spawn('ssmtp', args, {cwd: __dirname});

        smtp.on('error', (e) => {
            this.logAlarm(LOG_ERROR, 'SMTP', 'error=' + e);
        });

        smtp.on('exit', (code, signal) => {
        });

        smtp.on('close', (code, signal) => {
            if (code || signal) {
                this.logAlarm(LOG_ERROR, 'SMTP', 'error=' + code + ' signal=' + signal);
            } else {
                this.logAlarm(LOG_DEBUG, 'SMTP', 'email sent to ' + to);
            }
            this.emailCur = null;
            this.emailPoll();
            if (email.callback)
                email.callback.call(this, code);
        });

        smtp.stdout.setEncoding('utf-8');
        smtp.stdout.on('data', (chunk) => {
            this.chunkToLine(chunk).forEach( (line) => {
                this.logAlarm(LOG_DEBUG, 'SMTP', line);
            });
        });

        //  STDERR
        smtp.stderr.setEncoding('utf-8');
        smtp.stderr.on('data', (chunk) => {
            this.chunkToLine(chunk).forEach( (line) => {
                this.logAlarm(LOG_ERROR, 'SMTP', line);
            });
        });

        smtp.stdin.setEncoding('utf-8');
        smtp.stdin.write('From: ' + email.from + "\n");
        smtp.stdin.write('To: ' + to + "\n");
        smtp.stdin.write(email.text);
        smtp.stdin.end();
    },

    filterCheck: function (value, f) {
        return f !== undefined && !value.match('^' + f + '$');
    },

    /*
     * COM API
     */
    connList: [],
    comInit: function (config) {

        this.address = config.getIP('com_addr', { optional: true });
        if (!this.address)
            return;

        this.comName = config.getString('com_name', { default: MON_TYPE });
        this.logsLocked = config.getBool('com_logs_lock', { default: false });

        WebSocket.setMaxBufferLength(64 * 1024 * 1024);
        WebSocket.setBinaryFragmentation(WS_BIN_CHUNK_SIZE);
        this.ws = WebSocket.createServer(this.onConnect.bind(this));
        var host = this.address.host.replace(/[\[\]]/g, ''); // Remove [] for ipv6;
        var port = this.address.port || WS_DEFAULT_PORT;

        this.logCom(LOG_INFO, 'SERVER', 'Starting on ' + host + ':' + port);

        var auth = config.getObject('com_auth', { optional: true });
        if (auth) {
            var password = auth.getFile('passfile', { load: true, optional: true });
            if (password) {
                this.auth = { password: password.split(/[\r\n]/)[0] };
            } else {
                this.auth = { password: auth.getString('password') };
            }

            this.auth.unsecure = auth.getBool('unsecure', { optional: true, default: false });
        }

        this.ws.listen(port, host);
    },

    comSend: function (conn, msg, cb) {
        if (conn && conn.ws) {
            msg.time = (new Date() - this.startTime) / 1000;
            if (cb) {
                var id = msg.message_id = 'msg' + conn.nextId++;
                conn.pending[id] = {
                    message: msg.message,
                    cb: cb,
                    timeout: setTimeout(this.comSendTimeout.bind(this, conn, id), WS_SEND_TIMEOUT),
                };
            }

            conn.ws.send(JSON.stringify(msg));
            return true;
        }
        return false;
    },

    comSendBin: function (conn, msg, bin, cb) {
        if (conn && conn.ws) {
            var stream = conn.ws.beginBinary();

            msg.time = (new Date() - this.startTime) / 1000;
            if (cb) {
                var id = msg.message_id = 'msg' + conn.nextId++;
                var p = conn.pending[id] = {
                    message: msg.message,
                    cb: cb,
                    timeout: 0,
                    stream: stream,
                };
            }

            // Send
            var data = Buffer.concat([Buffer.from(JSON.stringify(msg) + '\0'), bin]);
            var pos = 0;
            var n = 0;
            var nextWrite = () => {
                for (;;) {
                    var end = Math.min(pos + WS_BIN_CHUNK_SIZE, data.length);
                    if (pos === end) {
                        stream.end();
                        return;
                    }

                    n++;
                    var chunk = data.slice(pos, end);
                    pos = end;
                    if (!stream.write(chunk)) {
                        stream.once('drain', nextWrite);
                        break;
                    }
                }
                if (p.cb) {
                    clearTimeout(p.timeout);
                    p.timeout = setTimeout(this.comSendTimeout.bind(this, conn, id), WS_SEND_TIMEOUT);
                }
            };

            nextWrite();
            return true;
        }
        return false;
    },

    comSendTimeout: function (conn, id) {

        var p = conn.pending[id];
        if (p) {
            this.logCom(LOG_ERROR, 'SERVER', 'Timeout for ' + p.message);
            p.cb(null, 'timeout');
            p.cb = null;
            delete conn.pending[id];
            if (p.stream)
                p.stream.end();
        }
    },

    comResponse: function (conn, org, msg) {

        msg = msg || {};

        if (org.message_id) {
            msg.message_id = org.message_id;
        }
        msg.message = org.message;

        return this.comSend(conn, msg);
    },

    comError: function (conn, org, error, data) {

        this.comLog(conn, LOG_ERROR, error, data);
        return this.comResponse(conn, org, { error: error });
    },

    comNotify: function (msg) {

        if (!this.stopped) {
            this.connList.forEach( (conn) => {
                if (conn.register[msg.message]) {
                    this.comSend(conn, msg);
                }
            });
        }
    },

    comLog: function (conn, level, msg, data) {
        this.logCom(level, conn.hostname, msg, data);
    },

    comKill: function (conn, msg) {
        this.comLog(conn, LOG_ERROR, msg);
        this.comConnClose(conn);
    },

    comConnClose: function (conn) {
        if (conn && conn.ws) {
            if (!conn.error)
                conn.close = 'local';
            conn.ws.close();
            conn.ws = null;
        }
    },

    comConnGet: function (hostname) {

        for (var i = 0; i < this.connList.length; i++) {
            var conn = this.connList[i];
            if (conn.hostname === hostname)
                return conn;
        }
        return null;
    },

    onConnect: function (ws) {

        // Init connection
        var conn = {
            ws: ws,
            register: {},
            proxyComponents: null,
            hostname: ws.socket.remoteAddress + ':' + ws.socket.remotePort,
            logRequest: {
                logLast: null,
                min:     0,
                max:     0,
                logs:    [],
                msg:     null,
                send:    false,
                authenticated: false,
            },
            proxy: null,
            backupClean: false,
            keepalive: WS_KEEPALIVE,
            pending: {}, // Pending message (waiting for response)
            nextId: 0,
        };

        utilsModule.timerInit(conn);
        conn.timerCreate('logRequest', this.logConnTimeout.bind(this, conn));
        conn.timerCreate('keepalive-timeout', this.onConnTimeout.bind(this, conn));

        this.comLog(conn, LOG_INFO, 'Incoming connection');

        this.connList.push(conn);

        ws.on('text', this.onConnText.bind(this, conn));
        ws.on('close', this.onConnClose.bind(this, conn));
        ws.on('error', this.onConnError.bind(this, conn));

        utilsModule.setWSBinHandler(ws, this.onConnBin.bind(this, conn));

        if (this.auth) {
            conn.challenge = '';
            for (var i = 0; i < 32; i++) {
                conn.challenge += ((Math.random() * 16) >> 0).toString(16);
            }
            this.comResponse(conn, { message: 'authenticate' }, {
                challenge: conn.challenge,
                type: MON_TYPE,
                version: this.version,
                name: this.comName
            });
        } else {
            this.comResponse(conn, { message: 'ready' }, {
                ready: true,
                type: MON_TYPE,
                version: this.version,
                name: this.comName
            });
        }
    },

    onConnText: function (conn, str) {

        var msg = this.parseJSONData(str);
        if (!msg) {
            this.comLog(conn, LOG_ERROR, 'Invalid WS message', str);
            return;
        }

        if (msg instanceof Array) {
            msg.forEach( (m) => {
                this.onConnMsg(conn, m);
            });
        } else {
            this.onConnMsg(conn, msg);
        }
    },

    onConnBin: function (conn, type, msg, data) {

        if (conn.proxy)
            conn.timerStart('keepalive-timeout', conn.keepalive);

        if (type === 'chunk') return;
        if (type === 'error') {
            this.comLog(conn, LOG_ERROR, "Binary error: " + error);
            return;
        }

        switch (msg.message) {
        case 'software-upgrade-prepare':
            this.onHostMsg(conn, msg, data);
            break;

        default:
            this.comError(conn, msg, 'Unknown message');
            break;
        }
    },

    onConnMsgProxy: function (conn, msg) {

        conn.timerStart('keepalive-timeout', conn.keepalive);

        switch (msg.message) {
        case 'proxy-init':
            if (msg.hostname)
                conn.hostname = msg.hostname;

            if (conn.hostname === this.hostname) {
                this.comKill(conn, 'Loop detected');
                return;
            }
            if (msg.keepalive) {
                conn.keepalive = msg.keepalive;
                conn.timerStart('keepalive-timeout', conn.keepalive);
            }
            conn.proxy = {
                backup: false
            };
            this.comConnLinkUpdate(conn, 'connected');
            break;
        case 'proxy-ping':
            this.comLog(conn, LOG_DEBUG, 'Ping');
            break;
        case 'proxy-data':
            this.onConnProxyData(conn, msg);
            break;
        case 'proxy-components':
            if (msg.components) {
                if (msg.components[this.hostname]) {
                    this.comKill(conn, 'Loop detected');
                    return;
                }
                this.comLog(conn, LOG_INFO, 'Add proxy-components');

                // Update hosts
                for (host in msg.components) {
                    var comp = msg.components[host];
                    var info = comp._info_;
                    if (!info) continue; // Filter old clients

                    // Merge with stored values
                    var info1 = this.compGetInfo(host);
                    if (info1) {
                        for (var i in info1) {
                            if (i === 'address') continue;
                            if (info[i] === undefined) info[i] = info1[i];
                        }
                    }

                    // No address, set my intermediate proxy
                    if (!info.address) {
                        info.address = conn.ws.socket.remoteAddress;
                    }
                    if (info.state !== 'disconnected')
                        info.state = 'connected';
                    info.proxy = conn.hostname;
                    info.error = false;

                    // Delete backup error to retry
                    if (!conn.proxy.backup && this.backup) {
                        var hdata = this.backup.data.hosts[host];
                        if (hdata) {
                            for (var c in comp) {
                                if (c === '_info_') continue;
                                if (hdata[c] && hdata[c].error !== undefined) {
                                    delete hdata[c].error;
                                }
                            }
                        }
                        conn.proxy.backup = true;
                    }
                }

                conn.proxyComponents = msg.components;
                this.compUpdate();
            }
            break;
        default:
            return this.comError(conn, msg, 'Unknown proxy message: ' + msg.message, msg);
        }

        this.comResponse(conn, msg);
    },

    onConnAuth: function (conn, msg) {

        var auth = this.auth;
        var password = MON_TYPE + ':' + auth.password + ':' + this.comName;

        if (msg.password) {
            if (!auth.unsecure) {
                return this.comError(conn, msg, 'Unsecure authentication forbidden');
            }

            if (msg.password !== password) {
                return this.comError(conn, msg, 'Unsecure authentication failed');
            }
        } else if (!msg.res) {
            return this.comError(conn, msg, 'Missing res field');
        } else {

            var hmac = require('crypto').createHmac('sha256', password);
            hmac.update(conn.challenge);
            var res = hmac.digest('hex');

            if (res != msg.res) {
                return this.comError(conn, msg, 'Authetication failed');
            }
        }
        conn.authenticated = true;
        this.comResponse(conn, msg, { ready: true });
    },

    softwareUpgradePrepare: function (msg, cmd, cb) {

        /* XXX:
         * auto clean in install.sh
         */
        child_process.exec('tar xvzf ' + msg.file, { cwd: UPGRADE_PATH }, (error, stdout, stderr) => {

            this.unlink(UPGRADE_PATH + msg.file);

            if (error)
                return cb('error', 'Not a software release: ' + stderr.toString());

            var files = stdout.toString().replace(/\n$/, '').split(/\n/);
            var version = files.shift().replace('/', '');
            var monitor = false, install = false;
            files.forEach( (f) => {
                if (f.match(/ltemonitor/)) monitor = true;
                if (f.match(/install\.sh$/)) install = true;
            });
            if (!monitor)
                return cb('error', 'Missing monitor package');
            if (!install)
                return cb('error', 'Missing OTS package');

            this.softwareUpgradeLaunch(msg, cmd, version, cb);
        });
    },

    softwareUpgradeLaunch: function (msg, cmd, version, cb) {

        var install = UPGRADE_PATH + version + '/install.sh';
        if (!version.match(/^20\d{2}-\d{2}-\d{2}$/) && fs.existsSync(install))
            return cb('error', 'Not a software release');

        if (msg.args && !(msg.args instanceof Array))
            return cb('error', 'args must be an array');

        switch (cmd) {
        case 'software-upgrade-prepare':
        case 'software-upgrade-check':
            this.log(LOG_INFO, 'Check version ' + version);
            var args = [
                install,
                '--default',
                '--monitor',
                '--dry-run',
            ];
            if (msg.args) args.push.apply(args, msg.args);
            child_process.exec(args.join(' '), { cwd: UPGRADE_PATH }, (error, stdout, stderr) => {
                if (error)
                    return cb('error', stderr.toString());

                this.softwareUpgradeVersion = version;
                cb('data', { output: stdout.toString(), version: version });
            });
            break;
        case 'software-upgrade-start':
            this.log(LOG_INFO, 'Install version ' + version);
            var log = UPGRADE_PATH + 'lte-install-' + version + '.log';
            this.unlink(log);
            var args = [
                install,
                '--default',
                '--monitor',
            ];
            if (msg.args) args.push.apply(args, msg.args);
            args.push.apply(args, ['>', log, '&&', 'rm', '-Rf', UPGRADE_PATH + version]);
            var cmd = 'echo "' + args.join(' ') + '" | at now';
            this.log(LOG_INFO, 'Schedule install: ' + cmd);
            child_process.exec(cmd, { cwd: UPGRADE_PATH }, (error, stdout, stderr) => {
                if (error)
                    return cb('error', stderr.toString());

                this.softwareUpgradeVersion = null;
                cb('date', {});
            });
            break;
        }
    },

    removeHost: function (host) {

        var info = this.compGetInfo(host);
        if (info) {
            this.log(LOG_INFO, 'Remove host ' + host + ' from ' + info.proxy);
            var conn = this.comConnGet(info.proxy);
            if (conn) {
                if (info.proxy !== host) {
                    this.comSend(conn, { message: 'proxy-remove-host', host: host });
                } else {
                    this.comConnClose(conn);
                }
                delete conn.proxyComponents[host];
            }
            delete this.compAll[host];
            this.compUpdate();
            return true;
        }
        return false;
    },

    licenseSet: function (msg, cb) {

        var licenses = msg.licenses;
        if (!licenses) { // Legacy
            if (!msg.license)
                return cb('License not found');
            licenses = [{data: msg.license, name: msg.file}];
        }
        // Checks
        if (!(licenses instanceof Array))
            return cb('licenses must be an array');
        var count = licenses.length;
        if (!count)
            return cb('License not found');

        for (var i = 0; i < count; i++) {
            var license = licenses[i];
            if (!license.name)
                return cb('License name missing');
            if (!license.data || license.data.length > 1000000)
                return cb('Invalid license file: ' + license.name);
        }

        var licenseFiles = [];
        var handleLicense = () => {
            var license = licenses.shift();
            if (!license) {
                return cb('data', { files: licenseFiles });
            }

            var buffer = Buffer.from(license.data, 'base64');

            var file = LICENSE_PATH + license.name;
            if (!this.writeFileSync(file, buffer))
                return cb(this.fsError);

            var m = file.match(/\.(tgz|tar\.gz)$/);
            if (m) {
                require('child_process').exec('tar xvzf ' + file, { cwd: LICENSE_PATH }, (error, stdout, stderr) => {
                    this.unlink(file);
                    if (error)
                        return cb('error', stderr.toString());

                    var files = stdout.toString()
                                      .replace(/\n$/, '')
                                      .split(/\n/)
                                      .filter( (f) => { return this.licenseCheck(LICENSE_PATH + f); });
                    if (!files.length) {
                        this.log(LOG_INFO, 'No valid license found');
                        return cb('error', 'No valid license found');
                    }

                    this.log(LOG_INFO, 'Licenses uploaded: ' + files.join(', '));
                    licenseFiles.push.apply(licenseFiles, files);
                    handleLicense();
                });

            } else {
                if (!this.licenseCheck(file)) {
                    return cb('error', 'Invalid license file');
                }
                this.log(LOG_INFO, 'License uploaded: ' + license.name);
                licenseFiles.push(license.name);
                handleLicense();
            }
        };
        handleLicense();
    },

    licenseCheck: function (file) {

        try {
            child_process.execSync('cat ' + file + ' | grep host_id');
        } catch (e) {
            this.log(LOG_WARN, 'Invalid license file: ' + file);
            this.unlink(file);
            return false;
        }
        return true;
    },

    execAt: function (cmd, options, cb) {
        this.log(LOG_INFO, 'Schedule "' + cmd + '"');
        child_process.exec("echo '" + cmd + "' | at now", options, (error, stdout, stderr) => {
            if (error)
                return cb('error', stderr.toString());

            cb('data', {});
        });
    },

    onCompMsg: function (msg, cmd, cb) {
        return this.onRemoteMsg(msg, null, false, (type, data) => {
            switch (type) {
            case 'error':
                cb(type, data);
                break;
            case 'remote':
                delete data.message_id;
                cb(type, data);
                break;
            case 'comp':
                var comp = data;
                switch (cmd) {
                case 'backup':
                    comp.backupConfigs(cb);
                    break;

                case 'config-file-set':
                    var error = comp.setConfig(msg.config, msg.file);
                    if (error)
                        cb('error', error);
                    else
                        cb('data', {});
                    break;

                case 'config-file-get':
                    var file = comp.getConfig();
                    try {
                        var cfg = fs.readFileSync(file).toString('utf8');
                    } catch (e) {
                        this.log(LOG_WARN, 'Can\'t load config file ' + comp.configFile, e);
                        return cb('error', e);
                    }
                    cb('data', {config: cfg, file: path.basename(file)}, null);
                    break;
                case 'comp-autostart':
                    this.otsFifoSend(cmd, comp.id, msg.autostart);
                    cb('data', null);
                    break;
                }
                break;
            }
        });
    },

    onConnCompMsg: function (conn, msg) {
        this.onCompMsg(msg, msg.message, (type, data) => {
            if (type === 'error')
                this.comError(conn, msg, data, msg);
            else
                this.comResponse(conn, msg, data);
        });
    },

    onHostMsg: function (conn, msg, bin) {
        var cmd = msg.message;
        return this.onRemoteMsg(msg, bin, true, (type, data) => {
            switch (type) {
            case 'error':
                this.onHostMsgEnd(conn, msg, 'error', data);
                break;
            case 'localhost':
                switch (cmd) {
                case 'reboot-host':
                    setTimeout( () => { child_process.exec('sudo /sbin/shutdown -r now', function (error, stdout, stderr) {}); }, 1000);
                    this.onHostMsgEnd(conn, msg, 'data', null);
                    break;
                case 'restart-service':
                    this.execAt("sudo service lte restart", {}, this.onHostMsgEnd.bind(this, conn, msg));
                    break;
                case 'restart-host':
                    this.log(LOG_WARN, 'Quit monitor from remote API');
                    this.onHostMsgEnd(conn, msg, 'data', null);
                    setTimeout( process.kill.bind( process, process.pid, 'SIGTERM' ), 1000 );
                    break;
                case 'license-set':
                    this.licenseSet(msg, this.onHostMsgEnd.bind(this, conn, msg));
                    break;
                case 'software-upgrade-prepare':
                    try {
                        child_process.execSync('systemctl status atd | grep running')
                    } catch(e) {
                        var error = e.stderr.toString().replace(/\n$/, '');
                        this.log(LOG_ERROR, "AT daemon error: " + error, e);
                        if (error) {
                            this.onHostMsgEnd(conn, msg, 'error', error + "\nAT daemon may be missing.\ntry to install it with 'dnf install at'");
                        } else {
                            this.onHostMsgEnd(conn, msg, 'error', "AT daemon not started, try\nsystemctl start atd\nsystemctl enable atd");
                        }
                        return;
                    }

                    if (!this.writeFileSync(UPGRADE_PATH + msg.file, bin))
                        return this.onHostMsgEnd(conn, msg, 'error', this.fsError);

                    this.softwareUpgradePrepare(msg, cmd, this.onHostMsgEnd.bind(this, conn, msg));
                    break;
                case 'software-upgrade-check':
                case 'software-upgrade-start':
                    if (!this.softwareUpgradeVersion)
                        return this.onHostMsgEnd(conn, msg, 'error', 'No software upgrade in preparation');

                    this.softwareUpgradeLaunch(msg, cmd, this.softwareUpgradeVersion, this.onHostMsgEnd.bind(this, conn, msg));
                    break;
                case 'comp-autostart':
                    for (var id in this.compList) {
                        this.otsFifoSend(cmd, id, msg.autostart);
                    }
                    this.onHostMsgEnd(conn, msg, 'data', null);
                    break;
                default:
                    this.onHostMsgEnd(conn, msg, 'error', 'Not implemented: ' + cmd);
                    break;
                }
                break;
            case 'remote':
                this.onHostMsgEnd(conn, msg, 'data', data);
                break;
            }
        });
    },

    onHostMsgEnd: function (conn, msg, type, data) {
        if (type === 'error')
            this.comError(conn, msg, data);
        else
            this.comResponse(conn, msg, data || {});
    },

    onRemoteMsg: function (msg, bin, hostOnly, cb) {

        var host = msg.host;
        var info = this.compGetInfo(host);
        if (!info)
            return cb('error', 'Unknwon host: ' + host);

        if (!info.proxy) {
            if (hostOnly)
                return cb('localhost');

            var compId = msg.comp;
            var comp = this.compList[compId];
            if (!comp)
                return cb('error', 'Unknown component: ' + compId);

            return cb('comp', comp);
        }

        var conn1 = this.comConnGet(info.proxy);
        if (!conn1)
            return cb('error', 'Remote host not available');

        var msg1 = Object.assign({}, msg);
        delete msg1.message_id;

        var cb1 = (msg, error) => {
            if (error)
                cb('error', error);
            else
                cb('remote', msg);
        };

        msg1.message = 'proxy-' + msg1.message;
        if (bin)
            return this.comSendBin(conn1, msg1, bin, cb1);
        else
            return this.comSend(conn1, msg1, cb1);
    },

    onConnMsg: function (conn, msg) {

        var resp;

        var p = conn.pending[msg.message_id];
        if (p) {
            delete conn.pending[msg.message_id];
            clearTimeout(p.timeout);
            p.timeout = 0;
            p.cb(msg, msg.error);
            return;
        }

        // Restart keep alive
        if (conn.proxy || msg.message === 'proxy-init') {
            return this.onConnMsgProxy(conn, msg);
        }

        if (this.auth && !conn.authenticated) {
            if (msg.message === 'authenticate') {
                return this.onConnAuth(conn, msg);
            }
            return this.comError(conn, msg, 'Authentication not done');
        }

        switch (msg.message) {
        case 'stats':
        case 'log_set':
        case 'log_reset':
        case 'help':
            resp = { warning: 'Not implemented' };
            break;

        case 'config_get':
            resp = {
                version: '2024-12-23',
                name: this.comName,
                type: MON_TYPE,
                logs: this.logConfigGet(),
            };
            break;

        case 'config_set':
            var resp = {};
            if (msg.logs) {
                try {
                    if (this.logsLocked)
                        resp.logs = 'locked';
                    else
                        this.logConfigSet(msg.logs);
                } catch (e) {
                    this.comError(conn, msg, e);
                    return;
                }
            }
            break;

        case 'log_get':
            this.logConnRequest(conn, msg);
            return;

        case 'quit':
            this.comLog(conn, LOG_WARN, 'Quit monitor');
            process.kill( process.pid, 'SIGTERM' );
            break;

        case 'register':
            for (var i in msg.register) {
                var type = msg.register[i];
                conn.register[type] = true;
            }
            for (var i in msg.unregister) {
                conn.register[msg.unregister[i]] = false;
            }
            break;

        case 'state_get':
            resp = {
                components: this.compAll,
                hostname: this.hostname
            };
            if (this.customDef)
                resp.custom_definition = this.customDef;
            break;

        case 'remove-host':
            if (!this.removeHost(msg.host))
                return this.comError(conn, msg, 'Unknown host: ' + msg.host, msg);
            break;

        case 'alarm-toggle':
            var info = this.compGetInfo(msg.host);
            if (!info)
                return this.comError(conn, msg, 'Unknown host');

            info.alarmMuted = !info.alarmMuted;
            this.compUpdate();
            break;

        // Action on component
        case 'config-file-get':
        case 'config-file-set':
        case 'backup':
            return this.onConnCompMsg(conn, msg);

        // Action on host
        case 'reboot-host':
        case 'restart-service':
        case 'restart-host':
        case 'license-set':
        case 'software-upgrade-check':
        case 'software-upgrade-start':
            return this.onHostMsg(conn, msg);

        case 'comp-autostart':
            if (msg.comp)
                return this.onConnCompMsg(conn, msg);
            return this.onHostMsg(conn, msg);;

        case 'debug':
            if (!this.debug)
                return this.comError(conn, msg, 'Debug disabled');

            if (typeof msg.code !== 'string')
                return this.comError(conn, msg, 'Missing or invalid code');

            try {
                // Eval is evil
                resp = {
                    result: eval(msg.code),
                };
            } catch (e) {
                return this.comError(conn, msg, e.toString(), msg);
            }
            break;

        default:
            return this.comError(conn, msg, 'Unknown message: ' + msg.message, msg);
        }

        // Generic response
        this.comResponse(conn, msg, resp);
    },

    onConnProxyData: function (conn, msg) {

        for (var id in msg.data) {
            var data = msg.data[id];
            if (data.hostname === this.hostname) {
                this.comKill(conn, 'Loop detected');
                break;
            }

            switch (data.type) {
            case 'event':
                this.eventProcess(data);
                break;
            case 'stats':
            case 'cdr':
                if (this.stats) {
                    this.statsProcess(data);
                } else {
                    this.comLog(conn, LOG_WARN, 'Stats not enabled: data lost');
                }
                break;
            }
        }
    },

    onConnClose: function (conn) {
        var idx = this.connList.indexOf(conn);
        if (idx >= 0) {
            this.connList.splice(idx, 1);
            if (conn.proxyComponents) {
                for (var host in conn.proxyComponents) {
                    var comp = conn.proxyComponents[host];
                    for (var id in comp) {
                        comp[id].state = 'disconnected';
                    }
                }

                // Remote close
                if (conn.close !== 'local' && conn.proxy) {
                    this.comConnLinkUpdate(conn, 'disconnected');
                }
                this.compUpdate();
            }
        }

        for (var id in conn.pending) {
            if (conn.pending[id].cb)
                conn.pending[id].cb(null, 'connection closed');
            clearTimeout(conn.pending[id].timeout);
        }
        conn.pending = {};

        conn.timerKill();
        this.comLog(conn, LOG_INFO, 'Disconnected: ' + (conn.error || conn.close || 'closed by remote host'));
        conn.ws = null;
    },

    onConnError: function (conn, error) {
        if (!conn.error) {
            this.comLog(conn, LOG_ERROR, 'Connection error: ' + error.toString(), error);
            conn.error = error.toString();
        }
    },

    onConnTimeout: function (conn) {
        if (conn.ws)
            conn.ws.socket.destroy();
        this.comLog(conn, LOG_ERROR, conn.proxy ? 'Proxy timeout' : 'Connection timeout');
        conn.error = 'timeout';
        this.comConnClose(conn);
    },

    comConnLinkUpdate: function (conn, event) {

        var host = conn.hostname;
        var info = this.compGetInfo(host);
        if (!info) info = {};

        var e = utilsModule.linkStateUpdate(info, event, conn.error);
        if (e) {
            this.eventSet(host, 'PROXY', e.level, 'proxy-link', event, 'link ' + host + '/' + this.hostname + ' ' + e.text);
        }
    },

    /******************************************************
     * LOGS
     ******************************************************/
    debug: false,
    logFilename: null,
    logFileFD: process.stdout.fd,
    logLayers: {
        ALL: { level: LOG_INFO, max_size: 0}
    },
    logPath: null,
    logRotateSize: Number.POSITIVE_INFINITY,
    logSize: 0,
    logBuffer: [],
    logBufferSize: 256,
    logIdx: 0,
    logTimeFormat: 'short',
    logHeaders: [],

    log: function (level, msg, data) {
        this.logDump(level, this.id, msg, data);
    },

    log2: function (level, info, msg, data) {
        this.logDump(level, this.id, info + ': ' + msg, data);
    },

    logAlarm: function (level, info, msg, data) {
        this.logDump(level, 'ALARM', info + ': ' + msg, data);
    },

    logCom: function (level, info, msg, data) {
        this.logDump(level, 'COM', info + ': ' + msg, data);
    },

    logDump: function (level, layer, msg, data) {

        var l = this.logLayers[layer];

        if (l && l.level >= level) {
            var time, now = new Date();

            var log = {
                level: level,
                layer: layer,
                src: this.comName,
                idx: this.logIdx++,
                data: [msg]
            };

            log.timestamp = now * 1;
            switch (this.logTimeFormat) {
            case 'sec':
                time = ((now - this.startTime) / 1000).toFixed(3);
                break;
            case 'short':
                var h = now.getHours();
                var m = now.getMinutes();
                var s = now.getSeconds();
                var ms = now.getMilliseconds();
                time = ('0' + h).slice(-2) + ':' + ('0' + m).slice(-2) + ':' + ('0' + s).slice(-2) + '.' + ('00' + ms).slice(-3);
                break;
            case 'full':
                time = utilsModule.formatDate(now, true, ' ');
                break;
            }

            this.logWrite(`${time} [${layer}] - ${msg}\n`);
            if (data && l.max_size > 0) {
                var indent = this.logIndent + this.logIndent;
                this.logWrite(indent);
                this.logDumpData(indent, data);
                log.data.push(data);
            }
            this.logConnPush(log);
        }
    },

    logIndent: '    ',

    logDumpData: function (indent, data) {
        switch (typeof data) {
        case 'object':
            this.logWrite("{\n");
            var indent2 = indent + this.logIndent;
            for (var i in data) {
                this.logWrite(indent2 + i + ': ');
                this.logDumpData(indent2, data[i]);
            };
            this.logWrite(indent + "}\n");
            break;
        default:
            this.logWrite('' + data + "\n");
            break;
        }
    },

    logHeader: function (line) {
        var h = '# ' + line;
        this.logHeaders.push(h);
        this.logWrite(h + "\n");
    },

    logWrite: function (data) {
        this.logSize += fs.writeSync(this.logFileFD, data);

        // Log rotation
        if (!this.stopped && this.logSize >= this.logRotateSize) {
            this.logRotate();
        }
        if (this.debug)
            process.stdout.write(data);
    },

    logConnPush: function (log) {

        if (this.logBuffer.push(log) === this.logBufferSize) {
            this.logBuffer.shift();
        }

        this.connList.forEach( (conn) => {
            if (conn.logRequest.msg) {
                this.logConnAdd(conn, [log], 0);
            }
        });
    },

    logConnAdd: function (conn, logs, index) {

        var request = conn.logRequest;

        for (var i = index; i < logs.length; i++) {
            var log = logs[i];

            var level = request.filters[log.layer] | 0;
            if (level < log.level) continue;
            if (log.timestamp < request.start_ts || log.timestamp > request.end_ts) continue;

            if (request.logs.push(log) >= request.max) {
                this.logConnSend(conn);
                return;
            }
        }

        if (request.logs.length >= request.min) {
            if (!request.send) {
                conn.timerStart('logRequest', 100);
                request.send = true;
            }
        } else {
            conn.timerStart('logRequest', request.timeout);
        }
    },

    logConnTimeout: function (conn) {

        var request = conn.logRequest;
        if (request.logs.length) {
            this.logConnSend(conn);
        }
        request.min = 1;
    },

    logConnRequest: function (conn, msg) {

        var request = conn.logRequest;
        if (request.msg) {
            this.logConnSend(conn);
        }

        request.msg     = msg;
        request.min     = msg.min === undefined ? 1 : msg.min;
        request.max     = msg.max === undefined ? this.logBufferSize >> 1 : msg.min;
        request.timeout = (msg.timeout|| 1) * 1000;
        request.send    = false;
        request.start_ts = msg.start_timestamp === undefined ? 0 : msg.start_timestamp;
        request.end_ts   = msg.end_timestamp === undefined ? Number.POSITIVE_INFINITY : msg.end_timestamp;

        // Filters
        request.filters = {};
        if (msg.layers) {
            for (var layer in msg.layers) {
                if (!this.logLayers[layer]) {
                    return this.comError(conn, msg, 'Unknwon layer ' + layer);
                }

                var str = msg.layers[layer];
                if (typeof str !== 'string') {
                    return this.comError(conn, msg, 'Level for layer ' + layer + ' must be a string');
                }
                var level = LOG_LEVEL_STRING.indexOf(str.toUpperCase());
                if (level < 0) {
                    return this.comError(conn, msg, 'Invalid level ' + str + ' for layer ' + layer);
                }

                request.filters[layer] = level;
            }
        } else {
            for (var l in this.logLayers) {
                request.filters[l] = LOG_DEBUG;
            }
        }

        conn.timerStart('logRequest', request.timeout);

        // Load current
        var index = this.logBuffer.indexOf(request.logLast);
        this.logConnAdd(conn, this.logBuffer, index + 1);
    },

    logConnSend: function (conn) {

        var request = conn.logRequest;
        var logs = request.logs;
        request.logLast = logs.length > 0 ? logs[logs.length - 1] : null

        var resp = { logs: logs };
        if (request.msg.headers === true)
            resp.headers = this.logHeaders;
        this.comResponse(conn, request.msg, resp);

        // Clear
        conn.timerStop('logRequest');
        request.logs = [];
        request.msg  = null;
        request.send = false;
    },

    logRotate: function () {
        fs.closeSync(this.logFileFD);

        var ext = this.formatDateLog(new Date());
        if (this.logPath) {
            var dst = this.logPath + '/' + path.basename(this.logFilename) + '.' + ext;
        } else {
            var dst = this.logFilename + '.' + ext;
        }

        try {
            // First try to move file
            fs.renameSync(this.logFilename, dst);
        } catch (e) {
            // Different devices, let's copy and delete
            if (e.code === 'EXDEV') {
                // Move to tmp file to allow log file reopen while doing copy async
                var tmp = this.logFilename + '.' + ext + '.tmp';
                fs.renameSync(this.logFilename, tmp);

                // Then copy
                var from = fs.createReadStream(tmp);
                var to = fs.createWriteStream(dst);
                //readStream.on('error', callback);
                //writeStream.on('error', callback);
                from.on('close', function () { fs.unlinkSync(tmp); });
                from.pipe(to);
            } else {
                fs.unlinkSync(tmp);
                // XXX
            }
        }

        this.logFileFD = fs.openSync(this.logFilename, 'w');
        this.logSize = 0;
    },

    logSizeGet: function (s) {

        var m = s.match(/^(\d+(\.\d*)?)([MKG]?)$/);
        if (!m)
            return false;

        var size = m[1] - 0;
        if (size <= 0)
            return false;

        return size * ({'': 1, 'K': 1e3, 'M': 1e6, 'G': 1e9})[m[3]];
    },

    logConfigureStart: function (log_options, code) {

        try {
            this.logConfigure(log_options);
        } catch (e) {
            console.error('Bad log configuration', log_options);
            console.error(e);
            process.exit(code);
        }
    },

    logConfigure: function (log_options) {

        var list = log_options.split(',');
        for (var i = 0; i < list.length; i++) {
            var m = list[i].match(/^(\w+)\.(\w+)=(.+)$/);
            if (!m) continue;

            var layer = m[1].toUpperCase();
            var cmd = m[2];

            switch (layer) {
            case 'FILE':
                switch (cmd) {
                case 'rotate':
                    if (m[3] === 'now') {
                        // XXX
                    } else {
                        this.logRotateSize = this.logSizeGet(m[3])
                        if (this.logRotateSize === false)
                            throw 'Bad rotate size: ' + m[3];
                    }
                    break;
                case 'path':
                    this.logPath = m[3];
                    if (!fs.existsSync(this.logPath))
                        throw 'Path does not exist: ' + m[3];
                    break;
                case 'cut':
                case 'save':
                    // XXX
                    break;
                }
                break;
            case 'TIME':
                switch (cmd) {
                case 'short':
                case 'full':
                case 'sec':
                    this.logTimeFormat = cmd;
                    break;
                default:
                    throw 'Unsupported time format: ' + cmd;
                }
                break;
            default:
                switch (cmd) {
                case 'level':
                    this.logLayerSet(layer, m[3], undefined);
                    break;
                case 'max_size':
                    this.logLayerSet(layer, undefined, m[3]- 0);
                    break;
                }
                break;
            }
        }
        return true;
    },

    logLayerAdd: function (layer) {

        var all = this.logLayers.ALL;
        this.logLayers[layer] = {
            level: all.level,
            max_size: all.max_size
        };
    },

    logLayerSet: function (layer, level, max_size) {

        var l = this.logLayers[layer];
        if (!l)
            throw 'Unknown layer: ' + layer;

        if (level !== undefined) {
            var l0 = LOG_LEVEL_STRING.indexOf(level.toUpperCase());
            if (l0 < 0)
                throw 'Bad level: ' + level;

            l.level = l0;
        }
        if (max_size !== undefined) {
            if (isNaN(max_size))
                throw 'max_size must be a number';

            l.max_size = max_size;
        }

        if (layer === 'ALL') {
            for (var l in this.logLayers) {
                if (l !== 'ALL')
                    this.logLayerSet(l, level, max_size);
            }
        }
    },

    logConfigSet: function (logs) {

        for (var name in logs.layer) {
            var layer = logs.layer[name];
            this.logLayerSet(name, layer.max_size, layer.level);
        }

        if (logs.count !== undefined) {
            if (isNaN(logs.count))
                throw 'count must be a number: ' + logs.count;
            if (logs.count <= 0)
                throw 'count must be positive: ' + logs.count;

            this.logBufferSize = logs.count
            this.logBuffer = this.logBuffer.slice(-logs.count)
        }

        if (logs.rotate !== undefined) {
            var rotate = this.logSizeGet('' + logs.rotate);
            if (rotate === false || rotate < 0)
                throw 'rotate must be a positive number: ' + logs.rotate;

            this.logRotateSize = logs.rotate;
        }

        if (logs.path !== undefined) {
            if (logs.path) {
                if (!fs.existsSync(logs.path))
                    throw 'Path does not exist: ' + log.path;
            } else {
                logs.path = null;
            }
            this.logPath = logs.path;
        }

        return true;
    },

    logConfigGet: function () {

        var cfg = {
            layers: {},
            count: this.logBufferSize,
        };

        if (this.logRotateSize !== Number.POSITIVE_INFINITY)
            cfg.rotate = this.logRotateSize;
        if (this.logPath)
            cfg.path = this.logPath;

        for (var l in this.logLayers) {
            if (l === 'ALL') continue;
            var layer = this.logLayers[l];
            cfg.layers[l] = {
                level: LOG_LEVEL_STRING[layer.level].toLowerCase(),
                max_size: layer.max_size,
                payload: false
            };
        }
        if (this.logsLocked)
            cfg.locked = true;
        return cfg;
    },


    utilsInit: function (obj) {

        obj.monitor = this; // Link

        for (var id in this._tools) {
            obj[id] = this._tools[id];
        }

        // Log
        obj.log = function (level, msg, data) {
            this.monitor.log2(level, this.id, msg, data);
        };

        obj.parseJSONData = this.parseJSONData;
    },

    // Utils
    // XXX: move to utils
    parseJSONData: function (txt) {
        try {
            var msg = JSON.parse(txt);
        } catch (e) {
            this.log(LOG_ERROR, this.id, 'Parsing error: ' + e);
            return null;
        }
        return msg;
    },

    // External API
    formatDateLog: function (time) {

        return time.getUTCFullYear()
            + ('0' + (time.getUTCMonth() + 1)).slice(-2)
            + ('0' + time.getUTCDate()).slice(-2)
            + '.'
            + ('0' + time.getUTCHours()).slice(-2)
            + ':' + ('0' + time.getUTCMinutes()).slice(-2)
            + ':' + ('0' + time.getUTCSeconds()).slice(-2);
    },

    formatTitle: function (title) {
        return title.charAt(0).toUpperCase() + title.slice(1);
    },

    chunkToLine: function (chunk) {

        var lines = chunk.toString().split("\n");
        if (lines[lines.length-1] === '')
            lines.pop();
        return lines;
    },

    /*
     * Stats
     */
    statsInit: function (stats) {

        this.stats = {
            cron: utilsModule.createCron(stats),
            time1: new Date(),
        };

        // Proxy ?
        if (!this.proxy) {
            this.stats.store = utilsModule.createStore(stats);
            this.stats.store.log = this.statsLog.bind(this);
            this.stats.indent = stats.getNumber('indent', { default: 0, min: 0, max: 10 });
        }

        this.stats.enabled = stats.getBool('enabled', { default: true });
        this.stats.comp_poll_delay = stats.getNumber('comp_poll_delay', { default: STATS_POLL_DELAY, min: 1 }) * 1000;
        this.stats.sub_sampling = stats.getNumber('sub_sampling', { default: Number.POSITIVE_INFINITY, min: this.stats.comp_poll_delay / 1000 });

        if (this.stats.enabled)
            this.stats.cron.start(this.statsPoll.bind(this));
    },

    statsTerminate: function () {
        if (this.stats.store)
            this.stats.store.destroy();
        this.stats.cron.destroy();
    },

    statsOn: function () {
        return this.stats && this.stats.enabled;
    },

    statsPoll: function (curTime, nextTime) {

        this.statsLog(LOG_INFO, 'Next will occur on ' + nextTime);
        for (var id in this.compList) {
            this.compList[id].statsFlush();
        }
    },

    statsGetEndTime: function () {
        return this.stats.cron.nextTime;
    },

    customFieldsFilter: function (cf0, type) {

        if (!cf0) return undefined;

        var def = this.customDef;
        if (!def) return undefined;

        var cf1 = type === 'stats' ? [] : {};
        for (var id in cf0) {
            var d = def.find( (item) => { return item.id === id && item[type] !== false; });
            if (!d) continue;

            switch (type) {
            case 'stats':
                cf1.push({
                    id: id,
                    title: d.title,
                    value: cf0[id],
                });
                break;
            default:
                cf1[id] = cf0[id];
                break;
            }
        }
        return cf1;
    },

    statsProcess: function (stats) {

        var info = stats.info;
        if (!info)
            return;

        // Generated locally, add informations
        if (!info.hostname) {
            info.hostname = this.hostname;

            if (this.customFields)
                info.custom_fields = this.customFields;
        }

        // Send to proxy ?
        if (this.proxy) {
            this.proxy.dataPush(stats);
        } else {
            var diff = this.stats.store.checkExpired(info.start);
            if (diff > 0) {
                // Filter out custom fields
                info.custom_fields = this.customFieldsFilter(info.custom_fields, 'stats');

                var host = info.hostname.replace(/\s/g, '_');
                this.stats.store.save({
                    date: new Date(info.end * 1000),
                    dir: host,
                    name: info.id,
                    ext: stats.type,
                    data: JSON.stringify(stats, null, this.stats.indent)
                });
            }
        }
    },

    statsLog: function (level, title, data) {
        this.log(level, 'STATS: ' + title, data);
    },

    /*
     * Backup
     */
    backupInit: function (cfg) {

        var backup = this.backup = {
            cron: utilsModule.createCron(cfg),
            store: utilsModule.createStore(cfg),
            data: this.dataGet('backup') || {hosts: {}},
        };
        backup.store.log = this.backupLog1.bind(this);

        var time = backup.data.time;
        if (!time) {
            time = backup.data.time = new Date();
            this.backupSave();
        }
        backup.cron.start(this.backupCron.bind(this), new Date(time));

        this.backupLog(LOG_INFO, null, 'Next on ' + backup.cron.nextTime);
    },

    backupTerminate: function () {
        this.backup.store.destroy();
        this.backup.cron.destroy();
    },

    backupCron: function (curTime, nextTime) {
        this.backup.data.time = curTime * 1;
        this.backupLog(LOG_INFO, null, 'Next on ' + nextTime);
        this.backupSave();
        this.backupPoll();
    },

    backupSave: function () {
        this.dataSet('backup', this.backup.data, true);
    },

    backupLog1: function (level, title, data) {
        this.log(level, 'BACKUP: ' + title, data);
    },

    backupLog: function (level, comp, title, data) {
        if (comp)
            this.log(level, 'BACKUP: ' + comp.id + '@' + comp.host + ': ' + title, data);
        else
            this.backupLog1(level, title, data);
    },

    backupStart: function (comp) {
        this.backup.pending = comp;
        this.backupLog(LOG_DEBUG, comp, 'start');
        this.onRemoteMsg({ host: comp.host, comp: comp.id, message: 'backup' }, null, false, (type, data) => {
            switch (type) {
            case 'error':
                this.backupError(comp, data);
                break;
            case 'remote':
                this.backupStore(comp, data.data);
                break;
            case 'comp':
                data.backupConfigs( (type, data) => {
                    if (type === 'data') {
                        this.backupStore(comp, data.data);
                    } else {
                        this.backupError(comp, data);
                    }
                });
                break;
            }
        });
    },

    backupStore: function (comp, data) {

        var buffer = Buffer.from(data, 'base64');
        var date = new Date();
        if (!this.backup.store.save({
                dir: comp.host,
                name: comp.id,
                ext: 'tgz',
                date: date,
                data: buffer
            })) {
            comp.data.error = this.backup.fsError;
            this.backupError(comp, data);
        } else {
            this.backupLog(LOG_DEBUG, comp, 'done');
        }
        comp.data.last = date * 1;
        this.backupNext();
    },

    backupError: function (comp, error) {

        this.backupLog(LOG_ERROR, comp, error);
        comp.data.last = new Date() * 1;
        comp.data.error = error;
        this.backupNext();
    },

    backupPoll: function () {
        if (this.backup && !this.backup.pending) {
            this.backupNext();
        }
    },

    backupNext: function () {
        if (this.stopped) return false;

        // Save state
        if (this.backup.pending) {
            this.backupSave();
            this.backup.pending = null;
        }

        var bdata = this.backup.data;

        for (var h in this.compAll) {
            var host = this.compAll[h];

            if (!this.compAll[h]) {
                delete bdata[h]; // Host removed
                continue;
            }
            if (host._info_.state !== 'connected') continue;

            var h1 = bdata.hosts[h];
            if (!h1) h1 = bdata.hosts[h] = {};

            for (var c in host) {
                if (c === '_info_') continue;

                var cdata = h1[c];
                if (!cdata) cdata = h1[c] = { last: 0, error: null };

                //console.log('?', '' + new Date(cdata.last), ''+this.backup.cron.curTime);
                if (!cdata.error && cdata.last - this.backup.cron.curTime < 0) {
                    this.backupStart({
                        host: h,
                        id: c,
                        data: cdata
                    });
                    return true;
                }
            }
        }
        return false;
    },

    /*
     * System alarms
     */
    systemCheck: function () {

        child_process.exec('df', (error, stdout, stderr) => {

            this.timerStart('systemCheck');

            if (error) {
                this.log(LOG_WARN, "Can't check disk usage");
                return;
            }

            var lines = stdout.toString().replace(/\n$/, '').split(/\n/);
            lines.shift(); // Remove headers
            lines.forEach( (l) => {

                var values = l.split(/\s+/);
                if (values[0].match(/tmpfs/) || values[5].match(/^\/boot/)) return;

                var usage = values[4].replace(/%$/, '') - 0;
                if (usage > this.system.disk_usage) {
                    this.eventSet(this.hostname, this.id, LOG_ERROR, 'SYSTEM', 'High disk usage', 'Path "' + values[5] + '" is getting full: ' + usage + '%');
                }
            });
        });
    },
};



Monitor.start(process.argv);

