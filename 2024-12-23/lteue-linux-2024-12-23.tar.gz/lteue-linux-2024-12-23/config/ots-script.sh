#!/bin/bash
# Copyright (C) 2022-2024 Amarisoft
# lteue cleanup script version 2024-12-23

case "$2" in
starting|stopped)
    # Clean network namespaces
    for ID in $(ip netns | cut -d ' ' -f1) ; do
        if [[ $ID == ue[[:digit:]]* ]] ; then
            echo "Clean netns $ID"
            ip netns del $ID
        fi
    done
    ;;
esac

