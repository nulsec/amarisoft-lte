#!/bin/bash
# Copyright (C) 2015-2024 Amarisoft
# Install script version 2024-12-23


function Help
{
    HelpTRX
}

function HelpTRX
{
    local MSG="$1"
    if [ "$MSG" != "" ] ; then
        echo "$MSG"
    fi

    echo "Usage:"
    local types=$(cd $DIR && ls | grep "config" | cut -d "." -f2 | xargs echo | tr ' ' '|')
    echo "> $0 [--no-upgrade] <path> $types [<frontend name>]"
    exit 1
}

UPGRADE="y"
DIR=$(cd $(dirname $0) && pwd)

while [ "$1" != "" ] ; do
    case "$1" in
    --no-upgrade)
        UPGRADE="n"
        ;;
    --force-upgrade)
        UPGRADE="f"
        ;;
    --dma32)
        if [ "$DMA32" = "" ] ; then
            Help "Unknown argument: $1"
        fi
        DMA32="y"
        ;;
    --no-package)
        LINUX_PACKAGE=""
        ;;
    *)
        if [ "$DST" = "" ] ; then
            DST=$(cd $1 && pwd)
            if [ ! -d "$DST" ] ; then
                Help "Directory '$DST' not found"
            fi
        else
            if [ "$TYPE" = "" ] ; then
                TYPE="$1"
            else
                if [ "$FE" = "" ] ; then
                    FE="$1"
                else
                    Help "Unknown argument: $1"
                fi
            fi
        fi
        ;;
    esac
    shift
done

if [ "$DST" = "" -o "$TYPE" = "" ] ; then
    Help
fi

if [ ! -d "${DIR}/config.${TYPE}/" ] ; then
    Help "No configuration files for $TYPE"
fi

function Install
{
    local ID="$1"
    shift

    rm -Rf ${DST}/config/${ID}
    cp -r ${DIR}/config.${TYPE}/ ${DST}/config/${ID}
    ${DST}/config/rf_select.sh ${ID} 1>/dev/null

    for i in $@; do
        rm -f ${DST}/$i
        ln -s ${DIR}/$i ${DST}
    done
}


# Delete default files and copy configs
Install "s72" "trx_s72.so"

exit 0

