/*
 * C utilities version 2024-12-23
 *
 * Copyright (C) 2012-2024 Amarisoft
 * Author: Fabrice Bellard
 */
#ifndef _CUTILS_H
#define _CUTILS_H

#include <time.h>

#ifndef _BOOL_defined
#define _BOOL_defined
#undef FALSE
#undef TRUE

typedef int BOOL;
enum {
    FALSE = 0,
    TRUE = 1,
};

typedef uint8_t BOOL8;
#endif

static inline int min_int(int a, int b)
{
    if (a < b)
        return a;
    else
        return b;
}

static inline int max_int(int a, int b)
{
    if (a > b)
        return a;
    else
        return b;
}

#define likely(x)       __builtin_expect(!!(x), 1)
#define unlikely(x)     __builtin_expect(!!(x), 0)
#define no_inline __attribute__((noinline))

#endif /* _CUTILS_H */
