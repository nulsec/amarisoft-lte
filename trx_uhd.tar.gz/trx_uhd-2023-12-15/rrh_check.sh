#!/bin/bash
# Copyright (C) 2012-2023 Amarisoft
# Ettus USRP presence checker 2023-12-15

TYPE="##TYPE##"

set -e

if [ "$TYPE" = "b2x0" ] ; then
    uhd_usrp_probe
    exit 0
fi

while [ "$1" != "" ] ; do
    case "$1" in
    --ots)
        ;;
    --cfg)
        shift
        ADDRS=$(./json_util dump $1 rf_driver args | grep -oP "\d+\.\d+\.\d+\.\d+")
        for i in $ADDRS ; do
            uhd_usrp_probe --args=addr=$i
        done
        ;;
    --temp)
        shift
        ;;
    *)
        echo "Unknwon argument: $1" >&2
        exit 2
        ;;
    esac
    shift
done

exit 0

