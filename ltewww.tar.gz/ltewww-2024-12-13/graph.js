/*
 * Copyright (C) 2017-2024 Amarisoft
 *
 * Amarisoft Web interface 2024-12-13
 */


var Graph = function (config)
{
    if (!config)
        config = {};

    if (config.debug)
        this.debug = true;

    this._graphs        = [];
    this._series        = {};
    this._seriesList    = [];
    this._margin        = this._oMerge({
        top: 5,
        bottom: 70,
        left: 70,
        right: 5
    }, config.margin);
    this._columns = config.columns || 1;
    this._orthonormal = config.orthonormal;
    this._overMode = config.overMode || 'point';

    // Axis
    var axisCfg = this._oMerge({x: {}, y: {}}, config.axis);
    this._axis = {};
    this._axisY = [];
    for (var i in axisCfg) {
        var a = this._axis[i] = {_default: axisCfg[i]};
        a.name = i;
        if (i !== 'x')
            this._axisY.push(a);
    }

    this.reset();

    for (var i in this._axis)
        this._updateAxis(this._axis[i], 100);

    for (var id in config.series)
        this.addSerie(id, config.series[id]);

    this.title = config.title;
    this.onOver = config.onOver;
    this.onClick = config.onClick;
}

Graph.prototype.fontDef = "10px helvetica, arial, verdana, sans-serif",

Graph.prototype._oMerge = function (a, b)
{
    for (var i in b) {
        var p = b[i];
        if (typeof p === 'object' && p !== null) {
            if (typeof a[i] !== 'object' && a[i] !== null)
                a[i] = p instanceof Array ? [] : {};
            this._oMerge(a[i], p);
        } else {
            a[i] = p;
        }
    }
    return a;
}

Graph.prototype._getValue = function (value, def, exec)
{
    switch (typeof value) {
    case 'number':
        return value;
    case 'function':
        if (!exec)
            return value;
        return this._getValue(value(), def);
    case 'undefined':
        break;
    default:
    case 'string':
        return value;
    }

    return def;
}

Graph.prototype._resetAxis = function (a)
{
    var cfg = a._default;
    var a0 = {
        min:            0,
        max:            0,
        maxSize:        Number.POSITIVE_INFINITY,
        stepFrac:       10,
        stepMin:        50,
        auto:           'fit',
        grad:           true,
        unit:           '',
        name:           a.name,
        index:          0,
        noUnit:         false,
        unitPrecision:  3,
        hidden:         false,
        enabled:        true,
        title:          '',
        format:         ''
    };

    for (var j in a0) {
        a[j] = this._getValue(cfg[j], a0[j], j !== 'unit');
    }
    a.from  = a.min,
    a.to    = a.max,
    a.count = 0;

    if (a.name === 'x') a.x = true; // Identify x axis

    if (a.stepFrac < 1) {
        console.warn('Bad stepFrac:', a.stepFrac, this);
        a.stepFrac = 1;
    }
}

Graph.prototype._axisSeriesUpdate = function ()
{
    for (var i in this._axis) {
        var a = this._axis[i];
        a.n_series = 0;
        a.n_histo = 0;
    }

    for (var i in this._series) {
        var s = this._series[i];
        if (s.enabled) {
            s.y.forEach(function (a) { a.n_series++; });
            if (s.drawStyle[0] === 'histogram') s.x.n_histo++; // XXX
        }
    }
};

Graph.prototype.reset = function ()
{
    this._zoomed = false;

    for (var i in this._series) {
        var s = this._series[i];
        s.values = [];
    }

    var axis = this._axis;
    this._unit2axis = {};
    for (var i in axis) {
        var a = axis[i];
        this._resetAxis(a);
        if (!this._unit2axis[a.unit]) this._unit2axis[a.unit] = [a];
        else this._unit2axis[a.unit].push(a);
    }
    this._axisSeriesUpdate();
};

Graph.prototype.flushSeries = function ()
{
    this._series = {};
    this._seriesList = [];
    this._defaultColorIndex = 0;
}

Graph.prototype._addToAxis = function (a, v) {

    switch (a.auto) {
    case 'fit':
    case 'histogram':
        if (!a.count++) {
            a.min = a.from = Math.min(
                a._default.hasOwnProperty('min') ? a.min : Number.POSITIVE_INFINITY,
                a._default.hasOwnProperty('from') ? a.from : Number.POSITIVE_INFINITY,
                v);
            a.max = a.to = Math.max(
                a._default.hasOwnProperty('max') ? a.max : Number.NEGATIVE_INFINITY,
                a._default.hasOwnProperty('to') ? a.to : Number.NEGATIVE_INFINITY,
                v);
        } else {
            a.min = a.from = Math.min(v, a.min);
            a.max = a.to   = Math.max(v, a.max);
        }
        break;

    case 'max':
        if (a.to === a.max && v > a.to) {
            a.from += v - a.to;
            a.to = a.max = v;
            if (a.x) a.reset = true;
        }
        break;

    case 'min':
        if (a.from === a.min && v < a.from) {
            a.to += v - a.from;
            a.from = a.min = v;
            if (a.x) a.reset = true;
        }
        break;

    case 'zeroCentered':
        if (a.from === a.min && -Math.abs(v) < a.from) {
            a.from = a.min = -Math.abs(v);
        }
        if (a.to === a.max && Math.abs(v) > a.to) {
            a.to = a.max = Math.abs(v);
        }
        break;
    }
};

Graph.prototype._updateAxis = function (a, size)
{
    switch (a.auto) {
    case 'fit':
    case 'histogram':
        break;
    case 'max':
        var diff = a.to - a.max;
        if (diff > 0) {
            a.from += diff;
            a.max = a.to;
        }
        a.from = Math.max(a.from, a.min);
        break;
    case 'min':
        // XXX
        break;
    default:
        var len = Math.min(a.to - a.from, a.max - a.min);
        var diff = a.min - a.from;
        if (diff > 0) {
            a.from += diff;
        } else {
            diff = a.to - a.max;
            if (diff > 0)
                a.from -= diff;
        }
        a.to = a.from + len;
        break;
    }

    // Window size
    var len = a.to - a.from;
    if (!len)
        len = a.to || 1;

    // Compute step
    switch (a.auto) {
    case 'histogram':
        var from = a.from - 0.5;
        var to = a.to + 0.5;
        var step = 1;
        break;
    case 'fix':
        var from = a.from;
        var to = a.to;
        var step = len / a.stepFrac;
        break;
    default:
        var step = Math.pow(10, Math.floor(Math.log(len) / Math.log(10))) / a.stepFrac;
        var from = Math.floor(a.from / step) * step;
        var to   = Math.ceil(a.to / step) * step;
        break;
    }

    if (to === from) {
        from -= step;
        to += step;
    }
    a.dispSize = to - from;

    var scale = size / (to - from);

    return {
        scale:    scale, // From unit to pixels

        // In pixels
        step:    Math.ceil(a.stepMin / scale / step) * step,

        // In axis unit
        from:    from,
        to:        to,
    };
};

Graph.prototype.addValues = function (id, values, replace)
{
    var s = this._series[id];
    if (s) {
        if (replace)
            s.values = [];
        this._addValues(s, values);
        return true;
    }
    return false;
}

Graph.prototype._addToAxisY = function (axis, ax, value)
{
    var v = value[axis.name];
    if (v === undefined) return;

    if (axis.auto === 'fit') {
        if (value.x < ax.from || value.x > ax.to) return;
    }

    this._addToAxis(axis, v);
}

Graph.prototype._addValues = function (s, values)
{
    if (!values) return;

    // Shortcuts
    var ax = s.x;
    var ay = s.y;
    var sValues = s.values;

    for (var i = 0; i < values.length; i++) {
        var value = values[i];

        // XXX: check sort
        sValues.push(value);

        this._addToAxis(ax, value.x);
        for (var y = 0; y < ay.length; y++) {
            this._addToAxisY(ay[y], ax, value);
        }
    }

    if (ax.maxSize < Number.POSITIVE_INFINITY) {
        var min = ax.max - ax.maxSize;

        if (min > ax.min) {
            for (var id in this._series) {
                var serie = this._series[id];
                for (var i = 0; i < serie.values.length; i++) {
                    if (serie.values[i].x >= min)
                        break;
                }

                var toDel = serie.values.splice(0, i);
                for (var i = 0; i < toDel.length; i++) {
                }
            }
            ax.min = min;
        }
    }
};

Graph.prototype._unit1000 = function (v, u0, u1, u2)
{
    if (u2 && v > 1e6) return {value: v / 1e6, unit: u2};
    if (v > 1e3) return {value: v / 1e3, unit: u1};
    return {value: v, unit: u0};
}

Graph.prototype._axisFormatValue = function (v, unit)
{
    var res;

    switch (unit) {
    case 'time':
        v = Math.round(v);
        res = {
            value: lteLogs.ts2time(v).replace(/\.000$/, ''),
            unit: ''
        };
        break;

    case 'day':
        v = new Date(v);
        res = {
            value: [v.getYear() + 1900,
                    ('0' + (v.getMonth() + 1)).slice(-2),
                    ('0' + v.getDate()).slice(-2)
                ].join('-'),
            unit: '',
        };
        break;

    case 'date':
        v = new Date(v);
        res = {
            value: ("0" + v.getHours()).slice(-2) + ":" +
                ("0" + v.getMinutes()).slice(-2) + ":" +
                ("0" + v.getSeconds()).slice(-2) + "." +
                ("00" + v.getMilliseconds()).slice(-3),
            unit: '',
        };
        break;

    case 'duration':
        res = this._unit1000(v, 'ms', 's');
        break;

    case 'Brate':
        res = this._unit1000(v * 8, 'bps', 'Kbps', 'Mbps');
        break;

    case 'brate':
        res = this._unit1000(v, 'bps', 'Kbps', 'Mbps');
        break;

    case 'bsize':
        res = this._unit1000(v / 8, 'B', 'KB', 'MB');
        break;

    case 'Bsize':
        res = this._unit1000(v, 'B', 'KB', 'MB');
        break;

    case 'sr':
        res = {value: v, unit: 'MS/s'};
        break;

    case '%':
        res = {value: v * 100, unit: '%' };
        break;

    case '100%':
        res = {value: v, unit: '%' };
        break;

    default:
        if (typeof unit === 'function') {
            res = unit(v);
            if (typeof res !== 'object') {
                res = {value: res, unit: ''};
            }
        } else {
            res = {value: v, unit: unit};
        }
        break;
    }

    return res;
}

Graph.prototype._getHighDigitPow10 = function (v)
{
    v = Math.abs(v);
    if (v >= 1)
        return Math.floor(Math.log10(v));

    return -Math.ceil(-Math.log10(v));
}

Graph.prototype._axisFormat1 = function (v, axis, unit, showUnit, unitPrecision, delta)
{
    var res = this._axisFormatValue(v, unit);

    if (res.value instanceof Array) {
        return res.value.map((function (v1) {
            if (typeof v1 !== 'number') return v1;
            return this._axisFormat1(v1, axis, res.unit, showUnit, unitPrecision, delta);
        }).bind(this)).join(' ');
    }

    if (typeof res.value === 'number' && axis.dispSize > 0) {
        if (axis.auto === 'histogram')
            return Math.floor(v);

        if (res.value === 0) {
            res.value = '0';
        } else {
            var p10 = this._getHighDigitPow10(res.value);
            if (p10 >= 0) {
                res.value = res.value.toFixed(-Math.min(p10 + 1 - unitPrecision, 0));
            } else {
                if (delta !== undefined) {
                    p10d = this._getHighDigitPow10(delta);
                    p10 = Math.max(p10d, p10);
                }
                p10 = -p10 + unitPrecision - 1;
                if (p10 > 0) {
                    var n = Math.pow(10, p10);
                    res.value = (Math.round(res.value * n) / n).toString();
                } else {
                    res.value = '0';
                }
            }
        }
    }

    return showUnit ? res.value + '' + res.unit : res.value;
}

Graph.prototype._axisFormat = function (v, axis)
{
    return this._axisFormat1(v, axis, axis.unit, true, axis.unitPrecision);
}

Graph.prototype._axisRender = function (ctx, axis, v, max)
{
    if (axis.hidden)
        return;

    var value = this._axisFormat1(v, axis, axis.unit, !axis.noUnit, Math.floor(Math.log10(axis.stepFrac) + 1), axis.to - axis.from);

    if (max && max < ctx.measureText(value).width) {
        ctx.rotate(Math.PI / 4);
        ctx.textBaseline    = 'top';
        ctx.textAlign        = 'left';
        ctx.fillText(value, 0, 0);
    } else {
        ctx.fillText(value, 0, 0);
    }
}

Graph.prototype._defaultColorIndex = 0;
Graph.prototype._defaultColor = [
"#000000", "#1CE6FF", "#FF34FF", "#FF4A46", "#008941", "#006FA6", "#A30059",
"#FFDBE5", "#7A4900", "#0000A6", "#63FFAC", "#B79762", "#004D43", "#8FB0FF", "#997D87",
"#5A0007", "#809693", "#FEFFE6", "#1B4400", "#4FC601", "#3B5DFF", "#4A3B53", "#FF2F80",
"#61615A", "#BA0900", "#6B7900", "#00C2A0", "#FFAA92", "#FF90C9", "#B903AA", "#D16100",
"#DDEFFF", "#000035", "#7B4F4B", "#A1C299", "#300018", "#0AA6D8", "#013349", "#00846F",
"#372101", "#FFB500", "#C2FFED", "#A079BF", "#CC0744", "#C0B9B2", "#C2FF99", "#001E09",
"#00489C", "#6F0062", "#0CBD66", "#EEC3FF", "#456D75", "#B77B68", "#7A87A1", "#788D66",
"#885578", "#FAD09F", "#FF8A9A", "#D157A0", "#BEC459", "#456648", "#0086ED", "#886F4C",
"#34362D", "#B4A8BD", "#00A6AA", "#452C2C", "#636375", "#A3C8C9", "#FF913F", "#938A81",
"#575329", "#00FECF", "#B05B6F", "#8CD0FF", "#3B9700", "#04F757", "#C8A1A1", "#1E6E00",
"#7900D7", "#A77500", "#6367A9", "#A05837", "#6B002C", "#772600", "#D790FF", "#9B9700",
"#549E79", "#FFF69F", "#201625", "#72418F", "#BC23FF", "#99ADC0", "#3A2465", "#922329",
"#5B4534", "#FDE8DC", "#404E55", "#0089A3", "#CB7E98", "#A4E804", "#324E72", "#6A3A4C",
];

Graph.prototype.addSerie = function (id, config)
{
    var values = config.values;

    var s = this._series[id];
    if (!s) {
        s = this._oMerge({
            id: id,
            enabled: true,
            size: 2,
            x: 'x',
            y: ['y'],
            drawStyle: 'lines',
            crossSize: 2,
            autoScale: false,
        }, config);

        if (!s.color) {
            for (;;) {
                s.color = this._defaultColor[this._defaultColorIndex++];
                if (!s.colorMaxBrightness || lteLogs.getColLight(s.color) <= s.colorMaxBrightness)
                    break;
            }
        }

        // X axis
        s.x = this._axis[s.x];
        if (!s.x) return false;

        for (var i in s.y) {
            s.y[i] = this._axis[s.y[i]];
            if (!s.y[i])
                return false;
        }

        if (!(s.drawStyle instanceof Array))
            s.drawStyle = s.y.map(function (a) { return s.drawStyle; });

        this._series[id] = s;
        this._seriesList.push(s);

        this._axisSeriesUpdate();

        s.values = [];
        this._addValues(s, values);

        return true;
    }

    this._addValues(s, config.values);
    return false;
};

Graph.prototype.getSerieColor = function(id)
{
    return this._series[id].color;
}

Graph.prototype.getSerieTitle = function(id)
{
    return this._series[id].title;
}

Graph.prototype.getLastValue = function(id)
{
    var s = this._series[id];
    if (s && s.values.length) {
        var v = s.values[s.values.length - 1];
        return this._axisFormat(v[s.y[0].name], s.y[0]);
    }
    return "";
}

Graph.prototype.setSerie = function (id, enabled)
{
    var s = this._series[id];
    if (s && s.enabled !== enabled) {
        s.enabled = enabled;
        if (s.autoScale)
            this.rebuildAxis(true);
        return true;
    }
    return false;
};

Graph.prototype.isEnabled = function (id)
{
    var s = this._series[id];
    return s ? s.enabled : false;
}

Graph.prototype.enableAxis = function (id, enabled)
{
    var a = this._axis[id];
    if (a && a.enabled !== enabled) {
        a.enabled = enabled;
        this.draw();
    }
}

Graph.prototype._setWindow = function (a, from, len)
{
    if (!len) len = a.to - a.from;
    else      len = Math.min(len, a.max - a.min);

    if (from < a.min) {
        from = a.min;
    } else {
        var to = from + len;
        if (to > a.max)
            from = a.max - len;
    }
    var to = from + len;
    if (a.from !== from || a.to !== to) {
        a.from = from;
        a.to   = to;
        if (a.x) a.reset = true;
    }
};

Graph.prototype.setWindow = function (id, from, to)
{
    var a = this._axis[id];
    if (a && from < to) {
        a.from = from;
        a.to = to;
        if (a.min > from) a.min = from;
        if (a.max < to) a.max = to;
    }
    this._orthonormal = false;
    return false;
}

Graph.prototype.getValues = function (id)
{
    return this._series[id].values.slice();
}

Graph.prototype._bgColor = '#f0f0f0';
Graph.prototype._gridColor = '#ffffff';


Graph.prototype.exportSerie = function (id)
{
    var s = this._series[id];
    if (!s) return null;

    var y = s.y[0].name;

    return {
        name: s.title,
        x: this._axis.x.unit.replace(/^\s+/, ''),
        y: this._axis[y].unit.replace(/^\s+/, ''),
        values: s.values.map( (v) => {
            return {
                x: v.x,
                y: v[y]
            };
        })
    };
};

Graph.prototype.adjustAxis = function ()
{
    for (var u in this._unit2axis) {
        var list = this._unit2axis[u];
        if (list.length < 2) continue;

        var min = list[0].min;
        var max = list[0].max;

        for (var i = 1; i < list.length; i++) {
            min = Math.min(min, list[i].min);
            max = Math.max(max, list[i].max);
        }

        for (var i = 0; i < list.length; i++) {
            list[i].min = list[i].from = min;
            list[i].max = list[i].to = max;
        }
    }
};

Graph.prototype._unitText = {
    time: 's',
    Bsize: 'byte',
    Brate: 'byte/s'
};

Graph.prototype._unitName = {
    time: 'Time',
    Bsize: 'Data',
    Brate: 'Datarate'
};

Graph.prototype.getAxis = function ()
{
    return Object.keys(this._axis).map( (id) => {
        var a = this._axis[id];
        var name = a.title || this._unitName[a.unit] || a.name || id;
        var unit = this._unitText[a.unit] || a.unit;

        return {
            id: id,
            name: name,
            min: a.min,
            max: a.max,
            from: a.from,
            to: a.to,
            unit: unit,
        };
    });
}

/************
 *** Draw ***
 ************/
Graph.prototype.invalidate = function ()
{
    this._lastDrawRect = null;
};

Graph.prototype.draw = function (canvas, rect)
{
    if (canvas || rect) {
        this.drawFrame(canvas, rect);
    } else if (!this.drawPending) {
        this.drawPending = true;
        window.requestAnimationFrame(this.drawFrame.bind(this, null, null));
    }
}

Graph.prototype.rebuildAxis = function (rebuildX)
{
    this._axis.x.reset = false;

    for (var i in this._axisY) {
        this._resetAxis(this._axisY[i]);
    }
    if (rebuildX)
        this._resetAxis(this._axis.x);

    // Update values
    for (var j in this._series) {
        var s = this._series[j];
        if (!s.enabled) continue;

        var ax = s.x;
        var ay = s.y;
        var sValues = s.values;
        for (var i = 0; i < sValues.length; i++) {
            var value = sValues[i];
            for (var y = 0; y < ay.length; y++) {
                this._addToAxisY(ay[y], ax, value);
            }
        }
    }
};

Graph.prototype.drawFrame = function (canvas, rect)
{
    this.drawPending = false;

    // Redraw ?
    if (!canvas)
        canvas = this._canvas;

    if (!canvas)
        return false;

    if (!this._zoomed) {
        if (this._axis.x.reset)
            this.rebuildAxis();

        if (this._orthonormal)
            this.adjustAxis();
    }

    this._lastDrawRect = rect = (rect || this._lastDrawRect || {x: 0, y: 0, w: canvas.width, h: canvas.height});

    var t0 = new Date();

    this._canvas = canvas;

    var row = 0;
    var col = 0;
    var cMax = this._columns;

    Graph.last = this; // dbg

    // Get list of graph with associated series
    var graphs = [];
    var bottomGraph = [];
    for (var id in this._series) {
        var s = this._series[id];
        if (!s.enabled) continue;

        s.y.forEach(function (axis) {
            var index = axis.index;
            var g = graphs[index];

            if (!axis.enabled) return;

            if (!g) {
                if (col === cMax) {
                    col = 0;
                    row++;
                }
                g = graphs[index] = {ay: axis, col: col, row: row, az: []};
                bottomGraph[col] = g;
                col++;

            } else if (g.ay !== axis) {
                if (g.az.indexOf(axis) < 0) {
                    g.az.push(axis);
                }
            }
        });
    }

    var ctx = canvas.getContext("2d");
    ctx.save();
    var clip = rect.clip;
    if (clip) {
        ctx.beginPath();
        ctx.rect(clip.x, clip.y, clip.w, clip.h);
        ctx.clip();
    }

    ctx.fillStyle = this._bgColor;
    ctx.fillRect(rect.x, rect.y, rect.w, rect.h);

    // Remove empty graphs
    graphs = this._graphs = graphs.filter(function (g) { return g; });

    // Draw each graph
    var margin = this._margin;
    var bottom = margin.bottom;
    var top    = margin.top;

    var w = (rect.w / (bottomGraph.length)) >>> 0;
    var h = ((rect.h - bottom + top) / (row + 1)) >>> 0;

    for (i = 0; i < graphs.length; i++) {
        var graph = graphs[i];

        graph.x = graph.col * w + rect.x;
        graph.y = graph.row * h + rect.y;
        graph.w = w;
        graph.h = h + bottom - top;
        graph.h0 = h;

        if (graph !== bottomGraph[graph.col]) {
            graph.noGradX = true;
        }

        this._drawGraph(canvas, graph);

        for (var j = 0; j < graph.az.length; j++) {
            this._drawGraph(canvas, {
                x: graph.x,
                y: graph.y,
                w: graph.w,
                h: graph.h,
                ay: graph.az[j],
            }, true);
        }
    }

    ctx.restore();

    t0 = new Date() - t0;
    if (t0 > 500)
        console.log("Render", this.title, t0);
    return true;
}

Graph.prototype._drawGraph = function (canvas, graph, secondary)
{
    // Axis
    var ax = this._axis.x;
    var ay = graph.ay;
    if (!ay.n_series) {
        console.error("No serie for graph !", ay.name);
        return;
    }
    var y_name = ay.name;

    // Graph rectangle
    var margin = this._margin;
    var width = graph.w - margin.left - margin.right;
    var height = graph.h - margin.top - margin.bottom;

    if (this._orthonormal) {
        var size = Math.min(width, height);
        graph.X = margin.left + (width - size) >> 1;
        graph.Y = margin.top + (height - size) >> 1;
        graph.W = size;
        graph.H = size;
        width = height = size;
    } else {
        graph.X = margin.left;
        graph.Y = margin.top;
        graph.W = width;
        graph.H = height;
    }

    // Update all axis
    var graphX = this._updateAxis(ax, width);
    var graphY = this._updateAxis(ay, height - 2);

    // Coordinates
    var x0    = graph.fromX  = graphX.from;
    var x1    = graph.toX    = graphX.to;
    var sW    = graph.scaleX = graphX.scale;
    var stepX = graphX.step;
    var xr    = ax.renderer;

    var y0    = graph.fromY  = graphY.from;
    var y1    = graph.toY    = graphY.to;
    var sH    = graph.scaleY = graphY.scale;
    var stepY = graphY.step;
    var yr    = ay.renderer;

    var setX = function (x) { return (x - x0) * sW; };
    var setY = function (y) { return height - 1 - (y - y0) * sH; };
    var v2y  = function (v) { return (v - y0) * sH + 1; };

    var ctx = canvas.getContext("2d");

    // Clear and place
    ctx.save();
    if (Ext.isChrome && Ext.chromeVersion === 83) {
        canvas.style['image-rendering'] = 'pixelated';
    }
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.rect(graph.x, graph.y, graph.w, graph.h);
    ctx.clip();

    ctx.translate(graph.x + graph.X + 0.5, graph.y + graph.Y + 0.5);
    ctx.font = this.fontDef;

    if (!secondary) {
        // Title
        if (ay.title) {
            ctx.save();
            ctx.fillStyle = 'black';
            ctx.textBaseline    = 'middle';
            ctx.textAlign        = 'center';
            ctx.fillText(ay.title, graph.W >> 1, -(graph.Y >> 1));
            ctx.restore();
        }

        // Grid
        ctx.fillStyle    = 'black';
        ctx.textBaseline = 'top';
        ctx.textAlign    = 'center';
        ctx.strokeStyle  = this._gridColor;
        if (stepX > 0) {
            for (var x = Math.ceil(x0 / stepX) * stepX; x <= x1; x += stepX) {
                var myX = Math.round(setX(x));
                ctx.beginPath();
                ctx.moveTo(myX, 0);
                ctx.lineTo(myX, height);
                ctx.stroke();
                if (ax.grad && !graph.noGradX) {
                    ctx.save();
                    ctx.translate(myX, height + 5);
                    this._axisRender(ctx, ax, x, stepX * sW * 0.9);
                    ctx.restore();
                }
            }
        }
        if (stepY > 0) {
            ctx.textBaseline    = 'middle';
            ctx.textAlign        = 'right';
            ctx.strokeStyle        = this._gridColor;
            for (var y = Math.ceil(y0 / stepY) * stepY; y <= y1; y += stepY) {
                var myY = Math.round(setY(y));
                ctx.beginPath();
                ctx.moveTo(0, myY);
                ctx.lineTo(width, myY);
                ctx.stroke();
                if (ay.grad) {
                    ctx.save();
                    ctx.translate(-5, myY);
                    this._axisRender(ctx, ay, y);
                    ctx.restore();
                }
            }
        }
    }

    // Frame
    ctx.beginPath();
    ctx.strokeStyle = 'black';
    ctx.rect(0, 0, width, height);
    ctx.stroke();
    ctx.clip();

    // Highlight
    var hlSerie = null;
    if (this._highlightedRef && this._highlightedRef.axis === ay) {
        switch (this._overMode) {
        case 'point':
            var hlValue = this._highlightedRef.value;
            break;
        }
    }

    // Series
    var n_histo = 0;
    for (var s = 0, length = this._seriesList.length; s < length; s++) {
        var serie  = this._seriesList[s];

        var aIdx = serie.y.indexOf(ay);
        if (aIdx < 0) continue; // Not for me

        var values = serie.values;
        if (!serie.enabled) continue;
        if (!values.length) continue;

        ctx.save();
        var drawStyle = serie.drawStyle[aIdx];
        switch (drawStyle) {
        case 'points':
            for (var i = 0; i < values.length; i++) {
                var value = values[i];
                var x = value.x;
                ctx.fillStyle = serie.color;
                ctx.fillRect(setX(x), height - v2y(value[y_name]), 2, 2);
            }
            break;

        case 'cross':
            ctx.strokeStyle = serie.color;
            var cs = serie.crossSize || 2;
            for (var i = 0; i < values.length; i++) {
                var value = values[i];
                var x = setX(value.x);
                var y = setY(value[y_name]);
                ctx.beginPath();
                ctx.moveTo(x - cs, y);
                ctx.lineTo(x + cs, y);
                ctx.stroke();
                ctx.moveTo(x, y - cs);
                ctx.lineTo(x, y + cs);
                ctx.stroke();
            }
            break;

        case 'histogram':
            ctx.fillStyle = serie.color;
            ctx.strokeStyle = 'black';

            // Draw lines
            var dx = []
            var x = next_x = null;
            var y, next_y;
            for (var i = 0; i <= values.length; i++) {
                if (i < values.length) {
                    var value = values[i];
                    x = next_x;
                    next_x = setX(value.x);
                    y = next_y;
                    var v = value[y_name];
                    next_y = v !== null ? v2y(v) : null;

                    if (x === null) continue;

                    // if (ax.auto === 'histogram') dx.push(0.5);
                    dx.push((next_x - x) / 2);
                } else {
                    x = next_x;
                    y = next_y;
                }

                if (dx.length == 1) {
                    dx.push(dx[0]);
                }

                // Draw
                if (y !== null) {
                    var w = (dx[0] + dx[1]) / ax.n_histo;
                    var X = Math.round(x - dx[0]) + n_histo * w;
                    var W = Math.round(w);
                    ctx.beginPath();
                    ctx.rect(X, Math.round(height - y), W, Math.round(y));
                    ctx.fill();
                    ctx.stroke();
                }

                dx.shift();
            }
            n_histo++;
            break;

        case 'lines_wrap':
        default:
            ctx.beginPath();
            ctx.lineWidth   = serie.size;
            ctx.strokeStyle = serie.color;
            var firstValue  = null;
            var lines_wrap  = (drawStyle === 'lines_wrap');

            // Move to first value
            for (var i = 0; i < values.length; i++) {
                var value = values[i];
                var x = value.x;

                if (x >= x0)
                    break;
                firstValue = value;
            }
            if (!firstValue) {
                firstValue = values[0];
            }

            /* Use axis */
            var last_x2 = setX(firstValue.x);
            var last_y2 = height - v2y(firstValue[y_name]);
            ctx.moveTo(last_x2, last_y2);

            if (hlValue === firstValue)
                hlSerie = serie;

            // Draw lines
            for (;i < values.length; i++) {
                var value = values[i];
                var x = value.x;
                var x2 = setX(x);
                var y2 = height - v2y(value[y_name]);
                
                if (lines_wrap && Math.abs(y2 - last_y2) > height * 0.5) {
                    /* for phase display : draw the shortest line
                       assuming continuity between height - 1 and
                       0. We assuming clipping is done to hide the
                       extra segments. */
                    if (y2 < last_y2) {
                        ctx.lineTo(x2, y2 + height);
                        ctx.moveTo(last_x2, last_y2 - height);
                    } else {
                        ctx.lineTo(x2, y2 - height);
                        ctx.moveTo(last_x2, last_y2 + height);
                    }
                }
                ctx.lineTo(x2, y2);
                
                if (hlValue === value)
                    hlSerie = serie;

                if (x > x1)
                    break;

                last_y2 = y2;
                last_x2 = x2;
            }
            ctx.stroke();
            break;
        }
        ctx.restore();
    }

    var move = this._move;
    if (move && move.ctrl && move.pos) {
        ctx.save();
        ctx.beginPath();
        var y0 = 0;
        var y1 = height;
        if (move.shift) {
            y0 = Math.min(move.pos.y, move.y);
            y1 = Math.max(move.pos.y, move.y);
        }
        ctx.rect(move.x, y0, move.pos.x - move.x, y1 - y0);
        ctx.strokeStyle = 'green';
        ctx.fillStyle = 'rgba(0, 255, 0, 0.25)';
        ctx.fill();
        ctx.stroke();
        ctx.restore();
    }

    if (this._highlightedRef && this._highlightedRef.axis === ay) {
        switch (this._overMode) {
        case 'point':
            break;
        case 'time':
            var x = setX(this._highlightedRef.value);
            ctx.save();
            ctx.beginPath();
            ctx.moveTo(x, 0);
            ctx.lineTo(x, height);
            ctx.strokeStyle = '#a0a0a0';
            ctx.stroke();
            ctx.restore();
            break;
        }
    }

    if (hlSerie) {
        ctx.beginPath();
        ctx.arc(setX(hlValue.x), height - v2y(hlValue[y_name]), 3, 0, 2 * Math.PI, false);
        ctx.fillStyle = hlSerie.color;
        ctx.fill();
        ctx.lineWidth = 1;
        ctx.strokeStyle = '#000000';
        ctx.stroke();
    }

    ctx.restore();
};

Graph.prototype._eventToPosition = function (event)
{
    if (!this._canvas) return null;

    var rect = this._canvas.getBoundingClientRect();

    var x = event.clientX - rect.left;
    var y = event.clientY - rect.top;
    for (var i = 0; i < this._graphs.length; i++) {
        var graph = this._graphs[i];

        if (x < graph.x || x >= graph.x + graph.w ||
            y < graph.y || y >= graph.y + graph.h0)
            continue;

        var ax = this._axis.x;
        var ay = graph.ay;

        x -= graph.X + graph.x;
        y -= graph.Y + graph.y;

        var pos = {
            x: x,
            y: y,
            in: x >= 0 && x <= graph.W && y >= 0 && y <= graph.H,
            x0: ax.from,
            y0: ay.from,
            graph: graph,
            ctrl: event.ctrlKey,
            shift: event.shiftKey,
        };

        return pos;
    }
    return null;
}

Graph.prototype._zoomUpdate = function ()
{
    this._zoomed = false;
    for (var i in this._axis) {
        var a = this._axis[i];
        if (a.auto === 'max' || a.auto === 'min') continue;
        if (a.from !== a.min || a.to !== a.max) {
            this._zoomed = true;
            break;
        }
    }
};

// Wheel: zoom in/out
Graph.prototype.mouseWheelEvent = function (event)
{
    var move = this._eventToPosition(event);
    if (move && move.in) {
        var graph = move.graph;

        var f = 1.5;
        if (lteLogs.getMouseWheelDelta(event) > 0) f = 1 / f;

        var x = (graph.fromX + graph.toX) / 2;
        var w = (graph.toX - graph.fromX) * f;
        var y = (graph.fromY + graph.toY) / 2;
        var h = (graph.toY - graph.fromY) * f;

        var ax = this._axis.x;
        this._setWindow(ax, x - w / 2, w);
        this._axisY.forEach( (ay) => {
            this._setWindow(ay, y - h / 2, h);
        });

        this._zoomUpdate();
        this.draw();
        return true;
    }
};

// Down
Graph.prototype.mouseDownEvent = function (event)
{
    var move = this._eventToPosition(event);
    if (move && move.in)
        this._move = move;
};

Graph.prototype.setCursor = function (c)
{
    if (this._canvas)
        this._canvas.style.cursor = c || '';
}

// Move
Graph.prototype.mouseMoveEvent = function (event)
{
    var ret = false;
    var pos = this._eventToPosition(event);

    // Scroll into window
    var move = this._move;
    if (move) {
        var graph = move.graph;
        move.pos = pos;

        if (move.ctrl) {
            this.setCursor(move.shift ? 'crosshair' : 'pointer');
            if (!pos) {
                var rect = this._canvas.getBoundingClientRect();
                move.pos = {
                    x: event.clientX - rect.left - (graph.X + graph.x),
                    y: event.clientY - rect.top - (graph.Y + graph.y),
                };
            }

            this.draw();
            ret = true;

        } else if (pos) {
            this.setCursor('move');
            var ax = this._axis.x;
            this._setWindow(ax, move.x0 + (move.x - pos.x) / graph.scaleX, 0);
            this._axisY.forEach( (ay) => {
                this._setWindow(ay, move.y0 - (move.y - pos.y) / graph.scaleY, 0);
            });
            this.draw();
            return true;
        }
    }

    // Highlight ?
    if (pos && this.onOver) {
        var graph = pos.graph;
        ret = this.mouseMoveOnOver(pos, graph, event);
        if (!ret) {
            this.onOver(null);
            this.highlight(null);
        }
    }
    return ret;
}

Graph.prototype.menuContext = function (event)
{
}

Graph.prototype.mouseMoveOnOver = function (pos, graph, event)
{
    switch (this._overMode) {
    case 'point':
        var list = this._onOverPoint(pos, graph, event);
        if (list.length > 0) {

            // Move to top
            var serie = this._series[list[0].serie];
            var index = this._seriesList.indexOf(serie);
            this._seriesList.splice(index, 1);
            this._seriesList.push(serie);

            this.onOver([list[0]], list[0].clientX, list[0].clientY);
            this.highlight({value: list[0].value, axis: list[0].axis});
            return true;
        }
        break;

    case 'time':
        var x = pos.x / graph.scaleX + graph.fromX;
        var list = this._onOverTime(x, graph, event);
        if (list.length > 0) {
            this.onOver(list, event.clientX, event.clientY);
            this.highlight({axis: graph.ay, value: x});
            return true;
        }
        break;
    }
    return false;
};

Graph.prototype._onOverPoint = function (pos, graph, event)
{
    var ax = this._axis.x;
    var ay = graph.ay;

    var list = [];

    // Look into all series
    for (var s = this._seriesList.length; s--;) {
        var serie = this._seriesList[s];
        if (!serie.enabled) continue;

        var aIdx = serie.y.indexOf(ay);
        if (aIdx < 0) continue;
        var drawStyle = serie.drawStyle[aIdx];
        if (drawStyle === 'histogram') continue; // XXX

        var values = serie.values;
        var bestDist = 100;
        var bestItem = null;
        for (var i = 0; i < values.length; i++) {
            var value = values[i];
            var valueY = value[ay.name];
            var vX = (value.x - graph.fromX) * graph.scaleX;
            var vY = -(valueY - graph.toY) * graph.scaleY;
            var dist = Math.pow(vX - pos.x, 2) + Math.pow(vY - pos.y, 2);

            if (dist < bestDist) {
                bestDist = dist;
                bestItem = {
                    serie: serie.id,
                    axis: ay,
                    value: value,
                    X: value.x,
                    Y: valueY,
                    x: this._axisFormat(value.x, ax),
                    y: this._axisFormat(valueY, ay),
                    title: serie.title,
                    clientX: event.clientX + vX - pos.x,
                    clientY: event.clientY + vY - pos.y
                };
            }
        }
        if (bestItem)
            list.push(bestItem);
    }

    return list;
}

Graph.prototype._onOverTime = function (x, graph, event)
{
    var ax = this._axis.x;
    var ay = graph.ay;
    var az = graph.az;
    var list = [];

    for (var s = 0; s < this._seriesList.length; s++) {
        var serie = this._seriesList[s];

        // Skip
        if (!serie.enabled) continue;

        var axis = null;
        var aIdx = serie.y.indexOf(ay);
        if (aIdx >= 0) {
            axis = ay;
        } else {
            aIdx = 0;
            for (var i = 0; i < az.length; i++) {
                if (serie.y.indexOf(az[i]) >= 0) {
                    axis = az[i];
                    break;
                }
            }
        }
        if (!axis) continue;

        var drawStyle = serie.drawStyle[aIdx];
        var point = null;
        var values = serie.values;
        for (var i = 0; i < values.length; i++) {
            var x1 = values[i].x;
            var y1 = values[i][axis.name];

            switch (drawStyle) {
            case 'histogram':
                var range = this.histoGetRange(values, i);
                if (x >= range[0] && x <= range[1]) {
                    point = [x1, y1];
                }
                break;

            default:
                if (x1 < x) continue;

                if (x === x1) {
                    point = [x1, y1];
                } else if (i) {
                    var x0 = values[i-1].x;
                    if (x0 === x1) {
                        point = [x, y0];
                    } else {
                        // Interpolate
                        var y0 = values[i-1][axis.name];
                        point = [x, (x - x0) / (x1 - x0) * (y1 - y0) + y0];
                    }
                } else {
                    point = false;
                }
                break;
            }
            if (point !== null)
                break;
        }

        if (point && point[1] !== null) {
            list.push({
                serie: serie.id,
                title: serie.title,
                axis: axis,
                value: values[i],
                X: point[0],
                Y: point[1],
                x: this._axisFormat(point[0], ax),
                y: this._axisFormat(point[1], axis),
            });
        }
    }

    return list;
}

Graph.prototype.histoGetRange = function (values, index)
{
    var dx0 = 1, dx1 = 1;
    var x = values[index].x;

    if (index === 0) {
        dx0 = dx1 = values[1].x - x;
    } else if (index === values.length - 1) {
        dx0 = dx1 = x - values[index - 1].x;
    } else {
        dx0 = x - values[index - 1].x;
        dx1 = values[index + 1].x - x;
    }

    return [x - dx0 / 2, x + dx1 / 2];
};

Graph.prototype.highlight = function (ref)
{
    if (!this._highlightedRef && !ref)
        return false;

    if (this._highlightedRef && ref &&
        this._highlightedRef.value === ref.value &&
        this._highlightedRef.axis === ref.axis)
        return false;

    this._highlightedRef = ref;
    this.draw();
    return true;
};

// Out
Graph.prototype.mouseOutEvent = function (event)
{
    this.onOver(null);
};

// Up
Graph.prototype.mouseUpEvent = function (event)
{
    this.setCursor('');
    var move = this._move;
    if (!move)
        return;
    this._move = undefined;

    if (move.ctrl) {
        var graph = move.graph;
        var ax = this._axis.x;

        if (move.pos) {
            this._zoomed = true;
            var x0 = Math.max(ax.from, Math.min(move.x, move.pos.x) / graph.scaleX + graph.fromX);
            var x1 = Math.min(graph.fromX + Math.max(move.x, move.pos.x) / graph.scaleX, ax.to);
            this._setWindow(ax, x0, x1 - x0);
            if (move.shift) {
                this._axisY.forEach( (ay) => {
                    var y0 = Math.max(ay.from, graph.toY - Math.max(move.y, move.pos.y) / graph.scaleY);
                    var y1 = Math.min(graph.toY - Math.min(move.y, move.pos.y) / graph.scaleY, ay.to);
                    this._setWindow(ay, y0, y1 - y0);
                });
            }
        } else {
            this._zoomed = false;
            this._setWindow(ax, ax.min, ax.max - ax.min);
            if (move.shift) {
                this._axisY.forEach( (ay) => {
                    this._setWindow(ay, ay.min, ay.max - ay.min);
                });
            }
        }
        this.draw();
        return;
    }

    if (this.onClick) {
        var pos = this._eventToPosition(event);
        if (pos) {
            var dx = pos.x - move.x;
            var dy = pos.y - move.y;
            var d = Math.sqrt(dx * dx + dy * dy);
            if (d > 3)
                return;

            var graph = pos.graph;
            switch (this._overMode) {
            case 'point':
                var list = this._onOverPoint(pos, graph, event);
                break;
            case 'time':
                var x = pos.x / graph.scaleX + graph.fromX;
                var list = this._onOverTime(x, graph, event);
                break;
            }

            if (list.length > 0)
                this.onClick(list);
        }
    }
};


