/*
 * Copyright (C) 2023-2024 Amarisoft
 *
 * Amarisoft ASN.1 Editor 2024-12-13
 * Icons from
 * - http://icocentre.com/
 * - https://www.iconfinder.com/iconsets/24x24-free-pixel-icons (https://creativecommons.org/licenses/by/3.0/legalcode)
 *
 * Javascript Object Notation (JSON) Encoding Rules for ASN.1
 * https://www.itu.int/rec/dologin_pub.asp?lang=e&id=T-REC-X.697-202102-I!!PDF-E&type=items
 */

var process;

var dbg, dbgRoot, dbgNode;

const colorError = '#FFC0C0';

var ASN1Start = function () {
    Ext.application({
        name: 'ASN1Editor',
        launch: function() {
            this.viewport = this.getView('Viewport').create();

            var editor = Ext.create('lte.asn1.editor', {});

            this.viewport.add(editor);

            // URL parsing
            var type = null;
            var url = null;
            var parser = document.createElement('a');
            parser.href = location.href;
            parser.search.substr(1).split(/&/).forEach((p) => {
                p = p.split(/=/);
                switch (p[0]) {
                case 'debug':
                    editor.debugOn = true;
                    asn1Defs.unshift({
                        name: 'Test',
                        schema: {
                            type: 'SEQUENCE',
                            name: 'Test',
                            properties: [{
                                name: 'test',
                                definition: {
                                    type: 'BIT_STRING',
                                    min: 3,
                                    max: 11
                                },
                            }, {
                                name: 'Bool',
                                definition: {
                                    type: 'BOOLEAN',
                                }
                            }]
                        }
                    });
                    break;
                case 'url':
                    url = decodeURIComponent(p[1]);
                    break;
                case 'type':
                    type = p[1];
                    break;
                    break;

                }
            });

            if (url)
                editor.loadFileHTTP(url, type);

            // NodeJS mode
            if (process !== undefined) {
                var gui = require('nw.gui');
                var fs = require('fs');
                var path = require('path');
                var file = null;
                var argv = gui.App.argv;

                for (var i = 1; i < argv.length; i++) {
                    var arg = argv[i];
                    switch (arg) {
                    case '-d':
                        editor.debugOn = true;
                        break;
                    case '-t':
                        type = argv[++i];
                        break;
                    default:
                        if (!arg)
                            break;

                        if (arg[0] === '-') {
                            console.error('Bad parameter', arg);
                            process.exit(1);
                        }
                        if (file !== null) {
                            console.error('File already set', arg);
                            process.exit(1);
                        }
                        var file = arg;
                        break;
                    }
                }

                if (file) {
                    if (!path.isAbsolute(file))
                        file = path.join(argv[0], file);

                    if (fs.existsSync(file))
                        editor.loadFileNode(file, type);
                    else
                        Ext.Msg.alert("Can't load " + file, 'File not found');
                }
            }
        },
    });
};

if (process !== undefined) {
    console = new (require('console').Console)(process.stdout, process.stderr);
    process.on('uncaughtException', (error, origin) => {
        console.error(error);
    });
}

Ext.define('lte.asn1.editor', {

    extend: 'Ext.panel.Panel',
    header: false,
    border: false,
    layout: 'fit',

    tbar: {
        width: '100%',
        border: false,
        items: []
    },

    debugOn: false,

    constructor: function (config) {
        this.callParent(arguments);
    },

    initComponent: function () {
        this.callParent(arguments);

        this.tbar = this.down('toolbar');

        dbg = this;

        this.openButton = this.tbar.add({
            xtype: 'filefield',
            name: 'file',
            buttonOnly: true,
            allowBlank: false,
            buttonText: 'Open',
            labelWidth: 0,
            maxWidth: 50,
            listeners: {
                scope: this,
                boxready: function (myObj, width, height, eOpts) {
                    //myObj.fileInputEl.set({multiple: 'multiple'});
                },
                change: function (myObj, value, eOpts) {
                    setTimeout( () => {
                        this.loadFileHTML(myObj.extractFileInput().files[0]);
                    });
                }
            }
        });

        this.saveButton = this.tbar.add({
            xtype: 'button',
            text: 'Save',
            iconCls: 'icon-download',
            scope: this,
            disabled: true,
            tooltip: 'Save ASN.1',
            handler: function () {
                this.saveASN1(this.asn1File);
            }
        });

        this.newButton = this.tbar.add({
            xtype: 'button',
            text: 'New',
            iconCls: 'icon-pen',
            scope: this,
            tooltip: 'New ASN.1',
            handler: function () {
                this.loadASN1({}, null, '');
            }
        });

        this.tbar.add('|');

        this.addMissingsButton = this.tbar.add({
            xtype: 'button',
            text: 'Add missings',
            disabled: true,
            iconCls: 'icon-plus',
            scope: this,
            tooltip: 'All all mandatory properties',
            handler: function () {
                this.addMissings(this.asn1Def.schema, this.asn1Data, Infinity);
                this.updateTree();
            }
        });

        this.statusFile = this.tbar.add({
            xtype: 'panel',
            bodyPadding: 4,
            border: true,
            hidden: true,
            html: '&nbsp;',
        });

        this.statusError = this.tbar.add({
            xtype: 'panel',
            bodyPadding: 4,
            border: true,
            hidden: true,
            html: '&nbsp;',
            bodyStyle: {
                "background-color": colorError,
            },
        });

        this.tbar.add('->');
        this.tbar.add({
            xtype: 'panel',
            bodyPadding: 4,
            border: true,
            border: false,
            html: 'ASN.1 editor version 2024-12-13',
        });

        this.tbar.add({
            xtype: 'button',
            iconCls: 'icon-info',
            tooltip: 'Open tutorial',
            handler: function () {
                window.open("https://tech-academy.amarisoft.com/ASN1_Editor.html");
            },
        });

        var store = Ext.create('Ext.data.TreeStore', {
            fields: ['name', 'asn1', 'schema', 'edit', 'removable', 'options', 'error', 'info'],
            root: {name: '-', asn1: {}, schema: { type: '' }, edit: null, children: [], expanded: true},
        });

        var grid = this.grid = Ext.create('Ext.tree.Panel', {
            store: store,
            //rootVisible: false,
            useArrows: true,
            disabled: true,
            viewConfig: {
                markDirty: false,
                enableTextSelection: true,
                getRowClass: function(record, rowIndex, rowParams, store) {
                    return rowIndex & 1 ? 'x-grid-item-alt' : 'x-grid-item';
                }
            },
            plugins: [
                Ext.create('Ext.grid.plugin.CellEditing', {
                    clicksToEdit: 1,
                    listeners: {
                        scope: this,
                        beforeedit: function (a, b, c, d, e) {
                            var record = grid.getStore().getAt(b.rowIdx);
                            this.selRecord = record;
                            this.updateRecord(record, record.get('asn1'), record.get('schema'), false);
                            return true;
                        },
                        edit: function (editor, params, eOpts) {
                            this.selRecord = null;
                            var value = params.value;
                            if (value !== null) {
                                var record = params.record;
                                this.updateASN1(record, record.get('schema'), record.get('asn1'), value);
                            }
                            this.updateTree();
                        }
                    }
                })
            ],

            columns: [{
                xtype: 'treecolumn',
                text: 'Property',
                dataIndex: 'name',
                scope: this,
                renderer: function (name, md, record) {
                    return name;
                },
            }, {
                text: 'Value',
                dataIndex: 'edit',
                minWidth: 250,
                scope: this,
                renderer: function (asn1, md, record) {
                    var str = this.renderASN1(record, md);
                    if (str !== undefined) {
                        var error = record.get('error');
                        if (error)
                            md.style = "border: 1px solid #FF0000;";
                        return str;
                    }
                    return '&nbsp;';
                },
                getEditor: this.getEditor.bind(this),

            }, {
                xtype:'actioncolumn',
                text: 'Actions',
                scope: this,
                items: [{
                    getTip: function (value, md, record) {
                        var schema = record.get('schema');
                        switch (schema.type) {
                        case 'SEQUENCE_OF':
                            return 'Add element';
                        case 'SEQUENCE':
                            return 'Add missing properties recursively';
                        }
                    },
                    iconCls: 'icon-plus',
                    scope: this,
                    handler: function (v, row, col, item, e, record) {
                        var schema = record.get('schema');
                        switch (schema.type) {
                        case 'SEQUENCE_OF':
                            var asn1 = record.get('asn1');
                            asn1.push(this.createASN1(schema.sequence));
                            this.updateTree();
                            break;
                        case 'SEQUENCE':
                            var asn1 = record.get('asn1');
                            this.addMissings(schema, asn1, Infinity);
                            this.updateTree();
                            break;
                        }
                    },
                    getClass: function (v, md, record) {
                        var schema = record.get('schema');
                        switch (schema.type) {
                        case 'SEQUENCE_OF':
                            var asn1 = record.get('asn1');
                            if (schema.max === undefined || schema.max > asn1.length)
                                return 'icon-plus icon-small';
                            break;
                        case 'SEQUENCE':
                            if (this.isMissing(schema, record.get('asn1')))
                                return 'icon-refresh icon-small';
                            break;
                        }
                        return 'ama-hide';
                    },
                }, {
                    tooltip: 'Move up',
                    scope: this,
                    handler: function (v, row, col, item, e, record) {
                        var parent = record.parentNode;
                        if (!parent) return;
                        var pschema = parent.get('schema');
                        if (pschema.type === 'SEQUENCE_OF') {
                            var idx = this.getSequenceOfIndex(record);
                            this.swapSequenceOf(idx - 1, idx, parent);
                        }
                    },
                    getClass: function (v, md, record) {
                        var parent = record.parentNode;
                        if (!parent) return;
                        var pschema = parent.get('schema');
                        if (pschema.type === 'SEQUENCE_OF') {
                            var idx = this.getSequenceOfIndex(record);
                            if (idx > 0)
                                return 'icon-up icon-small';
                        }
                        return 'ama-hide';
                    },
                }, {
                    tooltip: 'Move down',
                    scope: this,
                    handler: function (v, row, col, item, e, record) {
                        var parent = record.parentNode;
                        if (!parent) return;
                        var pschema = parent.get('schema');
                        if (pschema.type === 'SEQUENCE_OF') {
                            var idx = this.getSequenceOfIndex(record);
                            this.swapSequenceOf(idx, idx + 1, parent);
                        }
                    },
                    getClass: function (v, md, record) {
                        var parent = record.parentNode;
                        if (!parent) return;
                        var pschema = parent.get('schema');
                        if (pschema.type === 'SEQUENCE_OF') {
                            var idx = this.getSequenceOfIndex(record);
                            if (idx >= 0 && idx < parent.childNodes.length - 1)
                                return 'icon-down icon-small';
                        }
                        return 'ama-hide';
                    },
                }, {
                    tooltip: 'Remove',
                    handler: function (v, row, col, item, e, record) {

                        var parent = record.parentNode;
                        var pschema = parent.get('schema');
                        var pasn1 = parent.get('asn1');
                        this.removeASN1(record, pschema, pasn1);

                        this.updateTree();
                    },
                    getClass: function (v, md, record) {
                        if (record.get('removable'))
                            return 'icon-delete icon-small';

                        return 'ama-hide';
                    },
                }],
            }, {
                text: 'Info',
                dataIndex: 'info',
                flex: 1,
                scope: this,
                renderer: function (info, md, record) {
                    var error = record.get('error');
                    if (error)
                        md.style = "background-color: " + colorError + ";";

                    return info ? info : '&nbsp;';
                },
            }],
            listeners:{
                scope: this,
                cellclick: function(table, td, cellindex, record) {
                },
                selectionchange: function (view, records, eOpts) {
                    var record = records[0];
                    if (record) {
                        var schema = record.get('schema');
                        this.debug('### Select', schema.type, record.get('asn1'), schema);
                        dbgNode = record;
                    }
                },
                afterlayout: function (g) {
                    if (this.treeDirty) {
                        clearTimeout(this.treeDirty);
                        this.treeDirty = setTimeout( () => {
                            this.treeDirty = 0;
                            g.columns[0].autoSize();
                            g.columns[1].autoSize();
                        }, 100);
                    }
                }
            }
        });

        this.add(grid);
        this.grid.columns[0].autoSizeOffset = 10;
        this.grid.columns[1].autoSizeOffset = 10;
        this.updateStatus();
    },

    removeASN1: function (record, pschema, pasn1) {

        switch (pschema.type) {
        case 'SEQUENCE':
            delete pasn1[record.get('name')];
            break;
        case 'SEQUENCE_OF':
            var siblings = record.parentNode.childNodes;
            for (var i = 0; i < siblings.length; i++) {
                if (siblings[i] === record) {
                    pasn1.splice(i, 1);
                    break;
                }
            }
            break;
        case 'OCTET_STRING':
            if (this.octetStringContains(pschema, pasn1)) {
                this.removeASN1(record, pschema.containing, pasn1);
            }
            break;
        }
    },

    getEditor: function (rec) {
        return this.getEditor1(rec, rec.get('schema'), rec.get('asn1'));
    },

    getEditor1: function (rec, schema, asn1) {

        switch (schema.type) {
        case 'SEQUENCE':
            var options = rec.get('options');
            if (!options)
                return;

            var cfg = {
                xtype: 'combobox',
                fieldLabel: '',
                name: '',
                allowBlank: true,
                queryMode: 'local',
                valueField: 'value',
                displayField: 'text',
                //validateOnChange: true,
                forceSelection: true,
                editable: false,
                autoSelect: false,
                store: Ext.create('Ext.data.Store', {
                    fields: ['value', 'text'],
                    data: options.map( (o) => {
                        return {
                            value: Object.assign({}, o),
                            text: o.name
                        };
                    }),
                }),
                listeners: {
                    scope: this,
                    change: function (cb) { cb.triggerBlur(); },
                    focus: function (cb) { cb.expand(); },
                },
            };
            break;
        case 'CHOICE':
            var cfg = {
                xtype: 'combobox',
                fieldLabel: '',
                name: '',
                allowBlank: true,
                queryMode: 'local',
                valueField: 'value',
                displayField: 'text',
                //validateOnChange: true,
                forceSelection: true,
                editable: false,
                autoSelect: false,
                store: Ext.create('Ext.data.Store', {
                    fields: ['value', 'text'],
                    data: schema.choices.map( (o) => {
                        return {
                            value: o,
                            text: o.name
                        };
                    }),
                }),
                listeners: {
                    scope: this,
                    change: function (cb) { cb.triggerBlur(); },
                    focus: function (cb) { cb.expand(); },
                },
            };
            break;
        case 'ENUMERATED':
            var cfg = {
                xtype: 'combobox',
                fieldLabel: '',
                name: '',
                allowBlank: true,
                queryMode: 'local',
                valueField: 'value',
                displayField: 'text',
                //validateOnChange: true,
                forceSelection: true,
                editable: false,
                autoSelect: false,
                store: Ext.create('Ext.data.Store', {
                    fields: ['value'],
                    data: schema.enumerateds.map( (o, idx) => {
                        return { value: o, text: o };
                    }),
                }),
                listeners: {
                    scope: this,
                    change: function (cb) { cb.triggerBlur(); },
                    focus: function (cb) { cb.expand(); },
                },
            };
            break;
        case 'INTEGER':
            var cfg = {
                xtype: 'numberfield',
                maxValue: schema.max !== undefined ? schema.max : Infinity,
                minValue: schema.min !== undefined ? schema.min : -Infinity,
                value: asn1,
                validator: (val) => { return this.updateRecord(rec, val, schema, true) === null; },
            };
            break;
        case 'OCTET_STRING':
            if (this.octetStringContains(schema, asn1)) {
                return this.getEditor1(rec, schema.containing, asn1);
            }
            // Explicit fallthrough
        case 'BIT_STRING':
            var cfg = {
                xtype: 'textfield',
                value: asn1,
                allowBlank: false,
                minLength: 0,
                validator: (val) => { return this.updateRecord(rec, val, schema, true) === null; },
            };
            break;
        case 'BOOLEAN':
            this.updateASN1(rec, schema, asn1, !asn1);
            this.updateTree();
            return null;
        default:
            return null;
        }
        return Ext.create('Ext.grid.CellEditor', { field: cfg });
    },

    updateStatus: function () {
        var def = this.asn1Def;
        if (this.asn1File) {
            this.statusFile.update(this.asn1File + ', ' + def.schema.label + ' (' + def.name + ')');
            this.statusFile.setVisible(true);
        } else {
            this.statusFile.setVisible(false);
        }

        var errors = this.errorCount;
        if (errors) {
            var msg = [this.dispQuant(errors, 'error')];
            if (this.missing)
                msg.push(this.dispQuant(this.missing, ' missing propert', {single: 'y', multiple: 'ies'}));
            this.statusError.update(msg.join(', '));
            this.statusError.setVisible(true);
        } else {
            this.statusError.setVisible(false);
        }
    },

    updateTree: function () {
        var t0 = new Date() * 1;
        var root = this.grid.getRootNode();
        var asn1 = this.asn1Data;

        dbgRoot = root;

        this.errorCount = 0;
        this.missing = 0;
        this.treeDirty = true;
        this.updateNode(root, this.asn1Def.schema, asn1);
        this.updateStatus();
        this.saveButton.setDisabled(!root.childNodes.length);
        this.addMissingsButton.setDisabled(!this.missing);

        this.grid.view.refresh();
        //console.log('Prof', new Date() - t0);
    },

    updateNode: function (node, schema, asn1) {
        var i, j;

        var leaf0 = node.isLeaf();

        for (var i = 0; i < node.childNodes.length; i++)
            node.childNodes[i].asn1Dirty = true;

        //console.log('U', schema.type, leaf0);
        switch (schema.type) {
        case 'SEQUENCE':
            var props = schema.properties;
            var options = [];
            var mandatory = 0;

            for (i = j = 0; i < props.length; i++) {
                var prop = props[i];
                var name = prop.name;
                var def  = prop.definition;

                var child = node.findChild('name', name);
                if (child)
                    j++;

                if (asn1.hasOwnProperty(name)) {
                    var value = this.fixASN1(asn1, name, def);
                    if (!child) {
                        child = node.insertChild(j, {
                            name: name,
                            schema: def,
                            asn1: value,
                            removable: true,
                            leaf: true,
                        });
                        j++;
                    } else {
                        this.nodeSet(child, 'asn1', value);
                        child.asn1Dirty = false;
                    }
                    this.updateNode(child, def, value);
                } else {
                    options.push(prop);
                    if (!prop.optional && prop.default === undefined)
                        mandatory++;
                }
            }

            this.missing += mandatory;
            if (mandatory > 1) {
                options.unshift({
                    name: '<mandatory>Add all mandatory properties</mandatory>',
                    mandatory: mandatory,
                });
            }

            this.nodeSet(node, 'options', options.length ? options : null);
            break;
        case 'SEQUENCE_OF':
            var sequence = schema.sequence;
            var min = schema.min || 0;

            for (i = 0; i < asn1.length; i++) {
                var value = this.fixASN1(asn1, i, sequence);

                var name = 'Sequence ' + i;
                var child = node.childNodes[i];
                if (!child) {
                    child = node.insertChild(i, {
                        name: name,
                        schema: sequence,
                        asn1: value,
                        removable: true,
                        leaf: true,
                    });
                } else {
                    this.nodeSet(child, 'asn1', value);
                    this.nodeSet(child, 'name', name);
                    child.asn1Dirty = false;
                }
                this.updateNode(child, sequence, value);
            }
            break;
        case 'CHOICE':
            var schema1 = this.getChoiceSchema(asn1, schema);
            if (!schema1)
                break;

            if (!asn1.hasOwnProperty(schema1.name))
                break;

            var value = this.fixASN1(asn1, schema1.name, schema1);
            switch (schema1.type) {
            case 'NULL':
                break;
            default:
                var child = node.findChild('name', schema1.name);
                if (!child) {
                    child = node.appendChild({
                        name: schema1.name,
                        schema: schema1,
                        asn1: value,
                        leaf: true,
                    });
                } else {
                    this.nodeSet(child, 'asn1', value);
                    child.asn1Dirty = false;
                }
                this.updateNode(child, schema1, value);
                break;
            }
            break;
        case 'OCTET_STRING':
            if (this.octetStringContains(schema, asn1)) {
                return this.updateNode(node, schema.containing, asn1);
            }
            break;
        case 'BIT_STRING':
            this.nodeSet(node, 'edit', this.renderBitString(asn1, schema));
            break;
        default:
            this.nodeSet(node, 'edit', asn1);
            break;
        }

        // Purge dirty
        for (var i = node.childNodes.length; i--;) {
            if (node.childNodes[i].asn1Dirty)
                node.childNodes[i].remove();
        }

        if (leaf0 && node.childNodes.length) {
            this.nodeSet(node, 'leaf', false);
            setTimeout( () => { node.expand(); }, 10 ); // All at once
        } else if (!leaf0 && !node.childNodes.length) {
            this.nodeSet(node, 'leaf', true);
        }

        // Check
        if (this.updateRecord(node, asn1, schema, false))
            this.errorCount++;

        //console.log('U', 'end');
    },

    isMissing: function (schema, asn1) {

        switch (schema.type) {
        case 'SEQUENCE':
            var props = schema.properties;
            for (i = j = 0; i < props.length; i++) {
                var prop = props[i];
                if (!asn1.hasOwnProperty(prop.name) && !prop.optional)
                    return true;
            }
            break;
        case 'SEQUENCE_OF':
            var min = schema.min || 0;
            if (asn1.length < min)
                return true;
            break;
        }
        return false;
    },

    addMissings: function (schema, asn1, depth) {

        if (depth-- < 0) return;

        switch (schema.type) {
        case 'SEQUENCE':
            var props = schema.properties;

            for (var i = 0; i < props.length; i++) {
                var prop = props[i];
                var name = prop.name;
                var def  = prop.definition;
                if (!asn1.hasOwnProperty(name)) {
                    if (prop.optional)
                        continue;
                    asn1[name] = this.createASN1(def);
                }
                this.addMissings(def, asn1[name], depth);
            }
            break;
        case 'SEQUENCE_OF':
            var sequence = schema.sequence;
            var min = schema.min || 0;

            for (var i = asn1.length; i < min; i++) {
                asn1.push(this.createASN1(sequence));
            }
            for (var i = 0; i < asn1.length; i++) {
                this.addMissings(sequence, asn1[i], depth);
            }
            break;
        case 'CHOICE':
            var schema1 = this.getChoiceSchema(asn1, schema);
            if (!schema1)
                break;

            if (asn1.hasOwnProperty(schema1.name)) {
                this.addMissings(schema1, asn1[schema1.name], depth);
            }
            break;
        case 'OCTET_STRING':
        case 'BIT_STRING':
        default:
            break;
        }
    },


    nodeSet: function (node, param, value) {
        if (node.get(param) !== value)
            node.set(param, value);
    },

    getChoiceSchema: function (asn1, schema) {
        var name = Object.keys(asn1)[0];
        if (name === undefined)
            return null;

        return schema.choices.find( (c) => { return c.name === name; });
    },

    getSequenceOfIndex: function (record) {
        var parent = record.parentNode;
        for (var i = 0; i < parent.childNodes.length; i++) {
            if (parent.childNodes[i] === record)
                return i;
        }
        return -1;
    },

    swapSequenceOf: function (idx0, idx1, node) {

        var asn1 = node.get('asn1');

        var tmp = asn1[idx0];
        asn1[idx0] = asn1[idx1];
        asn1[idx1] = tmp;

        node.childNodes[idx0].set('asn1', asn1[idx0]);
        node.childNodes[idx1].set('asn1', asn1[idx1]);

        this.updateTree();
    },

    // Value comes from editor
    updateASN1: function (node, schema, asn1, value) {

        this.debug('###################### EDIT #################', schema.type, '##############', value);

        switch (schema.type) {
        case 'SEQUENCE':
            if (value.mandatory) {
                this.addMissings(schema, asn1, 1);
            } else {
                asn1[value.name] = this.createASN1(value.definition);
            }
            return;
        case 'CHOICE':
            if (asn1[value.name] === undefined) {
                node.removeChild(node.firstChild);
                for (var id in asn1) delete asn1[id];
                asn1[value.name] = this.createASN1(value);
            }
            return;
        case 'ENUMERATED':
        case 'INTEGER':
        case 'BOOLEAN':
            break;
        case 'BIT_STRING':
            var bound = this.getBound(schema);
            if (bound.min !== bound.max) {
                // Go back to hexa form
                value = {
                    length: value.length,
                    value: this.bin2hex(value),
                };
            } else {
                value = this.bin2hex(value);
                if (value.length & 1)
                    value += '0';
            }
            break;
        case 'OCTET_STRING':
            if (this.octetStringContains(schema, asn1)) {
                this.updateASN1(node, schema.containing, asn1, value);
                return;
            }
            break;
        default:
            return;
        }

        // Flat fields
        var parent = node.parentNode;
        var pasn1 = parent.get('asn1');
        switch (parent.get('schema').type) {
        case 'SEQUENCE':
            var name = node.get('name');
            pasn1[name] = value;
            break;
        case 'SEQUENCE_OF':
            var idx = this.getSequenceOfIndex(node);
            if (idx >= 0)
                pasn1[idx] = value;
            break;
        case 'CHOICE':
            var name = parent.firstChild.get('name');
            pasn1[name] = value;
            break;
        }
    },

    fixASN1: function (pasn1, id, schema) {

        var asn1 = pasn1[id];
        switch (schema.type) {
        case 'SEQUENCE':
        case 'CHOICE':
            if (typeof asn1 !== 'object' || asn1 === null)
                asn1 = {};
            break;
        case 'SEQUENCE_OF':
            if (!(asn1 instanceof Array))
                asn1 = {};
            break;
        case 'INTEGER':
            var i = asn1 - 0;
            if (!isNaN(i))
                asn1 = i;
            break;
        case 'BOOLEAN':
            asn1 = !!asn1;
            break;
        case 'OCTET_STRING':
            if (this.octetStringContains(schema, asn1))
                return this.fixASN1(pasn1, id, schema.containing);

            if (typeof asn1 !== 'string')
                asn1 = '';
            break;
        case 'BIT_STRING':
            if (schema.min === schema.max) {
                if (typeof asn1 === 'object' && asn1.length === schema.min)
                    asn1 = asn1.value;
                if (typeof asn1 !== 'string')
                    asn1 = '';
            } else if (typeof asn1 !== 'object') {
                asn1 = { value: '', length: 0 };
            }
            break;
        case 'NULL':
            asn1 = null;
            break;
        }
        pasn1[id] = asn1;
        return asn1;
    },

    renderASN1: function (record, md) {
        return this.renderASN1i(record, md, record.get('asn1'), record.get('schema'));
    },

    renderASN1i: function (record, md, asn1, schema) {

        switch (schema.type) {
        case 'SEQUENCE':
            var options = record.get('options');
            if (options) {
                md.style += " cursor: pointer; color: #404040;";
                return 'Add element...';
            }
            break;
        case 'SEQUENCE_OF':
            break;
        case 'CHOICE':
            md.style += " cursor: pointer; color: #404040;";
            var schema1 = this.getChoiceSchema(asn1, schema);
            if (!schema1)
                return 'Select choice';
            return schema1.name;
        case 'NULL':
            return schema.name;
        case 'BOOLEAN':
            if (asn1)
                return this.getIcon('ok', 'Enabled');
            return this.getIcon('off', 'Disabled');
        case 'ENUMERATED':
        case 'INTEGER':
            return asn1;
        case 'OCTET_STRING':
            if (this.octetStringContains(schema, asn1))
                return this.renderASN1i(record, md, asn1, schema.containing);
            return asn1;
        case 'BIT_STRING':
            return this.renderBitString(asn1, schema);
        case '':
            break;
        default:
            console.error('Unknown type ' + schema.type, asn1, schema);
            break;
        }
        return undefined;
    },

    renderBitString: function (asn1, schema) {

        if (schema.min === schema.max) {
            var len = schema.min;
        } else {
            var len = asn1.length;
            asn1 = asn1.value;
        }
        if (!asn1.match(/^([0-9a-f]*)$/i))
            return asn1; /* Error */

        var bin = this.hex2bin(asn1);
        for (var i = len; i < bin.length; i++) {
            if (bin[i] !== '0')
                return bin;
        }
        return bin.slice(0, len);
    },

    octetStringContains: function (schema, asn1) {
        return schema.containing && typeof asn1 !== 'string' || !asn1;
    },

    hex2bin: function (hex) {

        bin = '';
        for (var i = 0; i < hex.length; i++) {
            var c = ('0x' + hex[i]) - 0;
            for (var j = 4; j--;)
                bin += c & (1 << j) ? '1' : '0';
        }
        return bin;
    },

    bin2hex: function (bin) {
        return ASN1.bin2hex(bin);
    },

    getIcon: function (icon, tip) {
        return "<img src='data:image/gif;base64,R0lGODlhAQABAID/AMDAwAAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==' class='x-tree-icon icon-" + icon + "' title='" + tip + "'>";;
    },

    getSchemaType: function (schema) {
        return schema.type;
    },

    getASN1Error: function (asn1, schema, editor) {

        var hl = function (s) { return '<b>' + s + '</b>'; };

        switch (schema.type) {
        case 'SEQUENCE':
            var props = schema.properties;
            for (var i = 0; i < props.length; i++) {
                var prop = props[i];
                if (!prop.optional && prop.default === undefined && asn1[prop.name] === undefined)
                    return 'Missing ' + hl(prop.name) + ' element in sequence';
            }
            break;
        case 'SEQUENCE_OF':
            if (schema.min !== undefined && asn1.length < schema.min)
                return 'At least ' + hl(schema.min) + ' elements in sequence ' + this.dispBe(schema.min) + ' required';

            if (schema.max !== undefined && asn1.length > schema.max)
                return 'At most ' + hl(schema.max) + ' elements in sequence ' + this.dispBe(schema.max) + ' required';

            break;
        case 'INTEGER':
            if (asn1 === null)
                return 'Bad value: ';

            if (schema.min !== undefined && asn1 < schema.min)
                return 'Must be at least ' + hl(schema.min);

            if (schema.max !== undefined && asn1 > schema.max)
                return 'Must be at most ' + hl(schema.max);

            break;
        case 'CHOICE':
            var names = Object.keys(asn1);
            if (names.length === 0)
                return 'Missing choice';
            break;
        case 'BIT_STRING':
            // Use bin form
            var bin = editor ? asn1 : this.renderBitString(asn1, schema);
            var m = bin.match(/^([01]*)$/i);
            if (!m)
                return 'Field requires 0 or 1 digits';

            var bound = this.getBound(schema);
            var fix = bound.min == bound.max;

            if (bin.length < bound.min)
                return 'Bit string too short, field requires ' + (fix ? '' : 'at least ') + this.dispQuant(bound.min, 'bit');
            if (bin.length > bound.max)
                return 'Bit string too log, field requires ' + (fix ? '' : 'at most ') + this.dispQuant(bound.max, 'bit');
            break;
        case 'OCTET_STRING':
            if (this.octetStringContains(schema, asn1))
                return this.getASN1Error(asn1, schema.containing, editor);

            var m = asn1.match(/^([0-9a-f]*)$/i);
            if (!m)
                return 'Field requires hexadecimal digits';

            var str = m[1];
            len = str.length;
            if (len & 1)
                return 'Number of hexadecimal digits must be even';

            len = len >> 1;
            var bound = this.getBound(schema);
            if (len < bound.min)
                return 'At least ' + this.dispQuant(bound.min, 'byte') + ' must be set';
            if (len > bound.max)
                return 'At most ' + this.dispQuant(bound.max, 'byte') + ' must be set';
            break;
        case 'ENUMERATED':
            var idx = schema.enumerateds.indexOf(asn1);
            if (idx < 0)
                return 'Bad value: ' + asn1;
            break;
        }
        return null;
    },

    updateRecord: function (record, asn1, schema, editor) {
        var e = this.getASN1Error(asn1, schema, editor);
        if (e) {
            record.set('error', true);
            record.set('info', e);
            return true;
        }

        record.set('error', false);
        record.set('info', this.getSchemaInfo(schema, asn1, record === this.selRecord));
        return e;
    },

    getSchemaInfo: function (schema, asn1, sel) {

        if (sel) {
            var info = this.getSchemaInfoSel(schema, asn1);
            if (info)
                return info;
        }
        switch (schema.type) {
        case 'SEQUENCE':
            var def = [];
            var props = schema.properties;
            for (var i = 0; i < props.length; i++) {
                var prop = props[i];
                if (!asn1.hasOwnProperty(prop.name) && !prop.optional && prop.default !== undefined)
                    def.push(prop.name);
            }
            if (def.length)
                return 'This sequence has default ' + this.dispQuant(def.length, 'value', {noQuant: true}) + ' for ' + def.join(', ');

            break;
        }
        return null;
    },

    getSchemaInfoSel: function (schema, asn1) {

        switch (schema.type) {
        case 'SEQUENCE':
            var mandatory = [];
            var props = schema.properties;
            for (var i = 0; i < props.length; i++) {
                var prop = props[i];
                if (!prop.optional && prop.default === undefined)
                    mandatory.push(prop.name);
            }
            if (mandatory.length)
                return 'Mandatory ' + this.dispQuant(mandatory.length, 'field', { noQuant: true}) + ': ' + mandatory.join(', ');
            break;
        case 'SEQUENCE_OF':
            if (schema.min !== undefined) {
                if (schema.min === schema.max)
                    return this.dispQuant(schema.max, 'element')  + ' in sequence ' + this.dispBe(schema.max) + ' required';
                if (schema.max !== undefined)
                    return 'Between ' + schema.min + ' and ' + this.dispQuant(schema.max, 'element') + ' in sequence ' + this.dispBe(schema.min) + ' required';
                return 'At least ' + this.dispQuant(schema.min, 'element') + ' in sequence ' + this.dispBe(schema.max) + ' required';
            }
            if (schema.max !== undefined)
                return 'At most ' + schema.max + ' elements in sequence ' + this.dispBe(schema.min) + ' required';
            break;
        case 'INTEGER':
            if (schema.min !== undefined && schema.max !== undefined)
                return 'Value must be between ' + schema.min + ' and ' + schema.max;
            if (schema.min !== undefined)
                return 'Value must be at least ' + schema.min;
            if (schema.max !== undefined)
                return 'Value must be at most ' + schema.max;
            break;
        case 'CHOICE':
            break;
        case 'BIT_STRING':
            var bound = this.getBound(schema);
            if (bound.min !== undefined) {
                if (bound.min === bound.max)
                    return 'Bit string requires ' + this.dispQuant(bound.min, 'bits');
                if (bound.max !== undefined)
                    return 'Bit string requires between ' + bound.min + ' and ' + this.dispQuant(bound.max, 'bits');
                return 'Bit string requires at least ' + this.dispQuant(bound.min, 'bits');
            }
            if (bound.max !== undefined)
                return 'Bit string requires at most ' + this.dispQuant(bound.max, 'bits');
            break;
        case 'OCTET_STRING':
            if (schema.containing)
                return this.getSchemaInfo(schema.containing, asn1);
            if (bound.min !== undefined) {
                if (bound.min === bound.max)
                    return 'Octet string requires ' + this.dispQuant(bound.min, 'bits');
                if (bound.max !== undefined)
                    return 'Octet string requires at between ' + bound.min + ' and ' + this.dispQuant(bound.max, 'bits');
                return 'Octet string requires at least ' + this.dispQuant(bound.min, 'byte');
            }
            if (bound.max !== undefined)
                return 'Octet string requires at most ' + this.dispQuant(bound.max, 'byte');
            break;
        case 'ENUMERATED':
            break;
        }
        return null;
    },

    getBound: function (value) {
        return {
            min: value.min === undefined ? -Infinity : value.min,
            max: value.max === undefined ? Infinity : value.max,
        };
    },

    createASN1: function (schema) {

        switch (schema.type) {
        case 'SEQUENCE':
        case 'CHOICE':
            return {};
        case 'SEQUENCE_OF':
            return [];
        case 'INTEGER':
            var v = 0;
            if (schema.min !== undefined)
                v = Math.max(v, schema.min);

            if (schema.max !== undefined)
                v = Math.min(v, schema.max);

            return v;
        case 'OCTET_STRING':
            if (schema.containing)
                return this.createASN1(schema.containing);
            return '';
        case 'BIT_STRING':
            return '';
        case 'ENUMERATED':
            return schema.enumerateds[0];
        case 'NULL':
            return null;
        }
        return '?';
    },

    saveASN1prompt: function () {

        if (process) {
            this.saveASN1write(this.asn1File || (this.asn1Def.name + '.jer'));
            return;
        }

        Ext.Msg.prompt('Export ASN.1', 'Enter filename:', (btn, name) => {

            if (btn !== 'ok' || !name)
                return;

            if (!this.asn1File && !name.match(/\.jer$/))
                name += '.jer';

            this.saveASN1write(name);

        }, this, false, this.asn1File);
    },

    saveASN1write: function (name) {

        // XXX: make indentation configurable
        var blob = new Blob([JSON.stringify(this.asn1Data, null, 2)], { type: 'application/json;charset=utf-8;' });
        if (navigator.msSaveBlob) { // IE 10+
            navigator.msSaveBlob(blob, name);
        } else {
            var link = document.createElement("a");
            if (link.download !== undefined) { // feature detection
                // Browsers that support HTML5 download attribute
                var url = URL.createObjectURL(blob);
                link.setAttribute("href", url);
                link.setAttribute("download", name);
                link.style = "visibility:hidden";
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                this.asn1File = name;
            }
        }
    },

    saveASN1: function () {

        if (this.errorCount) {
            Ext.Msg.confirm('ASN.1 is not valid', 'Save anyway ?', (btn) => {
                if (btn === 'yes')
                    this.saveASN1prompt();
            });

        } else {
            this.saveASN1prompt();
        }
    },

    loadFileHTML: function (file) {

        var reader = new window.FileReader();
        reader.onload = (e) => {
            var bb = reader.result;

            if (!bb) {
                console.error("Can't load file");
                return;
            }

            this.loadASN1(bb, null, file.name);
        };

        reader.onerror = (e) => {
            console.error("Can't load file", e);
        };

        reader.readAsArrayBuffer(file);
    },

    selectASN1Def: function (type, cb) {

        if (type) {
            for (var i = 0; i < asn1Defs.length; i++) {
                var def = asn1Defs[i];
                if (def.name.toLowerCase() === type.toLowerCase()) {
                    cb(def);
                    return;
                }
            }
            console.error('Unknown asn1 type', type);
        }

        var store = Ext.create('Ext.data.Store', {
            fields: ['name', 'schema'],
            data: asn1Defs.map( (d) => { return Object.assign({}, d); }),
        });

        var grid = Ext.create('Ext.grid.Panel', {
            store: store,
            layout: 'fit',
            columns: [{
                text: 'Type',
                flex: 1.5,
                dataIndex: 'schema',
                renderer: function (schema, md, record) {
                    return schema.label;
                },
            }, {
                text: 'ID',
                flex: 1,
                dataIndex: 'name',
            }],
            listeners: {
                scope: this,
                selectionchange: function (view, records, eOpts) {
                    if (records.length) {
                        var data = records[0].getData();
                        win.close();
                        cb(data);
                    }
                },
            },
        });

        var win = Ext.create('Ext.window.Window', {
            title: 'Select ASN.1 type',
            width: 600,
            height: 400,
            modal: true,
            constraint: true,
            layout: 'fit',
            iconCls: 'icon-logs',
            items: [grid],
        });
        win.show();
    },

    loadFileNode: function (file, type) {

        var fs = require('fs');

        try {
            var data = fs.readFileSync(file);
        } catch (e) {
            console.error("Can't load " + file, e);
            process.exit(1);
        }

        this.loadASN1(data, type, file);
    },

    loadFileHTTP: function (url0, type) {

        /* Get size */
        var url = url0 + "?nocache=" + (new Date() - 0);

        var xhr = new XMLHttpRequest();
        xhr.open("GET", url);
        xhr.responseType = "arraybuffer";
        xhr.onreadystatechange = () => {

            if (xhr.readyState !== 4) return;

            if (xhr.status < 200 || xhr.status >= 300) {
                Ext.Msg.alert("Error", "Can't load: " + url0 + ', error=' + xhr.status);
                return;
            }

            this.loadASN1(xhr.response, type, url0);
        };
        xhr.send();
    },

    loadASN1: function (asn1, type, file) {

        this.debug('Load ASN.1', file, type);
        this.selectASN1Def(type, (def) => {
            this.convertASN1(asn1, def, (asn1, error) => {
                if (asn1)
                    this.selectASN1(asn1, def, file);
                else
                    Ext.Msg.alert("Can't parse " + file, error);
            });
        });
    },

    selectASN1: function (asn1, def, file) {
        this.asn1Data = asn1;
        this.asn1Def = def;
        this.asn1File = (file || '').split('/').pop();

        var root = this.grid.getRootNode();
        while (root.firstChild)
            root.removeChild(root.firstChild);

        var root = this.grid.getRootNode();
        root.set('schema', def.schema);
        root.set('asn1', asn1);
        root.set('name', def.schema.label);

        this.grid.setDisabled(false);
        this.updateTree();
    },

    convertASN1: function (data, def, cb) {

        switch (typeof data) {
        case 'object':
            if (data instanceof ArrayBuffer || (process && data instanceof Buffer)) {
                var decoder = new TextDecoder();
                text = decoder.decode(data);
                break;
            }
            cb(data);
            return;
        case 'string':
            var text = data;
            break;
        default:
            cb(null, 'Internal error');
            return;
        }

        // Try JSON
        var asn1 = null;
        try {
            asn1 = JSON.parse(text);
        } catch (e) {
            var error = e.toString();
        }
        if (asn1) {
            cb(asn1, null);
            return;
        }

        asn1 = ASN1.fromGSER(text.split(/\r?\n/));
        if (asn1) {
            cb(asn1, null);
            return;
        }

        if (process) {
            if (data instanceof ArrayBuffer)
                data = Buffer.from(data);

            this.convertTool(text, 'json_util', '-i 0 dump -', (asn1, e) => {
                if (asn1)
                    cb(asn1, null);

                this.convertTool(text, 'lte_toolbox', 'asn1-convert - ' + def.name + ' gser jer', (asn1, e) => {
                    if (asn1)
                        return cb(asn1, null);

                    this.convertTool(text, 'lte_toolbox', 'asn1-convert - ' + def.name + ' hex jer', (asn1, e) => {
                        if (asn1)
                            return cb(asn1, null);

                        this.convertTool(data, 'lte_toolbox', 'asn1-convert - ' + def.name + ' per jer', (asn1, e) => {
                            cb(asn1, e);
                        });
                    });
                });
            });
        } else {
            var xhr = new XMLHttpRequest();
            xhr.open('PUT', 'asn1.php?type=' + def.name);
            xhr.onreadystatechange = () => {

                if (xhr.readyState !== 4) return;
                if (xhr.status < 200 || xhr.status >= 300) {
                    return cb(null, 'HTTP error: ' + xhr.status);
                }
                try {
                    var resp = JSON.parse(xhr.responseText);
                } catch (e) {
                    return cb(null, '' + e);
                }
                if (resp.error)
                    cb(null, resp.error);
                else
                    cb(resp.data);
            }
            xhr.send(data);
        }
    },

    convertTool: function (data, tool, args, cb) {

        var fs = require('fs');
        var dirs = ['./', '../', '../../', '../ots/', '/root/ots/'];

        for (var i = 0; i < dirs.length; i++) {
            if (fs.existsSync(dirs[i] + tool)) {

                var proc = require('child_process').exec(dirs[i] + tool + ' ' + args, (error, stdout, stderr) => {
                    var asn1 = null;
                    if (!error) {
                        try {
                            asn1 = JSON.parse(stdout);
                        } catch (e) {
                        }
                    }
                    cb(asn1, stderr);
                });

                proc.stdin.write(data);
                proc.stdin.end();
                return;
            }
        }

        cb(false);
    },

    debug: function () {
        if (this.debugOn) {
            console.log.apply(console, Array.from(arguments));
        }
    },

    dispQuant: function (n, txt, opt) {
        opt = opt || {};
        txt = txt + (n > 1 ? (opt.multiple || 's') : (opt.single || ''));
        if (opt.noQuant)
            return txt;

        if (opt.highlight)
            txt = hl(n) + ' ' + txt;

        return n + ' ' + txt;
    },

    dispBe: function (n) {
        return n > 1 ? 'are' : 'is'
    },
});



if (0)
console.log(JSON.stringify(ASN1.fromGSER([
"{",
"  message c1: systemInformationBlockType1: {",
"    cellAccessRelatedInfo {",
"      plmn-IdentityList {",
"        {",
"          plmn-Identity {  /* patched by eNB */",
"            mcc {",
"              0,",
"              0,",
"              0",
"            },",
"            mnc {",
"              0,",
"              0",
"            }",
"          },",
"          cellReservedForOperatorUse notReserved",
"        }",
"      },",
"      trackingAreaCode '0000'H, /* patched by eNB */",
"      cellIdentity '0000000'H, /* patched by eNB */",
"      cellBarred notBarred,",
"      intraFreqReselection allowed,",
"      csg-Indication FALSE",
"    },",
"    cellSelectionInfo {",
"      q-RxLevMin -70",
"    },",
"    p-Max 10, /* maximum power allowed for the UE (dBm) */",
"    freqBandIndicator 1, /* patched by eNB */",
"    schedulingInfoList {",
"      {",
"        si-Periodicity rf16,",
"        sib-MappingInfo {",
"          sibType3",
"        }",
"      }",
"    },",
"    si-WindowLength ms40,",
"    systemInfoValueTag 8",
"  }",
"}"
]), null, 2));

