Ext.define("lte.view.tab", {

    extend: 'lte.client.tab',
    layout: 'fit',

    _chartList: [],


    constructor: function (config) {
        this._fps = {
            max: config.fps ? config.fps : 25,
            count: 0,
        };

        this.callParent(arguments);
    },

    initComponent: function () {
        this.callParent(arguments);

        var frameDuration = Math.ceil(1000 / this._fps.max);

        this._updater = Ext.create("lte.updater", {
            scope:       this,
            updateDelay: frameDuration,
            autoDelay:   frameDuration,
            dirty:       true,
            lock:        1,
            handler:     this.redraw,
        });


        var mainPanel = Ext.create('Ext.panel.Panel', {
            html: '<canvas></canvas>',
            listeners: {
                scope: this,
                resize: function(cont, width, height) {
                    var canvas = mainPanel.el.down("canvas").dom;
                    if (this._canvas !== canvas) {
                        this._canvas = canvas;
                        /*
                        canvas.addEventListener(lteLogs.getMouseWheelEvent(), function (event) { graph.mouseWheelEvent(event); }, {passive: true});
                        this._addMouseListener(canvas, graph, 'mouseout', 'mouseOutEvent');
                        var listener = this._mouseListener.bind(this, canvas, graph);
                        canvas.addEventListener('mousemove', listener, false);
                        canvas.addEventListener('mousedown', listener, false);
                        canvas.addEventListener('mouseup', listener, false);
                        canvas.addEventListener('contextmenu', listener, false);
                        */
                    }
                    lteLogs.setCanvasSize(canvas, width, height);
                    this.redraw();
                }
            }
        });

        this._plots = [{
            type: 'power',
            title: 'Spectrum',
            enabled: true,
            rescale: true,
        }, {
            type: 'power_time',
            title: 'Time',
            enabled: false,
            rescale: true,
        }, {
            type: 'qam',
            title: 'QAM',
            enabled: false,
            rescale: true,
        }, {
            type: 'mer',
            title: 'MER',
            enabled: false,
            rescale: true,
        }];

        this._fps.time = new Date() * 1;

        this.tbar = this.down('toolbar');

        this._plots.forEach( (p) => {
            this.tbar.add({
                type: 'checkbox',
                boxLabel: p.title,
                labelWidth: 0,
                labelSeparator: '',
                xtype: 'checkbox',
                value: p.enabled,
                listeners: {
                    scope: this,
                    change: function (field, newValue, oldValue, eOpts) {
                        p.enabled = newValue;
                    }
                }
            });
        });

        this.add(mainPanel);
    },

    setClientConfig: function (config) {
        this.sample_rate = config.sample_rate;
        this.frequency = config.frequency;
    },

    redraw: function () {

        if (this._redrawPending || !this._canvas)
            return;

        var plots = [];
        var trans = [];
        for (var i = 0; i < this._plots.length; i++) {
            if (this._plots[i].enabled) {
                plots.push({ type: this._plots[i].type });
                trans.push(i);
            }
        }

        this._redrawPending = true;
        this.client.sendMessage({ message: 'plots', plots: plots }, (msg) => {

            msg.plots.forEach( (p, i) => {
                this._plots[trans[i]].data = msg.__binary__.slice(p.offset, p.offset + p.size)
            });

            window.requestAnimationFrame(this.drawFrame.bind(this));
        });
    },

    drawMargin: 8,

    plotRescaleY: function (p, data, count) {
        if (p.rescale) {
            if (!p.rescaleCount) {
                p.ymax = -Infinity;
                p.ymin = Infinity;
                p.rescaleCount = this._fps.max;
            } else if (--p.rescaleCount == 0) {
                p.rescale = false;
            }
            for (var i = 0; i < count; i++) {
                var a = data[i * 2];
                var b = data[i * 2 + 1];
                p.ymax = Math.max(p.ymax, a, b);
                p.ymin = Math.min(p.ymin, a, b);
            }
            p.ymin = Math.floor(p.ymin / 10) * 10;
            p.ymax = Math.ceil(p.ymax / 10) * 10;
        }
    },

    drawPower: function (ctx, p) {

        var width = p.width;
        var height = p.height;

        var data = new Float32Array(p.data);
        var count = data.length / 2;
        if (!count)
            return;

        ctx.translate(this.drawMargin, this.drawMargin);
        width -= this.drawMargin * 2;
        height -= this.drawMargin * 2;

        switch (p.type) {
        case 'power':
        case 'power_time':
        case 'mer':
            this.plotRescaleY(p, data, count);
            p.ystep = 10;

            switch (p.type) {
            case 'power':
                p.xmin = this.frequency - this.sample_rate / 2;
                p.xmax = this.frequency + this.sample_rate / 2;
                p.getX = function (v) { return (v / 1e6).toFixed(Math.max(0, 6 - k)); }
                break;
            case 'power_time':
                p.xmin = 0;
                p.xmax = 1e4; // us
                p.getX = function (v) { return v / 1000; };
                break;
            case 'mer':
                p.xmin = 0;
                p.xmax = count;
                p.getX = function (v) { return v; };
                break;
            }
            p.xstep = 0.5;

            var nb = Math.ceil(width / 100); // Every 100px
            var xstep = (p.xmax - p.xmin) / nb;
            var k = Math.floor(Math.log10(xstep));
            var n = Math.ceil(xstep / Math.pow(10, k));
            if (n > 5) n = 5;
            else if (n > 2) n = 2;
            p.xstep = n * Math.pow(10, k);
            break;
        case 'qam':
            p.xmin = -1;
            p.xmax =  1;
            p.ymin = -1;
            p.ymax =  1;
            p.xstep = 0.5;
            p.ystep = 0.5;
            p.getX = function (v) { return v; };
            break;
        }

        // Axis
        var yw = 20;
        var xh = 20;

        width -= yw;
        height -= xh;
        ctx.translate(yw, 0);

        ctx.font = "bold 12px helvetica";
        ctx.fillStyle = '#00FF00';
        ctx.strokeStyle = '#004000';

        // Y axis
        var getY = function (y) { return height - (y - p.ymin) * height / (p.ymax - p.ymin); };

        ctx.beginPath();
        ctx.textAlign = 'right';
        ctx.textBaseline = 'middle';

        var y0 = Math.ceil(p.ymin / p.ystep) * p.ystep;
        for (var y = y0; y <= p.ymax; y += p.ystep) {
            var y1 = getY(y);
            ctx.fillText(y, -2, y1);
            ctx.moveTo(0, y1);
            ctx.lineTo(width, y1);
        }
        ctx.stroke();

        // X axis
        var getX = function (x) { return (x - p.xmin) * width / (p.xmax - p.xmin); };

        ctx.beginPath();
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';

        var x0 = Math.ceil(p.xmin / p.xstep) * p.xstep;
        for (var x = x0; x <= p.xmax; x += p.xstep) {
            var X = getX(x);
            ctx.fillText(p.getX(x), X, height + (xh >> 1));
            ctx.moveTo(X, 0);
            ctx.lineTo(X, height);
        }
        ctx.stroke();

        ctx.strokeStyle = '#00FF00';
        ctx.beginPath();
        ctx.moveTo(0, height);
        ctx.lineTo(width, height);
        ctx.moveTo(0, 0);
        ctx.lineTo(0, height);
        ctx.stroke();


        switch (p.type) {
        case 'power':
        case 'power_time':
            ctx.beginPath();
            ctx.strokeStyle = '#808000';
            for (var i = 0; i < count; i++) {
                var x = i * width / count;
                var y = getY(data[i * 2 + 1]);
                if (i == 0)
                    ctx.moveTo(x, y);
                else
                    ctx.lineTo(x, y);
            }
            ctx.stroke();

            ctx.beginPath();
            ctx.strokeStyle = 'yellow';
            for (var i = 0; i < count; i++) {
                var x = i * width / count;
                var y = getY(data[i * 2]);
                if (i == 0)
                    ctx.moveTo(x, y);
                else
                    ctx.lineTo(x, y);
            }
            ctx.stroke();
            break;
        case 'qam':
            ctx.beginPath();
            ctx.strokeStyle = 'yellow';
            for (var i = 0; i < count; i++) {
                var x = getX(data[i * 2]);
                var y = getY(data[i * 2 + 1]);
                ctx.moveTo(x, y);
                ctx.lineTo(x + 1, y + 1);
            }
            ctx.stroke();
            break;
        case 'mer':
            ctx.beginPath();
            ctx.strokeStyle = '#808000';
            for (var i = 0; i < count; i++) {
                var x = i * width / count;
                var y = getY(data[i * 2 + 1]);
                ctx.moveTo(x, y);
                ctx.lineTo(x + 1, y + 1);
            }
            ctx.stroke();

            ctx.beginPath();
            ctx.strokeStyle = 'yellow';
            for (var i = 0; i < count; i++) {
                var x = i * width / count;
                var y = getY(data[i * 2]);
                ctx.moveTo(x, y);
                ctx.lineTo(x + 1, y + 1);
            }
            ctx.stroke();
            break;
        }
    },

    initPlot: function (ctx, p, rect) {

        ctx.save();
        ctx.translate(rect.x + 0.5, rect.y + 0.5);
        ctx.beginPath();
        ctx.rect(0, 0, rect.w, rect.h);
        ctx.clip();
        p.width = rect.w;
        p.height = rect.h;
        return p;
    },

    endPlot: function (ctx, plot) {
        ctx.restore();
    },

    drawFrame: function () {

        this._redrawPending = false;

        var canvas = this._canvas;
        var ctx = canvas.getContext("2d");
        ctx.save();

        ctx.fillStyle = 'black';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        var plots = this._plots.filter( (p) => { return p.enabled && p.data; });

        lteLogs.aaa = this;

        var width = canvas.width;
        var height = canvas.height;

        /* XXX: compute col/row only on enable change */
        var row = Math.ceil(Math.sqrt(plots.length));
        var col = row - 1;
        if (row * col < plots.length) col++;

        var rect = [];
        var x = 0;
        var y = 0;
        for (var r = 0; r < plots.length;) {
            rect.push({
                x: x,
                y: y,
                w: (width / col) >> 0,
                h: (height / row) >> 0,
            });
            if (++r == col) {
                y += (height / row) >> 0;
                x = 0;
            } else {
                x += (width / col) >> 0
            }
        }

        plots.forEach( (p, i) => {
            this.initPlot(ctx, p, rect[i]);
            this.drawPower(ctx, p);
            this.endPlot(ctx, p);
        });

        ctx.restore();

        this._fps.count++;
        var now = new Date() * 1;
        var diff = now - this._fps.time;
        if (diff >= 5000) {
            //console.log('FPS', Math.round(this._fps.count * 1000 / diff));
            this._fps.count = 0;
            this._fps.time = now;
        }
    },
});

