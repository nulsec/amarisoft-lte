/*
 * Copyright (C) 2012-2024 Amarisoft
 *
 * Amarisoft Web interface 2024-12-13
 */

lteLogs.LOGS_MAX = 2000000;
lteLogs.LOGS_RANGE = null;
lteLogs.LOGS_LAYERS = null;
lteLogs.LOGS_INFO = null;

// Modify tshark path according to your system
const TSHARK_WIN32 = 'c:\\Program Files\\Wireshark\\tshark';
const TSHARK_LINUX = '/usr/bin/tshark'; // On Linux, tshark may be in PATH by default so no need to update

const HFN_WRAP_THRESHOLD = 512;

var LTELog = function (l)
{
    for (var i in l)
        this[i] = l[i];
}

LTELog.prototype.getDataStr = function (cb)
{
    return this.getData().join("\n");
};

LTELog.prototype.getData = function (cb)
{
    return this.data || [];
};

LTELog.prototype.exportInfoPanel = function (cb)
{
    if (!this.data)
        return '&nbsp';

    // External decoding
    if (!this.decoded && lteLogs.mode === 'app') {
        this._decode(cb);
        this.decoded = true;
    }

    return this.getDataStr();
};


LTELog.prototype.getTime = function ()
{
    return lteLogs.ts2time(this.timestamp);
}

LTELog.prototype.exportTextLog = function (short)
{
    switch (this.exportTimeFormat) {
    case 'sec':
        var time = (this.timestamp / 1000).toFixed(3);
        break;
    case 'full':
        var time = lteLogs.ts2time(this.timestamp, true);
        break;
    case 'short':
    default:
        var time = lteLogs.ts2time(this.timestamp);
        break;
    }
    var h = [time, '[' + this.layer + ']'];

    switch (this.dir) {
    case DIR_DL:
        if (layerConfig[this.layer].bidir) {
            var myLayerDir = modelConfig[this.client.config.model].layerDir;
            if (myLayerDir[this.layer].FROM == DIR_DL)
                h.push('FROM');
            else
                h.push('TO');
        } else {
            h.push('DL');
        }
        break;
    case DIR_UL:
        if (layerConfig[this.layer].bidir) {
            var myLayerDir = modelConfig[this.client.config.model].layerDir;
            if (myLayerDir[this.layer].FROM == DIR_UL)
                h.push('FROM');
            else
                h.push('TO');
        } else {
            h.push('UL');
        }
        break;
    default:
        h.push('- ');
        break;
    }

    var indent = '        ';

    var data = this.data ? this.data.slice() : [];

    var msg = this.msg;
    switch (this.layer) {
    case 'RTP': // To be removed
    case 'LICENSE':
    case 'EPDG':
    case 'IKEV2':
    case 'GTPC':
        h.push(this.exportIdHexa(this.ue_id, 0, '-'));
        break;
    case 'COM':
        h.push(this.exportIdHexa(this.ue_id, 0, '-'));
        this.exportLogInfo(h, ':');
        break;
    case 'PROD':
        h.push(this.exportIdHexa(this.ue_id, 0, '-'));
        this.exportLogInfo(h, ':');
        if (this.info === SIM_EVENT || this.info == IP_SIM)
            indent = '';
        break;
    case 'MEDIA':
        h.push(this.exportIdHexa(this.ue_id, 0, '-'));
        this.exportLogInfo(h, '');
        break;
    case 'IPSEC':
    case 'IMS':
        h.push(this.exportIdHexa(this.ue_id, 0, '-'));
        this.exportLogInfo(h, ':');
        break;
    case 'SIP':
        h.push(this.exportIdHexa(this.ue_id, 0, '-'));
        if (this.msg0)
            msg = this.msg0;
        break;
    case 'S1AP':
    case 'NGAP':
        if (this.linkIds) {
            h.push(this.exportIdHexa(this.linkIds.core, 4, '-'));
            h.push(this.exportIdHexa(this.linkIds.ran, 4, '-'));
        }
        break;
    case 'IP':
        this.exportLogUEID(h);
        h.push('len=' + this.ip_len);
        this.exportLogInfo(h, '');
        break;
    case 'PHY':
        this.exportLogUEID(h);
        this.exportLogCell(h);

        h.push(this.exportIdHexa(this.rnti, 4, '   -'));
        if (this.frame !== undefined)
            h.push(('       ' + this.getFrameString()).slice(-7));
        else
            h.push('   -');
        this.exportLogInfo(h, ':');
        if (this.channel === PDCCH)
            indent = "\t";

        for (var i in this.signalRecord) {
            data.push('Link: ' + i + '@' + this.signalRecord[i].offset);
        }
        break;
    case 'RRC':
    case 'MAC':
        this.exportLogUEID(h);
        this.exportLogCell(h);
        this.exportLogInfo(h, ':');
        break;
    case 'NAS':
        this.exportLogUEID(h);
        this.exportLogInfo(h, ':');
        break;
    case 'RLC':
    case 'PDCP':
        this.exportLogUEID(h);
        this.exportLogInfo(h, '');
        break;
    default:
        this.exportLogInfo(h, ':');
        break;
    }
    if (msg)
        h.push(msg);

    h = h.join(' ');
    if (short)
        return h;

    var txt = [h];
    if (data.length)
        txt.push.apply(txt, data.map(function (d) {
            if (!d)
                return '';
            return indent + d.replace(/\n(?!$)/g, '\n' + indent);
        }));
    if (this.marker)
        txt.push(indent + '#GUI.marker=' + this.marker);
    txt.push('');

    return txt.join("\n");
};

LTELog.prototype.exportIdHexa = function (id, size, undef)
{
    if (id === undefined)
        return undef;

    id = id.toString(16);
    if (id.length < size)
        return ('0000000' + id).slice(-size);

    return id;
}

LTELog.prototype.exportLogCell = function (h)
{
    h.push(this.cell !== undefined ?
        ('0' + this.cell.toString(16)).slice(-2) :
        ' -'
    );
}

LTELog.prototype.exportLogUEID = function (h)
{
    h.push(this.exportIdHexa(this.ue_id, 4, '   -'));
}

LTELog.prototype.exportLogInfo = function (h, sep)
{
    if (this.info)
        h.push(lteLogs.id2string(this.info) + sep);
}

LTELog.prototype.getFrameString = function (hfn)
{
    if (hfn && this.hfn > 0)
        return this.hfn + '.' + this.frame + '.' + this.slot;
    return this.frame + '.' + this.slot;
}

LTELog.prototype.hasError = function ()
{
    var tbs = this.tb;
    if (!tbs) return false;

    for (var i = 0; i < tbs.length; i++) {
        var tb = tbs[i];
        if (tb && (tb.error || tb.crc === false)) return true;
    }

    return false;
}

LTELog.prototype.newTB = function (index)
{
    if (!this.tb) this.tb = [];
    this.tb[index] = this.cur_tb = {error: false, crc: undefined, retx: 0, tb_len: 0};
}

LTELog.prototype._decode = function (cb)
{
    switch (this.layer) {
    case 'IMS':
        switch (this.msg) {
        case 'SMS-CP':
            this._decodeBin('nas', 0, this.data.length, cb);
            break;
        }
        break;
    case 'SIP':
        switch (lteLogs.id2string(this.info)) {
        case 'MESSAGE':
            for (var i = 0; i < this.data.length; i++) {
                if (this.data[i] === '') {
                    this._decodeBin('rp', i + 1, this.data.length, cb);
                    break;
                }
            }
            break;
        }
        break;
    case 'IP':
        this._decodeBin('ip', 0, this.data.length, cb);
        break;
    case 'IPSEC':
        if (this.ip_len)
            this._decodeBinIPsec(cb);
        break;
    case 'GTPU':
        this._decodeBin('gtp', 0, this.data.length, cb);
        break;
    case 'S72':
        this._decodeBin('ecpri', 0, this.data.length, cb);
        break;
    }
}

LTELog.prototype._decodeBinIPsec = function (cb)
{
    var c = this.data.indexOf('');
    if (c > 0) {
        var c1 = this.data.slice(0, c);
        var c2 = this.data.slice(c + 1);
    } else {
        c1 = this.data;
        c2 = null;
    }

    this._decodeBin1('ip', c1, function (error, lines1) {
        if (error) {
            cb(this, error);
            return;
        }
        this.data = c1;
        this.data.push.apply(this.data, lines1);

        if (!c2) {
            cb(null);
            return;
        }

        this._decodeBin1('ip', c2, function (error, lines2) {

            if (error) {
                cb(this, error);
                return;
            }
            this.data.push.apply(this.data, c2);
            this.data.push.apply(this.data, lines2);
            cb(null);
        });
    });
};

LTELog.prototype._decodeBin = function (type, from, to, cb)
{
    this._decodeBin1(type, this.data.slice(from, to), 
        function (error, lines) {

            if (lines) {
                lines.unshift(from, to - from); // Insert splice indexes
                this.data.splice.apply(this.data, lines);
            }
            cb(error);

        }
    );
}

LTELog.prototype._decodeBin1 = function (type, logData, cb)
{
    var child = require('child_process');
    var proto, opt, marker, size, output = "";

    var bytes = logData.reduce(function (list, line) {
        var m = line.match(/(\d+):\s+(([\d\sa-z]{2})+)\s+.+/);
        if (m) {
            list.push.apply(list, m[2].trim().split(/\s+/));
        }
        return list;
    }, []).map(function (b) { return parseInt(b, 16); });

    if (!bytes.length)
        return;

    switch (type) {
    case 'ip':
        proto = 101;
        opt = [];
        size = this.ip_len;
        marker = /Raw packet data/;
        break;
    case 'rp':
        proto = 162;
        size = bytes.length;
        opt = ['-o', '"uat:user_dlts:\\"User 15 (DLT=162)\\",\\"gsm_a_rp\\",\\"0\\",\\"\\",\\"0\\",\\"\\""'];
        marker = /DLT: 162, Payload: gsm_a_rp/;
        break;
    case 'nas':
        proto = 162;
        size = bytes.length;
        opt = ['-o', '"uat:user_dlts:\\"User 15 (DLT=162)\\",\\"gsm_a_dtap\\",\\"0\\",\\"\\",\\"0\\",\\"\\""'];
        marker = /DLT: 162, Payload: gsm_a_dtap/;
        break;
    case 'gtp':
        proto = 162;
        size = this.sdu_len;
        opt = ['-o', '"uat:user_dlts:\\"User 15 (DLT=162)\\",\\"gtp\\",\\"0\\",\\"\\",\\"0\\",\\"\\""'];
        marker = /DLT: 162, Payload: gtp/;
        break;
    case 'ecpri':
        proto = 162;
        size = this.sdu_len;
        opt = ['-o', '"uat:user_dlts:\\"User 15 (DLT=162)\\",\\"ecpri\\",\\"0\\",\\"\\",\\"0\\",\\"\\""'];
        marker = /DLT: 162, Payload: ecpri/;
        break;
    default:
        cb.call(this, 'Bad type');
        return;
    }

    size = Math.max(size, bytes.length);

    var pcap_h = Buffer.allocUnsafe(24);
    pcap_h.writeUInt32LE(0xa1b2c3d4, 0); // Magic
    pcap_h.writeUInt16LE(2, 4); // Major
    pcap_h.writeUInt16LE(4, 6); // Minor
    pcap_h.writeUInt32LE(0, 8); // Zone
    pcap_h.writeUInt32LE(0, 12); // Sigfigs
    pcap_h.writeUInt32LE(65535, 16); // Snaplen
    pcap_h.writeUInt32LE(proto, 20); // Network

    var rec_h = Buffer.allocUnsafe(16);
    rec_h.writeInt32LE(0, 0);
    rec_h.writeInt32LE(0, 4);
    rec_h.writeInt32LE(bytes.length, 8);
    rec_h.writeInt32LE(size, 12);

    var data = Buffer.concat([pcap_h, rec_h, new Buffer(bytes)]);

    //var fs = require('fs');
    //fs.writeFile('/tmp/packet.pcap', data);

    switch (process.platform) {
    case 'linux':
        var p = child.spawn('sh', ['-c', 'tee | ' + TSHARK_LINUX + ' -nVr - ' + opt.join(' ')]);
        break;
    case 'win32':
        var p = child.spawn(TSHARK_WIN32, ['-nVr', '-'].concat(opt));
        break;
    default:
        return;
    }

    p.stderr.setEncoding('utf-8');
    p.stderr.on('data', function (chunk) {
        //console.log("STDERR: " + chunk);
    });
    p.on('error', function (error) {
        //console.log('Error:', error);
    });
    p.on('close', (function (error) {
        if (error) {
            if (cb) cb.call(this, error);
            //this.decoded = false;
            return;
        }

        var lines = output.split(/\n/);

        // Remove non intersting part
        for (var i = 0; i < lines.length; i++) {
            if (lines[i].match(marker)) {
                lines = lines.slice(i + 1, lines.length);
                break;
            }
        }
        cb.call(this, null, lines);
    }).bind(this))

    // Out
    p.stdout.setEncoding('utf-8');
    p.stdout.on('data', function (chunk) {
        output += chunk;
    });

    // In
    try {
        //p.stdin.setEncoding('utf-8');
        p.stdin.write(data);
        p.stdin.end();
    } catch (e) {
    }
}

LTELog.prototype.findData = function (regExp)
{
    if (this.data) {
        for (var i = 0; i < this.data.length; i++) {
            var m = this.data[i].match(regExp);
            if (m)
                return m;
        }
    }
    return null;
}


LTELog.prototype.clean = function ()
{
    for (var i in this.signalRecord)
        this.signalRecord[i].array = null;
}

LTELog.prototype.getUE = function ()
{
    if (this.ue_id !== undefined) {
        var ue = this.client.getUE(this.ue_id);
        if (ue)
            return ue;
    }
    return { ue_id: this.ue_id };
};

Object.defineProperty(LTELog.prototype, 'global_ue_id', {
    get: function () {
        if (this.use_global_ue_id)
            return this.getGlobalUEID();

        return this.ue_id;
    }
});

LTELog.prototype.getGlobalUEID = function ()
{
    return this.getUE().ue_id;
};

Object.defineProperty(LTELog.prototype, 'imsi', {
    get: function () {
        return this.getUE().imsi;
    }
});

Object.defineProperty(LTELog.prototype, 'imei', {
    get: function () {
        return this.getUE().imei;
    }
});

LTELog.prototype.getCell = function ()
{
    return this.client.getCell(this.cell);
}

LTELog.prototype.getUECaps = function ()
{
    var ue = this.getUE();
    if (ue.caps) {
        ue.caps.parse();
        if (ue.caps.ready)
            return ue.caps;
    }
    return null;
};

LTELog.prototype.getToolTip = function ()
{
    var info = [];

    switch (this.layer) {
    case 'PHY':
        if (this.frame !== undefined) info.push('Frame: ' + this.getFrameString(true));
        info.push('Cell: ' + this.cell);
        info.push('Channel: ' + lteLogs.id2string(this.channel));
        break;
    }
    info.push('Time: ' + lteLogs.ts2time(this.timestamp));
    info.push(lteLogs.tooltip(this.msg));
    return info.join('</br>');
};

LTELog.prototype.getPRB = function ()
{
    if (!this.prb)
        return null;

    var prb = this.prb.split(',');
    if (this.prb2)
        prb.push.apply(prb, this.prb2.split(','));

    return prb.map(function (r) {
        var r = r.split(':');
        return {start: r[0] | 0, len: (r[1] === undefined ? 1 : r[1] | 0)};
    });
};

LTELog.prototype.getPRBCount = function ()
{
    var n, prbs, i;
    prbs = this.getPRB();
    if (!prbs) {
        /* legacy case (remove) */
        var n = this.l_crb;
        if (this.l_crb2)
            n += this.l_crb2;
    } else {
        n = 0;
        for(i = 0; i < prbs.length; i++)
            n += prbs[i].len;
    }
    return n;
}

LTELog.prototype.clipboardCopy = function (short)
{
    var input = document.getElementById('clipboard');
    input.value = this.exportTextLog(short);
    input.select();
    document.execCommand('copy');
};

LTELog.prototype.isBrowsable = function ()
{
    var data = this.getData();
    if (!data.length)
        return false;

    switch (this.layer) {
    case 'RRC':
    case 'S1AP':
    case 'NGAP':
    case 'X2AP':
    case 'NRPPa':
    case 'LPPa':
    case 'LCSAP':
    case 'LPP':
        if (ASN1.fromGSER(data))
            return true;
        break;
    case 'N7':
    case 'N8':
    case 'N12':
    case 'N13':
    case 'N17':
    case 'N50':
    case 'NL1':
    case 'N5':
    case 'N20':
    case 'N62':
    case 'COM':
    case 'GTPC':
        return true;
    case 'S6':
    case 'S13':
    case 'RX':
    case 'CX':
    case 'NAS':
    case 'IKEV2':
    case 'IPSEC':
    case 'IP':
        return true;
    }

    return false;
}

LTELog.prototype.getBrowseData = function ()
{
    var data = this.getData();

    switch (this.layer) {
    case 'RRC':
    case 'S1AP':
    case 'NGAP':
    case 'X2AP':
    case 'NRPPa':
    case 'LPPa':
    case 'LCSAP':
    case 'LPP':
        return ASN1.fromGSER(data);
    case 'N7':
    case 'N8':
    case 'N12':
    case 'N13':
    case 'N17':
    case 'N50':
    case 'NL1':
    case 'N5':
    case 'N20':
    case 'N62':
        var jsonData = {};
        var step = 0;
        data.forEach( function (line) {
            if (line === 'HEADERS:') {
                jsonData.headers = {};
            } else if (line === 'DATA:') {
                jsonData.data = '?';
            } else if (jsonData.data) {
                try {
                    jsonData.data = JSON.parse(line);
                } catch (e) {
                    jsonData.data = e.toString();
                }
            } else if (jsonData.headers) {
                var m = line.match(/(.+?): (.+)$/);
                if (m)
                    jsonData.headers[m[1]] = m[2];
            }
        });
        break;
    case 'NAS':
    case 'S6':
    case 'S13':
    case 'RX':
    case 'CX':
    case 'IKEV2':
    case 'GTPC':
        return this.text2json(data, 2);
    case 'IPSEC':
    case 'IP':
        return this.text2json(data, 4);
    case 'COM':
        try {
            return JSON.parse(data.join(''));
        } catch (e) {
        }
        break;
    default:
        break;
    }

    return null;
};

LTELog.prototype.browse = function ()
{
    var jsonData = this.getBrowseData();
    if (jsonData) {
        var win = Ext.create('lte.json.win', {
            title: this.layer + ': ' + this.msg,
            jsonData: jsonData,
            expandLevel: 1,
        });
        win.show();
    }
}

LTELog.prototype.text2json = function (lines, indent)
{
    var path  = [{name: 'root', children: [], value: ''}];
    var level = 0;
    var hexa  = null;

    // Build tree
    for (var i = 0; i < lines.length; i++) {
        var line = lines[i];

        var m = line.match(_regExpHexDump);
        if (m) {
            if (!hexa) {
                hexa = { name: 'Hexa dump', children: [] };
                path[0].children.push(hexa);
            }
            hexa.children.push({name: m[1], children: [], value: m[2].replace(/^\s+/, ''), icon: 'icon-logs'});
            continue;
        }
        hexa = null;

        var m = line.match(/^([\s]*)([^\s].*)$/);
        if (!m) continue;
        line = m[2];

        var l = Math.floor(m[1].length / indent) + 1;

        if (l <= level) {
            level = l;
            var parent = path[l - 1];
        } else if (l > level) {
            var parent = path[level];
            level++;
        }

        var node = path[level] = { name: line, children: []};
        parent.children.push(node);

        var m1 = line.match(/^\[(.+)\]$/);
        if (m1) {
            node.icon = 'icon-info';
            node.name = m1[1];
        }

        var v = node.name.match(/^(.+?)(\s*[:=]\s*)(.*)/);
        if (v) {
            node.name = v[1];
            node.value = v[3];
        }
    }

    // Convert and handle duplicate names
    var convert = function (node) {

        var json = {};
        var multi = {};
        node.children.forEach( function (c) {
            var value = convert(c);
            var name  = c.name;
            if (multi[name]) {
                if (!(value instanceof Object))
                    value = Object.defineProperty({}, '__value__', { enumerable: false, value: value });
                Object.defineProperty(value, '__name__', { enumerable: false, value: name });
                name = name + '#' + (multi[name]++);
            } else {
                multi[name] = 1;
            }
            json[name] = value;
        });

        if (node.value)
            Object.defineProperty(json, '__value__', { enumerable: false, value: node.value });
        if (node.icon)
            Object.defineProperty(json, '__icon__', { enumerable: false, value: node.icon });

        return json;
    }
    return convert(path[0]);
}

LTELog.prototype.getTimestamp = function (us)
{
    if (!us)
        return this.timestamp;
    return this.timestamp_us || this.timestamp * 1000;
};

var LTECell = function (cell_id, config)
{
    for (var id in config)
        this[id] = config[id];

    this.cell_id = cell_id;
    this.setRat(this.rat, true);
};

LTECell.prototype.id = 0;
LTECell.prototype.rat = 'lte';
LTECell.prototype.n_rb_dl = 0;
LTECell.prototype.n_rb_ul = 0;
LTECell.prototype.dl_mu = 0;
LTECell.prototype.ul_mu = 0;
LTECell.prototype.mode = 'FDD';
LTECell.prototype.pci = '?';
LTECell.prototype.gain = 0;
LTECell.prototype.is_nr = false; // Shortcut

LTECell.prototype.n_cs_an               = 0;
LTECell.prototype.cyclic_prefix         = 0
LTECell.prototype.delta_pucch_shift     = 2;
LTECell.prototype.n_rb_cqi              = 0;
LTECell.prototype.br_dl_sf_bitmap       = undefined;
LTECell.prototype.nb_dl_sf_bitmap       = undefined;
LTECell.prototype.prach_freq_offset     = 2;
LTECell.prototype.prach_config_index    = 2;

LTECell.prototype.setRat = function (rat, force)
{
    if ((!rat || rat === this.rat) && !force) return;

    switch (rat) {
    case 'nbiot':
        this.n_rb_dl = 2;
        this.n_rb_ul = 12;
        break;
    case 'nr':
        this.is_nr = true;
        break;
    }
    this.rat = rat;
};

LTECell.prototype.getSlotCount = function (ul)
{
    return 10 * (1 << (ul ? this.ul_mu : this.dl_mu));
};

LTECell.prototype.getDLRatio = function ()
{
    var ratio = this._dlRatio;
    if (ratio === undefined) {
        ratio = 1;
        if (this.mode === 'TDD' && this.uldl_config !== undefined) {
            ratio = [4 / 10, 6 / 10, 8 / 10, 7 /10, 8 / 10, 9 / 10, 5 / 10][this.uldl_config];
            // XXX: NR
        }
    }
    this._dlRatio = ratio;
    return ratio;
};

LTECell.prototype.getULRatio = function ()
{
    var ratio = this._ulRatio;
    if (ratio === undefined) {
        ratio = 1;
        if (this.mode === 'TDD' && this.uldl_config !== undefined) {
            ratio = 1 - [4 / 10, 6 / 10, 8 / 10, 7 /10, 8 / 10, 9 / 10, 5 / 10][this.uldl_config];
            // XXX: NR
        }
    }
    this._ulRatio = ratio;
    return ratio;
};

LTECell.prototype.getSlotDiff = function (f0, s0, f1, s1, ul)
{
    var sc = this.getSlotCount(ul);
    var wrap = 1024 * sc;

    var diff = (f0 * sc + s0 - (f1 * sc + s1)) % wrap;
    if (diff < -wrap / 2) diff += wrap;
    if (diff > wrap / 2) diff -= wrap;
    return diff
}

LTECell.prototype.getName = function ()
{
    if (this.label !== undefined)
        return this.label;
    return '#' + this.cell_id;
}

const _regExpPhy = new RegExp(/^([a-f0-9\-]+)\s+([a-f0-9\-]+)\s+([\d\.\-]+) (\w+): (.+)/);
const _regExpInfo1 = new RegExp(/^([\w\-]+): (.+)/);
const _regExpInfo2 = new RegExp(/^([\w]+) (.+)/);
const _regExpParams1 = new RegExp(/\s+/);
const _regExpParams2 = new RegExp(/=|:/);
const _regExpIP = new RegExp(/^(len=\d+)\s+(\S+)\s+(.*)/);
const _regExpIPsec = new RegExp(/^len=(\d+)\s+(.*)/);
const _regExpIKEV2 = new RegExp(/^(\S+)\s+(.*)/);
const _regExpSDULen = new RegExp(/SDU_len=(\d+)/);
const _regExpSIP = new RegExp(/^([:\.\[\]\da-f]+)\s+(\S+) (.+)/);
const _regExpMediaReq = new RegExp(/^(\S+) (.+)/);
const _regExpSignalRecord = new RegExp(/Link:\s([\w\d]+)@(\d+)/);
const _regExpS72 = new RegExp(/^(\d+)\s+(.+)/);

const _regExpCellID = new RegExp(/^([a-f0-9\-]+) (.+)/);
const _regExpRRC_UE_ID = new RegExp(/Changing UE_ID to 0x(\d+)/);
const _regExpRRC_TMSI = new RegExp(/(5G|m)-TMSI '([\dA-F]+)'H/);
const _regExpRRC_NEW_ID = new RegExp(/newUE-Identity (['\dA-FH]+)/);
const _regExpRRC_CRNTI = new RegExp(/c-RNTI '([\dA-F]+)'H/);
const _regExpNAS_TMSI = new RegExp(/m-TMSI = 0x([\da-f]+)/);
const _regExpNAS_5GTMSI = new RegExp(/5G-TMSI = 0x([\da-f]+)/);
const _regExpRRC_BC = new RegExp(/(EUTRA|MRDC|NR|NRDC|UplinkTxSwitch) band combinations/);

const _regExpPDCCH = new RegExp(/^\s*(.+)=(\d+)$/);
const _regExpS1NGAP = new RegExp(/^([\da-f\-]+)\s+([\da-f\-]+) (([^\s]+) .+)/);
const _regExpHexDump = new RegExp(/^([\da-f]+):((\s+[\da-f]{2}){1,16})\s+.{1,16}$/);
const _regExpSkip = new RegExp(/(\d+) logs skipped/);

(function () {

    for (var c in modelConfig) {
        var model = modelConfig[c];

        model.layerDir = {};
        for (var i in layerConfig) {
            model.layerDir[i] = {
                'UL': DIR_UL,
                'DL': DIR_DL,
                'FROM': DIR_DL,
                'TO': DIR_UL,
                '-': DIR_NONE,
            };
        }
    };

    // XXX: could be done base on clientType definition in logs.js
    for (var i in layerConfig) {
        if (i !== 'IMS' && i !== 'CX' &&
            i !== 'RX' && i !== 'S6' &&
            i !== 'S13' && i !== 'SGsAP' &&
            i !== 'SBcAP' && i !== 'N8' &&
            i !== 'N12' && i !== 'N13' &&
            i !== 'N17' && i !== 'N50' &&
            i !== 'MMS' && i !== 'HTTP2' &&
            i !== 'LCSAP' && i !== 'NL1' &&
            i !== 'GTPC' && i !== 'N5' && 
            i !== 'N20' && i != 'N62') {
            modelConfig.MME.layerDir[i].FROM = DIR_UL;
            modelConfig.MME.layerDir[i].TO = DIR_DL;
        }
        modelConfig.IMS.layerDir[i].FROM = DIR_UL;
        modelConfig.IMS.layerDir[i].TO = DIR_DL;
    }
    modelConfig.N3IWF.layerDir.IKEV2.FROM = DIR_UL;
    modelConfig.N3IWF.layerDir.IKEV2.TO = DIR_DL;
    modelConfig.N3IWF.layerDir.IPSEC.FROM = DIR_UL;
    modelConfig.N3IWF.layerDir.IPSEC.TO = DIR_DL;

    modelConfig.ENB.layerDir.TRX.FROM = DIR_UL;
    modelConfig.ENB.layerDir.TRX.TO = DIR_DL;
    modelConfig.ENB.layerDir.S72.FROM = DIR_UL;
    modelConfig.ENB.layerDir.S72.TO = DIR_DL;

    modelConfig.UE.layerDir.GTPU.FROM = DIR_UL;
    modelConfig.UE.layerDir.GTPU.TO = DIR_DL;
    modelConfig.UE.layerDir.S72.FROM = DIR_DL;
    modelConfig.UE.layerDir.S72.TO = DIR_UL;

})();

const PDSCH = lteLogs.string2id('PDSCH');
const PDCCH = lteLogs.string2id('PDCCH');
const EPDCCH = lteLogs.string2id('EPDCCH');
const PUSCH = lteLogs.string2id('PUSCH');
const PUCCH = lteLogs.string2id('PUCCH');
const NPDSCH = lteLogs.string2id('NPDSCH');
const NPUSCH = lteLogs.string2id('NPUSCH');
const NPBCH = lteLogs.string2id('NPBCH');
const BCCH = lteLogs.string2id('BCCH');
const BCCH_BCH = lteLogs.string2id('BCCH-BCH');
const BCCH_NB = lteLogs.string2id('BCCH-NB');
const BCCH_BCH_NB = lteLogs.string2id('BCCH-BCH-NB');
const BCCH_NR = lteLogs.string2id('BCCH-NR');
const BCCH_BCH_NR = lteLogs.string2id('BCCH-BCH-NR');
const ID_HINTS = lteLogs.string2id('HINTS');
const SRS = lteLogs.string2id('SRS');
const CSI = lteLogs.string2id('CSI');
const NTN = lteLogs.string2id('NTN');
const SSB = lteLogs.string2id('SSB');
const SLOT = lteLogs.string2id('SLOT');

const SIM_EVENT = lteLogs.string2id('SIM-Event');
const IP_SIM = lteLogs.string2id('IP-SIM');


var clientList = {

    clients: [],
    ue_id: 0,

    add: function (client) {
        this.clients.push(client);
    },
    remove: function (client) {
        var idx = this.clients.indexOf(client);
        if (idx >= 0) {
            this.clients.splice(idx, 1);

            if (this.clients.length === 0)
                this.ue_id = 0;
        }
    },
    getUEId: function () {
        return '#' + (++this.ue_id);
    },
};



Ext.define("lte.client", {

    constructor: function (config) {
        lteLogs.setLogger(config.name, this);

        this.clientId      = ++lteLogs.lastClientId;
        this.config        = config;
        this._logs         = [];
        this._logCount     = 0;
        this._components   = {};
        this._params       = {cells: {}};
        this._state        = "stop";
        this._hasCell      = false;
        this._hasPhy       = false;
        this._hasData      = false;
        this._hasRNTI      = false;
        this._hasRB        = false;
        this._microseconds = false;
        this._signalRecord = false;
        this.filtered      = false;

        this._resetParserState();

        if (config.enabled) {
            clientList.add(this);
            this.start();
        }

        if (config.model)
            this.setModel(config.model, true);

        this._eventListeners = {};
        this._eventListenerId = 0;
    },

    start: function () {
        this._setState("start");
    },

    stop: function () {
        this._setState("stop");
    },

    destroy: function () {
        if (this.config.enabled)
            this.toggleState();
        this._setState("destroy");
    },

    _resetParserState: function () {

        // this._lastHarq[cell] = [log.ue_id * 32 + harq# => last log]
        this._lastHarq = [];
        this._lastNBHarq = [];

        this._frame = {last: 0, hfn: 0, ts: -1};

        this._tmsi2ue_id = {};
        this._rnti2ue_id = {};

        // Indexed by ue_id:
        // {
        //   ue_id: <ue_id>
        //   caps:  LTECaps
        //   imsi: "IMSI"
        //   imei: "IMEI"
        // }
        this._ueList = {};

        this._lastTS = 0;
        this._tsOffset = 0;
        this._lastCell = null;
    },

    _reset: function () {
        if (this._logCount) {
            this._resetFlag       = true;
            this._logs.length     = 0;
            this._logCount        = 0;
            this._resetParserState();
            this._hasCell         = false;
            this._hasPhy          = false;
            this._hasData         = false;
            this._hasRNTI         = false;
            this._hasRB           = false;
            this._signalRecord    = false;
            lteLogs.updateLogs();
            lteLogs.refreshClientGrid();
        }
    },

    _setState: function (state) {
        if (state !== this._state) {
            this.debug("State change", this._state, state);

            this._state = state;
            switch (state) {
            case "stop":
                this._reset();
                this.closeComponents();
                lteLogs.gridColumnsUpdate();
                break;

            case "start":
            case "connected":
                lteLogs.gridColumnsUpdate();
                break;

            case "loading":
            case "connecting":
                break;

            case "destroy":
                this.closeComponents();
                return;
            }
            lteLogs.refreshClientGrid();
        }
    },

    setError: function (error) {
        this._error = error || '';
        if (error)
            console.error(this.config.name, error);
        this._setState('error');
    },

    getError: function () {
        return this._error;
    },

    registerEventListener: function (type, cb, tag) {
        var id = this._eventListenerId++;
        this._eventListeners[id] = {type: type, cb: cb, tag: tag};
        return id;
    },

    unregisterEventListener: function (id) {
        delete this._eventListeners[id];
    },

    sendEvent: function (event) {

        var type = event.type;
        for (var i in this._eventListeners) {
            var el = this._eventListeners[i];
            if (el.type === type || el.type === '*') {
                el.cb(event);
            }
        }
    },

    setHeaders: function (headers) {

        this.headers = headers;
        var cells = [];

        for (var i = 0; i < headers.length; i++) {
            var info, h = headers[i];

            if (info = h.match(/lte(\w+) version ([\d-]+)/i)) {

                if (!this.config.model) {
                    var model = info[1].toUpperCase();
                    if (modelConfig[model])
                        this.setModel(model);
                }

                this.version = info[2];

            } else if (h.match(/Licensed to/)) {

                this.license = h;

            } else if (info = h.match(/Metadata:(.+)$/)) {
                var metadata = JSON.parse(info[1]);
                this.setModel(metadata.model);

            } else if (info = h.match(/(global_(ran_node|enb)_id)=([\d\.]+)/)) {

                if (!this.config.model)
                    this.setModel('ENB');
                this.setRanId(info[3]);

            // Cell
            } else if (info = h.match(/Cell 0x([a-f\d]+): (.*)/)) {

                var cell = {
                    cell_id: parseInt(info[1], 16),

                    //Consider SIB information acquired when parameters are received directly
                    sib1Decoded: true,
                    sib2Decoded: true,
                };

                var list = info[2].split(/\s+/);
                for (var j in list) {
                    var params = list[j].split("=");
                    cell[params[0]] = this._headerCellParam(params[0], params[1]);
                }

                cells.push(cell);

            // Cell params
            } else if (cells.length) {
                var cell = cells[cells.length - 1];
                if (info = h.match(/([UD]L): (.*)/)) {
                    var dir = info[1];
                    var list = info[2].split(/\s+/);
                    for (var j in list) {
                        var params = list[j].split("=");
                        cell[params[0]] = this._headerCellParam(params[0], params[1]);
                    }
                } else if (info = h.match(/SSB: (.*)/)) {
                    if (!cell.ssb) cell.ssb = [];
                    var ssb = {};
                    var list = info[1].split(/\s+/);
                    for (var j in list) {
                        var params = list[j].split("=");
                        ssb[params[0]] = this._headerCellParam(params[0], params[1]);
                    }
                    if (ssb.symb)
                        cell.ssb.push(ssb);
                }
            }
        }

        for (var i = 0; i < cells.length; i++) {
            this._addCell(cells[i].cell_id, cells[i]);
        }
        lteLogs.refreshClientGrid();
    },

    _headerCellParam: function (p, v) {
        switch (p) {
        case 'br_dl_sf_bitmap':
        case 'nb_dl_sf_bitmap':
        case 'label':
            return v;
        case 'symb':
            if (v === '')
                return null;
            return v.split(/,/).map( (rb) => rb - 0 );
        case 'prb':
            return v.split(/:/).map( (rb) => rb - 0 );
        default:
            if (isNaN(v))
                return v;
            return v - 0;
        }
    },

    /* stop
     * start
     * loading
     * connecting
     * connected
     * error
     */
    getState: function () {
        return this._state;
    },

    hasCell: function () {
        return this._hasCell;
    },

    hasPhy: function () {
        return this._hasPhy;
    },

    hasUs: function () {
        return this._microseconds;
    },

    hasData: function () {
        return this._hasData;
    },

    hasRNTI: function () {
        return this._hasRNTI;
    },

    hasRB: function () {
        return this._hasRB;
    },

    hasSignal: function () {
        return this._signalRecord;
    },

    isRealTime: function () {
        return false;
    },

    isEnabled: function () {
        return this.config.enabled;
    },

    isConfigurable: function () {
        return false;
    },

    getConfig: function (name) {
        return this.config[name];
    },

    setConfig: function (name, value, save) {
        if (value !== undefined)
            this.config[name] = value;
        else
            delete this.config[name];

        if (save)
            lteLogs.saveConfig();
    },

    setEnabled: function (enabled) {
        if (this.config.enabled != enabled) {
            this.toggleState();
        }
    },

    resetLogs: function () {
    },

    toggleState: function () {
        if (!this.config.enabled) {
            this.config.enabled = true;
            clientList.add(this);
            this.start();
        } else {
            clientList.remove(this);
            this.config.enabled = false;
            this.stop();
        }
        lteLogs.refreshClientGrid();
        lteLogs.saveConfig();
    },

    hasLogs: function () {
        return this._logCount > 0;
    },

    getParams: function (id) {
        return this._params[id];
    },

    getLogs: function () {

        if (this._state === "destroy")
            return null;

        var state = {
            logs:    this._logs,
            reset:    this._resetFlag,
        };
        this._resetFlag = false;
        this._logs  = [];
        return state;
    },

    addComponent: function addComponent(id, comp) {
        var prev = this._components[id];
        if (prev)
            prev.close();
        this._components[id] = comp;
    },

    removeComponent: function (id, delOnly) {
        var comp = this._components[id];
        if (comp) {
            delete this._components[id];
            if (!delOnly)
                comp.close();
        }
    },

    getComponent: function getComponent(id) {
        return this._components[id] || null;
    },

    closeComponents: function closeComponents() {

        this.sendEvent({type: 'close'});

        var list = this._components;
        this._components = {}; // Reset first to avoid recursion
        for (var id in list) {
            list[id].close();
        }
    },

    textLogsAdd: function(logs) {

        var t0 = new Date() - 0;

        this.logModelGuess(logs);

        for (var i = 0; i < logs.length; i++) {
            var log = logs[i] = new LTELog(logs[i]);
            /*if (log.data) {
                // Purge empty lines
                while (log.data.length && log.data[log.data.length - 1] === '')
                    log.data.pop();
            }*/

            if (log.signalRecord)
                this._signalRecord = true;

            log.dir = this._dirConvert(log);
        }

        this._logListParse(logs, false);

        this.prof('Load file in', new Date() - t0, 'ms');
        //console.log('Load file in', new Date() - t0, 'ms');
    },

    // Try to guess model from layers
    logModelGuess: function (logs) {

        var modelGuess = this.modelGuess;
        if (modelGuess) {
            for (var i = 0; i < logs.length; i++) {
                var log = logs[i];
                modelGuess[log.layer] = true;
            }

            var mlist = modelList.concat(); // Duplicate

            for (var l in layerConfig) {
                if (!modelGuess[l]) continue;

                var dir = layerConfig[l].dir;
                for (var j = 0; j < modelList.length; j++) {
                    var m = modelList[j];
                    if (!dir[m]) {
                        var idx = mlist.indexOf(m);
                        if (idx >= 0)
                            mlist.splice(idx, 1);
                    }
                }
                if (mlist.length < 2)
                    break;
            }

            if (mlist.length > 0) {
                this.setModel(mlist);
                this.modelGuess = null;
            } else {
                // XXX: parse logs later ?
            }
        }
    },

    logModelGuessInit: function () {

        if (!this.config.model) {
            // Try all models
            if (!this.tryModelHint(modelList)) {
                this.setModel('MME'); // Default
            }

            this.modelGuess = {};
            for (var j in layerConfig) {
                this.modelGuess[j] = false;
            }
        }
    },

    logGetParse: function (msg) {

        var count = this._logCount;

        if (msg.headers)
            this.setHeaders(msg.headers);
        this.logModelGuessInit();

        var us = !!msg.microseconds;
        if (us)
            this._microseconds = true;

        var logs = msg.logs;
        if (logs) {
            this.info("Logs received", logs.length);
            if (logs instanceof Array) {
                this.logModelGuess(logs);

                for (var i = 0, length = logs.length; i < length; i++) {
                    var log = logs[i] = new LTELog(logs[i]);
                    if (us)
                        log.timestamp = Math.floor(log.timestamp_us / 1000);
                    log.msg = log.data.shift()
                    log.dir = this._dirConvert(log);
                    if (log.info)
                        log.info = lteLogs.string2id(log.info);

                    // Look for signal logs
                    if (log.layer === 'PHY') {
                        var data = log.getData();
                        for (var j = data.length; j--;) {
                            var sigRec = data[j].match(_regExpSignalRecord);
                            if (sigRec) {
                                if (!log.signalRecord) {
                                    log.signalRecord = {};
                                    this._signalRecord = true;
                                }
                                log.signalRecord[sigRec[1]] = {offset: sigRec[2] >>> 0};
                                data.splice(j, 1);
                            }
                        }
                    }
                    log.data.forEach( (d, i) => {
                        if (typeof d === 'object')
                            log.data[i] = JSON.stringify(d, null, 2);
                    });
                    logs[i] = log;
                }
                this._logListParse(logs, true);
            }
        }

        if (!count && this._logCount)
            lteLogs.refreshClientGrid();

        // Update only if last request
        if (this._logGetId === msg.message_id)
            this._logGet();
    },

    _logGet: function (params) {
    },

    getModelIcon: function () {
        var model = modelConfig[this.config.model];
        return model ? model.icon : '';
    },

    getClientIcon: function () {
        var icon = this.getModelIcon();
        return icon ? icon : this.clientIcon;
    },

    getColor: function () {
        return this.config.color || null;
    },

    setColor: function (color) {
        if (!color) {
            delete this.config.color;
        } else {
            if (color.match(/^[\da-fA-F]+$/))
                color = '#' + color;
            this.config.color = color;
        }
    },

    getName: function () {
        return this.config.name;
    },

    setName: function (name) {
        this.config.name = name;
    },

    getInfo: function () {

        var info = [this._info];
        if (this.version) info.push('v' + this.version);
        if (this._state === 'error' && this._error) info.push(this._error);

        return info.join(', ');;
    },

    getModel: function () {
        return this.config.model;
    },

    tryModelHint: function (models) {

        var hint = this._modelHint;
        if (hint) {
            for (var i = 0; i < models.length; i++) {
                var model = models[i];

                var mHint = modelConfig[model].modelHint;
                if (!mHint) // No hint, base on model name
                    mHint = new RegExp(model, 'i');

                if (hint.match(mHint)) {
                    return this.setModel(model);
                }
            }
        }
        return false;
    },

    setModel: function (model, force) {

        if (model instanceof Array) {
            if (this.tryModelHint(model))
                return true;

            model = model[0];
        }

        if (model === this.config.model && !force)
            return true;

        this.config.model = model;

        switch (model) {
        case 'ENB':
        case 'N3IWF':
            this.txDir = DIR_DL;
            this.rxDir = DIR_UL;
            this.ranIds = [];
            break;
        case 'UE':
            this.txDir = DIR_UL;
            this.rxDir = DIR_DL;
            break;
        default:
            break;
        }
        if (modelConfig[model]) {
            this._layerDir = modelConfig[model].layerDir;
        } else {
            this._layerDir = {};
        }

        var mainTab = this.getComponent("mainTab");
        if (mainTab)
            mainTab.setIconCls(this.getClientIcon());

        lteLogs.gridColumnsUpdate();
        return true;
    },

    _dirConvert: function (log) {
        var layerDir = this._layerDir[log.layer];
        if (layerDir)
            return layerDir[log.dir];
        return 0;
    },

    setUEError: function (ue, error) {
        if (!ue.errors) {
            ue.errors = [error];
        } else {
            if (ue.errors.indexOf(error) < 0)
                ue.errors.push(error);
        }
    },

    /*
     * UE list
     */
    getUE: function (ue_id) {
        return this._ueList[ue_id];
    },

    getUECaps: function (ue_id) {

        var ue = this.createUE(ue_id);
        if (!ue.caps)
            ue.caps = new LTECaps(ue.ue_id);
        return ue.caps;
    },

    createUE: function (ue_id) {

        var ue = this._ueList[ue_id];
        if (!ue) {
            ue = this._ueList[ue_id] = {
                ue_id: ue_id,
                caps: undefined,
                imsi: undefined,
                imei: undefined,
            };
        }
        return ue;
    },

    getUEByParam: function (name, value) {

        for (var id in this._ueList) {
            var ue = this._ueList[id];
            if (ue[name] === value)
                return ue;
        }
        return null;
    },

    setSameUE: function (log, ue_id) {
        this.setSameUEID(ue_id, log.ue_id);
    },

    setSameUEID: function (id0, id1) {

        var ue0 = this._ueList[id0];
        var ue1 = this._ueList[id1];

        if (ue0 === ue1) {
            if (!ue1) {
                ue1 = this.createUE(id1);
                this._ueList[id0] = ue1;
            }
        } else if (!ue0) {
            this._ueList[id0] = ue1;
        } else if (!ue1) {
            this._ueList[id1] = ue0;
        } else {
            // Update pointers
            this.globalUELink(ue0, ue1);
        }
    },

    globalUELink: function (ueRef, ue1) {
        clientList.clients.forEach( (client) => {
            var found = false;
            for (var id in client._ueList) {
                var ue = client._ueList[id];
                if (ue !== ue1) continue;

                console.log('Update', id, ueRef);
                client._ueList[id] = ueRef;
                found = true;
            }
            if (found) {
                // Merge clientUE in ueRef
                // XXX: merge caps
                if (!ueRef.imsi) ueRef.imsi = ue1.imsi;
                if (!ueRef.imei) ueRef.imei = ue1.imei;
                if (!ueRef.caps) ueRef.caps = ue1.caps;

                if (typeof ueRef.ue_id === 'number') {
                    if (typeof ue1.ue_id === 'string')
                        ueRef.ue_id = ue1.ue_id;
                    else
                        ueRef.ue_id = clientList.getUEId();
                }
                client._ueList[ueRef.ue_id] = ueRef;
            }
        });
    },

    addUERanID: function (log, ran_ue_id, ran_id) {
        // Check duplicate
        if (this._ranIdLinks) {
            for (var i in this._ranIdLinks) {
                var link1 = this._ranIdLinks[i];
                if (link1.ran_id === ran_id && link1.ran_ue_id === ran_ue_id && link1.ue_id === log.ue_id)
                    return;
            }
        }

        var link = {ue_id: log.ue_id, ran_ue_id: ran_ue_id, ran_id: ran_id};

        var ran = this.getRanClient(ran_id);
        if (ran) {
            this.updateUERanID(ran, link);
        } else {
            // Not found, try later
            if (!this._ranIdLinks) this._ranIdLinks = [];
            this._ranIdLinks.push(link);
        }
    },

    updateUERanID: function (ran, link) {

        var ue = this.createUE(link.ue_id);
        var ueRef = ran.createUE(link.ran_ue_id);
        this.globalUELink(ueRef, ue);
    },

    setRanId: function (ran_id) {

        this.ranIds.push(ran_id);

        for (var i = 0; i < clientList.clients.length; i++) {
            var client = clientList.clients[i];
            if (!client._ranIdLinks) continue;

            client._ranIdLinks = client._ranIdLinks.filter( (link) => {
                if (link.ran_id !== ran_id) return true; // Not for me
                client.updateUERanID(this, link);
                return false;
            });
        }
    },

    getRanClient: function (ran_id) {
        for (var i = 0; i < clientList.clients.length; i++) {
            var client = clientList.clients[i];
            if (client.ranIds && client.ranIds.indexOf(ran_id) >= 0)
                return client;
        }
        return null;
    },
    /* end of UE list */


    _setTMSI: function (log, tmsi) {

        tmsi = parseInt(tmsi, 16);
        var ue_id = this._tmsi2ue_id[tmsi];
        if (ue_id) {
            this.setSameUE(log, ue_id);
        } else {
            this._tmsi2ue_id[tmsi] = log.ue_id;
        }
    },

    _setRNTI: function (log, rnti) {

        var m = rnti.match(/'([\dA-F]+)'H/);
        if (m) rnti = parseInt(m[1], 16);
        else   rnti = rnti | 0;

        this._rnti2ue_id[rnti] = log.ue_id;
    },

    _logParsePhy: function (log, msg, ws) {
        var dir = log.dir;
        var tb_swap = 0;

        // WebSocket message or text ?
        if (!ws) {
            var info = msg.match(_regExpPhy);
            if (!info) {
                this.warn("Bad PHY log", log);
                return false;
            }
            log.cell    = parseInt(info[1], 16);
            log.rnti    = parseInt(info[2], 16) || undefined;
            log.channel = info[4];
            var msg     = log.msg = info[5];

            var frame = info[3].split('.');
            log.frame = frame[0] - 0;
            log.slot  = frame[1] - 0;
        }

        if (!this._logSetInfo(log, log.channel)) return false;
        log.channel = log.info;

        if (isNaN(log.cell))
            log.cell = undefined;
        else
            this._lastCell = log.cell;

        // Parse arg=value list
        var args = msg.split(_regExpParams1);
        for (var m = 0, count = args.length; m < count; m++) {
            var param = args[m].split('=');
            var value = param[1];
            param = param[0];

            switch (param) {
            // RB
            case 'n_prb':
            case 'l_crb':
            case 'l_crb2':
            case 'rb_start':
                log[param] = value | 0;
                log.hasRB = true;
                // Avoid SRS
                break;

            case 'prb':
            case 'prb2':
            case 'bitmap':
                log[param] = value;
                log.hasRB = true;
                break;

            case 'symb':
            case 're_symb':
            case 'format':
            case 'chan_symb':
                log[param] = value;
                break;

            case 'cr':
            case 'mer':
            case 'snr':
            case 'freq_shift':
            case 'rssi':
            case 'rsrp':
                log[param] = parseFloat(value);
                break;

            case 'shift':
                log.rb_shift = value | 0;
                log.hasRB = true;
                break;

            case 'p':
                log.rb_p = value | 0;
                log.hasRB = true;
                break;

            case 'ack':
            case 'type':
            case 'nl':
            case 'sequence_index':
            case 'n':
            case 'br':
            case 'rep':
            case 'ru':
            case 'sf':
            case 'L': // XXX proto
            case 'k0':
            case 'k1':
            case 'k2':
            case 'ul_cqi':
            case 'n_ant':
            case 'chan_interp':
            case 'n_ant_pbch':
                log[param] = value | 0;
                break;

            case 'mu_bit':
                var cell = this._getCell(log.cell);
                cell.dl_mu = value | 0;
                cell.ul_mu = value | 0;
                break;

            case 'ber':
                var ber = value.split('/');
                log[param] = ber[0] / ber[1];
                break;

            case 'ri':
                if (log.info === CSI)
                    log[param] = parseInt(value, 10);
                else
                    log[param] = parseInt(value, 2) + 1;
                break;

            case 'cce_index':
                /* take first number before '/' */
                log[param] = value.substr(0, value.indexOf("/")) | 0;
                break;

            case 'tb_swap':
                tb_swap = 1;
                break;

            case 'tb_len':
                if (!log.cur_tb) log.newTB(0);
                log.cur_tb.tb_len = value | 0;
                break;

            case 'crc':
                log.cur_tb.crc = value === 'OK';
                break;

            case 'fs':
                var cell = this._getCell(log.cell);
                cell.mode = value;
                break;

            case 'CW0:':
                log.newTB(tb_swap);
                break;

            case 'CW1:':
                log.newTB(1 - tb_swap);
                break;

            case 'tb_index':
                log.newTB(value | 0);
                break;

            case 'retx':
                if (log.cur_tb)
                    log.cur_tb.retx = value | 0;
                break;

            case 'cqi':
                if (log.info === CSI)
                    log.cqi = parseInt(value, 10);
                else
                    log.cqi = parseInt(value.substring(0,4), 2);
                break;

            case 'harq':
                log.harq = isNaN(value) ? value : value | 0;
                break;

            case 'n_rb_dl':
                var cell = this._getCell(log.cell);
                cell.n_rb_dl = value | 0;
                cell.n_rb_ul = value | 0;
                break;

            case 'epre':
            case 'ta':
                log[param] = value - 0;
                break;

            case 'dci':
                var f = value[0];
                if (f === '0')      log.dci_ul = value;
                else if (f === '1') log.dci_dl = value;
                else if (f === '6') {
                    if (value[2] === '0')      log.dci_ul = value;
                    else if (value[2] === '1') log.dci_dl = value;
                }
                break;

            // NTN
            case 'elevation':
            case 'azimuth':
            case 'ta_ue':
            case 'ta_common':
                log[param] = value - 0;
                break;

            // NB-IoT
            case 'n_sf':
            case 'n_rep':
            case 'n_ru':
            case 'n_sc':
            case 'sc_sp':
            case 'n_sc_start':
            case 'fmt':
                log[param] = value | 0;
                log.hasRB = true;
                break;
            }
        }
        return true;
    },

    _logParseMac: function (log) {
        var ce = '';
        var ext = false;
        var args = log.msg.split(_regExpParams1);
        for (var m = 0, count = args.length; m < count; m++) {

            var arg = args[m];
            var i = arg.indexOf(':');
            if (i >= 0) {
                var ce = arg.substr(0, i);
                arg = arg.substr(i + 1);
                switch (ce) {
                case 'STBSR':
                case 'SBSR':
                case 'LTBSR':
                case 'LBSR':
                    var cell = this._getCell1(log);
                    if (!cell || !cell.is_nr) break;
                    log.ul_buffer_size = 0;
                    break;
                }
            }

            var param = arg.split('=');
            var value = param[1];
            switch (param[0]) {
            case 'ph':
                var cell = this._getCell1(log);
                if (cell) {
                    if (cell.is_nr) {
                        if (value > 55)
                            log.phr = (value - 55) * 2 + 22;
                        else
                            log.phr = value - 33;
                    } else {
                        log.phr = value - 23;
                    }
                }
                break;
            case 'ext':
                var cell = this._getCell1(log);
                if (!cell || cell.is_nr) break;
                switch (ce) {
                case 'TBSR':
                case 'SBSR':
                case 'LBSR':
                    ext = true;
                    break;
                }
                break;
            case 'b':
                var cell = this._getCell1(log);
                if (!cell || cell.is_nr) break;
                switch (ce) {
                case 'TBSR':
                case 'SBSR':
                    if (ext)
                        log.ul_buffer_size = this._lte_ext_bsr_table[value];
                    else
                        log.ul_buffer_size = this._lte_bsr_table[value];
                    break;
                case 'LBSR':
                    if (ext)
                        log.ul_buffer_size = this._lte_ext_bsr_table[value] + this._lte_ext_bsr_table[args[++m]] + this._lte_ext_bsr_table[args[++m]] + this._lte_ext_bsr_table[args[++m]];
                    else
                        log.ul_buffer_size = this._lte_bsr_table[value] + this._lte_bsr_table[args[++m]] + this._lte_bsr_table[args[++m]] + this._lte_bsr_table[args[++m]];
                    break;
                }
                break;
            case 'len':
                this._hasData = true;
                switch (ce) {
                case 'PAD':
                    log.mac_pad = (log.mac_pad | 0) + (value | 0);
                    break;
                case 'LCID':
                    log.mac_len = (log.mac_len | 0) + (value | 0);
                    break;
                }
                break;
            case 'ta':
                log.ta = value - 31;
                break;
            default:
                if (param[0].match(/^bs(\((\d+)\))?$/)) {
                    var cell = this._getCell1(log);
                    if (!cell || !cell.is_nr) break;
                    switch (ce) {
                    case 'STBSR':
                    case 'SBSR':
                        log.ul_buffer_size += this._nr_short_bsr_table[value];
                        break;
                    case 'LTBSR':
                    case 'LBSR':
                        log.ul_buffer_size += this._nr_long_bsr_table[value];
                        break;
                    }
                }
                break;
            }
        }
    },

    _logParseSIB1: function(log) {
        var data = log.getData();
        if (!data.length)
            return;
        
        //Find cell with the preceding PHY log ...
        if (this._lastCell == null)
            return;
        var cell = this._getCell(this._lastCell);
        if (cell.sib1Decoded)
            return;
        
        var asn1 = ASN1.fromGSER(data);
        
        //Try to find BR DL SF bitmap if not already done ...
        if (cell.br_dl_sf_bitmap === undefined) {
            var brAccr13 = ASN1.dig(asn1, 'systemInformationBlockType1', 'nonCriticalExtension', 'nonCriticalExtension' , 'nonCriticalExtension', 'nonCriticalExtension', 'nonCriticalExtension', 'bandwidthReducedAccessRelatedInfo-r13');
            if (brAccr13) {
                var dlBitmap = brAccr13['fdd-DownlinkOrTddSubframeBitmapBR-r13'];
                if (dlBitmap) {
                    //Parse hex or bitstring
                    if (m = dlBitmap.value.match(/\'(\w+)\'H/)) {
                        cell.br_dl_sf_bitmap = parseInt(m[1], 16).toString(2);
                    } else if (m = dlBitmap.value.match(/\'(\w+)\'B/)) {
                        cell.br_dl_sf_bitmap = m[1];
                    }
                    //Extend 10 bits pattern in 40
                    if (cell.br_dl_sf_bitmap && cell.br_dl_sf_bitmap.length == 10) {
                        cell.br_dl_sf_bitmap = cell.br_dl_sf_bitmap + cell.br_dl_sf_bitmap + cell.br_dl_sf_bitmap + cell.br_dl_sf_bitmap;
                    }
                }
            }
        } 
        cell.sib1Decoded = true;
    },

    _logParseSIB : function(log) {
        var data = log.getData();
        if (!data.length)
            return;
        
        //Find cell with the preceding PHY log ...
        if (this._lastCell == null)
            return;
        var cell = this._getCell(this._lastCell);

        //Only check for SIB2 for now ...
        if (cell.sib2Decoded)
            return;
        
        var asn1 = ASN1.fromGSER(data);
        var sib2 = ASN1.dig(asn1, 'systemInformation', 'systemInformation-r8', 'sib-TypeAndInfo', 'sib2');
        if (sib2) {
            if (cell.delta_pucch_shift === undefined ) {
                var pucchCfg = ASN1.dig(sib2, 'radioResourceConfigCommon', 'pucch-ConfigCommon');
                cell.delta_pucch_shift = pucchCfg['deltaPUCCH-Shift'].match(/ds(\d+)/)[1] - 0;
                cell.n_rb_cqi = pucchCfg['nRB-CQI'];
                cell.n_cs_an = pucchCfg['nCS-AN'];
            }

            if (cell.prach_config_index === undefined ) {
                var prachCfg = ASN1.dig(sib2, 'radioResourceConfigCommon', 'prach-Config', 'prach-ConfigInfo');
                cell.prach_config_index = prachCfg['prach-ConfigIndex'];
                cell.prach_freq_offset = prachCfg['prach-FreqOffset'];
            }
            cell.sib2Decoded = true;
        }
    },

    _logListRRC: function (log) {

        switch (log.msg.toLowerCase()) {
        case 'sib1':
            this._logParseSIB1(log);
            break;
        case 'sib':
            this._logParseSIB(log);
            break;
        case 'rrc connection request':
            var m = log.findData(_regExpRRC_TMSI);
            if (m) this._setTMSI(log, m[2]);
            break;

        case 'rrc connection reconfiguration':
            var m = log.findData(_regExpRRC_NEW_ID);
            if (m) this._setRNTI(log, m[1]);
            break;

        case 'rrc connection reestablishment request':
            var m = log.findData(_regExpRRC_CRNTI);
            if (m) this._setRNTI(log, m[1]);
            break;

        case 'ue capability information':
            this.getUECaps(log.ue_id).add(log.getData());
            break;
        }

        switch (log.info) {
        case BCCH_NR:
            var cell = this._getCell(log.cell);
            cell.setRat('nr');
            break;
        }
    },

    _logListNAS: function (log) {

        switch (log.msg.toLowerCase()) {
        case 'attach accept':
            var m = log.findData(_regExpNAS_TMSI);
            if (m) this._setTMSI(log, m[1]);
            break;
        case 'registration accept':
            var m = log.findData(_regExpNAS_5GTMSI);
            if (m) this._setTMSI(log, m[1]);
            break;
        }

        var hints = this._logParseHints(log, {
            ran_ue_id: 0,
            ran_address: ''
        });
        if (hints && hints.ran_ue_id) {
            // RAN ID
            var ranId = hints.global_ran_node_id || hints.global_enb_id;
            if (ranId)
                this.addUERanID(log, hints.ran_ue_id, ranId);
        }
    },

    _logParseHints: function (log, cfg) {
        if (log.info !== ID_HINTS) return null;

        var hints = log.hints = lteLogs.splitArgs(log.msg, cfg || {});

        // IMEISV/IMEI
        var imei = hints.imei;
        if (!imei && hints.imeisv) {
            imei = hints.imeisv.slice(0, -2); // remove sv
        }
        if (imei) {
            var ue = this.getUEByParam('imei', imei);
            if (ue)
                this.setSameUE(log, ue.ue_id);
            else
                ue = this.createUE(log.ue_id);
            ue.imei = imei;
        }

        // IMSI
        var imsi = hints.imsi;
        if (imsi) {
            var ue = this.getUEByParam('imsi', imsi);
            if (ue) {
                // XXX
            } else {
                ue = this.createUE(log.ue_id);
                ue.imsi = imsi;
            }
        }

        return hints;
    },

    _logListPHY: function (log) {

        if (log.hasRB)
            this._hasRB = true;

        this._hasCell = true;
        this._hasPhy = true;

        if (log.rnti !== undefined) {
            this._hasRNTI = true;
            var ue_id = this._rnti2ue_id[log.rnti];
            if (ue_id !== undefined) {
                this.setSameUE(log, ue_id);
                this._rnti2ue_id[log.rnti] = undefined;
            }
        }

        if (isNaN(log.frame)) {
            log.frame = undefined;
        } else {
            var frame = this._frame;
            var ts = log.timestamp;
            if (frame.ts >= 0) {

                var elapsed = ts - frame.ts;
                frame.hfn += Math.floor(elapsed / 10240);

                // Differentiate wrapping from backward log (Can't be too far in the past)
                // by comparing elapsed time to sfn diff
                var diff = log.frame - frame.last;
                if (diff >= 1024 - HFN_WRAP_THRESHOLD) {
                    // |---------------B-|-A-------------B-|
                    //       1: back          2: normal
                    var f1 = (elapsed % 10240) / 10;
                    if (Math.abs(1024 - diff - f1) <= HFN_WRAP_THRESHOLD)
                        frame.hfn--;

                } else if (diff < -HFN_WRAP_THRESHOLD) {
                    // |---------------A-|----B----------a-|
                    frame.hfn++;

                } else if (diff < 0) {
                    // |--------B-A------|--------B--------|
                    //       1: normal        2: wrap
                    var f1 = (elapsed % 10240) / 10;
                    if (Math.abs(diff - f1) > HFN_WRAP_THRESHOLD)
                        frame.hfn++;
                }
            }
            frame.ts = ts;
            frame.last = log.frame;
            log.hfn = frame.hfn;
        }

        // Retransmission needed
        switch (log.channel) {
        case NPDSCH:
            this._logListParseNPDSCH(log);
            break;

        case NPUSCH:
            this._logListParseNPUSCH(log);
            break; 

        case PDSCH:
            if (log.harq >= 0) {
                this._logListParseHarq(log, log.harq);
            }
            break;
        case PUSCH:
            if (log.harq >= 0) {
                this._logListParseHarq(log, log.harq + 16);
            }
            break;
        case NPBCH:
            // UE case
            if (log.dir === DIR_DL) {
                var cell = this._getCell(log.cell);
                cell.setRat('nbiot');
            }
            break;
        case PDCCH:
        case EPDCCH:
            if (log.data) {
                log.data.forEach(function (line) {
                    var m = line.match(_regExpPDCCH);
                    if (m) {
                        var param = m[1];
                        switch (param) {
                        case 'mcs':
                        case 'mcs1':
                            if (log.dci_ul)
                                log.mcs_ul = m[2] - 0;
                            else
                                log.mcs_dl = m[2] - 0;
                            break;
                        case 'mcs2':
                            // XXX
                            break;
                        default:
                            log[param] = m[2] - 0;
                            break;
                        }
                    }
                });
            }
            break;
        }
    },

    _logListParseNPDSCH: function(log) {
        if (!this._lastNBHarq[log.cell])
            this._lastNBHarq[log.cell] = [];
        if (!this._lastNBHarq[log.cell][log.ue_id])
            this._lastNBHarq[log.cell][log.ue_id] = [];

        //Add NPDSCH rep to current HARQ context
        if (log.hasRB && log.harq === undefined && log.tb[0]) {
            this._lastNBHarq[log.cell][log.ue_id].push(log);
        }
    },

    
    _logListParseNPUSCH: function(log) {
        if (!this._lastNBHarq[log.cell])
            this._lastNBHarq[log.cell] = [];
        if (!this._lastNBHarq[log.cell][log.ue_id])
            this._lastNBHarq[log.cell][log.ue_id] = [];

        //NPUSCH format 2 : ACK of all previous NPDSCH rep
        if (log.ack === 0 || log.ack === 1 || log.ack === 2) {
            this._lastNBHarq[log.cell][log.ue_id].map(
                function (l) {
                    l.tb[0].acked = log.ack === 1;
                    l.tb[0].error = !l.tb[0].acked;
                }
            );
            this._lastNBHarq[log.cell][log.ue_id] = [];
            return;
        }

        if (!log.tb)
            return;

        //NPUSCH format 1 : store log for repetition logs and wait for CRC
        this._lastNBHarq[log.cell][log.ue_id].push(log);
        if (log.tb[0].crc !== undefined) {
            this._lastNBHarq[log.cell][log.ue_id].map(
                function (l) {
                     l.tb[0].crc = log.tb[0].crc;
                     l.tb[0].error = !l.tb[0].crc;
                }
            );
            this._lastNBHarq[log.cell][log.ue_id] = [];
        }  
     },

    _logListParseHarq: function (log, harq) {

        if (!log.tb)
            return;

        var id = harq + log.ue_id * 32;
        var lastHarq = this._lastHarq;
        var lastHarqCell = lastHarq[log.cell];
        if (!lastHarqCell)
            lastHarqCell = lastHarq[log.cell] = [];

        var data = log.dir !== DIR_NONE;
        var prev = lastHarqCell[id];
        if (prev) {
            var length = Math.max(log.tb.length, prev.tb.length);
            for (var i = 0; i < length; i++) {
                var tb0 = log.tb[i];
                var tb1 = prev.tb[i];
                if (!tb0) {
                    if (tb1 && data) tb1.acked = true;
                    continue;
                }
                if (!tb1) continue;
                if (tb0.retx > tb1.retx) {
                    if (!tb1.crc) tb1.error = true;
                    if (data) {
                        log.retx_prev = prev;
                        prev.retx_next = log;
                    }
                } else if (!tb0.retx && log.dir !== DIR_NONE) {
                    tb1.acked = true;
                }
            }
        }
        if (data)
            lastHarqCell[id] = log;
    },

    _logParseCellId: function (log, ws) {

        if (!ws) {
            var info = log.msg.match(_regExpCellID);
            if (info) {
                var cell = parseInt(info[1], 16);
                if (!isNaN(cell)) {
                    this._hasCell = true;
                    log.cell = cell;
                }
                log.msg = info[2];
            }
        } else if (log.cell !== undefined) {
            this._hasCell = true;
        }
    },

    _logSetInfo: function (log, info) {
        info = lteLogs.string2id(info);

        // Filter by info
        if (lteLogs.LOGS_INFO !== null && lteLogs.LOGS_INFO.indexOf(info) < 0) {
            return false;
        }
        log.info = info;
        return true;
    },

    _logListParse: function (list, ws) {
        var info;
        var length = list.length;

        for (var i = 0; i < length; i++) {
            var log = list[i];
            log.msg = log.msg + '';

            this._addLog(log);

            // Parse message
            switch (log.layer) {
            case 'PHY':
                if (!this._logParsePhy(log, log.msg, ws)) continue;
                this._logListPHY(log);
                break;

            case 'RRC':
                this._logParseCellId(log, ws);
                var info = log.msg.match(_regExpRRC_UE_ID);
                if (info) {
                    this.setSameUE(log, parseInt(info[1], 16));
                    continue;
                }

                if (info = log.msg.match(_regExpInfo1)) {
                    if (!this._logSetInfo(log, info[1])) continue;
                    log.msg = info[2];

                    this._logListRRC(log);
                }

                if (info = log.msg.match(_regExpRRC_BC)) {
                    try {
                        var data = log.getDataStr();
                        data = JSON.parse(data);
                        this.getUECaps(log.ue_id).setBandComb(data, info[1].toLowerCase());
                    } catch (e) {
                        console.error('Band combination parsing error', e, data);
                    }
                }
                break;
            case 'NAS':
                if (info = log.msg.match(_regExpInfo1)) {
                    if (!this._logSetInfo(log, info[1])) continue;
                    log.msg  = info[2];
                    this._logListNAS(log);
                }
                break;
            case 'MON':
            case 'OTS':
                if (info = log.msg.match(_regExpInfo1)) {
                    if (!this._logSetInfo(log, info[1])) continue;
                    log.msg  = info[2];
                }
                break;
            case 'RLC':
            case 'PDCP':
                if (info = log.msg.match(_regExpInfo2)) {
                    if (!this._logSetInfo(log, info[1])) continue;
                    log.msg  = info[2];
                }
                break;

            case 'IP':
                if (info = log.msg.match(_regExpIP)) {
                    info.shift();
                    log.ip_len = info.shift().split('=')[1] - 0;
                    if (!this._logSetInfo(log, info.splice(0, 1)[0])) continue;
                    log.msg  = info.join(' ');
                    this._hasData = true;
                }
                break;

            case 'IPSEC':
                if (info = log.msg.match(_regExpInfo1)) {
                    if (!this._logSetInfo(log, info[1])) continue;
                    log.msg  = info[2];
                }
                var packet = log.msg.match(_regExpIPsec);
                if (packet) {
                    log.ip_len = packet[1] - 0;
                    this._hasData = true;
                }
                break;

            case 'MAC':
                this._logParseCellId(log, ws);
                this._logParseMac(log);
                break;

            case 'GTPU':
                var sdu_len = log.msg.match(_regExpSDULen);
                if (sdu_len) {
                    log.sdu_len = sdu_len[1] - 0;
                    this._hasData = true;
                }
                break;

            case 'S72':
                if (info = log.msg.match(_regExpS72)) {
                    log.msg = info[2];
                    log.cell = info[1] - 0;
                }
                var args = log.msg.split(_regExpParams1);
                var info = '';
                for (var m = 0; m < args.length; m++) {
                    var param = args[m].split('=');
                    var value = param[1];
                    var name = param[0];
                    switch (name) {
                    case 'len':
                        log.sdu_len = value - 0;
                        break;
                    case 'type':
                        info = value;
                        break;
                    case 'dir':
                        info += '/' + value;
                        break;
                    case 'n_f':
                    case 'frame':
                        log.frame = value - 0;
                        break;
                    case 'n_sf':
                    case 'sf':
                        log.slot = value * 2; // XXX: SCS
                        break;
                    case 'slot':
                        log.slot += (value - 0);
                        break;
                    }
                }
                if (info)
                    log.info = lteLogs.string2id(info);
                break;

            case 'SIP':
                // XXX: fix export
                if (info = log.msg.match(_regExpSIP)) {
                    if (!this._logSetInfo(log, info[2])) continue;
                    log.msg0 = log.msg;
                    log.msg = info[3].replace(/ ue_id=(\d+)/, (function (t, ue_id) {
                        this.setSameUE(log, ue_id - 0);
                        return '';
                    }).bind(this)) + (log.dir === DIR_UL ? ' from ' : ' to ') + info[1];
                }
                break;

            case 'MEDIA':
            case 'RTP': // To be removed
                if (info = log.msg.match(_regExpMediaReq)) {
                    if (!this._logSetInfo(log, info[1])) continue;
                    log.msg = info[2];
                }
                break;

            case 'S1AP':
            case 'NGAP':
                if (info = log.msg.match(_regExpS1NGAP)) {
                    log.msg = info[3];
                    var coreId = parseInt(info[1], 16);
                    var ranId = parseInt(info[2], 16);
                    if (isNaN(coreId)) coreId = undefined;
                    if (isNaN(ranId)) ranId = undefined;
                    log.linkIds = {
                        core: coreId,
                        ran: ranId,
                    };
                    switch (this.config.model) {
                    case 'MME':
                        if (coreId) log.ue_id = coreId;
                        break;
                    default:
                        if (ranId) log.ue_id = ranId;
                        break;
                    }
                }
                break;

            case 'SWU':
            case 'NWU':
                if (info = log.msg.match(_regExpInfo1)) {
                    if (!this._logSetInfo(log, info[1])) continue;
                    log.msg  = info[2];
                }
                break;

            case 'IMS':
                if (info = log.msg.match(_regExpInfo1)) {
                    if (!this._logSetInfo(log, info[1])) continue;
                    log.msg  = info[2];

                    var hints = this._logParseHints(log, { rid: 0, aid: 0 });
                    if (hints) {
                        if (hints.rid)
                            this.setSameUEID(log.ue_id, hints.rid);
                        if (hints.aid)
                            this.setSameUEID(log.ue_id, hints.aid);
                    }
                }
                break;

            case 'EPDG':
            case 'PROD':
            case 'COM':
                if (info = log.msg.match(_regExpInfo1)) {
                    if (!this._logSetInfo(log, info[1])) continue;
                    log.msg  = info[2];

                    var hints = this._logParseHints(log);
                }
                //if (log.msg.match(/'ue_get'/) || log.msg.match(/'stats'/) || log.msg.match(/'log_get'/)) continue;
                if (info = log.msg.match(_regExpSkip)) {
                    log.skip += info[1] - 0;
                }
                break;

            case 'M2AP':
            case 'X2AP':
            case 'XnAP':
            case 'M2AP':
            case 'TRX':
            case 'CX':
            case 'RX':
            case 'S6':
            case 'S13':
            case 'SGsAP':
            case 'SBcAP':
            case 'N8':
            case 'N12':
            case 'N13':
            case 'N17':
            case 'N50':
            case 'N20':
            case 'N62':
            case 'NL1':
            case 'MMS':
            case 'HTTP2':
            case 'LCSAP':
            case 'LPPa':
            case 'LPP':
            case 'NRPPa':
                break;

            default:
                this.warn("Unknown layer", log.layer, log.msg);
                break;
            }

            this._logs.push(log);
            this._logCount++;

        } /* End of list loop */

        if (inlineCache.update(list, true, false)) {
            this._logs = [];
            return;
        }

        if (length)
            lteLogs.updateLogs();
    },

    _addCell: function (id, config) {
        var cell = this._params.cells[id];
        if (cell) {
            this.updateCell(cell, config);
        } else {
            var cell = cell = this._params.cells[id] = new LTECell(id - 0, config);
        }
        return cell;
    },

    updateCell: function (cell, config) {
        if (cell.cell_id !== config.cell_id) {
            console.error('Cell update error', cell, config);
            return false;
        }
        for (var i in config)
            cell[i] = config[i];
        cell.setRat(config.rat);
        return true;
    },

    getCell: function (id) {
        var cell = this._params.cells[id];
        if (!cell)
            cell = new LTECell(id - 0, {label: 'Unknown', mode: '', rat: ''});
        return cell;
    },

    getCells: function () {
        var cells = [];
        for (var id in this._params.cells)
            cells.push(this._params.cells[id]);
        return cells;
    },

    getCellIds: function () {
        if (this._params.cells)
            return Object.keys(this._params.cells);
        return [];
    },

    _getCell: function (id, config) {
        var cell = this._params.cells[id];
        if (cell) {
            for (var i in config) {
                cell[i] = config[i];
            }
            return cell;
        }
        return this._addCell(id, config);
    },

    _getCell1: function (log) {
        return this._params.cells[log.cell] || null;
    },

    saveCell: function (cell) {

        var cell1 = this._params.cells[cell.cell_id];
        if (!cell1) {
            this._addCell(cell.cell_id, cell);
        }
    },

    _addLog: function (log) {

        // Check wrapping
        var timestamp = log.timestamp + this._tsOffset;
        if (timestamp < this._lastTS - 100) {
            console.log('Log wrap by', this._lastTS - timestamp, log);
            timestamp += 86400000;
            this._tsOffset += 86400000;
        }
        this._lastTS = log.timestamp = timestamp;

        log.client = this; // Link

        log.id = globalLogId++;
    },


    _lte_bsr_table: [
        0, 10, 12, 14, 17, 19, 22, 26, 31, 36, 42, 49, 57, 67, 78,
        91, 107, 125, 146, 171, 200, 234, 274, 321, 376, 440, 515,
        603, 706, 826, 967, 1132, 1326, 1552, 1817, 2127, 2490,
        2915, 3413, 3995, 4677, 5476, 6411, 7505, 8787, 10287,
        12043, 14099, 16507, 19325, 22624, 26487, 31009, 36304,
        42502, 49759, 58255, 68201, 79846, 93479, 109439, 128125,
        150000,
        /* Note: we put a large enough values for +infinity, but not
                 so large to avoid overflows when doing additions of buffer
                 sizes */
        100000000,
    ],

    _lte_ext_bsr_table: [
        0, 10, 13, 16, 19, 23, 29, 35, 43, 53 ,65, 80, 98, 120, 147,
        181, 223, 274, 337, 414, 509, 625, 769, 945, 1162, 1429, 1757,
        2161, 2657, 3267, 4017, 4940, 6074, 7469, 9185, 11294, 13888,
        17077, 20999, 25822, 31752, 39045, 48012, 59039, 72598, 89272,
        109774, 134986, 165989, 204111, 250990, 308634, 379519, 466683,
        573866, 705666, 867737, 1067031, 1312097, 1613447, 1984009,
        2439678, 3000000,
        /* Note: we put a large enough values for +infinity, but not
                 so large to avoid overflows when doing additions of buffer
                 sizes */
        100000000
    ],

    _nr_short_bsr_table: [
        0, 10, 14, 20, 28, 38, 53, 74, 102, 142, 198, 276, 384, 535,
        745, 1038, 1446, 2014, 2806, 3909, 5446, 7587, 10570, 14726,
        20516, 28581, 39818, 55474, 77284, 107669, 150000,
        /* Note: we put a large enough values for +infinity, but not
                 so large to avoid overflows when doing additions of buffer
                 sizes */
        100000000
    ],

    _nr_long_bsr_table: [
        0, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 22, 23, 25, 26,
        28, 30, 32, 34, 36, 38, 40, 43, 46, 49, 52, 55, 59, 62, 66, 71,
        75, 80, 85, 91, 97, 103, 110, 117, 124, 132, 141, 150, 160, 170,
        181, 193, 205, 218, 233, 248, 264, 281, 299, 318, 339, 361, 384,
        409, 436, 464, 494, 526, 560, 597, 635, 677, 720, 767, 817, 870,
        926, 987, 1051, 1119, 1191, 1269, 1351, 1439, 1532, 1631, 1737,
        1850, 1970, 2098, 2234, 2379, 2533, 2698, 2873, 3059, 3258, 3469,
        3694, 3934, 4189, 4461, 4751, 5059, 5387, 5737, 6109, 6506, 6928,
        7378, 7857, 8367, 8910, 9488, 10104, 10760, 11458, 12202, 12994,
        13838, 14736, 15692, 16711, 17795, 18951, 20181, 21491, 22885,
        24371, 25953, 27638, 29431, 31342, 33376, 35543, 37850, 40307,
        42923, 45709, 48676, 51836, 55200, 58784, 62599, 66663, 70990,
        75598, 80505, 85730, 91295, 97221, 103532, 110252, 117409, 125030,
        133146, 141789, 150992, 160793, 171231, 182345, 194182, 206786,
        220209, 234503, 249725, 265935, 283197, 301579, 321155, 342002,
        364202, 387842, 413018, 439827, 468377, 498780, 531156, 565634,
        602350, 641449, 683087, 727427, 774645, 824928, 878475, 935498,
        996222, 1060888, 1129752, 1203085, 1281179, 1364342, 1452903,
        1547213, 1647644, 1754595, 1868488, 1989774, 2118933, 2256475,
        2402946, 2558924, 2725027, 2901912, 3090279, 3290873, 3504487,
        3731968, 3974215, 4232186, 4506902, 4799451, 5110989, 5442750,
        5796046, 6172275, 6572925, 6999582, 7453933, 7937777, 8453028,
        9001725, 9586039, 10208280, 10870913, 11576557, 12328006, 13128233,
        13980403, 14887889, 15854280, 16883401, 17979324, 19146385, 20389201,
        21712690, 23122088, 24622972, 26221280, 27923336, 29735875, 31666069,
        33721553, 35910462, 38241455, 40723756, 43367187, 46182206, 49179951,
        52372284, 55771835, 59392055, 63247269, 67352729, 71724679, 76380419,
        81338368,
        /* Note: we put a large enough values for +infinity, but not
             so large to avoid overflows when doing additions of buffer
             sizes */
        100000000,
        0
    ],

    getBinDataBinFile: function (cb) {

        if (this._binFile) {
            cb(this._binFile);
            return true;
        }

        if (this._binFileZip) {
            this._binFileZip.async("uint8array").then((function (data) {
                if (data) {
                    this._binFile = new Uint8Array(data).buffer;
                }
                cb(this._binFile);
            }).bind(this));
            return true;
        }
        return false;
    },

    getBinData: function (cb) {

        if (this.getBinDataBinFile(cb))
            return;

        cb(null);
    },

    _signalDataBinFileDownload: function (signal, cb, binCb) {

        if (this._binFile)
            return this._signalDataBinFileParse(signal, cb);

        if (this._signalDownloadPending) {
            this._signalDownloadPending.push({signal: signal, cb: cb});
            return;
        }
        this._signalDownloadPending = [{signal: signal, cb: cb}];

        this.getBinData(binCb);
    },

    _signalDataBinFileDownloadAsync: function (signal, cb, data) {
    },

    _signalDataBinFileEnd: function () {

        var binFile = this._binFile;
        for (var i = 0; i < this._signalDownloadPending.length; i++) {
            var p = this._signalDownloadPending[i];
            if (binFile)
                this._signalDataBinFileParse(p.signal, p.cb);
            else
                p.cb(null);
        }
        this._signalDownloadPending = null;
    },

    _signalDataBinFileParse: function (signal, cb) {
        this._signalDataParse(signal, cb, this._binFile, signal.offset);
    },

    _signalDataDownload: function (signal, cb) {
        cb(null);
    },

    signalDataGet: function (log, dataCb) {

        var total = Object.keys(log.signalRecord).length;
        var count = 0;
        var error = 0;

        var cb = function (signal) {

            if (!signal.array)
                error++;

            if (++count === total)
                dataCb(error > 0);
        };

        for (var i in log.signalRecord) {
            var signal = log.signalRecord[i];
            if (signal.array)
                cb.call(this, signal, signal.data);
            else
                this._signalDataDownload(signal, cb.bind(this, signal));
        }
    },

    _signalDataParse: function (signal, cb, data, data_offset) {

        var header = new DataView(data, data_offset, 12);

        signal.type = header.getUint32(4, true);
        signal.len = header.getUint32(8, true);

        switch(signal.type) {
        case 0: /* cfloat32 */
            signal.size = signal.len * 8;
            signal.array = new Float32Array(data, data_offset + 12, signal.len * 2);
            break;
        case 1: /* cint16 */
            signal.size = signal.len * 4;
            signal.array = new Int16Array(data, data_offset + 12, signal.len * 2);
            break;
        case 2: /* uint16 */
            signal.size = signal.len * 2;
            signal.array = new Uint16Array(data, data_offset + 12, signal.len);
            break;
        default:
            signal.size = 0;
            signal = null;
            break;
        }

        if (cb)
            cb(signal);
    },

    _createLogParser: function (mode) {

        var t0 = 0;
        //var worker = new Worker('logstext.js?version=' + (new Date() * 1));
        var worker = new Worker('logstext.js?version=2024-12-13');
        worker.onmessage = (function (e) {

            var data = e.data;
            switch (data.type) {
            case 'debug':
                console.log('Parse debug', data.text);
                break;

            case 'headers':
                this.setHeaders(data.headers);
                this.logModelGuessInit();
                break;

            case 'logs.text':
                var overflow = data.logs.length + this._logCount - lteLogs.LOGS_MAX;
                if (overflow > 0)
                    data.logs.splice(data.logs.length - overflow);

                if (data.microseconds)
                    this._microseconds = true;
                this.textLogsAdd(data.logs);

                worker.postMessage({type: 'next', room: lteLogs.LOGS_MAX - this._logCount});
                break;

            case 'end':
                this.parsing = false;
                lteLogs.refreshClientGrid();
                inlineCache.stop(this);
                break;

            case 'error':
                Ext.Msg.alert('Parsing error', data.error);
                break;
            }

        }).bind(this);

        worker.onerror = function (e) {
            console.error("Parsing error: " + e.message + ' at ' + e.filename + ':' + e.lineno);
        };

        this.parsing = true;
        lteLogs.refreshClientGrid();

        // Init
        worker.postMessage({
            type: 'init',
            mode: mode,
            filter: {
                range: lteLogs.LOGS_RANGE,
                layers: lteLogs.LOGS_LAYERS,
                max: lteLogs.LOGS_MAX,
                info: lteLogs.LOGS_INFO
            }
        });

        return {
            worker: worker,
            add: function (bytes, pending) {
                worker.postMessage({type: 'data', data: bytes}, [bytes.buffer]);
            },
            end: function () {
                worker.postMessage({type: 'end'});
            }
        }
    },

    checkFormat: function (bytes) {

        for (var i = 0; i < 8; i++) {
            var byte = bytes[i];
            if (byte < 0x20 && byte !== 0x0a && byte !== 0x0d && byte !== 0x09) return 'binary';
        }
        return 'text';
    },

    _load: {
        state: 'none',
        format: 'unknown',
        bytes: null,
    },

    loadZip: function () {

        var load = this._load;
        var bytes = load.bytes;

        JSZip.loadAsync(bytes, {checkCRC32: true})
            .then((function (zip) {

                load.format = 'zip';

                var files = zip.file(/.*.log/);
                if (!files.length) {
                    this.loadSetText();
                    return;
                }
                this._zipFile = zip;
                this._binFileZip = zip.file(files[0].name + '.bin');

                files[0].async("uint8array").then((function (data) {
                    load.state = 'starting';
                    load.bytes = null;
                    load.format = 'unknown';
                    this.loadAdd(data);
                    this.loadEnd();
                }).bind(this));

            }).bind(this), (function (e) {

                if (load.format !== 'zip' && e.message.match(/corrupted/i)) {
                    load.format = 'zip';
                    if (load.state === 'zip-end') {
                        this.loadZip(load.bytes);
                    }
                } else {
                    // Error
                    load.format = 'text';
                    load.state = 'starting';
                    Ext.Msg.alert('Bad file format', 'File seems corrupted');
                    this.loadAdd(load.bytes);
                    this.loadEnd();
                }

            }).bind(this));
    },

    loadSetText: function () {

        this._load.format = 'text';

        if (this._load.bytes) {
            this.loadAdd(bytes);
            this._load.bytes = null;
        }

    },

    loadStart: function () {

        var load = this._load;
        if (load.state !== 'none') {
            load.canceled = true;
        }

        var load = this._load = {
            state: 'starting',
            format: 'unknown',
            count: 0,
        };

        lteLogs.load(true);
        this._setState('start');
    },

    loadAdd: function (bytes) {

        var load = this._load;

        if (load.state === 'starting') {
            if (load.format === 'unknown')
                load.format = this.checkFormat(bytes);

            if (load.format === 'binary') {
                load.bytes = bytes;
                if (JSZip) {
                    this.loadZip();
                    load.state = 'zip-init';
                    return; // Async
                }
                load.bytes = null;
                load.format = 'text';
            }
            load.count = 0;

            switch (load.format) {
            case 'text':
                load.parser = this._createLogParser(load.format);
                break;
            }
            load.state = load.format;
        }

        switch (load.state) {
        case 'zip-init':
            if (!load.bytes) {
                load.bytes = bytes;
            } else if (load.bytes instanceof Uint8Array) {
                var tmp = new Uint8Array(load.bytes.byteLength + bytes.byteLength);
                tmp.set(load.bytes, 0);
                tmp.set(bytes, load.bytes.byteLength);
                load.bytes = tmp;
            } else {
                load.bytes = Buffer.concat([load.bytes, bytes]);
            }
            break;

        case 'text':
            load.parser.add(bytes, false);
            break;
        }
        load.count++;
    },

    loadEnd: function () {

        var load = this._load;

        switch (load.state) {
        case 'zip-init':
            load.state = 'zip-end';
            if (load.format === 'zip') {
                this.loadZip();
            }
            return;
        case 'text':
            load.parser.end();
            break;
        case 'starting':
            break;
        }
        load.state = 'none';
        lteLogs.load(false);
    },

    exportLogs: function (logs, mode, cb) {

        if (!logs || !logs.length) {
            cb(false);
            return;
        }

        var msg = [];
        var skip = 0;
        logs.forEach( (log) => { skip += log.skip; });
        if (skip > 0)
            msg.push('<b>*** Warning, export has ' + skip + ' logs skipped ***</b>');
        msg.push('Please enter filename:');

        Ext.Msg.prompt('Export logs for ' + this.getName(), msg.join('<br/>'), function (btn, text) {
            if (btn === 'ok')
            this.exportLogs1(logs, mode, text, cb);
            else
                cb(false);

        }, this, false, this.getModel().toLowerCase() + '-export.log');
    },

    exportLogs1: function (logs, mode, filename, cb) {

        lteLogs.load(true);

        var model = this.getModel();

        // Headers + metadata
        var headers = ['# Logs exported on ' + new Date() + ' from GUI version 2024-12-13'].concat(this.headers);

        if (this.isRealTime()) {
            headers.push('# Metadata:' + JSON.stringify({
                model: model,
                version: this.version,
                cells: this.getParams('cells'),
                info: this._info,
                src: this.getName(),
            }));
        }

        var data = headers.map(function (line) { return line + "\n" });
        var i = 0;
        var addLog = (function () {
            for (var j = 0; j < 10000; j++, i++) {
                if (i >= logs.length) {
                    if (JSZip) {
                        switch (mode) {
                        case 'zip':
                            this.getBinData((function (binData) {

                                var zip = new JSZip();
                                zip.file(filename, new Blob(data, { type: 'application/octet-binary' }));
                                if (binData)
                                    zip.file(filename + '.bin', binData);

                                zip.generateAsync({
                                    type: 'blob',
                                    compression: 'DEFLATE',
                                    compressionOptions: {level: 9}
                                }).then(function (zdata) {
                                    lteLogs.exportFile(zdata, filename + '.zip', 'application/octet-binary');
                                    lteLogs.load(false);
                                    cb(true);
                                });
                            }).bind(this));
                            return;
                        }
                    }
                    lteLogs.exportFile(data, filename, 'application/octet-binary');
                    lteLogs.load(false);
                    cb(true);
                    return;
                }

                var txt = logs[i].exportTextLog();
                data.push(new TextEncoder('utf8').encode(txt));
            }
            setTimeout(addLog, 1);
        }).bind(this);

        setTimeout(addLog, 1);
    },
});

const HTTP_NO_CACHE = true;

Ext.define("lte.client.url", {

    extend: 'lte.client',

    clientIcon: 'icon-url',

    constructor: function (config) {
        this.callParent(arguments);
        this._info = config.url;
        this._modelHint = config.url;
    },

    start: function () {

        this._setState("loading");
        lteLogs.load(true);

        /* Get size */
        var index = 0;
        var url = this.config.url;
        if (HTTP_NO_CACHE) {
            url += "?nocache=" + (new Date() - 0);
            index = 4;
        }

        this._httpGet(url, 0, index, (function (data, length) {

            if (!data) {
                switch (length) { // HTTP Error code
                case 404:
                    this.setError('not found');
                    break;
                default:
                    this.setError(length);
                    break;
                }
                lteLogs.load(false);
                return;
            }
            this.config.model = null; // Reset
            this.loadStart();
            if (!length || length === data.length) {
                this.loadAdd(data);
                this.loadEnd();
                return;
            }

            var index = 0;

            /* Download by chunks */
            var nextChunk = (function () {

                var size = Math.min(length - index, this._chunkSize);
                this._httpGet(url, index, size, (function (data1, length1) {
                    this.loadAdd(data1);

                    index += size;
                    if (index === length) {
                        this.loadEnd();
                    } else {
                        nextChunk();
                    }

                }).bind(this));
                return;
            }).bind(this);
            nextChunk();

        }).bind(this));
    },

    getUrl: function () {
        return this.config.url;
    },

    setUrl: function (url) {
        if (this.config.url !== url) {
            this.config.url = url;
            if (this.config.enabled) {
                this.stop();
                this.start();
            }
        }
    },

    _chunkSize: 25 * 1000000,

    _httpGet: function (url, position, size, cb) {

        var xhr = new XMLHttpRequest();
        xhr.open("GET", url);
        if (size > 0)
            xhr.setRequestHeader("Range", "bytes=" + position + "-" + (position + size - 1));
        xhr.responseType = "arraybuffer";

        xhr.onreadystatechange = function () {

            if (xhr.readyState !== 4) return;

            if (xhr.status < 200 || xhr.status >= 300) {
                lteLogs.error("Can't load", url);
                return cb(null, xhr.status);
            }

            var length = 0;
            if (size > 0) {
                var range = xhr.getResponseHeader("Content-Range");
                if (range && (range = range.match(/(\d+)-(\d+)\/(\d+)/))) {
                    length = range[3] - 0;
                }
            } else {
                length = xhr.getResponseHeader("content-length") - 0;
            }

            cb(new Uint8Array(xhr.response), length);

            /*var length = xhr.getResponseHeader("content-length") - 0;
            if (!length) {
                var range = xhr.getResponseHeader("Accept-Ranges");
                if (!range || !range.match(/bytes/)) {

                    lteLogs.warn("File does not accept chunk load0", url);
                    var oneshot = true;
                }
            }
            */
        }
        xhr.send();
    },

    isConfigurable: function () {
        return !this.config.locked;
    },

    _signalDataDownload1: function (signal, cb, url, size) {

        var offset = signal.offset;

        var xhr = new XMLHttpRequest();
        xhr.open('GET', url);
        xhr.setRequestHeader("Range", "bytes=" + offset + "-" + (offset + size - 1));
        xhr.responseType = "arraybuffer";
        xhr.onreadystatechange = (function () {
            if (xhr.readyState !== 4) return;
            this._signalDataParse(signal, cb, xhr.response, 0);
            return;
        }).bind(this);
        xhr.send();
    },

    _signalDataDownload: function (signal, cb) {

        if (this.getBinDataBinFile((function (binFile) {
                this._signalDataParse(signal, cb, binFile, signal.offset);
            }).bind(this))) {
            return;
        }

        var url = this.getUrl() + '.bin';
        var offset = signal.offset;

        // First download header
        var xhr = new XMLHttpRequest();
        xhr.open('GET', url);
        xhr.setRequestHeader("Range", "bytes=" + offset + "-" + (offset + 3));
        xhr.responseType = "arraybuffer";

        xhr.onreadystatechange = (function () {
            if (xhr.readyState !== 4) return;

            if (xhr.status < 200 || xhr.status >= 300) {
                lteLogs.error("Can't load", url);
                return cb(null);
            }

            var header = new DataView(xhr.response, 0, 4);
            this._signalDataDownload1(signal, cb, url, header.getUint32(0, true) + 4);

        }).bind(this);
        xhr.send();
    },
});


Ext.define("lte.client.file", {

    extend: 'lte.client',

    clientIcon: 'icon-logs',

    constructor: function (config) {
        this.callParent(arguments);
        this._info = config.file.name + " (" + config.file.size + "B)";
        this._modelHint = config.file.name;
    },

    getName: function () {
        return this.config.name.split(/\//).pop();
    },

    start: function () {

        this._setState("loading");
        lteLogs.load(true);

        var reader = new window.FileReader();
        reader.onload = (function fileRead(e) {
            var bb = reader.result;

            if (!bb) {
                this.setError('No data');
                lteLogs.load(false);
                return;
            }

            this.loadStart();
            this.loadAdd(new Uint8Array(bb));
            this.loadEnd();

        }).bind(this);

        reader.onerror = (function (e) {
            this.setError(e.toString());
            lteLogs.load(false);
        }).bind(this);

        //reader.readAsText(file);
        reader.readAsArrayBuffer(this.config.file);
    },

    _signalDataDownload: function (signal, cb) {

        this._signalDataBinFileDownload(signal, cb, (function (data) {

            if (data || this._zipFile) {
                this._signalDataBinFileEnd();
                return;
            }

            lteLogs.loadFile({
                cb: function (files)  {
                    if (files) {
                        this._binFile = files[0].data;
                    }
                    this._signalDataBinFileEnd();
                },
                scope: this
            });

        }).bind(this));
    },
});

Ext.define("lte.client.localfile", {

    extend: 'lte.client',

    clientIcon: 'icon-logs',

    _chunkSize: 50 * 1000000,

    constructor: function (config) {
        this.callParent(arguments);
        this._info = config.file;
        this._modelHint = config.file;
    },

    getName: function () {
        return this.config.name.split(/\//).pop();
    },

    start: function () {

        if (inlineCache.start(this))
            return;

        var fs = require('fs');
        var filename = this.config.file;

        fs.open(filename, 'r', (function (err, fd) {
            if (err) {
                Ext.Msg.alert(filename, err);
                this.setError(err);
                lteLogs.load(false);
                return;
            }

            var length = fs.statSync(filename).size;
            var index = 0;

            this.loadStart();
            var nextChunk = (function () {

                var size = Math.min(length - index, this._chunkSize);
                fs.read(fd, Buffer.alloc(size), 0, size, null, (function (err, count, data) {

                    if (err) {
                        this.setError(err);
                        lteLogs.load(false);
                        Ext.Msg.alert(filename, err);
                        return;
                    }

                    this.loadAdd(data);
                    index += size;
                    if (index === length || !this.parsing) {
                        this.loadEnd();
                    } else {
                        nextChunk();
                    }
                }).bind(this));
            }).bind(this);
            nextChunk();

        }).bind(this));
    },

    _signalDataDownload1: function (signal, cb, size, headerMode) {

        if (size > 1e6) {
            cb();
            return; // Protection
        }

        var filename = this.config.file + '.bin';
        var offset = signal.offset;
        var fs = require('fs');

        fs.open(filename, 'r', (function (err, fd) {
            if (err) {
                if (!this.signalDataLoadError) {
                    Ext.Msg.alert(filename, err);
                    this.signalDataLoadError = true;
                }
                cb();
                return;
            }
            fs.read(fd, Buffer.alloc(size), 0, size, offset, (function (err, count, data) {
                if (err) {
                    Ext.Msg.alert(filename, err);
                    return;
                }
                if (headerMode) {
                    var header = new DataView(data.buffer, 0, size);
                    this._signalDataDownload1(signal, cb, header.getUint32(0, true) + 4, false);
                } else {
                    this._signalDataParse(signal, cb, data.buffer, 0);
                }
            }).bind(this));
        }).bind(this));
    },

    _signalDataDownload: function (signal, cb) {

        if (this.getBinDataBinFile((function (binFile) {
                this._signalDataParse(signal, cb, binFile, signal.offset);
            }).bind(this))) {
            return;
        }

        this._signalDataDownload1(signal, cb, 4, true)
    },
});


Ext.define("lte.client.server", {

    extend: 'lte.client',

    clientIcon: 'icon-network2',

    constructor: function (config) {
        this.callParent(arguments);
        this._info = config.address;
        this._msgHandlers = {};
        this._msgHandlers1 = {};
        this._msgFifo = [];
        this._msgHandler = {};
        if (config.info) {
            this._error = config.info;
            this._state = 'error';
        }
        if (config.ots)
            this.clientIcon = 'icon-ama';
    },

    _msgId: 0,

    _msgBatchSize: 100,

    start: function () {
        this._setState("connecting");
        try {
            var addr = this.getAddress();
            if (addr.ip.match(/:/)) // IPv6
                addr.ip = '[' + addr.ip + ']';
            var url = (this.config.ssl ? 'wss://' : 'ws://') + addr.ip + ':' + addr.port;
            var socket = new WebSocket(url);
        } catch (e) {
            this.setError("Can't connect to " + url);
            return;
        };

        socket.onopen    = Ext.Function.bind(this._onSocketOpen, this, [socket], 0);
        socket.onclose   = Ext.Function.bind(this._onSocketClose, this, [socket], 0);
        socket.onmessage = Ext.Function.bind(this._onSocketMessage0, this, [socket], 0);
        socket.onerror   = Ext.Function.bind(this._onSocketError, this, [socket], 0);
        
        socket.binaryType = 'arraybuffer';

        this.addComponent("socket", socket);
        lteLogs.refreshClientGrid();
    },

    resetLogs: function () {
        switch (this.getState()) {
        case 'connected':
            this.sendMessage({message: 'log_reset'}, function (resp) {
                this._reset();
            });
            break;
        default:
            this._reset();
            break;
        }
    },

    stop: function () {
        this._setState("stop");
        this._stopTimers();
    },

    _stopTimers: function () {
        if (this._reconnnectTimer) {
            this.debug("Stop reconnection timer");
            clearTimeout(this._reconnnectTimer);
            this._reconnnectTimer = null;
        }
        if (this._statsTimer) {
            clearTimeout(this._statsTimer);
            this._statsTimer = 0;
            this._resetStats();
        }
        if (this._msgDeferTimer) {
            clearTimeout(this._msgDeferTimer);
            this._msgDeferTimer = 0;
        }
        if (this._readyTimer) {
            clearTimeout(this._readyTimer);
            this._readyTimer = 0;
        }
    },

    _resetStats: function () {
        lteStatsTab.add(this.getName(), {cpu: {global: 0}});
    },

    isPaused: function () {
        return !!this.config.pause;
    },

    isRealTime: function () {
        return true;
    },

    isConfigurable: function () {
        return true;
    },

    // Toggle play/pause
    playPause: function () {
        if (this.config.pause) {
            this.config.pause = false;
            if (this.getState() === "connected")
                this._logGet();
        } else {
            this.config.pause = true;
        }

        lteLogs.saveConfig();
    },

    getAddress: function () {
        var addr = this.config.address;
        if (!addr)
            return null;

        addr = addr.split(/:/);
        var port = addr.pop();
        var ip = addr.join(':');
        if (!ip && this.config.ots)
            ip = location.host; // Workaround
        return { ip: ip, port: port };
    },

    setAddress: function (address, ssl) {
        if (this.config.address !== address || this.config.ssl !== ssl) {
            this.config.address = address;
            this.config.ssl = ssl;
            if (this.config.enabled) {
                this.stop();
                this.start();
            }
        }
    },

    _logGet: function (params) {

        var config = this.config;
        if (config.pause)
            return;

        var layers = {};
        Object.keys(config.logs.layers).forEach(function (l) {
            layers[l] = config.logs.layers[l].filter;
        });
        params = Object.assign({
            timeout: 1,
            min: 64,
            max: 2048,
            layers: layers,
            message: 'log_get',
            headers: this._logCount === 0,
        }, params);

        this._logGetId = this.sendMessage(params, this.logGetParse.bind(this));
    },

    logSet: function (msg, level) {
        this.sendMessage({
            message: "log_set",
            layer: 'PROD',
            level: level || 'debug',
            log: msg,
        });
    },

    sendMessageList: function (msg, cb, error) {

        var length = msg.length;
        var recv   = [];

        var cbs = function (index, resp, id) {
            recv[index] = resp;
            if (!resp.notification)
                length--;

            cb(recv, resp, index, !length);
        }

        for (var i = 0; i < length; i++) {
            recv[i] = null;
            this.sendMessage(msg[i], cbs.bind(this, i), error);
        }
    },

    // cb(resp, message_id)
    sendMessage: function (msg, cb, error) {

        // Check
        var socket = this.getComponent("socket");
        if (!socket || socket.readyState !== socket.OPEN) return;
        if (!msg) return;
        if (typeof cb !== 'function') cb = null;

        var id = msg.message_id = ++this._msgId;
        if (cb)
            this._msgHandlers[id] = {cb: cb, error: error};

        if (this._msgDeferTimer) {
            clearTimeout(this._msgDeferTimer);
            this._msgDeferTimer = 0;
        }

        this.debug(this._info, "Send message", msg);
        if (this._msgFifo.push(msg) < this._msgBatchSize) {
            this._msgDeferTimer = Ext.Function.defer(this._sendMessageNow, 1, this);
        } else {
            this._sendMessageNow();
        }
        return id;
    },

    sendMessageBin: function (msg, data, cb, error) {

        // Check
        var socket = this.getComponent("socket");
        if (!socket || socket.readyState !== socket.OPEN) return;
        if (!msg) return;
        if (typeof cb !== 'function') cb = null;

        var id = msg.message_id = ++this._msgId;
        if (cb)
            this._msgHandlers[id] = {cb: cb, error: error};

        var blob = new Blob([(new TextEncoder()).encode(JSON.stringify(msg) + '\0'), data]);
        this.getComponent("socket").send(blob);
        return id;
    },

    _sendMessageNow: function () {

        if (this._msgFifo.length === 1) {
            var msg = JSON.stringify(this._msgFifo.shift());
        } else {
            var msg = JSON.stringify(this._msgFifo);
            this._msgFifo.length = 0;
        }
        this.debug("Send message", msg);
        this.getComponent("socket").send(msg);
        this._msgDeferTimer = 0;
    },

    getLogsConfig: function() {
        return this.config.logs;
    },

    migrateLogs: function (logs) {
        if (!logs)
            return

        var phy = logs.layers.PHY;
        if (phy) {
            (['signal', 'cch', 'rep', 'dci_size', 'csi', 'cell_meas', 'ntn']).forEach(function (flag) {
                if (logs[flag] === undefined) return;
                if (phy[flag] === undefined)
                    phy[flag] = logs[flag];
                delete logs[flag];
            });
        }
    },

    logsLocked: function () {
        if (this.log_lock)
            return 'locked';
        return this.config.readonly;
    },

    setLogsConfig(logs1, save) {

        var myLogs = this.config.logs;

        if (save && this.logsLocked()) {
            // Only update filters
            for (var l in logs1.layers) {
                myLogs.layers[l].filter = logs1.layers[l].filter;
            }
            lteLogs.saveConfig();
            this._logGet({timeout: 0});
            return;
        }

        // Clone to remove filter
        if (!logs1) {
            var logs = lteLogs.clone(myLogs);
        } else {
            var logs = Ext.Object.merge({}, myLogs, logs1);
        }

        // Reformat (remove filter)
        for (var l in logs.layers) {
            delete logs.layers[l].filter;
        }

        this.sendMessage({message: 'config_set', logs: logs}, function (msg) {
            if (save) {
                this.config.logs = Ext.Object.merge({}, myLogs, logs1);
                lteLogs.saveConfig();
            }
            this._logGet({timeout: 0});
        }, true);
    },

    _onSocketOpen: function (socket) {
        this.info('Connection open: ' + this.config.name);
        this._stopTimers();
        // For older software without ready/authenticate messages
        this._readyTimer = setTimeout(this._onSocketReady.bind(this, socket), 5000);
    },

    _authenticate: function (password, challenge) {

        this.password = null;

        if (crypto.subtle) {
            // Use password as key for hmac
            crypto.subtle.importKey("raw",(new TextEncoder()).encode(password), {name:"hmac", hash: "SHA-256"}, false, ["sign"]).then((function (key) {
                return crypto.subtle.sign('HMAC', key, (new TextEncoder()).encode(challenge));

            }).bind(this)).then((function (buf) {
                var msg = JSON.stringify({
                    message: 'authenticate',
                    // Convert res to hexadecimal string
                    res: Array.from(new Uint8Array(buf)).map(function (i) { return ('0' + i.toString(16)).slice(-2);}).join('')
                });
                this.getComponent("socket").send(msg);
                this.password = password; // Store password

            }).bind(this));
        } else {
            var msg = JSON.stringify({
                message: 'authenticate',
                password: password
            });
            this.getComponent("socket").send(msg);
            this.password = password; // Store password
        }
    },

    _promptPassword: function (msg) {

        var challenge = msg.challenge;
        var submit = (function() {
            var pwd = pass.getValue();
            if (pwd) {
                this._authenticate(msg.type + ':' + pwd + ':' + msg.name, challenge);
                challenge = null;
                win.close();
            }
        }).bind(this);

        var pass = Ext.create("Ext.form.field.Text", {
            fieldLabel: 'Enter password',
            inputType: 'password',
            value: '',
            width: 250,
            readOnly: true,
            allowBlank: false,
            listeners: {
                // Prevent autocomplete
                focus: function () {
                    pass.setReadOnly(false);
                },
                specialkey: function (me, e) {
                    if (e.getKey() == e.ENTER)
                        submit();
                }
            }
        });

        var button = Ext.create('Ext.Button', {
            text: 'Login',
            scope: this,
            margin: '0 0 0 10',
            flex: 1,
            handler: submit
        })

        var win = Ext.create('Ext.window.Window', {
            title: this.getName() + ': ' + (msg.error ? msg.error : 'Authentication required'),
            height: 90,
            width: 350,
            layout: 'hbox',
            modal: true,
            resizeable: false,
            autoShow: true,
            bodyStyle: 'padding: 10px;',
            items: [pass, button],
            listeners: {
                scope: this,
                close: function () {
                    if (challenge)
                        this.toggleState();
                }
            }
        });
    },

    _onSocketMessage0: function (socket, event) {

        this._stopTimers();

        // Parse message
        try {
            var data = event.data;
            var msg = JSON.parse(data);

        } catch (e) {
            this.error("JSON error", e, event, event.data);
            return;
        }

        switch (msg.message) {
        case 'authenticate':
            if (msg.ready) {
                this._onSocketReady(socket);

            } else if (!msg.error && this.password) {
                this._authenticate(this.password, msg.challenge);
            } else if (msg.error) {
                var error = [msg.error];
                if (msg.error === 'Unsecure authentication forbidden') {
                    if (!this.config.ssl)
                        error.push('Use SSL connection');
                }
                Ext.Msg.alert('Authentication failure', error.join('<br/>'), () => {
                    this._promptPassword(msg);
                });
            } else {
                this._promptPassword(msg);
            }
            break;
        case 'ready':
            this._onSocketReady(socket);
            break;
        case 'error':
            this.setError(msg.error);
            break;
        default:
            break;
        }
    },

    _onSocketReady: function (socket) {

        socket.onmessage = Ext.Function.bind(this._onSocketMessage, this, [socket], 0);

        this._msgFifo.length = 0;

        // Check current config
        var myConfig = this.config;
        var firstCon = !myConfig.logs;

        // Get config
        this.sendMessage({message: 'config_get'}, function (config) {

            this.info("Config received");

            this._reset();

            // Set
            this.version = config.version;
            this._name = config.name;
            this.setModel(config.type);
            if (config.profiling)
                this._profilingAvailable = true;

            this.migrateLogs(config.logs);
            this.migrateLogs(myConfig.logs);

            var ro = this.config.readonly;
            if (!ro && config.logs.locked)
                this.log_lock = ro = true;

            if (firstCon) {
                myConfig.logs = config.logs;
            } else if (ro) {
                myConfig.logs = Ext.Object.merge({}, myConfig.logs, config.logs);
            } else {
                myConfig.logs = Ext.Object.merge({}, config.logs, myConfig.logs);
            }

            // Clean up
            var layers = myConfig.logs.layers;
            Object.keys(layers).forEach(function (l) {
                if (config.logs.layers[l] === undefined) {
                    delete layers[l];
                } else if (layers[l].filter === undefined) {
                    if (ro) {
                        layers[l].filter = layers[l].level;
                        if (lteLogs.LOGS_LAYERS && lteLogs.LOGS_LAYERS.indexOf(l) < 0) {
                            layers[l].filter = 'none';
                        }
                    } else {
                        switch (l) {
                        case 'NAS':
                        case 'RRC':
                            layers[l].filter = 'debug';
                            break;
                        case 'EVENT':
                        case 'ALARM':
                        case 'MON':
                            layers[l].filter = 'info';
                            break;
                        case 'PROD':
                            layers[l].filter = 'info';
                            break;
                        default:
                            layers[l].filter = 'warn';
                            break;
                        }
                    }
                };
            });

            this._params.cells = {};
            for (var id in config.cells)
                this._addCell(id, config.cells[id]);
            for (var id in config.nb_cells) {
                config.nb_cells[id].rat = 'nbiot';
                this._addCell(id, config.nb_cells[id]);
            }
            for (var id in config.nr_cells) {
                config.nr_cells[id].rat = 'nr';
                this._addCell(id, config.nr_cells[id]);
            }

            var tab = this._openMainTab(config);
            if (tab && tab.setClientConfig)
                tab.setClientConfig(config);

            this._setState("connected");
            if (firstCon && !myConfig.skipLogMenu) {
                Ext.create('lte.client.config', {
                    client: this,
                    title: 'Please configure logs',
                    firstConnection: true,
                }).show();
            } else if (ro) {
                this._logGet({timeout: 0});
            } else {
                this.setLogsConfig();
            }

            if (this._monitorWindow)
                this._monitorWindow.clientStart();
        });
    },

    _onSocketClose: function (socket, event) {
        this.info("Close socket");

        if (event.code !== 1000 && this._state === 'error') {
            this.setError('Error code ' + event.code + ', see rfc6455 section-7.4.1');

            if (this.config.ots) {
                Ext.Ajax.request({
                    url: 'loglist.php?comp=' + this.config.comp,
                    scope: this,
                    success: function (response, opts) {
                        try {
                            var config = JSON.parse(response.responseText);
                            if (config && typeof config.address === 'string' && config.address) {
                                this.config.address = config.address;
                                this._error = config.info;
                                lteLogs.refreshClientGrid();
                            }
                        } catch (e) {
                        }
                    }
                });
            }
        }

        var curSocket = this.getComponent("socket");

        if (curSocket === socket) {
            lteLogs.refreshClientGrid();
            this._stopTimers();
            this.closeComponents();
            curSocket = null;

            if (this.getState() === 'connected') {
                if (this._monitorWindow)
                    this._monitorWindow.clientStop();
            }

        } else {
            this.warn("Close deffered");
        }

        if (!curSocket && this.config.enabled) {
            this.debug("Start reconnection timer");
            if (this.getState() !== "stop")
                this._setState("error");
            this._reconnnectTimer = setTimeout(this.start.bind(this), this.config.reconnectDelay || 15000);
        }
    },

    _onSocketError: function (socket, event) {
        this.setError(event.error);
        this.warn(event);
    },

    _onSocketMessage: function (socket, event) {

        // Parse message
        try {
            var data = event.data;
            if (data instanceof ArrayBuffer) {
                var len = (new Uint32Array(data.slice(0,4)))[0];
                var msg = JSON.parse(String.fromCharCode.apply(null, new Int8Array(data.slice(4, 4 + len))));

                if (msg.binary) {
                    msg.__binary__ = data.slice(4 + len);
                } else {
                    // Skip old useless size information
                    msg.__binary__ = data.slice(4 + len + 4);
                }

            } else {
                var msg = JSON.parse(data);
            }

        } catch (e) {
            this.error("JSON error", e, event, event.data);
            console.error("JSON error", e, event, event.data);
            return;
        }

        // Check message handler by id
        var id = msg.message_id;
        var handler = this._msgHandlers[id];
        if (handler) {
            // Delete if not progress message
            if (!msg.notification)
                delete this._msgHandlers[id];

            if (msg.error) {
                if (!handler.error)
                    Ext.Msg.alert(this.config.name, '' + msg.error);
                else if (typeof handler.error === 'function')
                    handler.error(msg.error);
                else if (handler.error === true)
                    handler.cb.call(this, msg, id);
                return;
            }

            this.debug("Response received", id, msg);
            return handler.cb.call(this, msg, id);
        }

        // Check message handler by name
        var name = msg.message;
        var handler = this._msgHandlers1[name];
        if (handler)
            return handler.call(this, msg);

        switch (name) {
            case "ue_update":
                break;

            default:
                this.error("Unknown message", name, msg);
                break;
        }
    },

    setMessageHandler: function (names, cb) {
        this.sendMessage({message: 'register', 'register': names});
        if (typeof names === 'string')
            names = [names];
        for (var i in names)
            this._msgHandlers1[names[i]] = cb;
    },

    unsetMessageHandler: function (names) {
        this.sendMessage({message: 'register', 'unregister': names});
        if (typeof names === 'string')
            names = [names];
        for (var i in names)
            delete this._msgHandlers1[names[i]];
    },

    _openMainTab: function (config) {

        switch (this.config.model) {
        case 'MME':
        case 'ENB':
        case 'IMS':
        case 'UE':
        case 'LICENSE':
        case 'MONITOR':
        case 'MCC':
        case 'VIEW':
            break;
        default:
            return;
        }

        // Already instanciated ?
        if (this.getComponent("mainTab"))
            return;

        var tab = Ext.create('lte.' + this.config.model.toLowerCase() + '.tab', {
            'title': this.config.name,
            'iconCls': this.getClientIcon(),
            'client': this,
        });
        lteLogs.addTab(tab, this.config.active);

        this.addComponent("mainTab", tab);

        this._updateStats(true);
        return tab;
    },

    _statsPolldelay: 1000,

    setRefreshDelay: function (delay) {
        this._statsPolldelay = delay;
    },

    getRefreshDelay: function () {
        return this._statsPolldelay;
    },

    _updateStats: function (first) {

        var msg = {message: 'stats'};
        var tab = this.getComponent("mainTab");
        if (tab && tab.statsPrepare) tab.statsPrepare(msg);

        this.sendMessage(msg, (function (resp) {

            var tab = this.getComponent("mainTab");
            if (!tab) return;

            // Schedule next
            this._statsTimer = Ext.Function.defer(this._updateStats, this.getRefreshDelay(), this);

            // First call will reset stats
            if (first) {
                this._resetStats();
                return;
            }

            this.sendEvent({type: 'stats', data: resp});

            lteStatsTab.add(this.getName(), resp);

        }).bind(this));
    },

    profileReset: function () {
        if (this._profilingAvailable)
            this.sendMessage({message: 'prof_reset'}, function () {});
    },
    profileDump: function () {
        if (this._profilingAvailable)
            this.sendMessage({message: 'prof_dump'}, function () {});
    },

    _signalDataDownload: function (signal, cb) {
        this.sendMessage({message: 'log_bin_get', offset: signal.offset}, function (resp) {
            if (resp.__binary__) {
                this._signalDataParse(signal, cb, resp.__binary__, 0);
            } else {
                cb();
            }
        }, function (error) { console.log(error); });
    },

    setSignalViewer: function (win) {

        var comp = this.getComponent('signal');

        if (win) {
            if (comp) {
                console.log('Signal viewer already set');
                return false;
            }
            this.signalViewer = win;

            this.setLogsConfig({
                layers: {
                    PHY: {
                        level: 'debug',
                        signal: true,
                    }
                }
            });
            this.addComponent('signal', win);

            this.setMessageHandler(win.signals, (function (msg) {

                // Generate log
                var log = new LTELog({
                    timestamp: msg.timestamp,
                    layer: msg.layer,
                    dir: this._dirConvert(msg),
                    data: msg.data
                });
                log.signalRecord = {};
                var signal = log.signalRecord[msg.label] = {offset: 0};
                this._signalDataParse(signal, (signal1) => {
                        log.channel = msg.channel;
                        log.ue_id = msg.ue_id;
                        log.client = this;
                        if (this._logParsePhy(log, msg.data, true)) {
                            this.signalViewer.addLog(log);
                        }
                    }, msg.__binary__, 0);
            }).bind(this));
            return true;
        }

        if (comp) {
            this.unsetMessageHandler(this.signalViewer.signals);
            this.setLogsConfig();
            this.removeComponent('signal', true);
            this.signalViewer = null;
            return true;
        }

        return false;
    },

});




// List all potential properties to use inline JS caching
var inlineCache = {
    on: false,
    list: {},
    clients: [],
    client: null,

    start: function (client) {
        if (!this.on)
            return false;

        if (this.client) {
            this.clients.push(client);
            return true;
        }

        console.log("Start " + client.getName() + ' (' + this.clients.length + ' pendings)');
        this.client = client;
        return false;
    },

    stop: function (client) {
        if (!this.on)
            return;

        this.client = null;

        var client = this.clients.shift();
        if (client) {
            client.start();
        } else {
            this.dump();
        }
    },

    update: function (logs) {
        if (!this.on)
            return false;

        var props = this.list;
        for (var i = 0; i < logs.length; i++) {
            var log = logs[i];
            for (var id in log) {
                if (typeof log[id] === 'function') continue;
                props[id] = true;
            }
        }
        return true;
    },

    get: function (force) {
        this.on = true;
        this.update(lteLogs.getLogs());
        this.dump(force);
    },

    dump: function (force) {
        console.log("### Not found ###");
        var ids = Object.keys(this.list);
        ids.sort();
        this.cmp(ids, LTELog.prototype, force);

        console.log("### Deprecated ###");
        ids = [];
        for (var id in LTELog.prototype) {
            if (typeof LTELog.prototype[id] !== 'function')
                ids.push(id);
        }
        ids.sort();
        this.cmp(ids, this.list);
    },

    cmp: function (ids, ref, force) {
        for (var i = 0; i < ids.length; i++) {
            var id = ids[i];

            var v = undefined;
            if (ref.hasOwnProperty(id)) {
                if (!force) continue;
                v = LTELog.prototype[id];
                if (typeof v === "string") v = "\"" + v + "\"";
            }
            console.log("LTELog.prototype." + id + " = " + v + ";");
        }
    },
};



LTELog.prototype.ue = undefined;

LTELog.prototype.timestamp = 0;
LTELog.prototype.layer = undefined;
LTELog.prototype.dir = undefined;
LTELog.prototype.msg = undefined;
LTELog.prototype.skip = 0;

LTELog.prototype.info    = undefined;
LTELog.prototype.ue_id   = undefined;
LTELog.prototype.rnti    = undefined;
LTELog.prototype.data    = undefined;
LTELog.prototype.idx     = undefined;
LTELog.prototype.level   = undefined;
LTELog.prototype.client  = null;
LTELog.prototype.id      = -1;
LTELog.prototype.ack     = undefined;
LTELog.prototype.decoded = false;
LTELog.prototype.marker  = undefined;
LTELog.prototype.logIndex = 0;
LTELog.prototype.hints = undefined;

LTELog.prototype.exportTimeFormat = localStorage.exportTimeFormat || '';

LTELog.prototype.beta_offset_ind = undefined;
LTELog.prototype.bwp = undefined;
LTELog.prototype.chan_interp = undefined;
LTELog.prototype.chan_symb = undefined;
LTELog.prototype.cif = undefined;
LTELog.prototype.downlink_power_offset = undefined;
LTELog.prototype.flag_for_paging = undefined;
LTELog.prototype.fmt = undefined;
LTELog.prototype.freq_hopping = undefined;
LTELog.prototype.lsb_sfn = undefined;
LTELog.prototype.mod_override = undefined;
LTELog.prototype.new_data_indicator2 = undefined;
LTELog.prototype.nl = undefined;
LTELog.prototype.pdcch_order = undefined;
LTELog.prototype.pdsch_re_mapping_qcl = undefined;
LTELog.prototype.pmi_confirmation = undefined;
LTELog.prototype.prach_mask_index = undefined;
LTELog.prototype.preamble_index = undefined;
LTELog.prototype.precoding_info = undefined;
LTELog.prototype.ra_pb_idx = undefined;
LTELog.prototype.rate_matching = undefined;
LTELog.prototype.re_symb = undefined;
LTELog.prototype.resource_allocation_header = undefined;
LTELog.prototype.ru = undefined;
LTELog.prototype.rv_idx2 = undefined;
LTELog.prototype.sf = undefined;
LTELog.prototype.short_msg_ind = undefined;
LTELog.prototype.si_indicator = undefined;
LTELog.prototype.sri = undefined;
LTELog.prototype.ssb_index = undefined;
LTELog.prototype.sul_ind = undefined;
LTELog.prototype.tb_swap_flag = undefined;
LTELog.prototype.ul_index = undefined;

// PHY
LTELog.prototype.n       = undefined;
LTELog.prototype.br      = undefined;
LTELog.prototype.cell    = undefined;
LTELog.prototype.channel = undefined;
LTELog.prototype.frame   = undefined;
LTELog.prototype.slot    = undefined; // = subframe
LTELog.prototype.hfn     = 0;
LTELog.prototype.tb      = undefined; // Transport blocks
LTELog.prototype.cur_tb  = undefined;
LTELog.prototype.cqi     = undefined;
LTELog.prototype.ul_cqi  = undefined;
LTELog.prototype.harq    = undefined;
LTELog.prototype.rep     = 0;
LTELog.prototype.format  = undefined;
LTELog.prototype.signalRecord = undefined;
LTELog.prototype.cce_index = undefined;
LTELog.prototype.L       = undefined;
LTELog.prototype.dci     = undefined;
LTELog.prototype.k0      = 0;
LTELog.prototype.k1      = undefined;
LTELog.prototype.k2      = 4;

LTELog.prototype.csi_request = undefined;
LTELog.prototype.dci_dl = undefined;
LTELog.prototype.dci_sf_repetition_number = undefined;
LTELog.prototype.dci_ul = undefined;
LTELog.prototype.filtered = undefined;
LTELog.prototype.frequency_hopping = undefined;
LTELog.prototype.harq_ack_offset = undefined;
LTELog.prototype.hopping_flag = undefined;
LTELog.prototype.index = undefined;
LTELog.prototype.mcs_dl = undefined;
LTELog.prototype.mcs_ul = undefined;
LTELog.prototype.new_data_indicator1 = undefined;
LTELog.prototype.linkIds = undefined;
LTELog.prototype.repetition_number = undefined;
LTELog.prototype.retx_next = undefined;
LTELog.prototype.retx_prev = undefined;
LTELog.prototype.rv_idx1 = undefined;
LTELog.prototype.srs_request = undefined;
LTELog.prototype.symb = undefined;
LTELog.prototype.tpc_command = undefined;

LTELog.prototype.type    = undefined;
LTELog.prototype.snr     = undefined;
LTELog.prototype.ber     = undefined;
LTELog.prototype.mer     = undefined;
LTELog.prototype.ta      = undefined;
LTELog.prototype.ri      = undefined;
LTELog.prototype.epre    = undefined;
LTELog.prototype.sequence_index = undefined;

LTELog.prototype.antenna_ports = undefined;
LTELog.prototype.cr = undefined;
LTELog.prototype.cyclic_shift = undefined;
LTELog.prototype.dai = undefined;
LTELog.prototype.dci_len = undefined;
LTELog.prototype.distributed_vrb = undefined;
LTELog.prototype.dmrs_seq_init = undefined;
LTELog.prototype.harq_feedback_timing = undefined;
LTELog.prototype.harq_process = undefined;
LTELog.prototype.ndi = undefined;
LTELog.prototype.ndi1 = undefined;
LTELog.prototype.pucch_rsc = undefined;
LTELog.prototype.rb_alloc_type = undefined;
LTELog.prototype.rv_idx = undefined;
LTELog.prototype.tb_scaling = undefined;
LTELog.prototype.time_domain_rsc = undefined;
LTELog.prototype.ul_sch_indicator = undefined;
LTELog.prototype.vrb_to_prb_map = undefined;

// MAC
LTELog.prototype.phr     = undefined;
LTELog.prototype.ul_buffer_size = undefined;
LTELog.prototype.mac_pad  = undefined;
LTELog.prototype.mac_len  = undefined;

// GTP
LTELog.prototype.sdu_len  = undefined;

// IP
LTELog.prototype.ip_len  = undefined;

// RB
LTELog.prototype.n_prb    = undefined;
LTELog.prototype.l_crb    = undefined;
LTELog.prototype.l_crb2   = undefined;
LTELog.prototype.rb_start = undefined;
LTELog.prototype.prb      = undefined;
LTELog.prototype.bitmap   = undefined;
LTELog.prototype.rb_shift = undefined;
LTELog.prototype.rb_p     = undefined;
LTELog.prototype.hasRB    = false;

// IoT
LTELog.prototype.n_sf       = undefined;
LTELog.prototype.n_rep      = undefined;
LTELog.prototype.n_ru       = undefined;
LTELog.prototype.n_sc       = undefined;
LTELog.prototype.sc_sp      = undefined;
LTELog.prototype.n_sc_start = undefined;


Ext.define("lte.client.test", {

    extend: 'lte.client',

    clientIcon: 'icon-ama',

    constructor: function (config) {
        this.callParent(arguments);
    },

    start: function () {

        this._setState("start");
        for (var i in layerConfig) {
            var log = new LTELog({
                timestamp: 0,
                layer: i,
                msg: 'Test ' + i,
                data: [],
            });
            this._addLog(log);
            this._logs.push(log);
        }
        lteLogs.updateLogs();
    },
});


