/*
 * Copyright (C) 2019-2024 Amarisoft
 *
 * Amarisoft Web interface 2024-12-13
 * LTE Tools
 */

/*
 * Capabilities
 */
var LTECaps = function (ue_id)
{
    this.ue_id = ue_id;
    this.bands = [];
    this.category = undefined;
    this.category_dl = undefined;
    this.category_ul = undefined;

    this._data = [];
    this._count = 0;
    this.band_comb = [];
    this.asn1 = [];
}

LTECaps.prototype.ready = false;

LTECaps.prototype.UE_CAPS_MIMO = {'twoLayers': 2, 'fourLayers': 4, 'eightLayers': 8};

LTECaps.prototype.getCategory = function ()
{
    var cat = [];
    if (this.category_dl !== undefined)
        cat.push('DL=' + this.category_dl);
    if (this.category_ul !== undefined)
        cat.push('UL=' + this.category_ul);

    if (cat.length > 0)
        return cat.join(', ');

    if (this.category !== undefined)
        return this.category + '';

    return '?';
};

LTECaps.prototype.add = function (data)
{
    // Store pending data
    if (data && data instanceof Array && data.length > 0) {
        this._data.push(data);
    }
};

LTECaps.prototype.parse = function ()
{
    while (this._data.length > 0) {
        this._count++;
        this.ready = true;
        this._parse(ASN1.fromGSER(this._data.shift()));
    }
};

LTECaps.prototype._parseR13 = function (asn1)
{
    var root = ASN1.dig(asn1, 'ueCapabilityInformation-r13', 'ueCapabilityInformation-r13', 'ue-Capability-Container-r13');
    if (root) {
        // Category
        this.category = root['ue-Category-NB-r13'];

        var bands = ASN1.dig(root, 'rf-Parameters-r13', 'supportedBandList-r13');
        if (bands) {
            this.bands = bands.map(function (b) {
                return {band: b['band-r13']};
            });
        }
    }
};

LTECaps.prototype._parse = function (asn1)
{
    this.asn1.push(asn1);

    asn1 = ASN1.dig(asn1, 'message', 'c1');

    var info = ASN1.dig(asn1, 'ueCapabilityInformation', 'criticalExtensions');
    if (info) {
        var ratList = ASN1.dig(info, 'c1', 'ueCapabilityInformation-r8', 'ue-CapabilityRAT-ContainerList') || [];
        var ratList1 = ASN1.dig(info, 'ueCapabilityInformation', "ue-CapabilityRAT-ContainerList");
        if (ratList1 instanceof Array)
            ratList.push.apply(ratList, ratList1);

        ratList.forEach( (rat) => {
            switch (rat['rat-Type']) {
            case 'eutra':
                this._parseRatEUTRA(rat['ueCapabilityRAT-Container']);
                break;
            case 'nr':
                this._parseRatNR(rat['ueCapabilityRAT-Container']);
                this._parseRatNR(rat['ue-CapabilityRAT-Container']);
                break;
            case 'eutra-nr':
                this._parseRatEUTRA_NR(rat['ueCapabilityRAT-Container']);
                break;
            }
        });
    }

    if (this.category === undefined) {
        return this._parseR13(asn1);
    }
};

LTECaps.prototype._parseRatEUTRA = function (asn1)
{
    if (!asn1) return;

    this.category = asn1['ue-Category'] >>> 0;

    var mimo = 1;
    if (this.category >= 5) {
        mimo = 4;
    } else if (this.category >= 2) {
        mimo = 2;
    }

    // Bands
    var extBands = []; // Extended band
    var bands = ASN1.dig(asn1, 'rf-Parameters', 'supportedBandListEUTRA');
    if (bands instanceof Array) {
        this.bands = bands.map(function (b, i) {
            if (b.bandEUTRA === 64) {
                extBands.push(i);
            }
            return { band: b.bandEUTRA };
        });

        var ext = ASN1.dig(asn1, 2, 'nonCriticalExtension', 'lateNonCriticalExtension', 3, 'nonCriticalExtension', 'rf-Parameters-v9e0', 'supportedBandListEUTRA-v9e0');
        extBands.forEach((function (b) {
            this.bands[b].band = ext[b]['bandEUTRA-v9e0'];
        }).bind(this));
    }

    // CA
    var ca = ASN1.dig(asn1, 2, 'nonCriticalExtension');
    try {
        extBands = []; // Extended band

        var ca1 = ca['nonCriticalExtension'];
        var cat = ca1['ue-Category-v1020'];
        if (cat !== undefined) this.category = cat - 0;
        this.ca = ca1['rf-Parameters-v1020']['supportedBandCombination-r10'].map((function (c0, i0) {
            return c0.map((function (c1, i1) {
                var band = c1['bandEUTRA-r10'];
                if (band === 64)
                    extBands.push([i0, i1]);

                var dl = c1['bandParametersDL-r10'];
                var ul = c1['bandParametersUL-r10'];
                return {
                    band: band,
                    dl: dl ? dl[0]['ca-BandwidthClassDL-r10'] : null,
                    ul: ul ? ul[0]['ca-BandwidthClassUL-r10'] : null,
                    mimo: mimo,
                    'mimo-9-10': dl ? this.UE_CAPS_MIMO[dl[0]['supportedMIMO-CapabilityDL-r10']] : mimo,
                };
            }).bind(this));
        }).bind(this));
        var bands = ASN1.dig(ca, 'lateNonCriticalExtension', 7, 'nonCriticalExtension', 'rf-Parameters-v10i0', 'supportedBandCombination-v10i0') || [];
        for (var i = 0; i < bands.length; i++) {
            var c1 = this.ca[i];
            for (var j = 0; j < c1.length; j++) {
                var c0 = ASN1.dig(bands[i], 'bandParameterList-v10i0', '' + j, 'bandParametersDL-v10i0', '0');
                if (c0 && c0['fourLayerTM3-TM4-r10'] === 'supported') {
                    c1[j]['mimo4-3-4'] = true;
                }
            }
        }

        if (extBands.length) {
            var ext = ASN1.dig(ca1, 2, 'nonCriticalExtension', 'rf-Parameters-v1090', 'supportedBandCombination-v1090');
            if (ext) {
                extBands.forEach((function (e) {
                    var band = ext[e[0]][e[1]];
                    this.ca[e[0]][e[1]].band = band['bandEUTRA-v1090'];
                }).bind(this));
            }
        }

    } catch (e) {};

    var a = ASN1.dig(ca, 7, 'nonCriticalExtension');
    if (a) {
        var cat = a['ue-Category-v11a0'];
        if (cat !== undefined) this.category = cat - 0;

        a = ASN1.dig(a, 'nonCriticalExtension');
        if (a) {
            var b = ASN1.dig(a, 'rf-Parameters-v1250', 'supportedBandListEUTRA-v1250');
            for (var i in b) {
                if (b[i]['dl-256QAM-r12'] === 'supported')
                    this.bands[i].dl256qam = true;
            }

            var cat = a['ue-CategoryDL-r12'];
            if (cat !== undefined) this.category_dl = cat - 0;

            var cat = a['ue-CategoryUL-r12'];
            if (cat !== undefined) this.category_ul = cat - 0;

            var a = ASN1.dig(a, 'nonCriticalExtension');
            if (a) {
                var cat = a['ue-CategoryDL-v1260'];
                if (cat !== undefined) this.category_dl = cat - 0;

                a = ASN1.dig(a, 'nonCriticalExtension', 'nonCriticalExtension', 'nonCriticalExtension',
                                 'nonCriticalExtension', 'nonCriticalExtension');
                if (a) {
                    var cat = a['ue-CategoryDL-v1330'];
                    if (cat !== undefined) this.category_dl = cat - 0;
                }
            }
        }
    }

    this.bands.sort(function (a, b) { return a.band - b.band; });
};

LTECaps.prototype._parseRatNR = function (asn1)
{
    if (!asn1) return;

    // Bands
    var bands = ASN1.dig(asn1, 'rf-Parameters', 'supportedBandListNR');
    if (bands instanceof Array) {
        this.nrBands = bands.map(function (b) {
            return {band: b.bandNR};
        });
    }

    // VoNR
    var v1540 = ASN1.dig(asn1, 2, 'nonCriticalExtension');
    if (v1540) {
        var vonr = [];
        if (ASN1.dig(v1540, 'ims-Parameters', 'ims-ParametersFRX-Diff', 'voiceOverNR') === 'supported') {
            vonr.push('FR1', 'FR2');
        } else {
            if (ASN1.dig(v1540, 'fr1-Add-UE-NR-Capabilities-v1540', 'ims-ParametersFRX-Diff', 'voiceOverNR') === 'supported')
                vonr.push('FR1');
            if (ASN1.dig(v1540, 'fr2-Add-UE-NR-Capabilities-v1540', 'ims-ParametersFRX-Diff', 'voiceOverNR') === 'supported')
                vonr.push('FR2');
        }
        if (vonr.length)
            this.vonr = vonr.join(', ');
    }
};

LTECaps.prototype._parseRatEUTRA_NR = function (asn1)
{
    if (!asn1) return;

    this.mrdc = undefined;

    var bands = ASN1.dig(asn1, 'rf-ParametersMRDC', 'supportedBandCombinationList');
    if (bands instanceof Array) {
        this.mrdc = bands.map((function (band) {

            var bl = band.bandList;
            return ASN1.map(bl.nr, function (b) {
                    return {
                        band: b.bandNR + ' NR',
                        dl: b['ca-BandwidthClassDL-NR'],
                        ul: b['ca-BandwidthClassUL-NR']
                    };
                }).concat(ASN1.map(bl.eutra, function (b) {
                    return {
                        band: b.bandEUTRA,
                        dl: b['ca-BandwidthClassDL-EUTRA'],
                        ul: b['ca-BandwidthClassUL-EUTRA']
                    };
                }));
        }).bind(this));
    }
};

LTECaps.prototype.setBandComb = function (json, rat_type)
{
    this.band_comb[rat_type] = json;
    this.ready = true;
}

LTECaps.prototype.addBandCombNode = function (node0, rat, rat_str)
{
    var node = this.addTreeNode(node0, true, rat_str);
    var json = this.band_comb[rat];

    var count = 0;

    json.forEach((function (el) {

        if (!el.bands.length)
            return;

        var render = (function (el, record) {
            var n_bands = el.bands.length;
            // Table header
            var html = '<table class="table_bc"><thead><tr>';
            el.bands.map(function (b) {
                if (b.includes('+'))
                    html += '<th class="th_bc" colspan="2">' + b + '</th>';
                else
                    html += '<th class="th_bc">' + b + '</th>';
                });
            html += '</tr>';

            if (record.get('ca_expanded')) {
                html += '<tr>';
                el.bands.map(function (b) { 
                    if (b.includes('DL'))
                        html += '<th class="th_bc"> DL </th>';
                    if (b.includes('UL'))
                        html += '<th class="th_bc"> UL </th>';
                });
                html += '</tr></thead><tbody>';
                //Need good old 'for' to go through both feature_dl and feature_ul array
                for (var i = 0; i < el.features_dl.length; i++) {
                    fdl = el.features_dl[i];
                    ful = el.features_ul[i];
                    html += '<tr>';
                    for (var j = 0; j < n_bands; j++) {
                        var b = el.bands[j];
                        if (b.includes('DL'))
                            html += '<td class="td_bc">' + fdl[j] + '</td>';
                        if (b.includes('UL'))
                            html += '<td class="td_bc">' + ful[j] + '</td>';
                    }
                    html += '</tr>';
                }
                html += '</tbody>';
            } else {
                html += '</tr></thead>';
            }
            return '<div style="overflow: auto;">' + html + '</table></div>';
        }).bind(this, el);

        node.appendChild({
            //iconCls: 'icon-home',
            name: 'Comb. ' + (++count),
            value: render,
            ca_expanded: false,
            leaf: true,
        });
    }).bind(this));
}

LTECaps.prototype.addCANodes = function (node, list)
{
    list.forEach((function (ca, index) {

        var comb = ca.map(function (b) {
            var txt = '<b>B' + b.band + '</b>';
            if (b.dl)   txt += ', DL c' + b.dl.toUpperCase();

            // MIMO
            if (b.mimo) txt += ', MIMO ' + b.mimo;
            if (b['mimo4-3-4'] && b.mimo < 4) {
                if (b['mimo-9-10'] === 4) txt += ' (TM-3/4/9/10: 4)';
                else txt += ' (TM-3/4: 4, TM-9/10: ' + b['mimo-9-10'] + ')';
            } else if (b['mimo-9-10'] && b['mimo-9-10'] != b.mimo) {
                txt += ' (TM-9/10: ' + b['mimo-9-10'] + ')';
            }

            if (b.ul)   txt += ', UL c' + b.ul.toUpperCase();
            return txt;
        }).join(' / ');

        var node1 = this.addTreeLeaf(node, 'Combination ' + index, comb);
    }).bind(this));
}


LTECaps.prototype.addTreeNode = function (node, expanded, name, value)
{
    return node.appendChild({
        //iconCls: 'icon-home',
        name: name,
        value: value,
        expanded: expanded
    });
};

LTECaps.prototype.addTreeLeaf = function (node, name, value)
{
    return node.appendChild({
        //iconCls: 'icon-home',
        name: name,
        value: value,
        leaf: true,
    });
};

LTECaps.prototype.getWidget = function (root)
{
    var store = Ext.create('Ext.data.TreeStore', {
        fields: ['name', 'value', 'ca_expanded'],
        root: {name: 'Capabilities', children: []},
    });

    var grid = Ext.create('Ext.tree.Panel', {
        store: store,
        rootVisible: false,
        useArrows: true,
        viewConfig: {
            markDirty: false,
            enableTextSelection: true,
        },
        columns: [{
            xtype: 'treecolumn',
            text: 'Capability',
            width: 180,
            dataIndex: 'name',
        }, {
            text: '',
            flex: 1,
            dataIndex: 'value',
            renderer: function (value, md, record) {
                if (typeof value === 'function')
                    return value(record);
                return value;
            },
        }],
        listeners:{
            cellclick: function(table, td, cellindex, record) {
                if (cellindex === 1) {
                    var expanded = record.get('ca_expanded');
                    if (typeof expanded === 'boolean') {
                        record.set('ca_expanded', !expanded);
                    }
                }
            },
        }
    });

    var root = grid.getRootNode();

    this.addTreeLeaf(root, 'Category', this.getCategory());
    if (this.vonr)
        this.addTreeLeaf(root, 'VoNR', this.vonr);

    if (this.bands) {
        this.addTreeLeaf(root, 'LTE bands', this.bands.map(function (b) {
                var txt = b.band;
                if (b.dl256qam) txt += ' (256QAM)';
                return txt;
            }).join(', ')
        );
    }

    if (this.nrBands) {
        this.addTreeLeaf(root, 'NR bands', this.nrBands.map(function (b) { return b.band; }).join(', '));
    }

    var ca = this.addTreeNode(root, true, 'CA combination');
    if (this.band_comb['eutra'])
        this.addBandCombNode(ca, 'eutra', 'EUTRA');
    else if (this.ca)
        this.addCANodes(ca, this.ca);
    
    if (this.band_comb['mrdc'])
        this.addBandCombNode(ca, 'mrdc', 'EN-DC');
    else if (this.mrdc)
        this.addCANodes(ca, this.mrdc);

    if (this.band_comb['nr'])
        this.addBandCombNode(ca, 'nr', 'NR');

    if (this.band_comb['nrdc'])
        this.addBandCombNode(ca, 'nrdc', 'NR-DC');

    if (this.band_comb['uplinktxswitch'])
        this.addBandCombNode(ca, 'uplinktxswitch', 'UL Tx Switch');

    return grid;
}


Ext.define('lte.capabilities.win', {

    extend: 'Ext.window.Window',
    title: 'UE caps',
    width: 1000,
    modal: true,
    constraint: true,
    layout: 'fit',
    iconCls: 'icon-question2',

    constructor: function (config) {
        this.callParent(arguments);
    },

    initComponent: function () {
        this.callParent(arguments);
        this.add(this.caps.getWidget());

        this.down('toolbar').add({
            tooltip: lteLogs.tooltip('Export'),
            text: 'Export',
            iconCls: 'icon-save',
            scope: this,
            handler: function () {
                var json = JSON.stringify(this.caps.asn1, null, 2);
                var file = this.log.client.getName().replace(/\.log$/, '');
                file += '-ue-caps-' + this.caps.ue_id + '.json';
                lteLogs.exportFile(json, file, 'application/json');
            }
        });

        this.down('toolbar').add({
            tooltip: lteLogs.tooltip('Browse ASN.1 capabilities'),
            text: 'Browse',
            iconCls: 'icon-folder',
            scope: this,
            handler: function () {
                var win = Ext.create('lte.json.win', {
                    title: this.title,
                    jsonData: this.caps.asn1

                });
                win.show();
            }
        });

        lteLogs.setWindowAutoHeight(this, {minHeight: 500});
    },
    tbar: [],
});


var JSONBrowser = {

    create: function (jsonData, expandLevel) {

        var jsonStore = Ext.create('Ext.data.TreeStore', {
            fields: ['name', 'value', 'iconCls'],
            root: this.buildTree({ children: [], expanded: true, name: '', value: ''}, jsonData, 0, expandLevel || 1),
        });

        var highlightPattern = null;

        var renderer = function (value) {
            value = '' + value;
            if (highlightPattern)
                value = value.replace(highlightPattern, '<highlight>$1</highlight>');
            return value;
        };

        var searchButton = Ext.create('Ext.button.Button', {
            tooltip: lteLogs.tooltip('Search'),
            iconCls: 'icon-search',
            disabled: true,
            scope: this,
            handler: function () {
                var root = jsonStore.getRoot();
                var e = [];
                this.searchInNode(root, highlightPattern, e);
                for (var i = e.length; i--;)
                    e[i].expand();
            },
        });

        var jsonGrid = Ext.create('Ext.tree.Panel', {
            store: jsonStore,
            rootVisible: false,
            useArrows: true,
            multiSelect: true,
            allowDeselect: true,
            autoScroll: true,
            height: '100%',
            layout: 'fit',
            border: 0,
            //viewConfig: { markDirty: false },
            columns: {
                items: [{
                    xtype: 'treecolumn',
                    text: 'Name',
                    dataIndex: 'name',
                    flex: 1,
                    renderer: renderer
                }, {
                    text: 'Value',
                    dataIndex: 'value',
                    flex: 1,
                    renderer: renderer
                }],
            },
            tbar: [{
                tooltip: lteLogs.tooltip('Expand all'),
                iconCls: 'icon-plus',
                scope: this,
                handler: function () {
                    jsonGrid.expandAll();
                }
            }, {
                tooltip: lteLogs.tooltip('Collapse all'),
                iconCls: 'icon-minus',
                scope: this,
                handler: function () {
                    var count = jsonStore.getCount();
                    for (i = 0; i < count; i++) {
                        var rec = jsonStore.getAt(i);
                        if (rec && !rec.isLeaf())
                            rec.collapse();
                    }
                }
            },
            '|',
            {
                xtype: 'textfield',
                fieldLabel: 'Search',
                labelWidth: 40,
                labelAlign: 'right',
                labelSeparator: '',
                listeners: {
                    scope: this,
                    change: function(combo, newValue, oldValue, eOpts) {
                        highlightPattern = lteLogs.getRexExp(newValue);
                        searchButton.setDisabled(highlightPattern === null);
                        jsonGrid.view.refresh();
                    },
                }
            },
                searchButton
            ],
            listeners: {
                scope: this,
                itemcontextmenu: function(tree, node, item, index, e, eOpts) {

                    var items = [];
                    items.push({
                        text: 'Collapse all but me',
                        iconCls: 'icon-minus',
                        scope: this,
                        handler: function () {
                            this.collapseButMe(node);
                        },
                    });
                    if (!node.isLeaf()) {
                        items.push({
                            text: 'Expand all',
                            iconCls: 'icon-plus',
                            scope: this,
                            handler: function () {
                                this.expandMe(node);
                            }
                        });
                    }

                    var menu = new Ext.menu.Menu({ items: items });
                    //{ text: 'More details', handler: function() {console.log("More details");} },
                    //{ text: 'Delete', handler: function() {console.log("Delete");} }
                    var position = e.getXY();
                    e.stopEvent();
                    menu.showAt(position);
                }
            }
        });
        return jsonGrid;
    },

    collapseButMe: function (node) {

        var parent = node.parentNode;
        if (parent) {
            this.forEachChild(parent, function (sibling) {
                if (sibling !== node && !sibling.isLeaf() && sibling.isExpanded())
                    sibling.collapse();
            });
            this.collapseButMe(parent);
        }
    },

    expandMe: function (node) {

        if (node.isLeaf())
            return;

        if (!node.isExpanded())
            node.expand();

        this.forEachChild(node, function (child) {
            this.expandMe(child);
        });
    },

    forEachChild: function (node, cb) {
        for (var i = 0;; i++) {
            var child = node.getChildAt(i);
            if (!child) break;

            if (cb.call(this, child) === false)
                break;
        }
    },

    searchInNode: function (node, pattern, expand) {

        var match = 0;

        for (var i = 0;; i++) {
            var child = node.getChildAt(i);
            if (!child)
                break;

            if (child.isLeaf()) {
                if (this.searchNodeTest(child, pattern))
                    match++;
            } else {
                match += this.searchInNode(child, pattern, expand);
            }
        }

        if (match) {
            if (!node.isExpanded())
                expand.push(node);
        } else {
            match = this.searchNodeTest(node, pattern);
            if (node.isExpanded() && !node.get('root'))
                node.collapse();
        }
        return match;
    },

    searchNodeTest: function (node, pattern) {

        var name = node.get('name');
        if (name.match(pattern))
            return true;

        var value = '' + node.get('value');
        if (value.match(pattern))
            return true;

        return false;
    },

    buildTree: function (root, json, level, expandLevel) {

        for (var id in json) {
            var value = json[id];
            var name  = id;
            var icon  = null;
            if (value !== null && value instanceof Object) {
                var name = value.__name__ || id;
                if (Object.keys(value).length > 0) {
                    var node = {
                        name: name,
                        expanded: level < expandLevel,
                        value: value.__value__ || '',
                        children: []
                    };
                    this.buildTree(node, value, level + 1, expandLevel);
                    root.children.push(node);
                    continue;
                }
                icon = value.__icon__;
                value = value.__value__ || '';
            }
            root.children.push({
                leaf: true,
                name: name,
                iconCls: icon || 'icon-zoom',
                value: value
            });
        }
        return root;
    },
};

Ext.define('lte.json.win', {

    extend: 'Ext.window.Window',
    title: 'JSON viewer',
    width: 700,
    modal: true,
    expandLevel: 1,
    layout: {
        type: 'fit',
        align: 'stretch',
    },
    iconCls: 'icon-folder',

    constructor: function (config) {
        this.callParent(arguments);
    },

    initComponent: function () {
        this.callParent(arguments);
        this.add(JSONBrowser.create(this.jsonData, this.expandLevel));
        lteLogs.setWindowAutoHeight(this, { minHeight: 600 });
    },

});


