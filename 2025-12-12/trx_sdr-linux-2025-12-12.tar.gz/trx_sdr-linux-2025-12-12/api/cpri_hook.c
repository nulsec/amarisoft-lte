/*
 * CPRI hook example version ##VERSION##
 *
 * Copyright (C) 2022-2025 Amarisoft
 */

/*
 * To build library:
 * make -f Makefile.cpri_hook
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <linux/limits.h>
#include <time.h>
#include <sys/time.h>
#include "libsdr.h"

/* Set it to 0 to disable profiling
 * microseconds
 */
#define CPU_TIME_MAX    67 /* 1 hyperframe */

#if CPU_TIME_MAX > 0
#define CPU_TIME_START int64_t cpu_time = -sdr_get_time_us()
#define CPU_TIME_END \
    cpu_time += sdr_get_time_us(); if (cpu_time > CPU_TIME_MAX) cpri_log(s, "%s took %"PRId64"us\n", __func__, cpu_time)
#else
#define CPU_TIME_START
#define CPU_TIME_END
#endif

static void __attribute__((format(printf, 2, 3))) cpri_log(const CPRIHookState *s, const char *fmt, ...)
{
    va_list ap;

    printf("[%s] ", s->device);
    va_start(ap, fmt);
    vprintf(fmt, ap);
    va_end(ap);
}

static void cpri_hook_rx(CPRIHookState *s, const uint8_t *subch_buf, const uint8_t *hfr_buf, int valid)
{
    int hfn, bfn, k;
    CPU_TIME_START;

    if (!valid) {
        //cpri_log(s, "Hyperframe not received\n");
        return;
    }

    k = s->speed_mult;
    hfn = subch_buf[64 * k];
    bfn = subch_buf[128 * k] + ((subch_buf[192 * k] & 0xF) << 8);

    cpri_log(s, "Sync=%02x bfn=%d hfn=%d\n", subch_buf[0], bfn, hfn);

    CPU_TIME_END;
}

static void cpri_hook_tx(CPRIHookState *s, uint8_t *buf, int hfr)
{
    CPU_TIME_START;

    CPU_TIME_END;
}

static void cpri_hook_terminate(CPRIHookState *s)
{
    cpri_log(s, "Terminate CPRI hook\n");
}

int cpri_hook_init(CPRIHookState *s)
{
    cpri_log(s, "Init CPRI hook version %d\n", CPRI_HOOK_VERSION);

    if (s->version != CPRI_HOOK_VERSION) {
        fprintf(stderr, "Incompatible hook version\n");
        return -1;
    }

    s->tx = cpri_hook_tx;
    s->rx = cpri_hook_rx;
    s->terminate = cpri_hook_terminate;

    return 0;
}

