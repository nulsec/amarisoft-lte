/*
 * PCI SDR driver
 *
 * Copyright (C) 2014-2025 Amarisoft
 */
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/types.h>
#include <linux/ioctl.h>
#include <linux/init.h>
#include <linux/errno.h>
#include <linux/mm.h>
#include <linux/fs.h>
#include <linux/mmtimer.h>
#include <linux/miscdevice.h>
#include <linux/posix-timers.h>
#include <linux/interrupt.h>
#include <linux/time.h>
#include <linux/math64.h>
#include <linux/mutex.h>
#include <linux/slab.h>
#include <linux/pci.h>
#include <linux/pci_regs.h>
#include <linux/delay.h>
#include <linux/wait.h>
#include <linux/cdev.h>
#include <linux/version.h>
#include <asm/cacheflush.h>
#include <asm/spinlock.h>


#include "sdr.h"
#include "csr.h"
#include "flags.h"


MODULE_DESCRIPTION("Amarisoft SDR board driver");
MODULE_AUTHOR("Amarisoft");
MODULE_VERSION(CONFIG_VERSION);

/* Si5324 Output 200MHz for CPRI_REFCLK */
//#define SI5324_200

//#define DEBUG_PPS
//#define DEBUG_CSR
//#define DEBUG_MSI

#define SDR_NAME "sdr"
#define SDR_MINOR_COUNT 20       /* Some like it hot */

/* Testing FreeRun the AD9528 on SDR100 board */
//#define FREERUN

#define DMA_CHANNEL_MAX 4
#define DMA_BUFFER_COUNT 150


/* Support for 61.44M 2 channel DMA (~*/
/*  max size for 150 hyperframes = 10 ms, 2 channels, 61.44 MHz */
/*  2ch * 4bytes (2x16b) * (61.440.000 / 15.000) = 32K */
/*  plus 32bytes header => 9 * 4K pages: 36K bytes */

#define DMA_5_BSIZE (16 * 256 * 9)
#define DMA_5_BUFFER_SIZE PAGE_ALIGN(DMA_5_BSIZE + 32)
#define DMA_5_BUFFER_SIZE_LOG2  4      /* allocate 64K = 2^4 pages (16 * 4K = 64K) for each DMA_BUFFER */
#define DMA_5_BUFFER_MAP_SIZE (DMA_5_BUFFER_SIZE * DMA_BUFFER_COUNT)

/* Support for 122.88M 2 channel DMA (~7.8Gb/s) */
/*  max size for 150 hyperframes = 10 ms, 2 channels, 122.88 MHz */
/*  2ch * 4bytes (2x16b) * (122.880.000 / 15.000) = 64K */
/*  plus 32bytes header => 17 * 4K pages: 68K bytes */

/* Also Support for CPRI10Gb/s  HW mapping x16 speed: 17 x256 x16 => 68K per buffer */
/*  plus 32bytes header => 18 * 4K pages: 72K bytes */
#define DMA_10_BSIZE (16 * 256 * 17)
#define DMA_10_BUFFER_SIZE PAGE_ALIGN(DMA_10_BSIZE + 32)
#define DMA_10_BUFFER_SIZE_LOG2  5      /* allocate 128K = 2^5 pages (32 * 4K = 128K) for each DMA_BUFFER */
#define DMA_10_BUFFER_MAP_SIZE (DMA_10_BUFFER_SIZE * DMA_BUFFER_COUNT)

/* Support for CPRI40 1x 25Gb/s (line rate 7a, 8, 9 and 10) on SFP0 */
#define DMA_25_BSIZE (48 * 256 * 17)  /* for CPRI HW mapping x48 speed: 51 x 4K */
#define DMA_25_BUFFER_SIZE PAGE_ALIGN(DMA_25_BSIZE + 32)
/* plus 32bytes header => 52 * 4K pages: 208K bytes */
#define DMA_25_BUFFER_SIZE_LOG2 6      /* allocate 256K = 2^6 pages (64 * 4K = 256K) for each DMA_BUFFER */
#define DMA_25_BUFFER_MAP_SIZE (DMA_25_BUFFER_SIZE * DMA_BUFFER_COUNT)

#define REG_MAP_OFFSET 0x40000000

#if defined(__arm__) || defined(__aarch64__)
/* Do not use Shared mem area for ARM architecture */
#else
#define USE_SHARED_MEM
#endif

#define SHARED_MEM_OFFSET 0x50000000
/* Reserve 16 int32 for each DMA channel */
//#define SHARED_MEM_SIZE (16 * sizeof(int32_t))
#define SHARED_MEM_SIZE 128
#define SHARED_MEM_SYNC_SIZE 128
#define SHARED_MEM_BUFSIZE PAGE_ALIGN((SHARED_MEM_SIZE * DMA_CHANNEL_MAX)+ SHARED_MEM_SYNC_SIZE)
#define SHARED_MEM_BUFSIZE_LOG2 0      /* allocate 4K = 2^0 pages (1 * 4K) for SHARED_MEM_BUFFER */


#define USE_DMA64        /* Use DMA 64bits if SDR board supports it */
/* 64 bits FPGA bitstreams are compatible with both 32 and 64 bits platforms */

/* Choice of memory allocation method: ALLOC_PAGES or GETFREEPAGES */
#define USE_ALLOC_PAGES             /* preferred method, support for PCIe DMA 64 bits */
//#define USE_GETFREEPAGES

//#define CONFIG_LOW_1MB_WORKAROUND    /* only useful for some old Linux kernels */


#define IRQ_MASK_DMA0_READER (1 << DMA0_READER_INTERRUPT)      /* 1 << 1  = 0x0002 */
#define IRQ_MASK_DMA0_WRITER (1 << DMA0_WRITER_INTERRUPT)      /* 1 << 0  = 0x0001 */
#define IRQ_MASK_DMA1_READER (1 << DMA1_READER_INTERRUPT)      /* 1 << 11 = 0x0800 */
#define IRQ_MASK_DMA1_WRITER (1 << DMA1_WRITER_INTERRUPT)      /* 1 << 10 = 0x0400 */
#define IRQ_MASK_DMA2_READER (1 << DMA2_READER_INTERRUPT)      /* 1 << 13 = 0x2000 */
#define IRQ_MASK_DMA2_WRITER (1 << DMA2_WRITER_INTERRUPT)      /* 1 << 12 = 0x1000 */
#define IRQ_MASK_DMA3_READER (1 << DMA3_READER_INTERRUPT)      /* 1 << 15 = 0x8000 */
#define IRQ_MASK_DMA3_WRITER (1 << DMA3_WRITER_INTERRUPT)      /* 1 << 14 = 0x4000 */

#define GPS_RX_FIFO_SIZE 4096

typedef enum {
    SYNC_STATE_STARTING,
    SYNC_STATE_WARMING,
    SYNC_STATE_LARGE, /* large corrections */
    SYNC_STATE_FINE, /* fine corrections */
} SDRSyncStateEnum;

typedef struct {
    int sync_source;
    uint32_t clock_freq;  /* in Hz */
    uint32_t tcxo_freq; /* in Hz */
    int tcxo_range_max;
    uint32_t tcxo_pwm_period;
    int retroaction_coef;
    int retroaction_coef_fine;
    uint32_t last_pps_clock;
    int consecutive_large_errors;
    int consecutive_small_errors;
    SDRSyncStateEnum state;
    int tcxo_large_threshold;
    int tcxo_fine_threshold;
    int integral;
    int pwm_min, pwm_max;
    int pwm_min_R05, pwm_max_R05;
    int tcxo_range_max_R05;
    int retroaction_coef_R05;
    int retroaction_coef_fine_R05;
    int has_CPRI_R05;  /* 0: N/A; 1: R05; -1:R04 */
    int last_width, last_diff, last_slope;
    int32_t abs_error;   /* cumulative clock error (can be negative or positive) */
    int error_threshold;  /* error threshold for correction */
    int zero_corr;
    int warm_count;

} SDRSyncState;

typedef struct {
#ifdef USE_ALLOC_PAGES
    struct page *dma_tx_pages[DMA_BUFFER_COUNT];
    struct page *dma_rx_pages[DMA_BUFFER_COUNT];
#else
    uint8_t *dma_tx_bufs[DMA_BUFFER_COUNT];
    uint8_t *dma_rx_bufs[DMA_BUFFER_COUNT];
#endif
    dma_addr_t dma_tx_bufs_addr[DMA_BUFFER_COUNT];
    dma_addr_t dma_rx_bufs_addr[DMA_BUFFER_COUNT];
    uint8_t tx_dma_started;
    uint8_t rx_dma_started;
    int8_t dma_interrupt_state; /* -1 = none, 0 = RX, 1 = TX */
    wait_queue_head_t dma_waitqueue;
    /* hw registers */
    uint32_t dma_base;
    int dma_reader_interrupt;
    int dma_writer_interrupt;
    int dma_tx_buf_count;
    int dma_rx_buf_count;
    int dma_tx_buf_size;
    int dma_rx_buf_size;
    int cpri_speed_mult;
} SDRDMAChannel;

typedef struct {
    int minor;
    struct pci_dev *dev;
    int numa_node;
    int numa_node_warn;
    atomic_t open_count;
    int max_open_count;
    int has_ad9361;
    int has_ad9528;
    int has_ad937x;
    int has_cdcm6208;
    int has_si5324;
    int has_cpri;
    
    int dma_channel_count;
    int dma_buffer_size;
    int dma_buffer_size_log2;
    int dma_buffer_map_size;
    
    int is_master;
    int board_rev;
    uint32_t sysid;
    uint32_t ad937x_base;

    resource_size_t bar0_size;
    phys_addr_t bar0_phys_addr;
    uint8_t *bar0_addr; /* virtual address of BAR0 */

    SDRDMAChannel dma_channels[DMA_CHANNEL_MAX];
    int reserved_channels[DMA_CHANNEL_MAX];
    struct file * reserved_files[DMA_CHANNEL_MAX];

    /* flash SPI */
    wait_queue_head_t flash_waitqueue;
    int flash_spi_done;

    /* GPS UART */
    wait_queue_head_t gps_waitqueue;
    int gps_write_done;
    int gps_rx_fifo_size;
    uint8_t *gps_rx_fifo_buf;
    int gps_rx_fifo_windex;
    int gps_rx_fifo_rindex;

    unsigned int system_clock_frequency;

    /* Clock */
    int profile;
    
    /* Synchronisation */
    SDRSyncState sync_state;

    /* mask to check lock state */
    int lock_mask;

    struct mutex sdr_mutex;  /* Mutex for SPI operations */

    struct spinlock gps_lock;   /* spinlock for GPS UART */

    struct page *shared_page;
    uint8_t *shared_mem;   /* kallocated buffer for shared memory zones */
    dma_addr_t shared_mem_addr;   /* Physical mapped address of shared memory */

    int dma_64;

    /* for SDR100V2 */
    int sma_pll_profile;
    int sma_pll_mode;
    uint32_t sma_pll_freq;
    uint32_t sma_pll_flags;

    uint16_t sma_pps_mode;
    uint16_t sma_pps_flags;

    /* For CPRI40 */
    int cpri_slave;

    int fpga_caps;

    /* Shared sync memory region */
    dma_addr_t shared_sync_mem_addr;       /* Physical address of shared memory */
    size_t shared_sync_mem_size;           /* Size of shared memory */
    
} SDRState;

static dev_t sdr_cdev;
static struct cdev sdr_cdev_struct;
static SDRState *sdr_minor_table[SDR_MINOR_COUNT];
/* Keep trace of failed init */
static int failed_minor_table[SDR_MINOR_COUNT];

static void sdr_end(struct pci_dev *dev, SDRState *s);
static int sdr_dma_stop(SDRState *s, int dma_channel);
static int sdr_gps_init(SDRState *s);
static void sdr_gps_end(SDRState *s);
static void sdr_gps_rx_enable(SDRState *s, int flag);
static void sdr_gps_rx_interrupt(SDRState *s);
static void sdr_ad9361_shutdown(SDRState *s);
static void sdr_clock_pps0_interrupt(SDRState *s1);
static int sdr_spi_reset(SDRState *s, int spi_type);

static inline uint32_t sdr_readl(SDRState *s, uint32_t addr)
{
    uint32_t val;
    val = readl(s->bar0_addr + addr);
#ifdef DEBUG_CSR
    printk("csr_read: 0x%08x @ 0x%08x", val, addr);
#endif
    return val;
}

static inline void sdr_writel(SDRState *s, uint32_t addr, uint32_t val)
{
#ifdef DEBUG_CSR
    printk("csr_write: 0x%08x @ 0x%08x", val, addr);
#endif
    writel(val, s->bar0_addr + addr);
}

static void sdr_enable_interrupt(SDRState *s, int irq_num)
{
    uint32_t v;

    if (irq_num < 0 || irq_num >= NB_INTERRUPT)
        return;
    v = sdr_readl(s, CSR_MSI_ENABLE_ADDR);
    v |= (1 << irq_num);
    sdr_writel(s, CSR_MSI_ENABLE_ADDR, v);
}

static void sdr_disable_interrupt(SDRState *s, int irq_num)
{
    uint32_t v;
    
    if (irq_num < 0 || irq_num >= NB_INTERRUPT)
        return;
    v = sdr_readl(s, CSR_MSI_ENABLE_ADDR);
    v &= ~(1 << irq_num);
    sdr_writel(s, CSR_MSI_ENABLE_ADDR, v);
}

static int sdr_open(struct inode *inode, struct file *file)
{
    SDRState *s;
    int minor;

    /* find PCI device */
    minor = iminor(inode);
    if (minor < 0 || minor >= SDR_MINOR_COUNT)
        return -ENODEV;
    if (failed_minor_table[minor])
        return -ENODEV;
        
    s = sdr_minor_table[minor];
    if (!s)
        return -ENODEV;

    /* MBU: for CPRI devices, allow one open per dma channel */
    
    if (atomic_inc_return(&s->open_count) > s->max_open_count) {
        atomic_dec(&s->open_count);
        return -EBUSY;
    }
    file->private_data = s;

    return 0;
}

/* mmap the DMA buffers and registers to user space */
static int sdr_mmap(struct file *file, struct vm_area_struct *vma)
{
    SDRState *s = file->private_data;
    unsigned long pfn;
    int is_tx, i, buf_idx;
    SDRDMAChannel *dc;

    if (vma->vm_pgoff == (REG_MAP_OFFSET >> PAGE_SHIFT)) {
        if (vma->vm_end - vma->vm_start != s->bar0_size)
            return -EINVAL;
        pfn = s->bar0_phys_addr >> PAGE_SHIFT;
        /* not cached */
        vma->vm_page_prot = pgprot_noncached(vma->vm_page_prot);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 3, 0)
        vm_flags_set(vma, VM_IO);
#else
        vma->vm_flags |= VM_IO;
#endif
        if (io_remap_pfn_range(vma, vma->vm_start, pfn,
                               vma->vm_end - vma->vm_start,
                               vma->vm_page_prot)) {
            printk(KERN_ERR SDR_NAME " io_remap_pfn_range failed\n");
            return -EAGAIN;
        }
    }
    else if (vma->vm_pgoff == (SHARED_MEM_OFFSET >> PAGE_SHIFT)) {
        if (vma->vm_end - vma->vm_start != SHARED_MEM_BUFSIZE)
            return -EINVAL;
#ifdef USE_ALLOC_PAGES
        pfn = page_to_pfn(s->shared_page);
#else
        pfn =  __pa(s->shared_mem) >> PAGE_SHIFT;
#endif
#if defined(__arm__) || defined(__aarch64__)
        /* not cached */
        vma->vm_page_prot = pgprot_noncached(vma->vm_page_prot);
#endif
        if (remap_pfn_range(vma, vma->vm_start, pfn,
                               SHARED_MEM_BUFSIZE, vma->vm_page_prot)) {
            printk(KERN_ERR SDR_NAME " remap_pfn_range smem failed\n");
            return -EAGAIN;
        }
    } else {
        if (vma->vm_end - vma->vm_start != s->dma_buffer_map_size)
            return -EINVAL;

        if ((vma->vm_pgoff % (s->dma_buffer_map_size >> PAGE_SHIFT)) != 0)
            return -EINVAL;
        buf_idx = vma->vm_pgoff / (s->dma_buffer_map_size >> PAGE_SHIFT);
        if (buf_idx >= 2 * s->dma_channel_count)
            return -EINVAL;
        is_tx = (buf_idx ^ 1) & 1;
        dc = &s->dma_channels[buf_idx >> 1];

        for(i = 0; i < DMA_BUFFER_COUNT; i++) {
#ifdef USE_ALLOC_PAGES
            if (is_tx)
                pfn = page_to_pfn(dc->dma_tx_pages[i]);
            else
                pfn = page_to_pfn(dc->dma_rx_pages[i]);
#else
            if (is_tx)
                pfn = __pa(dc->dma_tx_bufs[i]) >> PAGE_SHIFT;
            else
                pfn = __pa(dc->dma_rx_bufs[i]) >> PAGE_SHIFT;
#endif
            /* noncached only works on ARM (for test) */
            //vma->vm_page_prot = pgprot_noncached(vma->vm_page_prot);
            
            /* Note: the memory is cached, so the user must explicitly
               flush the CPU caches on architectures which require it. */
            if (remap_pfn_range(vma, vma->vm_start + i * s->dma_buffer_size, pfn,
                                s->dma_buffer_size, vma->vm_page_prot)) {
                printk(KERN_ERR SDR_NAME " remap_pfn_range bufs failed buf=%d i=%d\n", buf_idx, i);
                return -EAGAIN;
            }
        }
    }

    return 0;
}

static int sdr_release(struct inode *inode, struct file *file)
{
    SDRState *s = file->private_data;
    int i;

    /* Clear PCIE sync registers */
    sdr_writel(s, CSR_TIME_GEN_CONTROL_ADDR, 1);
    sdr_writel(s, CSR_TIME_SYNC_CONTROL_ADDR, 0);
    sdr_writel(s, CSR_PPS_SYNC_WRITER_CONTROL_ADDR, 0);
    sdr_writel(s, CSR_PPS_SYNC_WRITER_CONTROL_ADDR, 0);    

    for(i = 0; i < s->dma_channel_count; i++) {
        if (file == s->reserved_files[i]) {
            SDRDMAChannel *dc = &s->dma_channels[i];
            sdr_dma_stop(s, i);

            dc->cpri_speed_mult = 0;
            s->reserved_channels[i] = 0;
            s->reserved_files[i] = NULL;
            if (s->sysid == SYSID_CPRI_40G) {
                switch(i) {
                case 0:
                    sdr_writel(s, CSR_CPRI0_BASE + CSR_CPRI_PHY_CTRL_OFFSET, 0x0);
                    break;
                case 1:
                    sdr_writel(s, CSR_CPRI1_BASE + CSR_CPRI_PHY_CTRL_OFFSET, 0x0);
                    break;
                case 2:
                    sdr_writel(s, CSR_CPRI2_BASE + CSR_CPRI_PHY_CTRL_OFFSET, 0x0);
                    break;
                case 4:
                    sdr_writel(s, CSR_CPRI3_BASE + CSR_CPRI_PHY_CTRL_OFFSET, 0x0);
                    break;
                default:
                    break;
                }
            }
        }
    }
    if (atomic_dec_and_test(&s->open_count)) {
        /* Safety: release all DMA channels */
        for(i = 0; i < s->dma_channel_count; i++) {
            SDRDMAChannel *dc = &s->dma_channels[i];
            sdr_dma_stop(s, i);

            dc->cpri_speed_mult = 0;
            s->reserved_channels[i] = 0;
            s->reserved_files[i] = NULL;
        }
    
        sdr_gps_rx_enable(s, 0);
        if (s->has_ad9361) {
            sdr_ad9361_shutdown(s);
        }
        if (s->has_ad937x) {
            /* Set Isolation and TDD mode to force DTS to 0V */
            sdr_writel(s, s->ad937x_base + CSR_AD937X_RF1_CONFIG_ADDR_REL,
                       AD937X_RF_CONFIG_RX_TX_ISOLATION | AD937X_RF_CONFIG_RX_TX_TDD);
            sdr_writel(s, s->ad937x_base + CSR_AD937X_RF2_CONFIG_ADDR_REL,
                       AD937X_RF_CONFIG_RX_TX_ISOLATION | AD937X_RF_CONFIG_RX_TX_TDD);
        }
    }
    
    return 0;
}

static irqreturn_t sdr_interrupt(int irq, void *data)
{
    SDRState *s = data;
    uint32_t clear_mask, irq_vector;

    irq_vector = sdr_readl(s, CSR_MSI_VECTOR_ADDR);
    if ((irq_vector & 0xffff) == 0xffff)
        return IRQ_HANDLED;
    
#ifdef DEBUG_MSI
    {
        uint32_t irq_enable;
        irq_enable = sdr_readl(s, CSR_MSI_ENABLE_ADDR);
        printk(KERN_INFO SDR_NAME " MSI: sdr%d 0x%x 0x%x\n", s->minor, irq_vector, irq_enable);
    }
#endif
    clear_mask = 0;
    if (s->dma_channel_count >= 1) {
        if (irq_vector & IRQ_MASK_DMA0_READER) {
            clear_mask |= (IRQ_MASK_DMA0_READER);
        }
        if (irq_vector & IRQ_MASK_DMA0_WRITER) {
            clear_mask |= (IRQ_MASK_DMA0_WRITER);
        }
        /* wake up processes waiting on dma_wait() */
        if (clear_mask & (IRQ_MASK_DMA0_READER | IRQ_MASK_DMA0_WRITER)) {
            wake_up_interruptible(&s->dma_channels[0].dma_waitqueue);
        }
    }
    if (s->sysid == SYSID_RF_5G_V2) {
        /* All IRQ are handled on Master SDR100v2 but need to wakeup Slave */
        SDRState *ss = sdr_minor_table[s->minor + 1];
        if (ss) {
            if (irq_vector & IRQ_MASK_DMA1_READER) {
                clear_mask |= IRQ_MASK_DMA1_READER;
            }
            if (irq_vector & IRQ_MASK_DMA1_WRITER) {
                clear_mask |= IRQ_MASK_DMA1_WRITER;
            }
            /* wake up processes waiting on dma_wait() */
            if (clear_mask & (IRQ_MASK_DMA1_READER | IRQ_MASK_DMA1_WRITER)) {
                wake_up_interruptible(&ss->dma_channels[0].dma_waitqueue);
            }
            if (irq_vector & (1 << FLASH_INTERRUPT)) {
                ss->flash_spi_done = 1;
                wake_up(&ss->flash_waitqueue);
            }                
        }
    }
    if (s->dma_channel_count >= 2) {
        if (irq_vector & IRQ_MASK_DMA1_READER) {
            clear_mask |= IRQ_MASK_DMA1_READER;
        }
        if (irq_vector & IRQ_MASK_DMA1_WRITER) {
            clear_mask |= IRQ_MASK_DMA1_WRITER;
        }
        /* wake up processes waiting on dma_wait() */
        if (clear_mask & (IRQ_MASK_DMA1_READER | IRQ_MASK_DMA1_WRITER)) {
            wake_up_interruptible(&s->dma_channels[1].dma_waitqueue);
        }
    }
    if (s->dma_channel_count >= 3) {
        if (irq_vector & IRQ_MASK_DMA2_READER) {
            clear_mask |= (IRQ_MASK_DMA2_READER);
        }
        if (irq_vector & IRQ_MASK_DMA2_WRITER) {
            clear_mask |= (IRQ_MASK_DMA2_WRITER);
        }
        /* wake up processes waiting on dma_wait() */
        if (clear_mask & (IRQ_MASK_DMA2_READER | IRQ_MASK_DMA2_WRITER)) {
            wake_up_interruptible(&s->dma_channels[2].dma_waitqueue);
        }
    }
    if (s->dma_channel_count >= 4) {
        if (irq_vector & IRQ_MASK_DMA3_READER) {
            clear_mask |= (IRQ_MASK_DMA3_READER);
        }
        if (irq_vector & IRQ_MASK_DMA3_WRITER) {
            clear_mask |= (IRQ_MASK_DMA3_WRITER);
        }
        /* wake up processes waiting on dma_wait() */
        if (clear_mask & (IRQ_MASK_DMA3_READER | IRQ_MASK_DMA3_WRITER)) {
            wake_up_interruptible(&s->dma_channels[3].dma_waitqueue);
        }
    }

    if (irq_vector & (1 << PPS0_INTERRUPT)) {
        sdr_clock_pps0_interrupt(s);
        clear_mask |= (1 << PPS0_INTERRUPT);
    }

    if (irq_vector & (1 << FLASH_INTERRUPT)) {
        s->flash_spi_done = 1;
        wake_up(&s->flash_waitqueue);
        clear_mask |= (1 << FLASH_INTERRUPT);
    }
    if (irq_vector & (1 << GPS_UART_RX_INTERRUPT)) {
        clear_mask |= (1 << GPS_UART_RX_INTERRUPT);
    }

    sdr_writel(s, CSR_MSI_CLEAR_ADDR, clear_mask);

    if (irq_vector & (1 << GPS_UART_RX_INTERRUPT)) {
        /* we handle it after the clear to be sure we don't miss an
           interrupt */
        sdr_gps_rx_interrupt(s);
    }

    return IRQ_HANDLED;
}

static int sdr_dma_start(SDRState *s, struct sdr_ioctl_dma_start *m)
{
    SDRDMAChannel *dc;
    int i, val;

    if (m->dma_channel >= s->dma_channel_count)
        return -EINVAL;

    dc = &s->dma_channels[m->dma_channel];

    if (dc->tx_dma_started || dc->rx_dma_started)
        return -EIO;

    if (m->tx_buf_count == 0 && m->rx_buf_count == 0)
        return -EINVAL;

    /* check parameters */
    if (m->tx_buf_count != 0) {
        if (m->tx_buf_count < 2 || m->tx_buf_count > DMA_BUFFER_COUNT)
            return -EINVAL;
        /* Alignment constraint: 8Bytes for SDR50, 16Bytes for the others */
        if ((m->tx_buf_size & 7) != 0 ||
            (! s->has_ad9361 && (m->tx_buf_size & 15) != 0) ||
            m->tx_buf_size > s->dma_buffer_size ||
            m->tx_buf_size < 8) {
            return -EINVAL;
        }
    } else {
        if (m->tx_buf_size != 0)
            return -EINVAL;
    }

    if (m->rx_buf_count != 0) {
        if (m->rx_buf_count < 2 || m->rx_buf_count > DMA_BUFFER_COUNT)
            return -EINVAL;
        /* Alignment constraint: 8Bytes for SDR50, 16Bytes for the others */
        if ((m->rx_buf_size & 7) != 0 ||
            (! s->has_ad9361 && (m->rx_buf_size & 15) != 0) ||
            m->rx_buf_size > s->dma_buffer_size ||
            m->rx_buf_size < 8)
            return -EINVAL;
    } else {
        if (m->rx_buf_size != 0)
            return -EINVAL;
    }

    val = ((m->dma_flags & SDR_DMA_FLAGS_LOOPBACK) != 0);
    sdr_writel(s, dc->dma_base + CSR_DMA_LOOPBACK_ENABLE_OFFSET, val);

    /* Store DMA start parameters */
    dc->dma_tx_buf_count = m->tx_buf_count;
    dc->dma_rx_buf_count = m->rx_buf_count;
    dc->dma_tx_buf_size = m->tx_buf_size;
    dc->dma_rx_buf_size = m->rx_buf_size;
    
    /* init DMA write from FPGA */
    if (m->rx_buf_size != 0) {
        sdr_writel(s, dc->dma_base + CSR_DMA_WRITER_ENABLE_OFFSET, 0);
        sdr_writel(s, dc->dma_base + CSR_DMA_WRITER_TABLE_FLUSH_OFFSET, 1);
        sdr_writel(s, dc->dma_base + CSR_DMA_WRITER_TABLE_LOOP_PROG_N_OFFSET, 0);
        udelay(1000);
        for(i = 0; i < m->rx_buf_count; i++) {
            sdr_writel(s, dc->dma_base + CSR_DMA_WRITER_TABLE_VALUE_OFFSET,
                (!(i%DMA_BUFFER_PER_IRQ == 0)) * DMA_IRQ_DISABLE | /* generate an msi */
                m->rx_buf_size);
            sdr_writel(s, dc->dma_base + CSR_DMA_WRITER_TABLE_VALUE_OFFSET + 4,
                       (dc->dma_rx_bufs_addr[i] >>  0) & 0xffffffff); /* 32b Address LSB */
            if (s->dma_64) {
                sdr_writel(s, dc->dma_base + CSR_DMA_WRITER_TABLE_WE_OFFSET,
                           (dc->dma_rx_bufs_addr[i] >> 32) & 0xffffffff); /* 64b Address MSB + Write */
            } else {
                sdr_writel(s, dc->dma_base + CSR_DMA_WRITER_TABLE_WE_OFFSET, 1);
            }
        }
        sdr_writel(s, dc->dma_base + CSR_DMA_WRITER_TABLE_LOOP_PROG_N_OFFSET, 1);
    }

    /* init DMA read to FPGA */
    if (m->tx_buf_size != 0) {
        sdr_writel(s, dc->dma_base + CSR_DMA_READER_ENABLE_OFFSET, 0);
        sdr_writel(s, dc->dma_base + CSR_DMA_READER_TABLE_FLUSH_OFFSET, 1);
        sdr_writel(s, dc->dma_base + CSR_DMA_READER_TABLE_LOOP_PROG_N_OFFSET, 0);
        udelay(1000);
        for(i = 0; i < m->tx_buf_count; i++) {
            sdr_writel(s, dc->dma_base + CSR_DMA_READER_TABLE_VALUE_OFFSET,
                (!(i%DMA_BUFFER_PER_IRQ == 0)) * DMA_IRQ_DISABLE | /* generate an msi */
                m->tx_buf_size);
            sdr_writel(s, dc->dma_base + CSR_DMA_READER_TABLE_VALUE_OFFSET + 4,
                       (dc->dma_tx_bufs_addr[i] >>  0) & 0xffffffff); /* 32b Address LSB */
            if (s->dma_64) {
                sdr_writel(s, dc->dma_base + CSR_DMA_READER_TABLE_WE_OFFSET,
                           (dc->dma_tx_bufs_addr[i] >> 32) & 0xffffffff); /* 64b Address MSB + Write */
            } else {
                sdr_writel(s, dc->dma_base + CSR_DMA_READER_TABLE_WE_OFFSET, 1);
            }
        }
        sdr_writel(s, dc->dma_base + CSR_DMA_READER_TABLE_LOOP_PROG_N_OFFSET, 1);
    }

    /* start DMA */
    if (m->rx_buf_size != 0) {
        sdr_writel(s, dc->dma_base + CSR_DMA_WRITER_ENABLE_OFFSET, 1);
        dc->rx_dma_started = 1;
    }
    if (m->tx_buf_size != 0) {
        sdr_writel(s, dc->dma_base + CSR_DMA_READER_ENABLE_OFFSET, 1);
        dc->tx_dma_started = 1;
    }

    if (m->dma_flags & SDR_DMA_FLAGS_SYNC) {
        sdr_writel(s, dc->dma_base + CSR_DMA_SYNCHRONIZER_BYPASS_OFFSET, 0);
    } else {
        sdr_writel(s, dc->dma_base + CSR_DMA_SYNCHRONIZER_BYPASS_OFFSET, 1);
    }
    sdr_writel(s, dc->dma_base + CSR_DMA_SYNCHRONIZER_ENABLE_OFFSET, 1);
    dc->dma_interrupt_state = -1; /* no interrupt enabled */

    return 0;
}

static inline int sdr_dma_wait_condition(SDRState *s, struct sdr_ioctl_dma_wait *m,
                                         int last_buf_num)
{
    SDRDMAChannel *dc;
    uint32_t val;

    dc = &s->dma_channels[m->dma_channel];

    /* set current hyperframe */
    if (dc->tx_dma_started) {
        val = sdr_readl(s, dc->dma_base + CSR_DMA_READER_TABLE_LOOP_STATUS_OFFSET);
        m->tx_buf_num = val & 0xffff;
        m->tx_loop = val >> 16;
    } else {
        m->tx_buf_num = 0;
        m->tx_loop = 0;
    }
    if (dc->rx_dma_started) {
        val = sdr_readl(s, dc->dma_base + CSR_DMA_WRITER_TABLE_LOOP_STATUS_OFFSET);
        m->rx_buf_num = val & 0xffff;
        m->rx_loop = val >> 16;
    } else {
        m->rx_buf_num = 0;
        m->rx_loop = 0;
    }
    if (m->tx_wait) {
        return (m->tx_buf_num != last_buf_num);
    } else {
        return (m->rx_buf_num != last_buf_num);
    }
}

static int sdr_dma_wait(SDRState *s, struct sdr_ioctl_dma_wait *m)
{
    SDRDMAChannel *dc;
    int ret, last_buf_num, tx_wait;

    if (m->dma_channel >= s->dma_channel_count)
        return -EINVAL;
    dc = &s->dma_channels[m->dma_channel];

    tx_wait = (m->tx_wait != 0);
    if (tx_wait) {
        if (!dc->tx_dma_started)
            return -EIO;
        last_buf_num = m->tx_buf_num;
    } else {
        if (!dc->rx_dma_started)
            return -EIO;
        last_buf_num = m->rx_buf_num;
    }

    /* enable the correct interrupt if needed */
    if (tx_wait != dc->dma_interrupt_state) {
        if (tx_wait) {
            sdr_disable_interrupt(s, dc->dma_writer_interrupt);
            sdr_enable_interrupt(s, dc->dma_reader_interrupt);
        } else {
            sdr_disable_interrupt(s, dc->dma_reader_interrupt);
            sdr_enable_interrupt(s, dc->dma_writer_interrupt);
        }
        dc->dma_interrupt_state = tx_wait;
    }

    /* Sleep until sdr_dma_wait_conditions return TRUE (when loop index changes) */
    ret = wait_event_interruptible_timeout(dc->dma_waitqueue,
                                           sdr_dma_wait_condition(s, m, last_buf_num),
                                           msecs_to_jiffies(m->timeout));
    if (ret == 0) {
        /* timeout */
        ret = -EAGAIN;
    } else if (ret > 0) {
        ret = 0;
    }
    return ret;
}

static int sdr_dma_stop(SDRState *s, int dma_channel)
{
    SDRDMAChannel *dc;

    if (dma_channel >= s->dma_channel_count)
        return -EINVAL;

    dc = &s->dma_channels[dma_channel];

    sdr_disable_interrupt(s, dc->dma_reader_interrupt);
    sdr_disable_interrupt(s, dc->dma_writer_interrupt);

    dc->tx_dma_started = 0;
    sdr_writel(s, dc->dma_base + CSR_DMA_READER_TABLE_LOOP_PROG_N_OFFSET, 0);
    udelay(1000);
    sdr_writel(s, dc->dma_base + CSR_DMA_READER_TABLE_FLUSH_OFFSET, 1);
    udelay(1000);
    sdr_writel(s, dc->dma_base + CSR_DMA_READER_ENABLE_OFFSET, 0);
    udelay(1000);

    dc->rx_dma_started = 0;
    sdr_writel(s, dc->dma_base + CSR_DMA_WRITER_TABLE_LOOP_PROG_N_OFFSET, 0);
    udelay(1000);
    sdr_writel(s, dc->dma_base + CSR_DMA_WRITER_TABLE_FLUSH_OFFSET, 1);
    udelay(1000);
    sdr_writel(s, dc->dma_base + CSR_DMA_WRITER_ENABLE_OFFSET, 0);
    udelay(1000);

    sdr_writel(s, dc->dma_base + CSR_DMA_SYNCHRONIZER_ENABLE_OFFSET, 0);
    sdr_writel(s, dc->dma_base + CSR_DMA_SYNCHRONIZER_BYPASS_OFFSET, 0);

    return 0;
}

/* AD9361 SPI */

#define AD9361_SPI_TIMEOUT 100000 /* in us */

static void sdr_ad9361_write(SDRState *s, uint16_t addr, uint8_t val)
{
    unsigned int cmd;
    int i;

    cmd = (1 << 15) | (0 << 12) | addr;
    sdr_writel(s, CSR_RFIC_SPI_MOSI_ADDR, (cmd << 8) | val);
    sdr_writel(s, CSR_RFIC_SPI_CTRL_ADDR, (24 << 8) | RFIC_SPI_CTRL_START);
    /* Note: could use interrupt but not really critical */
    for(i = 0; i < AD9361_SPI_TIMEOUT; i++) {
        if (sdr_readl(s, CSR_RFIC_SPI_STATUS_ADDR) & RFIC_SPI_STATUS_DONE)
            break;
        udelay(1);
    }
    if (i == AD9361_SPI_TIMEOUT) {
        printk(KERN_ERR SDR_NAME " ad9361 write error\n");
    }
}

static uint8_t sdr_ad9361_read(SDRState *s, uint16_t addr)
{
    unsigned int cmd;
    int i;

    cmd = (0 << 15) | (0 << 12) | addr;
    sdr_writel(s, CSR_RFIC_SPI_MOSI_ADDR, cmd << 8);
    sdr_writel(s, CSR_RFIC_SPI_CTRL_ADDR, (24 << 8) | RFIC_SPI_CTRL_START);
    /* Note: could use interrupt but not really critical */
    for(i = 0; i < AD9361_SPI_TIMEOUT; i++) {
        if (sdr_readl(s, CSR_RFIC_SPI_STATUS_ADDR) & RFIC_SPI_STATUS_DONE)
            break;
        udelay(1);
    }
    if (i == AD9361_SPI_TIMEOUT) {
        printk(KERN_ERR SDR_NAME " ad9361 read error\n");
        return 0;
    }
    return sdr_readl(s, CSR_RFIC_SPI_MISO_ADDR) & 0xff;
}

#define MK_ID_REVISION(major, minor, micro) \
    (((major) << 16) | ((minor) << 8) | (micro))

static void sdr_ad9361_shutdown(SDRState *s)
{
    int val;

    /* Note: earlier versions are not compatible */
    if (sdr_readl(s, CSR_IDENTIFIER_REVISION_ADDR) < MK_ID_REVISION(0, 9, 40))
        return;

    /* shut down the PAs */
    sdr_writel(s, CSR_RFIC_RF1_CONFIG_ADDR, 0);
    sdr_writel(s, CSR_RFIC_RF2_CONFIG_ADDR, 0);

    /* put the AD9361 into sleep mode */

    /* disable TX VCO cal */
    val = sdr_ad9361_read(s, 0x230);
    sdr_ad9361_write(s, 0x230, val | 1);
    /* disable RX VCO cal */
    val = sdr_ad9361_read(s, 0x270);
    sdr_ad9361_write(s, 0x270, val | 1);
    /* clear to alert */
    sdr_ad9361_write(s, 0x014, 0x00);
    sdr_ad9361_write(s, 0x014, 0x20);
    /* wait at least 384 ADC clock cycles */
    udelay(100);
    /* move to wait */
    sdr_ad9361_write(s, 0x014, 0x00);
    udelay(1);
    /* turn off all clocks */
    sdr_ad9361_write(s, 0x009, 0x00);
}

/* AD9528 SPI */

#define AD9528_SPI_TIMEOUT 100000 /* in us */
//#define AD9528_SPI_TIMEOUT 500000 /* ??? */

static int sdr_ad9528_write(SDRState *s, uint16_t addr, uint8_t val)
{
    unsigned int cmd;
    int i;
    uint32_t reg_mosi, reg_ctrl, reg_status;

    mutex_lock(&s->sdr_mutex);
    //printk(KERN_ERR SDR_NAME " ad9528 write (%02x, %02x)\n", addr, val);

    switch (s->sysid) {
    case SYSID_RF_5G:
    case SYSID_RF_5G_V2:
        /* AD9528 is always on the SPI bus of AD937X0 */
        sdr_writel(s, CSR_AD937X0_BASE + CSR_AD937X_SPI_SEL_ADDR_REL, AD9528_SEL);
        reg_mosi = CSR_AD937X0_BASE + CSR_AD937X_SPI_MOSI_ADDR_REL;
        reg_ctrl = CSR_AD937X0_BASE + CSR_AD937X_SPI_CTRL_ADDR_REL;
        reg_status = CSR_AD937X0_BASE + CSR_AD937X_SPI_STATUS_ADDR_REL;
        break;
    case SYSID_CPRI_40G:
        reg_mosi = CSR_AD9528_SPI_MOSI_ADDR;
        reg_ctrl = CSR_AD9528_SPI_CONTROL_ADDR;
        reg_status = CSR_AD9528_SPI_STATUS_ADDR;
        break;
    default:
        mutex_unlock(&s->sdr_mutex);
        printk(KERN_ERR SDR_NAME " invalid ad9528 write\n");
        return -1;
    }
    cmd = (0 << 15) | addr;
    sdr_writel(s, reg_mosi, (cmd << 8) | val);
    sdr_writel(s, reg_ctrl, (24 << 8) | AD937X_SPI_CTRL_START);
    /* Note: could use interrupt but not really critical */
    for(i = 0; i < AD9528_SPI_TIMEOUT; i++) {
        if (sdr_readl(s, reg_status) & AD937X_SPI_STATUS_DONE) {
            break;
        }
        udelay(1);
    }
    mutex_unlock(&s->sdr_mutex);
    if (i == AD9528_SPI_TIMEOUT) {
        printk(KERN_ERR SDR_NAME " ad9528 write timeout\n");
        return -1;
    }
    return 0;
}

static uint sdr_ad9528_read(SDRState *s, uint16_t addr, uint8_t *pval)
{
    unsigned int cmd;
    int i;
    uint8_t val;
    uint32_t reg_mosi, reg_miso, reg_ctrl, reg_status;

    if (pval)
        *pval = 0;
    
    mutex_lock(&s->sdr_mutex);
    switch (s->sysid) {
    case SYSID_RF_5G:    
    case SYSID_RF_5G_V2:
        sdr_writel(s, CSR_AD937X0_BASE + CSR_AD937X_SPI_SEL_ADDR_REL, AD9528_SEL);
        reg_mosi = CSR_AD937X0_BASE + CSR_AD937X_SPI_MOSI_ADDR_REL;
        reg_miso = CSR_AD937X0_BASE + CSR_AD937X_SPI_MISO_ADDR_REL;
        reg_ctrl = CSR_AD937X0_BASE + CSR_AD937X_SPI_CTRL_ADDR_REL;
        reg_status = CSR_AD937X0_BASE + CSR_AD937X_SPI_STATUS_ADDR_REL;
        break;
    case SYSID_CPRI_40G:
        reg_mosi = CSR_AD9528_SPI_MOSI_ADDR;
        reg_miso = CSR_AD9528_SPI_MISO_ADDR;
        reg_ctrl = CSR_AD9528_SPI_CONTROL_ADDR;
        reg_status = CSR_AD9528_SPI_STATUS_ADDR;
        break;
    default:
        mutex_unlock(&s->sdr_mutex);
        printk(KERN_ERR SDR_NAME " invalid ad9528 read\n");
        return -1;
    }
    cmd = (1 << 15) | addr;
    sdr_writel(s, reg_mosi, cmd << 8);
    sdr_writel(s, reg_ctrl, (24 << 8) | AD937X_SPI_CTRL_START);
    /* Note: could use interrupt but not really critical */
    for(i = 0; i < AD9528_SPI_TIMEOUT; i++) {
        if (sdr_readl(s, reg_status) & AD937X_SPI_STATUS_DONE) {
            break;
        }
        udelay(1);
    }
    if (i == AD9528_SPI_TIMEOUT) {
        mutex_unlock(&s->sdr_mutex);
        printk(KERN_ERR SDR_NAME " ad9528 read timeout\n");
        return -1;
    }
    val = sdr_readl(s, reg_miso) & 0xff;
    
    mutex_unlock(&s->sdr_mutex);
    // printk(KERN_ERR SDR_NAME " ad9528 read (%02x,) => %02x\n", addr, val);
    if (pval)
        *pval = val;
    return 0;
}

/* AD937X SPI */

/* AD937X SPI is 25MHz speed, so a frame of 24 bits is about 1 us */
#define AD937X_SPI_TIMEOUT 10 /* in us */

static void sdr_ad937x_write(SDRState *s, uint16_t addr, uint8_t val)
{
    unsigned int cmd;
    int i;

    mutex_lock(&s->sdr_mutex);
    sdr_writel(s, s->ad937x_base + CSR_AD937X_SPI_SEL_ADDR_REL, AD937X_SEL);

    cmd = (0 << 15) | addr;
    sdr_writel(s, s->ad937x_base + CSR_AD937X_SPI_MOSI_ADDR_REL, (cmd << 8) | val);
    sdr_writel(s, s->ad937x_base + CSR_AD937X_SPI_CTRL_ADDR_REL,
               (24 << 8) | AD937X_SPI_CTRL_START);
    /* Note: could use interrupt but not really critical */
    for(i = 0; i < AD937X_SPI_TIMEOUT; i++) {
        if (sdr_readl(s, s->ad937x_base + CSR_AD937X_SPI_STATUS_ADDR_REL)
            & AD937X_SPI_STATUS_DONE) {
            break;
        }
        udelay(1);
    }
    mutex_unlock(&s->sdr_mutex);
    if (i == AD937X_SPI_TIMEOUT) {
        printk(KERN_ERR SDR_NAME " ad937x write timeout addr=0x%x val=0x%x\n", addr, val);
    }
}

static uint8_t sdr_ad937x_read(SDRState *s, uint16_t addr)
{
    unsigned int cmd;
    int i;
    uint8_t val;

    mutex_lock(&s->sdr_mutex);
    sdr_writel(s, s->ad937x_base + CSR_AD937X_SPI_SEL_ADDR_REL, AD937X_SEL);

    cmd = (1 << 15) | addr;
    sdr_writel(s, s->ad937x_base + CSR_AD937X_SPI_MOSI_ADDR_REL, cmd << 8);
    sdr_writel(s, s->ad937x_base + CSR_AD937X_SPI_CTRL_ADDR_REL,
               (24 << 8) | AD937X_SPI_CTRL_START);
    /* Note: could use interrupt but not really critical */
    for(i = 0; i < AD937X_SPI_TIMEOUT; i++) {
        if (sdr_readl(s, s->ad937x_base + CSR_AD937X_SPI_STATUS_ADDR_REL)
            & AD937X_SPI_STATUS_DONE) {
            break;
        }
        udelay(1);
    }
    if (i == AD937X_SPI_TIMEOUT) {
        mutex_unlock(&s->sdr_mutex);
        printk(KERN_ERR SDR_NAME " ad937x read timeout addr=0x%x\n", addr);
        return 0;
    }
    val = sdr_readl(s, s->ad937x_base + CSR_AD937X_SPI_MISO_ADDR_REL) & 0xff;
    mutex_unlock(&s->sdr_mutex);

    return val;
}

/* SPI flash */

//#define DEBUG_SPI

/* ALIGNED_MODE => the bitstream uses RIGHT aligned SPI string (could support up to 6 bytes) */
/* default is: left aligned starting at 4th byte position of high word, limited to 5 bytes total */

static int sdr_flash_spi(SDRState *s, struct sdr_ioctl_flash_spi *m)
{
    int ret;
    int mode;
    int retry = 5;

#ifdef DEBUG_SPI
    printk(KERN_INFO SDR_NAME " sdr_flash_spi sdr%d sysid=%x len=%d data=0x%08x:%08x\n", s->minor, s->sysid, m->tx_len,
           (uint32_t)(m->tx_data >> 32), (uint32_t)(m->tx_data & 0xFFFFFFFF));
#endif
    /* we can send from 1 to 8 bytes from tx_data */
    if (m->tx_len < 8 || m->tx_len > 48)
        return -EBADF;

    s->flash_spi_done = 0;
    
    /* 2023-02-06; SPI Flash retro-compatibility, the old SPI Flash core required tx_data to be
       shifted by software to 40-bit, which is no longer required by the new SPI Flash core.
    */
    mode = sdr_readl(s, CSR_FLASH_SPI_STATUS_ADDR);
    if (mode & FLASH_SPI_STATUS_ALIGNED_MODE) {
        /* All new bitstreams (post 2023-03-20) support ALIGNED_MODE (4 Bytes address) */
        
        /* CMD + Addr + Data must be RIGHT ALIGNED */
        if (m->tx_len < 40)
            m->tx_data = m->tx_data >> (40 - m->tx_len);
    }
    else {
        /* Legacy mode: only 40 bit mode, cmd is always at LSByte of first MOSI register */
        if (m->tx_len > 40) {
            printk(KERN_ERR SDR_NAME " Old FPGA does not support ALIGNED mode\n");
            return -EBADF;
        }
    }

 again:
    /* XXX: endianness */
    sdr_writel(s, CSR_FLASH_SPI_MOSI_ADDR + 0, m->tx_data >> 32);
    sdr_writel(s, CSR_FLASH_SPI_MOSI_ADDR + 4, m->tx_data);

    sdr_writel(s, CSR_FLASH_SPI_CTRL_ADDR,
               FLASH_SPI_CTRL_START | (m->tx_len * FLASH_SPI_CTRL_LENGTH));

    ret = wait_event_timeout(s->flash_waitqueue, s->flash_spi_done,
                             msecs_to_jiffies(2000));
    if (ret == 0) {
        if (retry-- > 0)
            goto again;

        printk(KERN_ERR SDR_NAME "sdr_flash_spi retry FAIL MOSI= %x %x\n",
               (uint32_t)((m->tx_data >> 32) & 0xffffffff),
               (uint32_t)((m->tx_data >>  0) & 0xffffffff));
        return -EIO;
    }
    /* XXX: endianness */
    m->rx_data  = ((uint64_t) sdr_readl(s, CSR_FLASH_SPI_MISO_ADDR + 0) << 32);
    m->rx_data |= ((uint64_t) sdr_readl(s, CSR_FLASH_SPI_MISO_ADDR + 4) <<  0);
#if 0
    if (mode & FLASH_SPI_STATUS_ALIGNED_MODE) {
        uint8_t *bp;
        bp = ((uint8_t*)&m->rx_data);
    }
#endif
#ifdef DEBUG_SPI
    printk(KERN_INFO SDR_NAME " MISO: 0x%x:%x\n",
           (uint32_t)(m->rx_data >> 32), (uint32_t)(m->rx_data & 0xFFFFFFFF));
#endif
    return 0;
}

//#define DEBUG_SPI_PAGE

#define FLASH_SPI_TIMEOUT  1000   /* in us */
/* Write nb bits (nb: 1..40) (1..48 if ALIGNED MODE) */
static int sdr_flash_send_64(SDRState *s, uint64_t data, int nb)
{
    int retry = 3;
    int i;
    
#ifdef DEBUG_SPI_PAGE0
    printk(KERN_INFO SDR_NAME " CMD + Addr: %08x:%08x nb=%d\n", 
           (uint32_t)(data >> 32), (uint32_t)(data & 0xFFFFFFFF), nb);
#endif
    
 again:
    sdr_writel(s, CSR_FLASH_SPI_MOSI_ADDR + 0, data >> 32);
    sdr_writel(s, CSR_FLASH_SPI_MOSI_ADDR + 4, (data & 0xFFFFFFFF));
    sdr_writel(s, CSR_FLASH_SPI_CTRL_ADDR,
               FLASH_SPI_CTRL_START | (nb * FLASH_SPI_CTRL_LENGTH));

    for (i = 0; i < FLASH_SPI_TIMEOUT; i++) {
        if (sdr_readl(s, CSR_FLASH_SPI_STATUS_ADDR) & FLASH_SPI_STATUS_DONE) {
#ifdef DEBUG_SPI_PAGE0
            printk(KERN_INFO SDR_NAME " send64(%d) OK i=%d\n", nb, i);
#endif
            return 0;
        }            
        udelay(1);
    }
    if (retry-- > 0)
        goto again;   
#ifdef DEBUG_SPI_PAGE0
    printk(KERN_INFO SDR_NAME " send64(%d) FAIL\n", nb);
#endif
    return -1;
}

static int sdr_flash_page_program(SDRState *s, struct sdr_ioctl_flash_page_program *m)
{
    int mode;
    __u64 data64;
    int i;
    int ret = 0;
    int shift;

#ifdef DEBUG_SPI_PAGE
    printk(KERN_INFO SDR_NAME " sdr_flash_page_program addr=%08x\n", m->page_addr);
#endif
    s->flash_spi_done = 0;
    
    /* 2023-02-06; SPI Flash retro-compatibility, the old SPI Flash core required tx_data to be
       shifted by software to 40-bit, which is no longer required by the new SPI Flash core.
    */
    shift = 0;
    mode = sdr_readl(s, CSR_FLASH_SPI_STATUS_ADDR);
    if (! (mode & FLASH_SPI_STATUS_ALIGNED_MODE)) {
        shift = 8; /* when writing 4 bytes */
    }

    /* To do a 256 bytes page program, we need the CS to stay low during the whole command */
    /* Set Chip Select. */
    sdr_writel(s, CSR_FLASH_SPI_CS_ADDR, 0b1* (1 << CSR_FLASH_SPI_CS_MODE_OFFSET) | 0b1);
    
    /* send 4PP command (0x12) + 4B address */
    if (m->mode4) {
        /* send cmd and 4Byte address: 40 bits */
        data64 = ((uint64_t)m->cmd << 32) | m->page_addr;
#ifdef DEBUG_SPI_PAGE
        printk(KERN_INFO SDR_NAME " CMD+4B addr: 0x%08x:0x%08x\n",
               (uint32_t)(data64 >> 32), (uint32_t)(data64 & 0xFFFFFFFF));
#endif
        if (sdr_flash_send_64(s, data64, 40) < 0) {
            ret = -EFAULT;
            goto done;
        }
    }
    else {
        data64 = ((uint64_t)m->cmd << 24) | m->page_addr;
        data64 <<= shift;
#ifdef DEBUG_SPI_PAGE
        printk(KERN_INFO SDR_NAME " CMD+3B addr: 0x%08x:0x%08x\n",
               (uint32_t)(data64 >> 32), (uint32_t)(data64 & 0xFFFFFFFF));
#endif
        /* send cmd and 3Byte address: 32 bits */
        if (sdr_flash_send_64(s, data64, 32) < 0) {
            ret = -EFAULT;
            goto done;
        }
    }
    
    /* Now send 256B page 4 bytes at a time */
    for (i = 0; i < 256; i+=4) {
        /* order 4 bytes so that first byte written is LSB */
        data64 = ((uint64_t)m->page_data[i] << 24) | ((uint64_t)m->page_data[i+1] << 16) |
            ((uint64_t)m->page_data[i+2] << 8) | ((uint64_t)m->page_data[i+3] << 0);
        data64 <<= shift;
        if (sdr_flash_send_64(s, data64, 32) < 0) {
            ret = -EFAULT;
            break;
        }
    }
 done:
    /* Release Chip Select. */
    sdr_writel(s, CSR_FLASH_SPI_CS_ADDR, 0b1* (1 << CSR_FLASH_SPI_CS_MODE_OFFSET) | 0b1);
    sdr_writel(s, CSR_FLASH_SPI_CS_ADDR, 0b0* (1 << CSR_FLASH_SPI_CS_MODE_OFFSET) | 0b1);
    
    return ret;
}

static int sdr_flash_page_read(SDRState *s, struct sdr_ioctl_flash_page_read *m)
{
    int mode;
    __u64 data64;
    int i;
    int ret = 0;
    int shift;

#ifdef DEBUG_SPI_PAGE
    printk(KERN_INFO SDR_NAME " sdr_flash_page_read addr=%08x\n", m->page_addr);
#endif
    s->flash_spi_done = 0;
    
    /* 2023-02-06; SPI Flash retro-compatibility, the old SPI Flash core required tx_data to be
       shifted by software to 40-bit, which is no longer required by the new SPI Flash core.
    */
    shift = 0;
    mode = sdr_readl(s, CSR_FLASH_SPI_STATUS_ADDR);
    if (! (mode & FLASH_SPI_STATUS_ALIGNED_MODE)) {
        shift = 8; /* when writing 4 bytes */
    }

    /* To do a 256 bytes page command, we need the CS to stay low during the whole command */
    /* Set Chip Select. */
    sdr_writel(s, CSR_FLASH_SPI_CS_ADDR, 0b1* (1 << CSR_FLASH_SPI_CS_MODE_OFFSET) | 0b1);
    
    /* send 4PP command (0x12) + 4B address */
    if (m->mode4) {
        /* send cmd and 4Byte address: 40 bits */
        data64 = ((uint64_t)m->cmd << 32) | m->page_addr;
#ifdef DEBUG_SPI_PAGE
        printk(KERN_INFO SDR_NAME " CMD+4B addr: 0x%08x:0x%08x\n",
               (uint32_t)(data64 >> 32), (uint32_t)(data64 & 0xFFFFFFFF));
#endif
        if (sdr_flash_send_64(s, data64, 40) < 0) {
            ret = -EFAULT;
            goto done;
        }
    }
    else {
        data64 = ((uint64_t)m->cmd << 24) | m->page_addr;
        data64 <<= shift;
#ifdef DEBUG_SPI_PAGE
        printk(KERN_INFO SDR_NAME " CMD+3B addr: 0x%08x:0x%08x\n",
               (uint32_t)(data64 >> 32), (uint32_t)(data64 & 0xFFFFFFFF));
#endif
        /* send cmd and 3Byte address: 32 bits */
        if (sdr_flash_send_64(s, data64, 32) < 0) {
            ret = -EFAULT;
            goto done;
        }
    }
    
    /* Now read 256 Bytes 4 at a time */
    for (i = 0; i < 256; i+=4) {
        /* send 4 bytes to clock */
        sdr_flash_send_64(s, 0, 32);
        data64  = ((uint64_t) sdr_readl(s, CSR_FLASH_SPI_MISO_ADDR + 4) <<  0);        
        //data64 |= ((uint64_t) sdr_readl(s, CSR_FLASH_SPI_MISO_ADDR + 0) << 32);
        /* order 4 bytes so that first byte written is LSB */
        m->page_data[i] = data64 >> 24;
        m->page_data[i+1] = data64 >> 16;
        m->page_data[i+2] = data64 >> 8;
        m->page_data[i+3] = data64 >> 0;
    }
 done:
    /* Release Chip Select. */
    sdr_writel(s, CSR_FLASH_SPI_CS_ADDR, 0b1* (1 << CSR_FLASH_SPI_CS_MODE_OFFSET) | 0b1);
    sdr_writel(s, CSR_FLASH_SPI_CS_ADDR, 0b0* (1 << CSR_FLASH_SPI_CS_MODE_OFFSET) | 0b1);
    
    return ret;
}

/****************************************************************/
/* Flash config block support */

#define FLASH_RESET   0xF0  /* For Cypress */

#define FLASH_READ_ID 0x9F
#define FLASH_READ    0x03
#define FLASH_WREN    0x06
#define FLASH_WRDI    0x04
#define FLASH_PP      0x02
#define FLASH_SE      0xD8
#define FLASH_BE      0xC7
#define FLASH_RDSR    0x05
#define FLASH_WRSR    0x01
/* status */
#define FLASH_WIP     0x01

#define FLASH_SECTOR_SIZE (1 << 16)

/* SPI Flash are 32MB = 512 sectors of 64K */
#define FLASH_SECTOR_COUNT 512
#define FLASH_CONFIG_ADDR ((FLASH_SECTOR_COUNT-1)*FLASH_SECTOR_SIZE)

#define MANUF_MICRON   0x20     /* Micron / ST / ... */
#define MANUF_ISSI     0x9D     /* ISSI */
#define MANUF_CYPRESS  0x01     /* Infineon / Cypress */

#define FLASH_CLRFLAG     0x50      /* Clear FlagStatus Register for Micron/JEDEC*/
#define FLASH_RESET       0xF0      /* Reset For Cypress */
#define FLASH_CLREXTENDED 0x82      /* Clear Extended Register for ISSI */

static uint64_t flash_spi(SDRState *s, int tx_len, uint8_t cmd,
                          uint32_t tx_data)
{
    struct sdr_ioctl_flash_spi m;
    m.tx_len = tx_len;
    m.tx_data = tx_data | ((uint64_t)cmd << 32);
    if (sdr_flash_spi(s, &m) < 0)
        return 0;
    return m.rx_data;
}

static uint8_t sdr_flash_read_byte(SDRState *s, uint32_t addr)
{
    uint8_t ret = flash_spi(s, 40, FLASH_READ, addr << 8) & 0xff;
    //   printk(" flread[0x%x] = 0x%x\n", addr, ret);
    return ret;
}

static uint8_t flash_read_status(SDRState *s)
{
    return flash_spi(s, 16, FLASH_RDSR, 0) & 0xff;
}

static uint32_t flash_read_id(SDRState *s)
{
    return flash_spi(s, 32, FLASH_READ_ID, 0) & 0xffffff;
}

static void spi_flash_init(SDRState *s)
{
    uint8_t manuf_byte;
    
    flash_read_id(s);  /* dummy read */
    flash_spi(s, 8, FLASH_WRDI, 0);
    
    manuf_byte = flash_read_id(s) >> 16; 
    switch(manuf_byte) {
    default:
    case MANUF_MICRON:
        flash_spi(s, 8, FLASH_CLRFLAG, 0);
        break;
    case MANUF_CYPRESS:
        flash_spi(s, 8, FLASH_RESET, 0);
        break;
    case MANUF_ISSI:
        flash_spi(s, 8, FLASH_CLREXTENDED, 0);        
        break;
    }
    printk(KERN_INFO SDR_NAME " Flash_init: ID=0x%x status=0x%x\n",
           manuf_byte, flash_read_status(s));
}


#define REC_START          0x00
#define REC_NOP            0x01
#define REC_VCXOCAL        0x02
#define REC_PLLMODE        0x04
#define REC_END            0xFF

#define REC_MAGIC          "SDRMAGIC"
#define REC_START_LEN      8
#define REC_VCXOCAL_LEN    10
#define REC_PLLMODE_LEN    10
#define REC_END_LEN        4

/* CRC utilities */
static uint32_t _crc32_table[256];

#define CRCPOLY_LE 0xedb88320

static void _crc32_init(uint32_t *tab)
{
    int i, j;
    uint32_t crc;

    tab[0] = 0;
    crc = 1;
    for(i = 128; i != 0; i >>= 1) {
        crc = (crc >> 1) ^ ((-(crc & 1)) & CRCPOLY_LE);
        for(j = 0; j < 256; j += 2 * i) {
            tab[i + j] = crc ^ tab[j];
        }
    }
}

/* XXX: optimize */
static uint32_t _crc32(uint32_t crc, const uint8_t *buf, int len)
{
    int i;

    for(i = 0; i < len; i++) {
        crc ^= buf[i];
        crc = (crc >> 8) ^ _crc32_table[crc & 0xff];
    }
    return crc;
}

/* Search for the Type record and returns it in buffer (no malloc for driver usage) */
static int sdr_flash_config_read_record(SDRState *s, uint8_t type, uint8_t *buf, int bufsize)
{
    int i;
    uint offset, start;
    uint8_t data[256];
    uint8_t rechead[4];    
    uint8_t rectype;
    uint16_t reclen;
    uint32_t crc;
    int ret = -1;

    if (s->sysid == SYSID_RF_5G_V2 && ! s->is_master)
        return 0;
    
    /* dummy read */
    flash_read_id(s);
    
    /* Wait for Flash initialisation */
    /* Wait for Flash initialisation */
    for (i = 0; i < 100; i++) {
        if (! (flash_read_status(s) & FLASH_WIP))
            break;
        msleep(10);
    }
    if (flash_read_status(s) & FLASH_WIP) {
        printk(KERN_ERR SDR_NAME " flash_read_status failed\n");
        return -1;
    }
    
    offset = start = FLASH_CONFIG_ADDR;
    /* Check START record */
    rectype = sdr_flash_read_byte(s, offset++);
    reclen = sdr_flash_read_byte(s, offset++);
    if (rectype != REC_START || reclen != REC_START_LEN)
        return -1;
    for (i = 0; i < reclen; i++)
        data[i] = sdr_flash_read_byte(s, offset++);
    data[i] = '\0';
    if (memcmp(data, REC_MAGIC, REC_START_LEN)) {
        return -1;
    }
    /* Init CRC table */
    _crc32_init(_crc32_table);
    crc = ~0;
    
    /* Read all following records */
    while (offset < start + FLASH_SECTOR_SIZE - 2) {
        rechead[0] = rectype = sdr_flash_read_byte(s, offset++);
        rechead[1] = reclen = sdr_flash_read_byte(s, offset++);
        
        if (rectype == REC_END) {
            if (reclen != REC_END_LEN) {
                return -1;
            }
            /* Now read and compare checksum */
            for (i = 0; i < reclen; i++)
                data[i] = sdr_flash_read_byte(s, offset++);
        
            if (crc != ((uint32_t)data[0] << 24 | ((uint32_t)data[1] << 16)
                        | ((uint32_t)data[2] << 8) | ((uint32_t)data[3]))) {
                printk(KERN_ERR SDR_NAME " flash_config has invalid CRC\n");
                return -1;
            }
            /* Config block is valid */
            return ret;
        }
        if (reclen == 0) {     /* extended records */
            rechead[2] = sdr_flash_read_byte(s, offset++);
            rechead[3] = sdr_flash_read_byte(s, offset++);
            reclen = (rechead[2] << 8) | rechead[3];
            crc = _crc32(crc, rechead, 4);
        }
        else {
            crc = _crc32(crc, rechead, 2);
        }
        
        if (rectype == type) {
            if (reclen > bufsize)
                return -2;
            /* copy data and compute CRC */
            while (reclen > 0) {
                uint16_t remain = reclen;
                
                if (remain > sizeof(data))
                    remain = sizeof(data);
                for (i = 0; i < remain; i++)
                    data[i] = sdr_flash_read_byte(s, offset++);
                crc = _crc32(crc, data, remain);
                memcpy(buf, data, remain);
                buf += remain;
                reclen -= remain;
            }
            /* Record found: we will return 0 */
            ret = 0;
        }
    }
    
    return ret; /* or -1 since we hit the end of config sector */
}

static int sdr_flash_config_read_vcxocal(SDRState *s)
{
    uint8_t buf[REC_VCXOCAL_LEN];
    uint16_t ratio = 0;

    msleep(10);
    if (sdr_flash_config_read_record(s, REC_VCXOCAL, buf, sizeof(buf)) == 0) {
        ratio = ((uint32_t)buf[0] << 8) | ((uint32_t)buf[1] << 0);
    }
    return ratio;
}

/* returns pll_mode (see enum in sdr.h), freq and flags from config record */
static int sdr_flash_config_read_pll(SDRState *s, uint32_t *pfreq, uint32_t *pflags)
{
    uint8_t buf[REC_PLLMODE_LEN];
    uint16_t mode = SMA_PLL_IDLE;

    if (pfreq)
        *pfreq = 10000000;
    if (pflags)
        *pflags = 0;
    
    msleep(10);
    if (sdr_flash_config_read_record(s, REC_PLLMODE, buf, sizeof(buf)) == 0) {
        mode = ((uint32_t)buf[0] << 8) | ((uint32_t)buf[1] << 0);
        if (pfreq) {
            *pfreq =  ((uint64_t)buf[2] << 24) | ((uint64_t)buf[3] << 16)
                      | ((uint64_t)buf[4] << 8) | ((uint64_t)buf[5] << 0) ;
        }
        if (pflags) {
            *pflags = ((uint64_t)buf[6] << 24) | ((uint64_t)buf[7] << 16)
                      | ((uint64_t)buf[8] << 8) | ((uint64_t)buf[9] << 0) ;
        }
    }
    return mode;
}

/****************************************************************/

/* GPS UART */

#define GPS_UART_SPEED 9600

static int sdr_gps_init(SDRState *s)
{
    switch(s->sysid) {
    case SYSID_RF_5G:
    case SYSID_RF_5G_V2:
        if (! s->is_master)
            return 0;
        break;
    default:
        break;
    }    
    s->gps_rx_fifo_size = GPS_RX_FIFO_SIZE;
    s->gps_rx_fifo_buf = kmalloc(s->gps_rx_fifo_size, GFP_KERNEL);
    if (!s->gps_rx_fifo_buf)
        return -ENOMEM;
    s->gps_rx_fifo_windex = 0;
    s->gps_rx_fifo_rindex = 0;

    init_waitqueue_head(&s->gps_waitqueue);

    sdr_writel(s, CSR_GPS_UART_DIVISOR_ADDR,
               s->system_clock_frequency / GPS_UART_SPEED / 16);

    sdr_enable_interrupt(s, GPS_UART_TX_INTERRUPT);
    return 0;
}

static void sdr_gps_end(SDRState *s)
{
    switch(s->sysid) {
    case SYSID_RF_5G:
    case SYSID_RF_5G_V2:
        if (! s->is_master)
            return;
        break;
    default:
        break;
    }
        
    /* restore initial speed so that we no longer receive GPS data */
    sdr_writel(s, CSR_GPS_UART_DIVISOR_ADDR, 1);
    sdr_disable_interrupt(s, GPS_UART_TX_INTERRUPT);
    sdr_disable_interrupt(s, GPS_UART_RX_INTERRUPT);
    kfree(s->gps_rx_fifo_buf);
}

static int sdr_gps_write(SDRState *s, const uint8_t *buf, int len)
{
    uint8_t c;
    int ret, i;

    for(i = 0; i < len; i++) {
        if (get_user(c, buf + i))
            return -EFAULT;
        s->gps_write_done = 0;
        sdr_writel(s, CSR_GPS_UART_TX_DATA_ADDR, c);
        sdr_writel(s, CSR_GPS_UART_CTRL_ADDR, GPS_UART_CTRL_TX_WE);
        ret = wait_event_timeout(s->gps_waitqueue, s->gps_write_done,
                                 msecs_to_jiffies(1000));
        if (ret == 0)
            return -EIO;
    }
    return 0;
}

static void sdr_gps_rx_enable(SDRState *s, int flag)
{
    if (flag) {
        /* flush the RX fifo to get the most recent messages */
        /* XXX: not atomic */
        s->gps_rx_fifo_windex = 0;
        s->gps_rx_fifo_rindex = 0;

        sdr_enable_interrupt(s, GPS_UART_RX_INTERRUPT);
    } else {
        sdr_disable_interrupt(s, GPS_UART_RX_INTERRUPT);
    }
}

/* Note: the speed is not critical */
static int sdr_gps_read(SDRState *s, uint8_t *buf, int len)
{
    uint8_t c;
    int len1;
    unsigned long flags;

    len1 = len;
    while (len != 0) {
        spin_lock_irqsave(&s->gps_lock, flags);    
        if (s->gps_rx_fifo_rindex == s->gps_rx_fifo_windex) {
            spin_unlock_irqrestore(&s->gps_lock, flags);
            break;
        }
        c = s->gps_rx_fifo_buf[s->gps_rx_fifo_rindex];
        if (++s->gps_rx_fifo_rindex == s->gps_rx_fifo_size)
            s->gps_rx_fifo_rindex = 0;
        spin_unlock_irqrestore(&s->gps_lock, flags);
        
        if (put_user(c, buf)) {
            /* Should push back rindex ? */
            return -EFAULT;
        }
        buf++;
        len--;
    }
    return len1 - len;
}

static void sdr_gps_rx_interrupt(SDRState *s)
{
    int p, p1;
    uint8_t c;
    unsigned long flags;
    
    /* XXX: workaround for interrupt masking problem */
    if ((sdr_readl(s, CSR_MSI_ENABLE_ADDR) &
         (1 << GPS_UART_RX_INTERRUPT)) == 0)
        return;

    for(;;) {
        if (!(sdr_readl(s, CSR_GPS_UART_STATUS_ADDR) & GPS_UART_STAT_RX_AVAILABLE))
            break;
        c = sdr_readl(s, CSR_GPS_UART_RX_DATA_ADDR);
        sdr_writel(s, CSR_GPS_UART_CTRL_ADDR, GPS_UART_CTRL_RX_RE);

        /* protect access to gps fifo */
        spin_lock_irqsave(&s->gps_lock, flags);
        p = s->gps_rx_fifo_windex;
        p1 = p + 1;
        if (p1 == s->gps_rx_fifo_size)
            p1 = 0;
        if (p1 != s->gps_rx_fifo_rindex) {
            s->gps_rx_fifo_buf[p] = c;
            s->gps_rx_fifo_windex = p1;
        }
        spin_unlock_irqrestore(&s->gps_lock, flags);
    }
}

/****************************************************************/

#define PROFILE_INTERNAL       0
#define PROFILE_SLAVE_122M88   1
#define PROFILE_SLAVE_38M40    2
#define PROFILE_SLAVE_10M00    3
#define PROFILE_EXT_38M40      4
#define PROFILE_EXT_30M72      5
/* special mode for SDR 4G board to accept 10MHz as CMOS on Master/Slave connector */
#define PROFILE_SLAVE_10M00_CMOS    6

#define PROFILE_AD_FMC         7


/* clock synchronisation */

#define CDCM_SPI_TIMEOUT 100 /* ms */
#define CDCM_PLL_LOCK_TIMEOUT 2000 //1000 /* ms */

static void cdcm_write(SDRState *s, uint16_t addr, uint16_t data)
{
    int count;

    sdr_writel(s, CSR_CDCM_SPI_MOSI_ADDR, ((addr & 0x7fff) << 16) | data);
    sdr_writel(s, CSR_CDCM_SPI_CTRL_ADDR, (32 << 8) | 1);
    count = 0;
    while ((sdr_readl(s, CSR_CDCM_SPI_STATUS_ADDR) & 1) == 0) {
        udelay(10);
        count++;
        if (count >= (CDCM_SPI_TIMEOUT * 100)) {
            printk(KERN_ERR SDR_NAME " cdcm_write timeout\n");
            break;
        }
    }
}

static uint16_t cdcm_read(SDRState *s, uint16_t addr)
{
    int count;

    sdr_writel(s, CSR_CDCM_SPI_MOSI_ADDR, ((addr & 0x7fff) | (1 << 15)) << 16);
    sdr_writel(s, CSR_CDCM_SPI_CTRL_ADDR, (32 << 8) | 1);
    count = 0;
    while ((sdr_readl(s, CSR_CDCM_SPI_STATUS_ADDR) & 1) == 0) {
        udelay(10);
        count++;
        if (count >= (CDCM_SPI_TIMEOUT * 100)) {
            printk(KERN_ERR SDR_NAME " cdcm_write timeout\n");
            break;
        }
    }
    return sdr_readl(s, CSR_CDCM_SPI_MISO_ADDR) & 0xffff;
}

/* CDCM Master config */

typedef struct _cdcm6208_profile {
    const char *name;
    uint32_t clock_freq;
    const uint16_t (*regs)[2];
    int size;
} cdcm6208_profile;

/* 38.4MHz internal VCXO */
static const uint16_t cdcm_regs_vcxo_38[][2] =
{
 //  { 0, 0x0079 },  /* PLL: 35pf/4010R internal filter, 2.5mA */
    { 0, 0x01B9 },  /*  PLL: 245pf/100R internal filter, 2.5mA  for 38.4MHz PFD (38.4MHz ref input) */
    { 1, 0x0000 },  /* PLL: M = 1 => PFD = 38.4MHz */
    { 2, 0x0013 },  /* PLL: N10= 1; N8 = 20; Distribution clock = 20 * PFD = 768 MHz */
                   /* 0x18 for 30.72MHz VCXO input */
    { 3, 0x00F0 },  /* PLL: PS = 1/4, no sync, cal enable; VCO = 3072 MHz */
    { 4, 0x30AF | (2 << 3)}, // Secondary Input (internal VCXO)  in LVCMOS */
    { 5, 0x019B },  /* Y0 => CPRI LVDS (not used ?) */
    { 6, 0x0013 },
    { 7, 0x0000 },  /* Y2 and Y3 disabled */
    { 8, 0x0013 },
    { 9, 0x0053 },  /* Y4 (RFIC): LVCMOS out from PLL */
    { 10, 0x0130 }, /* Divider: 20 => 38.4 MHz out */
    { 11, 0x0000 },
#if 1
    { 12, 0x0053 }, // Y5 (REFCLK_OUT):  LVCMOS + out from PLL (to fix clock distribution problem) */
    { 13, 0x0130 }, /* Divider: 20 => 38.4 MHz out */
    { 14, 0x0000 },
#else    /* output 10MHz (+40ppm) to test ext synchro on 10MHz */
    { 12, 0x0253 }, // Y5 (REFCLK_OUT):  LVCMOS + out from PLL */
    { 13, 0x0256 }, /* Divider: frac => 10 MHz out */
    { 14, 0x6000 },
#endif
    { 15, 0x0003 }, /* Y6 (FPGA_AUXCLK): LVDS out from PLL */
    { 16, 0x0130 }, /* Divider: 20 => 38.4 MHz out */
    { 17, 0x0000 },
    { 18, 0x0000 }, /* Y7 disabled */
    { 19, 0x0130 },
    { 20, 0x0000 },
};

cdcm6208_profile cdcm6208_internal_38M4_profile =
{
     "VCXO 38.4MHz",
     38400000,
     cdcm_regs_vcxo_38,
     ARRAY_SIZE(cdcm_regs_vcxo_38)
};
    
/* 38.4MHz external REF input */
static const uint16_t cdcm_regs_ext_38[][2] =
{
    { 0, 0x01B9 },  /*  PLL: 245pf/100R internal filter, 2.5mA  for 38.4MHz PFD (38.4MHz ref input) */
    { 1, 0x0000 },  /* PLL: M = 1 => PFD = 38.4MHz */
    { 2, 0x0013 },  /* PLL: N10= 1; N8 = 20; Distribution clock = 20 * PFD = 768 MHz */
    { 3, 0x00F0 },  /* PLL: PS = 1/4, no sync, cal enable */
    { 4, 0x20AF },  /* Primary Input (external Clock Input)  in LVDS */
    { 5, 0x019B },  /* Y0 => CPRI LVDS (not used ?) */
    { 6, 0x0013 },
    { 7, 0x0000 },  /* Y2 and Y3 disabled */
    { 8, 0x0013 },
    { 9, 0x2053 },  /* Y4 (RFIC): LVCMOS out from input */
    { 10, 0x0130 }, /* Divider: 20 => 38.4 MHz out */
    { 11, 0x0000 },
    { 12, 0x2053 }, // Y5 (REFCLK_OUT):  LVCMOS + out from input (to fix clock distribution problem) */
    { 13, 0x0130 }, /* Divider: 20 => 38.4 MHz out */
    { 14, 0x0000 },
    { 15, 0x0003 }, /* Y6 (FPGA_AUXCLK): LVDS out from PLL */
    { 16, 0x0130 }, /* Divider: 20 => 38.4 MHz out */
    { 17, 0x0000 },
    { 18, 0x0000 }, /* Y7 disabled */
    { 19, 0x0130 },
    { 20, 0x0000 },
};

cdcm6208_profile cdcm6208_external_38M4_profile =
{
     "External 38.4MHz",
     38400000,
     cdcm_regs_ext_38,
     ARRAY_SIZE(cdcm_regs_ext_38)
};

/* 10MHz external REF input, LVDS */
static const uint16_t cdcm_regs_ext_10[][2] =
{
    { 0, 0x03B9 },  /*  PLL: 562pf/100R internal filter, 1.5mA  for 2MHz PFD (10MHz ref input)) */
    { 1, 0x0010 },  /* PLL: M = 5;  PFD = 10/M = 2MHz */
    { 2, 0x01BF },  /* PLL: N10= 2; N8 = 192;  Distribution clock = 384 * PFD = 768 MHz */
    { 3, 0x00F0 },  /* PLL! PS = 1/4, no sync, cal enable */
    { 4, 0x200F,},  /* Primary Input (ext CLK)    LVDS, 1.2V common */
    { 5, 0x0183 },  /* CPRI_REFCLK on Y0 (not used ?) Y1 disabled */
    { 6, 0x0013 },  /* Divider: 20 => 38.4 MHz out */
    { 7, 0x0001 },  /* Y2 and Y3 disabled */
    { 8, 0x0013 },
    { 9, 0x0053 },  /* Y4 (RFIC): LVCMOS + out from PLL */
    { 10, 0x0130 }, /* Divider: 20 => 38.4 MHz out */
    { 11, 0x0000 },
    { 12, 0x0053 }, // Y5 (REFCLK_OUT):  LVCMOS + out from PLL */
    { 13, 0x0130 }, /* Divider: 20 => 38.4 MHz out */
    { 14, 0x0000 },
    { 15, 0x0003 }, /* Y6 (FPGA_AUXCLK): LVDS out from PLL */
    { 16, 0x0130 }, /* Divider: 20 => 38.4 MHz out */
    { 17, 0x0000 },
    { 18, 0x0001 }, /* Y7 disabled */
    { 19, 0x0130 },
    { 20, 0x0000 },
};

cdcm6208_profile cdcm6208_external_10M_profile =
{
     "External 10MHz LVDS",
     10000000,
     cdcm_regs_ext_10,
     ARRAY_SIZE(cdcm_regs_ext_10)
};

/* 10MHz external REF input, LVCMOS (2.5V maxi) */
static const uint16_t cdcm_regs_ext_10_cmos[][2] =
{
    { 0, 0x03B9 },  /*  PLL: 562pf/100R internal filter, 1.5mA  for 2MHz PFD (10MHz ref input)) */
    { 1, 0x0010 },  /* PLL: M = 5;  PFD = 10/M = 2MHz */
    { 2, 0x01BF },  /* PLL: N10= 2; N8 = 192;  Distribution clock = 384 * PFD = 768 MHz */
    { 3, 0x00F0 },  /* PLL! PS = 1/4, no sync, cal enable */
    { 4, 0x2017,},  /* Primary Input (ext CLK)    LVCMOS, 2.5V maxi */
    { 5, 0x0183 },  /* CPRI_REFCLK on Y0 (not used ?) Y1 disabled */
    { 6, 0x0013 },  /* Divider: 20 => 38.4 MHz out */
    { 7, 0x0001 },  /* Y2 and Y3 disabled */
    { 8, 0x0013 },
    { 9, 0x0053 },  /* Y4 (RFIC): LVCMOS + out from PLL */
    { 10, 0x0130 }, /* Divider: 20 => 38.4 MHz out */
    { 11, 0x0000 },
    { 12, 0x0053 }, // Y5 (REFCLK_OUT):  LVCMOS + out from PLL */
    { 13, 0x0130 }, /* Divider: 20 => 38.4 MHz out */
    { 14, 0x0000 },
    { 15, 0x0003 }, /* Y6 (FPGA_AUXCLK): LVDS out from PLL */
    { 16, 0x0130 }, /* Divider: 20 => 38.4 MHz out */
    { 17, 0x0000 },
    { 18, 0x0001 }, /* Y7 disabled */
    { 19, 0x0130 },
    { 20, 0x0000 },
};

cdcm6208_profile cdcm6208_external_10M_cmos_profile =
{
     "External 10MHz LVCMOS 2.5V",
     10000000,
     cdcm_regs_ext_10_cmos,
     ARRAY_SIZE(cdcm_regs_ext_10)
};

#if 0
static void cdcm_dump(SDRState *s)
{
    int i;

    for(i = 0; i <= 21; i++) {
        printk(KERN_INFO SDR_NAME " cdcm[%d] = 0x%x\n", i, cdcm_read(s, i));
    }
    i = 40;
    printk(KERN_INFO SDR_NAME " cdcm[%d] = 0x%x\n", i, cdcm_read(s, i));
}
#endif

/* Returns 0 if PLL is locked */
static int cdcm6208_initialize(SDRState *s, int profile)
{
    const uint16_t (*regs)[2];
    int size;
    uint8_t i;
    cdcm6208_profile *p = NULL;
    unsigned long timeout;

    if (profile == s->profile)
        return 0;
    
    switch(profile) {
    default:
    case PROFILE_INTERNAL:
        p = &cdcm6208_internal_38M4_profile;
        break;
    case PROFILE_SLAVE_38M40:
        p = &cdcm6208_external_38M4_profile;
        break;
    case PROFILE_SLAVE_10M00:
        p = &cdcm6208_external_10M_profile;
        break;
    case PROFILE_SLAVE_10M00_CMOS:
        p = &cdcm6208_external_10M_cmos_profile;
        break;
    }
    printk(KERN_INFO SDR_NAME " CDCM6208_initialize (%s)\n", p->name);
    
    regs = p->regs;
    size = p->size;
    
    sdr_writel(s, CSR_CDCM_RESET_ADDR, 1);
    /* program the CDCM while in reset state to avoid outputting
       spurious signals */
    for(i = 0; i < size; i++) {
        cdcm_write(s, regs[i][0], regs[i][1]);
    }
    sdr_writel(s, CSR_CDCM_RESET_ADDR, 0);

    /* wait until the PLL is locked */
    timeout = jiffies + msecs_to_jiffies(CDCM_PLL_LOCK_TIMEOUT);
    while ((cdcm_read(s, 21) & (1 << 2)) != 0) {  /* check UNLOCK bit */
        if ((long)(jiffies - timeout) >= 0) {
            printk(KERN_ERR SDR_NAME " cdcm6208: timeout while waiting for PLL lock\n");
            s->profile = -1;
            return -1;
        }
        msleep(10);
    }
    s->sync_state.clock_freq = p->clock_freq;
    s->profile = profile;
    
    return 0;
}

#define SI5324_SPI_TIMEOUT 10 /* ms */
#define SI5324_PLL_LOCK_CHECK
#define SI5324_PLL_LOCK_TIMEOUT 12000 /* ms (can be really slow...) */


static void si5324_write(SDRState *s, uint8_t addr, uint8_t data)
{
    int count;

    /* set address */
    sdr_writel(s, CSR_SI5324_SPI_MOSI_ADDR, ((0b00000000 << 8) | addr) << 16);
    sdr_writel(s, CSR_SI5324_SPI_CTRL_ADDR, (16 << 8) | 1);
    udelay(16);
    count = 0;
    while ((sdr_readl(s, CSR_SI5324_SPI_STATUS_ADDR) & 1) == 0) {
        udelay(10);
        count++;
        if (count >= (SI5324_SPI_TIMEOUT * 100)) {
            printk(KERN_ERR SDR_NAME " si5324_write timeout\n");
            break;
        }
    }

    /* write */
    sdr_writel(s, CSR_SI5324_SPI_MOSI_ADDR, ((0b01000000 << 8) | data) << 16);
    sdr_writel(s, CSR_SI5324_SPI_CTRL_ADDR, (16 << 8) | 1);
    udelay(16);
    count = 0;
    while ((sdr_readl(s, CSR_SI5324_SPI_STATUS_ADDR) & 1) == 0) {
        udelay(10);
        count++;
        if (count >= (SI5324_SPI_TIMEOUT * 100)) {
            printk(KERN_ERR SDR_NAME " si5324_write timeout\n");
            break;
        }
    }
}

static uint8_t si5324_read(SDRState *s, uint16_t addr)
{
    int count;

    /* set address */
    sdr_writel(s, CSR_SI5324_SPI_MOSI_ADDR, ((0b00000000 << 8) | addr) << 16);
    sdr_writel(s, CSR_SI5324_SPI_CTRL_ADDR, (16 << 8) | 1);
    udelay(16);
    count = 0;
    while ((sdr_readl(s, CSR_SI5324_SPI_STATUS_ADDR) & 1) == 0) {
        udelay(10);
        count++;
        if (count >= (SI5324_SPI_TIMEOUT * 100)) {
            printk(KERN_ERR SDR_NAME " si5324_read timeout\n");
            break;
        }
    }

    /* read */
    sdr_writel(s, CSR_SI5324_SPI_MOSI_ADDR, (0b10000000U << 8) << 16);
    sdr_writel(s, CSR_SI5324_SPI_CTRL_ADDR, (16 << 8) | 1);
    udelay(16);
    count = 0;
    while ((sdr_readl(s, CSR_SI5324_SPI_STATUS_ADDR) & 1) == 0) {
        udelay(10);
        count++;
        if (count >= (SI5324_SPI_TIMEOUT * 100)) {
            printk(KERN_ERR SDR_NAME " si5324_read timeout\n");
            break;
        }
    }

    return sdr_readl(s, CSR_SI5324_SPI_MISO_ADDR) & 0xff;
}

#ifdef SI5324_200
/* CLKIN1 = CLKOUT1 = 100MHz   CLKIN2 = 38.88MHz  CLKOUT2 = 200MHz (Eth) */
static const uint16_t si5324_regs_freerun[][2] = {
    {   0, 0x54},  /* FREE_RUN: CLKIN2 = XA/XB */
    {   1, 0xe4},  /* AutoSelect Priority: CLK1 = 1st, CLK2 = 2nd */
    /* CLK1 must have priority over CLK2 to support Slave sync mode */
    {   2, 0x32},
    {   3, 0x15},
    {   4, 0x92},
    {   5, 0xed},
    {   6, 0x3f},
    {   7, 0x2a},
    {   8, 0x00},
    {   9, 0xc0},
    {  10, 0x00},
    {  11, 0x40},
    {  19, 0x29}, /* LockT */
    {  20, 0x3e},
    {  21, 0xff},
    {  22, 0xdf},
    {  23, 0x1f},
    {  24, 0x3f},
    {  25, 0x60},  /* 25: N1_HS = 7 */
    {  31, 0x00},  /* 31-32-33: NC1_LS = 8 */
    {  32, 0x00},
    {  33, 0x07},
    {  34, 0x00},  /* 34-35-36: NC2_LS = 4 */
    {  35, 0x00},
    {  36, 0x03},
    {  40, 0x20},  /* 40: N2_HS = 5 */
    {  41, 0x1B},  /* 40-41-42:  N2_LS = 0x1B58 = 7000 */
    {  42, 0x57},
    {  43, 0x00}, /* 43-44-45: N31 = 0x271 = 625 (for 100.00 MHz MHz CLK1 input) */
    {  44, 0x02},
    {  45, 0x70},
    {  46, 0x00}, /* 46-47-48: N32 = 0x0F3 = 243 (for 38.88 MHZ FREE_RUN on CLK2 input) */
    {  47, 0x00},
    {  48, 0xF2},
    {  55, 0x0B},  /* CLKIN2: 25-54 MHZ, CLKIN1: 95-215 MHz */
    { 131, 0x1f},
    { 132, 0x02},
    { 137, 0x01},  /* Fast Lock */
    { 138, 0x0f},
    { 139, 0xff},
    { 142, 0x00},
    { 143, 0x00},
    { 136, 0x40},  /* Start ICAL */
};

#else

/* XTal = 38.88MHz */
/* CLKIN1 = CLKOUT1 = CLKOUT2 = 122.88MHz  CLIN2 = 38.88MHz */
static const uint16_t si5324_regs_freerun[][2] = {
    {   0, 0x54},  /* FREE_RUN: CLKIN2 = XA/XB */
    {   1, 0xe4},  /* AutoSelect Priority: CLK1 = 1st, CLK2 = 2nd */
    /* CLK1 must have priority over CLK2 to support Slave sync mode */
    {   2, 0x42},
    {   3, 0x15},
    {   4, 0x92},
    {   5, 0xed},
    {   6, 0x3f},  /* LVDS */
    {   7, 0x2a},
    {   8, 0x00},
    {   9, 0xc0},
    {  10, 0x00},
    {  11, 0x40},
    //{  19, 0x2B}, /* LockT = 13ms for fast LOCK (~ 8 sec) */
    {  19, 0x2C}, /* LockT = 6.6ms for faster LOCK (~ 6.6 sec)*/
    {  20, 0x3e},
    {  21, 0xff},
    {  22, 0xdf},
    {  23, 0x1f},
    {  24, 0x3f},
    {  25, 0xc0},  /* 25: N1_HS = 10 */
    {  31, 0x00},  /* 31-32-33: NC1_LS = 4 */
    {  32, 0x00},
    {  33, 0x03},
    {  34, 0x00},  /* 34-35-36: NC2_LS = 4 */
    {  35, 0x00},
    {  36, 0x03},
    {  40, 0xc0},  /* 40: N2_HS = 10 */
    {  41, 0x4f},  /* 40-41-42:  N2_LS = 0x5000 = 20480 */
    {  42, 0xff},
    {  43, 0x00}, /* 43-44-45: N31 = 0x1400 = 5120 (for 122.88 MHz CLK1 input) */
    {  44, 0x13},
    {  45, 0xff},
    {  46, 0x00}, /* 46-47-48: N32 = 0x654 = 1620 (for 38.88 MHZ FREE_RUN on CLK2 input) */
    {  47, 0x06},
    {  48, 0x53},
    {  55, 0x0B},  /* CLKIN2: 25-54 MHZ, CLKIN1: 95-215 MHz */
    { 131, 0x1f},
    { 132, 0x02},
    { 137, 0x01},  /* Fast Lock */
    { 138, 0x0f},
    { 139, 0xff},
    { 142, 0x00},
    { 143, 0x00},
    { 136, 0x40},  /* Start ICAL */
};
#endif

static const uint16_t si5324_regs_external_12288[][2] = {
    {   0, 0x14},  /* external ref */
    {   1, 0xe4},  /* AutoSelect Priority: CLK1 = 1st, CLK2 = 2nd */
    {   2, 0x42},
    {   3, 0x15},
    {   4, 0x92},
    {   5, 0xed},
    {   6, 0x3f},
    {   7, 0x2a},
    {   8, 0x00},
    {   9, 0xc0},
    {  10, 0x00},
    {  11, 0x40},
    {  19, 0x2C}, /* LockT = 6.6ms for faster LOCK (~ 6.6 sec)*/
    {  20, 0x3e},
    {  21, 0xff},
    {  22, 0xdf},
    {  23, 0x1f},
    {  24, 0x3f},
    {  25, 0xc0},  /* 25: N1_HS = 10 */
    {  31, 0x00},  /* 31-32-33: NC1_LS = 4 */
    {  32, 0x00},
    {  33, 0x03},
    {  34, 0x00},  /* 34-35-36: NC2_LS = 4 */
    {  35, 0x00},
    {  36, 0x03},
    {  40, 0xc0},  /* 40: N2_HS = 10 */
    {  41, 0x4f},  /* 40-41-42: N2_LS = 0x5000 = 20480 */
    {  42, 0xff},
    {  43, 0x00}, /* 43-44-45: N31 = 0x1400 = 5120 (for 122.88 MHz CLK1 input) */
    {  44, 0x13},
    {  45, 0xff},
    {  46, 0x00}, /* 46-47-48: N32 = 0x1400 = 5120 (for external 122.88 MHZ on CLK2 input) */
    {  47, 0x13},
    {  48, 0xff},
    {  55, 0x1B},  /* CLKIN2: 95-215 MHZ, CLKIN1: 95-215 MHz */
    { 131, 0x00}, //0x1f},
    { 132, 0x00}, //0x02},
    { 137, 0x01},    /* FastLock */
    { 138, 0x0f},
    { 139, 0xff},
    { 142, 0x00},
    { 143, 0x00},
    { 136, 0x40},  /* Start ICAL */
};

static const uint16_t si5324_regs_external_3840[][2] = {
    {   0, 0x14},  /* external ref */
    {   1, 0xe4},  /* AutoSelect Priority: CLK1 = 1st, CLK2 = 2nd */
    {   2, 0x42},
    {   3, 0x15},
    {   4, 0x92},
    {   5, 0xed},
    {   6, 0x3f},
    {   7, 0x2a},
    {   8, 0x00},
    {   9, 0xc0},
    {  10, 0x00},
    {  11, 0x40},
    //{  19, 0x2B}, /* LockT = 13ms for faster LOCK (< 10sec) */
    {  19, 0x2C}, /* LockT = 6.6ms for faster LOCK (~ 6.6 sec)*/
    {  20, 0x3e},
    {  21, 0xff},
    {  22, 0xdf},
    {  23, 0x1f},
    {  24, 0x3f},
    {  25, 0xc0},
    {  31, 0x00},
    {  32, 0x00},
    {  33, 0x03},
    {  34, 0x00},
    {  35, 0x00},
    {  36, 0x03},
    {  40, 0xc0},
    {  41, 0x4f},
    {  42, 0xff},
    {  43, 0x00}, /* 43-44-45: N31 = 0x1400 = 5120 (for 122.88 MHz CLK1 input) 24KHz PLL input */
    {  44, 0x13},
    {  45, 0xff},
    {  46, 0x00}, /* 46-47-48: N32 = 0x640 = 1600 (for external 38.40 MHZ on CLK2 input) */
    {  47, 0x06},
    {  48, 0x3f},
    {  55, 0x0B},  /* CLKIN2: 25-54 MHZ, CLKIN1: 95-215 MHz */
    { 131, 0x1f},
    { 132, 0x02},
    { 137, 0x01},
    { 138, 0x0f},
    { 139, 0xff},
    { 142, 0x00},
    { 143, 0x00},
    { 136, 0x40},  /* Start ICAL */
};

typedef struct _si5324_profile {
    const char *name;
    uint32_t clock_freq;
    const uint16_t (*regs)[2];
    int size;
} si5324_profile;

si5324_profile si5324_profile_int_38M8 =
{
     "VCXO 38.8MHz",
     38800000,
     si5324_regs_freerun,
     ARRAY_SIZE(si5324_regs_freerun)
};

si5324_profile si5324_profile_slave_122M88 =
{
     "Slave 122.88MHz",
     122880000,
     si5324_regs_external_12288,
     ARRAY_SIZE(si5324_regs_external_12288)
};

si5324_profile si5324_profile_slave_38M40 =
{
     "Slave 38.40MHz",
     38400000,
     si5324_regs_external_3840,
     ARRAY_SIZE(si5324_regs_external_3840)
};

/* return 1 if Locked, 0 if not locked */
static int si5324_wait_lock(SDRState *s)
{
    int locked = 0;
    unsigned long timeout;
    
    /* wait until the PLL is locked on internal clock */
    timeout = jiffies + msecs_to_jiffies(SI5324_PLL_LOCK_TIMEOUT);
    while ((si5324_read(s, 130) & (1 << 0)) != 0) {
        if ((long)(jiffies - timeout) >= 0) {
            printk(KERN_ERR SDR_NAME " si5324: timeout while waiting for PLL lock\n");
            break;
        }
        si5324_read(s, 0);
        msleep(10);
    }
    locked = (si5324_read(s, 130) & 1) ^ 1;
    
    printk(KERN_INFO SDR_NAME " si5324 %s in %d ms (reg[128]=0x%02x reg[129]=0x%02x reg[130]=0x%02x reco=%d)\n",
           locked ? "Locked" : "Not Locked",
           SI5324_PLL_LOCK_TIMEOUT + jiffies_to_msecs(jiffies - timeout),
           si5324_read(s, 128),
           si5324_read(s, 129),
           si5324_read(s, 130),
           sdr_readl(s, CSR_SI5324_RECOVERY_CLK_ENABLE_ADDR));
#if 0
    if (!locked) {
        int i;
        /* Check each reg except ICAL */
        for(i = 0; i < ARRAY_SIZE(si5324_regs) - 1; i++) {
            int idx = si5324_regs[i][0];
            uint16_t reg = si5324_read(s, idx);
            uint16_t reg0 = si5324_regs[i][1];
            if (reg != reg0) {
                 printk(KERN_INFO SDR_NAME "  reg[%d] = 0x%02x (init: 0x%02x)\n",
                        idx, reg, reg0);
            }
        }
    }
#endif
    return locked;
}

/* Return 0 if OK, -1 if not */
static int si5324_init(SDRState *s, int profile)
{
    si5324_profile *p = NULL;
    int i;

    /* Reset Recovery flag to use Si5324 as generator */
    sdr_writel(s, CSR_SI5324_RECOVERY_CLK_ENABLE_ADDR, 0);

    if (profile == s->profile)
        return 0;
    
    switch(profile) {
    default:
    case PROFILE_INTERNAL:
        p = &si5324_profile_int_38M8;
        break;
    case PROFILE_SLAVE_122M88:
        p = &si5324_profile_slave_122M88;
        break;
    case PROFILE_SLAVE_38M40:
        p = &si5324_profile_slave_38M40;
        break;
    }
    
    si5324_write(s, 136, 0x80); /* reset */
    msleep(10);
    si5324_write(s, 136, 0x00);
    
    for(i = 0; i < p->size; i++) {
        si5324_write(s, p->regs[i][0], p->regs[i][1]);
    }
    if (! si5324_wait_lock(s))
        return -1;
        
    s->sync_state.clock_freq = p->clock_freq;
    s->profile = profile;
    return 0;
}

/****************************************************************/

/* from t_ad9528.h */

#define AD9528_ADDR_ADI_SPI_CONFIG_A 0x000
#define AD9528_ADDR_ADI_SPI_CONFIG_B 0x001
#define AD9528_ADDR_IO_UPDATE        0x00F
#define AD9528_ADDR_INPUT_RECEIVERS1 0x108
#define AD9528_ADDR_PLL2_VCO_CTRL    0x203
#define AD9528_ADDR_SYSREF_CTRL3     0x402
#define AD9528_ADDR_SYSREF_CTRL4     0x403
#define AD9528_ADDR_OUT_POWERDOWN0   0x501
#define AD9528_ADDR_OUT_POWERDOWN1   0x502
#define AD9528_ADDR_STATUS_READBACK0 0x508
#define AD9528_ADDR_STATUS_READBACK1 0x509

#define AD9528_TCXO_FPGA          1
#define AD9528_TCXO_AD9528        0
#define AD9528_REFB_SATA          1
#define AD9528_REFB_UFL           0

#define AD9528_LOCK_INT              0xe2
#define AD9528_LOCK_REFA             0xe7
#define AD9528_LOCK_REFB             0xeb

#if 0
/* Using DEVCLK and SYSREF from PLL1 output (do not use PLL2) */
#define ADDEVCLK_OUT  0x20
#define ADSYSREF_OUT  0x60
#else
/* Using DEVCLK and SYSREF from PLL2 output */
#define ADDEVCLK_OUT  0x00
#define ADSYSREF_OUT  0x40
#endif

typedef struct _ad9528_profile {
    const char *name;
    uint32_t clock_freq;
    const uint16_t (*regs)[2];
    int size;
    int vcxo_flag;
    int lock_mask;
} ad9528_profile;


/* SDR5G Rev0 (->R03)  */
/* Ref = internal 122.88MHz VCXO, driven by FPGA PWM  Lock Mask = 0xe2 */
static const uint16_t ad9528_internal_122M88_regs[][2] = {
    { 0x00, 0x3c},
    { 0x01, 0x80},
    { 0x100, 0x01},  /* REFA div = 1 */
    { 0x101, 0x00},
    { 0x102, 0x01},
    { 0x103, 0x00},
    { 0x104, 0x01},  /* N1 div = 1 */
    { 0x105, 0x00},
    { 0x106, 0x0a},  /* PLL1 CP current: 5uA; 0x80 to force holdover */
    { 0x107, 0x23},  /* no Holdover */
    { 0x108, 0x00},
    { 0x109, 0x04},
    { 0x10a, 0x0a}, /* VDD/2 holdover */
    { 0x10b, 0x00},
    { 0x200, 0xe6},
    { 0x201, 0x87},
    { 0x202, 0x03},
    { 0x203, 0x00},
    { 0x204, 0x03},
    { 0x205, 0x2a},  /* PLL2 LoopFilter: 900R / 2500R / 16pF */
    { 0x206, 0x00},
    { 0x207, 0x00},
    { 0x208, 0x09},
    { 0x209, 0x00},
    { 0x300, 0x40},  /* SYSREF FPGA0 */
    { 0x301, 0x00},
    { 0x302, 0x09},
    { 0x303, 0x00},
    { 0x304, 0x00},
    { 0x305, 0x09},
    { 0x306, 0x00},
    { 0x307, 0x00},
    { 0x308, 0x09},
    { 0x309, 0x00},
    { 0x30a, 0x00},
    { 0x30b, 0x09},
    { 0x30c, 0x40},  /* SYSREF AG9371_A */
    { 0x30d, 0x00},
    { 0x30e, 0x09},
    { 0x30f, 0x00},
    { 0x310, 0x00},
    { 0x311, 0x09},
    { 0x312, 0x40},  /* SYSREF FPGA1 */
    { 0x313, 0x00},
    { 0x314, 0x09},
    { 0x315, 0x40},  /* SYSREF AD9371_B*/
    { 0x316, 0x00},
    { 0x317, 0x09},
    { 0x318, 0x00},  /* SATA0 SYSREF output: Channel Div */
    { 0x319, 0x00},
    { 0x31a, 0x09},  /* 0x27=> 30.72MHz; 0x09 => 122.88MHz; 0x1f => 38.4MHz */
    { 0x31b, 0x40},  /* SYSREF REF_OUT */
    { 0x31c, 0x00},
    { 0x31d, 0x09},
    { 0x31e, 0x00},  /* SATA1 SYSREF output: Channel Div */
    { 0x31f, 0x00},
    { 0x320, 0x09},  /* 0x27=> 30.72MHz; 0x09 => 122.88MHz; 0x1f => 38.4MHz */
    { 0x321, 0x00},  /* SATA2 SYSREF output: Channel Div */
    { 0x322, 0x00},
    { 0x323, 0x09},  /* 0x27=> 30.72MHz; 0x09 => 122.88MHz; 0x1f => 38.4MHz */
    { 0x324, 0x00},
    { 0x325, 0x00},
    { 0x326, 0x09},
    { 0x327, 0x00},
    { 0x328, 0x00},
    { 0x329, 0x09},
    { 0x32a, 0x00},
    { 0x32b, 0x00},
    { 0x32c, 0x00},
    { 0x32d, 0x00},
    { 0x32e, 0x00},
    { 0x400, 0x00},
    { 0x401, 0x08},  /* 8: Divide by 4096 => 30KHz SYSREF clock (2: divide by 1024 => 120KHz) */
    { 0x402, 0x00},  /* SPI trigger */
    { 0x403, 0x90},  /* Continous mode */
    { 0x404, 0x04},
    { 0x500, 0x10},
    { 0x501, 0x00},
    //{ 0x502, 0x3F}, /* 0x3F: power down CLKOUT 0, 1, and 2 */
    { 0x502, 0x22}, /* 0x32: Power down out 9 and 13 */
    { 0x503, 0xff},
    //{ 0x504, 0xc0},  /* power down LDO for 9 and CLK OUT */
    { 0x504, 0xdd}, /* power down LDO for 9 and 13 */
    { 0x505, 0x07},
    { 0x506, 0x01},
    { 0x507, 0x0c},
    
    { 0x00F, 0x01},   /* Update */
};

ad9528_profile ad9528_internal_122M88_1_profile = {
     "Internal 122.88MHz",
     122880000,
     ad9528_internal_122M88_regs,
     ARRAY_SIZE(ad9528_internal_122M88_regs),
     AD9528_REFB_SATA,   /* = AD9528_TVCO_FPGA on rev 0 */
     AD9528_LOCK_INT
};

/* Ref = 122.88MHz on REFA (SATA)  Lock Mask = 0xe7 */
static const uint16_t ad9528_RefA_122M88_regs[][2] = {
    { 0x00, 0x3c},
    { 0x01, 0x80},
    { 0x100, 0x02},  /* RefA div = 2 */
    { 0x101, 0x00},
    { 0x102, 0x01},
    { 0x103, 0x00},
    { 0x104, 0x02},  /* N1 div = 2    122.88MHz / 2 = 61.44MHz PFD freq */
    { 0x105, 0x00},
    { 0x106, 0x0a},
    { 0x107, 0x03},  /* Auto holdover */
    { 0x108, 0x28},  /* REFA on, diff */
    { 0x109, 0x04},
    { 0x10a, 0x02},  /* Ref = REFA, Tristate holdover */
    { 0x10b, 0x00},
    { 0x200, 0xe6},
    { 0x201, 0x87},  /* CAL div = 30 */
    { 0x202, 0x03},
    { 0x203, 0x00},
    { 0x204, 0x03},  /* M1 = 3 */
    { 0x205, 0x2a},
    { 0x206, 0x00},
    { 0x207, 0x00},
    { 0x208, 0x09},  /* N2 Div = 10 */
    { 0x209, 0x00},
    { 0x300, ADSYSREF_OUT}, /* OUT0: FPGA0_SYSREF */
    { 0x301, 0x00},
    { 0x302, 0x09},
    { 0x303, ADDEVCLK_OUT}, /* OUT1: FPGA0_DEV_CLK */
    { 0x304, 0x00},
    { 0x305, 0x09},
    { 0x306, ADDEVCLK_OUT}, /* OUT2: AD_A_DEV_CLK */
    { 0x307, 0x00},  /* 0x40 LVDS Boost */
    { 0x308, 0x09},
    { 0x309, ADDEVCLK_OUT}, /* OUT3: AD_B_DEV_CLK */
    { 0x30a, 0x00},  /* 0x40 LVDS Boost */
    { 0x30b, 0x09},
    { 0x30c, ADSYSREF_OUT}, /* OUT4: AD_A_SYSREF */
    { 0x30d, 0x00},
    { 0x30e, 0x09},
    { 0x30f, ADDEVCLK_OUT}, /* OUT5: FPGA1_DEV_CLK */
    { 0x310, 0x00},
    { 0x311, 0x09},
    { 0x312, ADSYSREF_OUT}, /* OUT6: FPGA1_SYSREF */
    { 0x313, 0x00},
    { 0x314, 0x09},
    { 0x315, ADSYSREF_OUT}, /* OUT7: AD_B_SYSREF */
    { 0x316, 0x00},
    { 0x317, 0x09},
    { 0x318, ADDEVCLK_OUT},  /* OUT8: CLKOUT0 */
    { 0x319, 0x00},
    { 0x31a, 0x09},
    { 0x31b, ADDEVCLK_OUT},  /* OUT9: REFOUT, N/A */
    { 0x31c, 0x00},
    { 0x31d, 0x09},
    { 0x31e, ADDEVCLK_OUT},  /* OUT10: CLKOUT1 */
    { 0x31f, 0x00},
    { 0x320, 0x09},
    { 0x321, ADDEVCLK_OUT},  /* OUT11: CLKOUT2 */
    { 0x322, 0x00},
    { 0x323, 0x09},
    { 0x324, ADDEVCLK_OUT},  /* OUT12: N/A */
    { 0x325, 0x00},
    { 0x326, 0x09},
    { 0x327, ADDEVCLK_OUT},  /* OUT13: N/A */
    { 0x328, 0x00},
    { 0x329, 0x09},
    { 0x32a, 0x00},
    { 0x32b, 0x00},
    { 0x32c, 0x00},
    { 0x32d, 0x00},
    { 0x32e, 0x00},
    { 0x400, 0x00},
    { 0x401, 0x08},  /* 2 */
    { 0x402, 0x00},
    { 0x403, 0x80},
    { 0x404, 0x04},
    { 0x500, 0x10},
    { 0x501, 0x00},
    { 0x502, 0x22}, /* Power down out 9 and 13 */
    { 0x503, 0xff},
    { 0x504, 0xdd}, /* power down LDO for 9 and 13 */
    { 0x505, 0x07},
    { 0x506, 0x01},
    { 0x507, 0x0c},

    { 0x0F, 0x01},   /* Update */
};

ad9528_profile ad9528_RefA_122M88_0_profile = {
     "RefA 122.88MHz",
     122880000,
     ad9528_RefA_122M88_regs,
     ARRAY_SIZE(ad9528_RefA_122M88_regs),
     AD9528_TCXO_AD9528,
     AD9528_LOCK_REFA
};

/* Ref = 38.40MHz on REFA (SATA)  Lock Mask = 0xe7*/
static const uint16_t ad9528_RefA_38M40_regs[][2] = {
    { 0x00, 0x3c},
    { 0x01, 0x80},
    { 0x100, 0x05},  /* REFA div = 5    38.40Mhz / 5  = 7.68MHz */
    { 0x101, 0x00},
    { 0x102, 0x01},
    { 0x103, 0x00},
    { 0x104, 0x10},  /* N1 div = 16    122.88MHz / 16 = 7.68MHz */
    { 0x105, 0x00},
    { 0x106, 0x0a},
    { 0x107, 0x03},
    { 0x108, 0x28},  /* REFA on, diff */
    { 0x109, 0x04},
    { 0x10a, 0x02},  /* Ref = REFA, tristate holdover */
    { 0x10b, 0x00},
    { 0x200, 0xe6},
    { 0x201, 0x87},  /* CAL div = 30 */
    { 0x202, 0x03},
    { 0x203, 0x00},
    { 0x204, 0x03},  /* M1 = 3 */
    { 0x205, 0x2a},
    { 0x206, 0x00},
    { 0x207, 0x00},
    { 0x208, 0x09},  /* N2 div = 10 */
    { 0x209, 0x00},
    { 0x300, ADSYSREF_OUT}, /* OUT0: FPGA0_SYSREF */
    { 0x301, 0x00},
    { 0x302, 0x09},
    { 0x303, ADDEVCLK_OUT}, /* OUT1: FPGA0_DEV_CLK */
    { 0x304, 0x00},
    { 0x305, 0x09},
    { 0x306, ADDEVCLK_OUT}, /* OUT2: AD_A_DEV_CLK */
    { 0x307, 0x00},  /* 0x40 LVDS Boost */
    { 0x308, 0x09},
    { 0x309, ADDEVCLK_OUT}, /* OUT3: AD_B_DEV_CLK */
    { 0x30a, 0x00},  /* 0x40 LVDS Boost */
    { 0x30b, 0x09},
    { 0x30c, ADSYSREF_OUT}, /* OUT4: AD_A_SYSREF */
    { 0x30d, 0x00},
    { 0x30e, 0x09},
    { 0x30f, ADDEVCLK_OUT}, /* OUT5: FPGA1_DEV_CLK */
    { 0x310, 0x00},
    { 0x311, 0x09},
    { 0x312, ADSYSREF_OUT}, /* OUT6: FPGA1_SYSREF */
    { 0x313, 0x00},
    { 0x314, 0x09},
    { 0x315, ADSYSREF_OUT}, /* OUT7: AD_B_SYSREF */
    { 0x316, 0x00},
    { 0x317, 0x09},
    { 0x318, ADDEVCLK_OUT},  /* OUT8: CLKOUT0 */
    { 0x319, 0x00},
    { 0x31a, 0x09},
    { 0x31b, ADDEVCLK_OUT},  /* OUT9: REFOUT, N/A */
    { 0x31c, 0x00},
    { 0x31d, 0x09},
    { 0x31e, ADDEVCLK_OUT},  /* OUT10: CLKOUT1 */
    { 0x31f, 0x00},
    { 0x320, 0x09},
    { 0x321, ADDEVCLK_OUT},  /* OUT11: CLKOUT2 */
    { 0x322, 0x00},
    { 0x323, 0x09},
    { 0x324, ADDEVCLK_OUT},  /* OUT12: N/A */
    { 0x325, 0x00},
    { 0x326, 0x09},
    { 0x327, ADDEVCLK_OUT},  /* OUT13: N/A */
    { 0x328, 0x00},
    { 0x329, 0x09},
    { 0x32a, 0x00},
    { 0x32b, 0x00},
    { 0x32c, 0x00},
    { 0x32d, 0x00},
    { 0x32e, 0x00},
    { 0x400, 0x00},
    { 0x401, 0x08}, /* 2 */
    { 0x402, 0x00},
    { 0x403, 0x80},
    { 0x404, 0x04},
    { 0x500, 0x10},
    { 0x501, 0x00},
    { 0x502, 0x22}, /* Power down out 9 and 13 */
    { 0x503, 0xff},
    { 0x504, 0xdd}, /* power down LDO for 9 and 13 */
    { 0x505, 0x07},
    { 0x506, 0x01},
    { 0x507, 0x0c},

    { 0x0F, 0x01},   /* Update */
};

ad9528_profile ad9528_RefA_38M40_0_profile = {
     "RefA 38.40MHz",
     38400000,
     ad9528_RefA_38M40_regs,
     ARRAY_SIZE(ad9528_RefA_38M40_regs),
     AD9528_TCXO_AD9528,
     AD9528_LOCK_REFA
};

/* Ref = 38.40MHz on REFB (ext CLK)  Lock Mask = 0xeb */
static const uint16_t ad9528_RefB_38M40_regs[][2] = {
    { 0x00, 0x3c},
    { 0x01, 0x80},
    { 0x100, 0x01},
    { 0x101, 0x00},
    { 0x102, 0x05},  /* REFB div = 5    38.40Mhz / 5  = 7.68MHz */
    { 0x103, 0x00},  /* REFB div = 5 */
    { 0x104, 0x10},  /* N1 div = 16    122.88MHz / 16 = 7.68MHz */
    { 0x105, 0x00},  /* N1 div = 16 */
    { 0x106, 0x0a},
    { 0x107, 0x03},
    { 0x108, 0x50},  /* REFB on, diff */
    { 0x109, 0x04},
    { 0x10a, 0x03},  /* Ref = REFB, tristate holdover */
    { 0x10b, 0x00},
    { 0x200, 0xe6},
    { 0x201, 0x87},  /* CAL div = 30 */
    { 0x202, 0x03},
    { 0x203, 0x00},
    { 0x204, 0x03},  /* M1 = 3 */
    { 0x205, 0x2a},
    { 0x206, 0x00},
    { 0x207, 0x00},
    { 0x208, 0x09},  /* N2 div = 10 */
    { 0x209, 0x00},
    { 0x300, ADSYSREF_OUT}, /* OUT0: FPGA0_SYSREF */
    { 0x301, 0x00},
    { 0x302, 0x09},
    { 0x303, ADDEVCLK_OUT}, /* OUT1: FPGA0_DEV_CLK */
    { 0x304, 0x00},
    { 0x305, 0x09},
    { 0x306, ADDEVCLK_OUT}, /* OUT2: AD_A_DEV_CLK */
    { 0x307, 0x00},  /* 0x40 LVDS Boost */
    { 0x308, 0x09},
    { 0x309, ADDEVCLK_OUT}, /* OUT3: AD_B_DEV_CLK */
    { 0x30a, 0x00},  /* 0x40 LVDS Boost */
    { 0x30b, 0x09},
    { 0x30c, ADSYSREF_OUT}, /* OUT4: AD_A_SYSREF */
    { 0x30d, 0x00},
    { 0x30e, 0x09},
    { 0x30f, ADDEVCLK_OUT}, /* OUT5: FPGA1_DEV_CLK */
    { 0x310, 0x00},
    { 0x311, 0x09},
    { 0x312, ADSYSREF_OUT}, /* OUT6: FPGA1_SYSREF */
    { 0x313, 0x00},
    { 0x314, 0x09},
    { 0x315, ADSYSREF_OUT}, /* OUT7: AD_B_SYSREF */
    { 0x316, 0x00},
    { 0x317, 0x09},
    { 0x318, ADDEVCLK_OUT},  /* OUT8: CLKOUT0 */
    { 0x319, 0x00},
    { 0x31a, 0x09},
    { 0x31b, ADDEVCLK_OUT},  /* OUT9: REFOUT, N/A */
    { 0x31c, 0x00},
    { 0x31d, 0x09},
    { 0x31e, ADDEVCLK_OUT},  /* OUT10: CLKOUT1 */
    { 0x31f, 0x00},
    { 0x320, 0x09},
    { 0x321, ADDEVCLK_OUT},  /* OUT11: CLKOUT2 */
    { 0x322, 0x00},
    { 0x323, 0x09},
    { 0x324, ADDEVCLK_OUT},  /* OUT12: N/A */
    { 0x325, 0x00},
    { 0x326, 0x09},
    { 0x327, ADDEVCLK_OUT},  /* OUT13: N/A */
    { 0x328, 0x00},
    { 0x329, 0x09},
    { 0x32a, 0x00},
    { 0x32b, 0x00},
    { 0x32c, 0x00},
    { 0x32d, 0x00},
    { 0x32e, 0x00},
    { 0x400, 0x00},
    { 0x401, 0x08}, /* 2 */
    { 0x402, 0x00},
    { 0x403, 0x80},
    { 0x404, 0x04},
    { 0x500, 0x10},
    { 0x501, 0x00},
    { 0x502, 0x22}, /* Power down out 9 and 13 */
    { 0x503, 0xff},
    { 0x504, 0xdd}, /* power down LDO for 9 and 13 */
    { 0x505, 0x07},
    { 0x506, 0x01},
    { 0x507, 0x0c},

    { 0x0F, 0x01},   /* Update */
};

ad9528_profile ad9528_RefB_38M40_0_profile = {
     "RefB 38.40MHz",
     38400000,
     ad9528_RefB_38M40_regs,
     ARRAY_SIZE(ad9528_RefB_38M40_regs),
     AD9528_TCXO_AD9528,    /* = AD9528_REFB_UFL on Rev 1 */
     AD9528_LOCK_REFB
};

ad9528_profile ad9528_RefB_38M40_1_profile = {
     "RefB 38.40MHz",
     38400000,
     ad9528_RefB_38M40_regs,
     ARRAY_SIZE(ad9528_RefB_38M40_regs),
     AD9528_REFB_SATA,    /* Select SATA input (Slave mode on Rev 1) */
     AD9528_LOCK_REFB
};

/* Ref = 30.72MHz on REFB (ext CLK)   Lock Mask = 0xeb */
static const uint16_t ad9528_RefB_30M72_regs[][2] = {
    { 0x00, 0x3c},
    { 0x01, 0x80},
    { 0x100, 0x01},
    { 0x101, 0x00},
    { 0x102, 0x01},  /* REFB div = 1 */
    { 0x103, 0x00},
    { 0x104, 0x04},  /* N1 div = 4    122.88MHz / 4 = 30.72MHz */
    { 0x105, 0x00},
    { 0x106, 0x0a},
    { 0x107, 0x03},
    { 0x108, 0x50},  /* REFB on, diff */
    { 0x109, 0x04},
    { 0x10a, 0x03},  /* Ref = REFB, tristate holdover */
    { 0x10b, 0x00},
    { 0x200, 0xe6},
    { 0x201, 0x87},  /* CAL div = 30 */
    { 0x202, 0x03},
    { 0x203, 0x00},
    { 0x204, 0x03},  /* M1 = 3 */
    { 0x205, 0x2a},
    { 0x206, 0x00},
    { 0x207, 0x00},
    { 0x208, 0x09},  /* N2 div = 10 */
    { 0x209, 0x00},
    { 0x300, ADSYSREF_OUT}, /* OUT0: FPGA0_SYSREF */
    { 0x301, 0x00},
    { 0x302, 0x09},
    { 0x303, ADDEVCLK_OUT}, /* OUT1: FPGA0_DEV_CLK */
    { 0x304, 0x00},
    { 0x305, 0x09},
    { 0x306, ADDEVCLK_OUT}, /* OUT2: AD_A_DEV_CLK */
    { 0x307, 0x00},  /* 0x40 LVDS Boost */
    { 0x308, 0x09},
    { 0x309, ADDEVCLK_OUT}, /* OUT3: AD_B_DEV_CLK */
    { 0x30a, 0x00},  /* 0x40 LVDS Boost */
    { 0x30b, 0x09},
    { 0x30c, ADSYSREF_OUT}, /* OUT4: AD_A_SYSREF */
    { 0x30d, 0x00},
    { 0x30e, 0x09},
    { 0x30f, ADDEVCLK_OUT}, /* OUT5: FPGA1_DEV_CLK */
    { 0x310, 0x00},
    { 0x311, 0x09},
    { 0x312, ADSYSREF_OUT}, /* OUT6: FPGA1_SYSREF */
    { 0x313, 0x00},
    { 0x314, 0x09},
    { 0x315, ADSYSREF_OUT}, /* OUT7: AD_B_SYSREF */
    { 0x316, 0x00},
    { 0x317, 0x09},
    { 0x318, ADDEVCLK_OUT},  /* OUT8: CLKOUT0 */
    { 0x319, 0x00},
    { 0x31a, 0x09},
    { 0x31b, ADDEVCLK_OUT},  /* OUT9: REFOUT, N/A */
    { 0x31c, 0x00},
    { 0x31d, 0x09},
    { 0x31e, ADDEVCLK_OUT},  /* OUT10: CLKOUT1 */
    { 0x31f, 0x00},
    { 0x320, 0x09},
    { 0x321, ADDEVCLK_OUT},  /* OUT11: CLKOUT2 */
    { 0x322, 0x00},
    { 0x323, 0x09},
    { 0x324, ADDEVCLK_OUT},  /* OUT12: N/A */
    { 0x325, 0x00},
    { 0x326, 0x09},
    { 0x327, ADDEVCLK_OUT},  /* OUT13: N/A */
    { 0x328, 0x00},
    { 0x329, 0x09},
    { 0x32a, 0x00},
    { 0x32b, 0x00},
    { 0x32c, 0x00},
    { 0x32d, 0x00},
    { 0x32e, 0x00},
    { 0x400, 0x00},
    { 0x401, 0x08}, /* 2 */
    { 0x402, 0x00},
    { 0x403, 0x80},
    { 0x404, 0x04},
    { 0x500, 0x10},
    { 0x501, 0x00},
    { 0x502, 0x22}, /* Power down out 9 and 13 */
    { 0x503, 0xff},
    { 0x504, 0xdd}, /* power down LDO for 9 and 13 */
    { 0x505, 0x07},
    { 0x506, 0x01},
    { 0x507, 0x0c},

    { 0x0F, 0x01},   /* Update */
};

ad9528_profile ad9528_RefB_30M72_0_profile = {
     "RefB 30.72MHz",
     30720000,
     ad9528_RefB_30M72_regs,
     ARRAY_SIZE(ad9528_RefB_30M72_regs),
     AD9528_TCXO_AD9528,     /* = AD9528_REFB_UFL for Rev 1 */
     AD9528_LOCK_REFB
};

/****************************************************************/
/* for SDR5G Rev1 (R04 ->)  */

/* Ref = 122.88MHz on REFB (SATA),  Lock Mask = 0xeB */
static const uint16_t ad9528_RefB_122M88_regs[][2] = {
    { 0x00, 0x3c},
    { 0x01, 0x80},
    { 0x100, 0x01},
    { 0x101, 0x00},
    { 0x102, 0x02},  /* REFB div = 2 */
    { 0x103, 0x00},
    { 0x104, 0x02},  /* N1 div = 2    122.88MHz / 2 = 61.44MHz PFD freq */
    { 0x105, 0x00},
    { 0x106, 0x0a},  /* 0x0a normal, 0x8a to force holdover */
    { 0x107, 0x03},  /* auto Holdover */
    { 0x108, 0x50},  /* REFB on, diff */
    { 0x109, 0x04},
    { 0x10a, 0x03},  /* Ref = REFB, tristate holdover */
    { 0x10b, 0x00},
    { 0x200, 0xe6},
    { 0x201, 0x87},  /* CAL div = 30 */
    { 0x202, 0x03},
    { 0x203, 0x00},
    { 0x204, 0x03},  /* M1 = 3 */
    { 0x205, 0x2a},
    { 0x206, 0x00},
    { 0x207, 0x00},
    { 0x208, 0x09},  /* N2 Div = 10 */
    { 0x209, 0x00},
    { 0x300, ADSYSREF_OUT}, /* OUT0: FPGA0_SYSREF */
    { 0x301, 0x00},
    { 0x302, 0x09},
    { 0x303, ADDEVCLK_OUT}, /* OUT1: FPGA0_DEV_CLK */
    { 0x304, 0x00},
    { 0x305, 0x09},
    { 0x306, ADDEVCLK_OUT}, /* OUT2: AD_A_DEV_CLK */
    { 0x307, 0x00},  /* 0x40 LVDS Boost */
    { 0x308, 0x09},
    { 0x309, ADDEVCLK_OUT}, /* OUT3: AD_B_DEV_CLK */
    { 0x30a, 0x00},  /* 0x40 LVDS Boost */
    { 0x30b, 0x09},
    { 0x30c, ADSYSREF_OUT}, /* OUT4: AD_A_SYSREF */
    { 0x30d, 0x00},
    { 0x30e, 0x09},
    { 0x30f, ADDEVCLK_OUT}, /* OUT5: FPGA1_DEV_CLK */
    { 0x310, 0x00},
    { 0x311, 0x09},
    { 0x312, ADSYSREF_OUT}, /* OUT6: FPGA1_SYSREF */
    { 0x313, 0x00},
    { 0x314, 0x09},
    { 0x315, ADSYSREF_OUT}, /* OUT7: AD_B_SYSREF */
    { 0x316, 0x00},
    { 0x317, 0x09},
    { 0x318, ADDEVCLK_OUT},  /* OUT8: CLKOUT0 */
    { 0x319, 0x00},
    { 0x31a, 0x09},
    { 0x31b, ADDEVCLK_OUT},  /* OUT9: REFOUT, N/A */
    { 0x31c, 0x00},
    { 0x31d, 0x09},
    { 0x31e, ADDEVCLK_OUT},  /* OUT10: CLKOUT1 */
    { 0x31f, 0x00},
    { 0x320, 0x09},
    { 0x321, ADDEVCLK_OUT},  /* OUT11: CLKOUT2 */
    { 0x322, 0x00},
    { 0x323, 0x09},
    { 0x324, ADDEVCLK_OUT},  /* OUT12: N/A */
    { 0x325, 0x00},
    { 0x326, 0x27},         /* 30.72MHz out */
    { 0x327, ADDEVCLK_OUT},  /* OUT13: N/A */
    { 0x328, 0x00},
    { 0x329, 0x09},
    { 0x32a, 0x00},
    { 0x32b, 0x00},
    { 0x32c, 0x00},
    { 0x32d, 0x00},
    { 0x32e, 0x00},
    { 0x400, 0x00},
    { 0x401, 0x08},  /* SYSREF Div 0x800 => 122.88/(2*2048) => 30KHz (2 => 122.88/1024 => 120KHz) */
    { 0x402, 0x00},  /* SPI trigger */
    { 0x403, 0x90},  /* Continous mode */
    { 0x404, 0x04},
    { 0x500, 0x10},
    { 0x501, 0x00},
    { 0x502, 0x22}, /* Power down out 9 and 13 */
    { 0x503, 0xff},
    { 0x504, 0xdd}, /* power down LDO for 9 and 13 */
    { 0x505, 0x07},
    { 0x506, 0x01},
    { 0x507, 0x0c},

    { 0x00F, 0x01},   /* Update */
};

ad9528_profile ad9528_RefB_122M88_1_profile = {
     "RefB 122.88MHz",
     122880000,
     ad9528_RefB_122M88_regs,
     ARRAY_SIZE(ad9528_RefB_122M88_regs),
     AD9528_REFB_SATA,           /* Select SATA connector on Rev1 */
     AD9528_LOCK_REFB
};

/* Coarse delay: 1 step = 1/2 period PLL2 (1.2288GHz) ~ 407 ps */
#define FPGASYSREF_COFF_A  0x00  /* Max: 0x3F */
#define FPGASYSREF_COFF_B  0x00  /* Max: 0x3F */
#define FPGADEVCLK_COFF_A  0x00  /* Max: 0x3F */
#define FPGADEVCLK_COFF_B  0x00  /* Max: 0x3F */
#define ADSYSREF_COFF_A  0 // 0x01  /* Max: 0x3F */
#define ADDEVCLK_COFF_A  0 // 0x01  /* Max: 0x3F */
#define ADSYSREF_COFF_B  0x00  /* Max: 0x3F */
#define ADDEVCLK_COFF_B  0x00  /* Max: 0x3F */

/* Fine delay: 0x10 to Enable, ~31ps/step */
#define FPGASYSREF_FINE  0 //(0x010 + 0x2)  /* Max: 0x0F */
#define FPGADEVCLK_FINE  0 //(0x010 + 0x2)  /* Max: 0x0F */

#define ADSYSREF_FINE  (0x0)  /* Max: 0x0F */
#define ADDEVCLK_FINE  (0x0)  /* Max: 0x0F */

#define ADSYSREF_BOOST 0  //(0x40)  /* to compensate extra 100R (remove for Production) */


/* Ref = 30.72MHz on REFA (SATA)  Lock Mask = 0xe7 */
static const uint16_t ad9528_RefA_30M72_regs[][2] = {
    { 0x00, 0x3c},
    { 0x01, 0x80},
    { 0x100, 0x01},  /* RefA div = 1 */
    { 0x101, 0x00},
    { 0x102, 0x01},
    { 0x103, 0x00},
    { 0x104, 0x04},  /* N1 div = 4    122.88MHz / 4 = 30.72MHz */
    { 0x105, 0x00},
    { 0x106, 0x0a},  /* PLL1 Charge Pump current: 10uA */
    { 0x107, 0x03},  /* Auto holdover */
    { 0x108, 0x08},  /* REFA on, single ended */
    { 0x109, 0x04},  /* 4: PPL1  from VCXO, 0: PLL1 from PPL2 output */
    { 0x10a, 0x02},  /* Ref = REFA, tristate holdover */
    { 0x10b, 0x00},
    { 0x200, 0xe6},
    { 0x201, 0x87},  /* CAL div = 30 */
    { 0x202, 0x03},
    { 0x203, 0x00},
    { 0x204, 0x03},  /* M1 = 3 */
    { 0x205, 0x2a},  /* PLL2 loop filter: 900R/2500R/16pF */
    { 0x206, 0x00},
    { 0x207, 0x00},
    { 0x208, 0x09},  /* N2 Div = 10 */
    { 0x209, 0x00},
    { 0x300, ADSYSREF_OUT}, /* OUT0: FPGA0_SYSREF */
    { 0x301, 0x00},
    { 0x302, 0x09},
    { 0x303, ADDEVCLK_OUT}, /* OUT1: FPGA0_DEV_CLK */
    { 0x304, 0x00},
    { 0x305, 0x09},
    { 0x306, ADDEVCLK_OUT}, /* OUT2: AD_A_DEV_CLK */
    { 0x307, 0x00},  /* 0x40 LVDS Boost */
    { 0x308, 0x09},
    { 0x309, ADDEVCLK_OUT}, /* OUT3: AD_B_DEV_CLK */
    { 0x30a, 0x00},  /* 0x40 LVDS Boost */
    { 0x30b, 0x09},
    { 0x30c, ADSYSREF_OUT}, /* OUT4: AD_A_SYSREF */
    { 0x30d, 0x00 + ADSYSREF_COFF_A},
    { 0x30e, 0x09},
    { 0x30f, ADDEVCLK_OUT}, /* OUT5: FPGA1_DEV_CLK */
    { 0x310, 0x00},
    { 0x311, 0x09},
    { 0x312, ADSYSREF_OUT}, /* OUT6: FPGA1_SYSREF */
    { 0x313, 0x00},
    { 0x314, 0x09},
    { 0x315, ADSYSREF_OUT}, /* OUT7: AD_B_SYSREF */
    { 0x316, 0x00 + ADSYSREF_COFF_B},
    { 0x317, 0x09},
    { 0x318, ADDEVCLK_OUT},  /* OUT8: CLKOUT0 */
    { 0x319, 0x00},
    { 0x31a, 0x09},   // 0x01 to output 614.4 MHz */
    { 0x31b, ADDEVCLK_OUT},  /* OUT9: REFOUT, N/A */
    { 0x31c, 0x00},
    { 0x31d, 0x09},
    { 0x31e, ADDEVCLK_OUT},  /* OUT10: CLKOUT1 */
    { 0x31f, 0x00},
    { 0x320, 0x09},
    { 0x321, ADDEVCLK_OUT},  /* OUT11: CLKOUT2 */
    { 0x322, 0x00},
    { 0x323, 0x09},
    { 0x324, ADDEVCLK_OUT},  /* OUT12: CY22150 for SDR100-V2 */
    { 0x325, 0x00},         /* 00 = LVDS  80 = HSTL */
    { 0x326, 0x27},         /* 30.72MHz out */
    { 0x327, ADDEVCLK_OUT},  /* OUT13: N/A */
    { 0x328, 0x00},
    { 0x329, 0x09},
    { 0x32a, 0x00},
    { 0x32b, 0x00},
    { 0x32c, 0x00},
    { 0x32d, 0x00},  /* SYSREF resampling Bypass 0xA2 */
    { 0x32e, 0x00},  /* SYSREF resampling Bypass 0x01 */
    { 0x400, 0x00},
    { 0x401, 0x08},  /* SYSREF Div 0x800 => 122.88/(2*2048) => 30KHz (2 => 122.88/1024 => 120KHz) */
    { 0x402, 0x00},
    { 0x403, 0x80},
    { 0x404, 0x04},
    { 0x500, 0x10},
    { 0x501, 0x00}, /*  Default: All power UP (else SYSREF does not work)*/
    { 0x502, 0x32}, /* Power down out 9, 12 and 13 */
    { 0x503, 0xff},
    { 0x504, 0xcd}, /* Power down out 9, 12 and 13 */
    { 0x505, 0x07},
    { 0x506, 0x01},
    { 0x507, 0x0c},

    { 0x0F, 0x01},   /* Update */
};

ad9528_profile ad9528_RefA_30M72_1_profile = {
     "RefA 30.72MHz",
     30720000,
     ad9528_RefA_30M72_regs,
     ARRAY_SIZE(ad9528_RefA_30M72_regs),
     AD9528_REFB_SATA,
     AD9528_LOCK_REFA
};

/****************/

/* FreeRun on internal VCXO  Lock Mask = 0xf2 */
static const uint16_t ad9528_FreeRun_regs[][2] = {
    { 0x00, 0x3c},
    { 0x01, 0x80},
    { 0x100, 0x01},  /* RefA div = 1 */
    { 0x101, 0x00},
    { 0x102, 0x01},
    { 0x103, 0x00},
    { 0x104, 0x04},  /* N1 div = 4    122.88MHz / 4 = 30.72MHz */
    { 0x105, 0x00},
    { 0x106, 0x0a},  /* Force Holdover */
    { 0x107, 0x03},  /* Auto holdover */
    { 0x108, 0x00},  /* REFA disabled, VCXO pos Single Ended */
    { 0x109, 0x04},  /* 4: PPL1  from VCXO, 0: PLL1 from PPL2 output */
    { 0x10a, 0x0a},  /* Holdover at VCC/2 */
    { 0x10b, 0x00},
    { 0x200, 0xe6},
    { 0x201, 0x87},  /* CAL div = 30 */
    { 0x202, 0x03},
    { 0x203, 0x00},
    { 0x204, 0x03},  /* M1 = 3 */
    { 0x205, 0x2a},
    { 0x206, 0x00},
    { 0x207, 0x00},
    { 0x208, 0x09},  /* N2 Div = 10 */
    { 0x209, 0x00},
    { 0x300, ADSYSREF_OUT}, /* OUT0: FPGA0_SYSREF */
    { 0x301, 0x00},
    { 0x302, 0x09},
    { 0x303, ADDEVCLK_OUT}, /* OUT1: FPGA0_DEV_CLK */
    { 0x304, 0x00},
    { 0x305, 0x09},
    { 0x306, ADDEVCLK_OUT}, /* OUT2: AD_A_DEV_CLK */
    { 0x307, 0x00},  /* 0x40 LVDS Boost */
    { 0x308, 0x09},
    { 0x309, ADDEVCLK_OUT}, /* OUT3: AD_B_DEV_CLK */
    { 0x30a, 0x00},  /* 0x40 LVDS Boost */
    { 0x30b, 0x09},
    { 0x30c, ADSYSREF_OUT}, /* OUT4: AD_A_SYSREF */
    { 0x30d, 0x00 + ADSYSREF_COFF_A},
    { 0x30e, 0x09},
    { 0x30f, ADDEVCLK_OUT}, /* OUT5: FPGA1_DEV_CLK */
    { 0x310, 0x00},
    { 0x311, 0x09},
    { 0x312, ADSYSREF_OUT}, /* OUT6: FPGA1_SYSREF */
    { 0x313, 0x00},
    { 0x314, 0x09},
    { 0x315, ADSYSREF_OUT}, /* OUT7: AD_B_SYSREF */
    { 0x316, 0x00 + ADSYSREF_COFF_B},
    { 0x317, 0x09},
    { 0x318, ADDEVCLK_OUT},  /* OUT8: CLKOUT0 */
    { 0x319, 0x00},
    { 0x31a, 0x09},
    { 0x31b, ADDEVCLK_OUT},  /* OUT9: REFOUT, N/A */
    { 0x31c, 0x00},
    { 0x31d, 0x09},
    { 0x31e, ADDEVCLK_OUT},  /* OUT10: CLKOUT1 */
    { 0x31f, 0x00},
    { 0x320, 0x09},
    { 0x321, ADDEVCLK_OUT},  /* OUT11: CLKOUT2 */
    { 0x322, 0x00},
    { 0x323, 0x09},
    { 0x324, ADDEVCLK_OUT},  /* OUT12: N/A */
    { 0x325, 0x00},
    { 0x326, 0x27},         /* 30.72MHz out */
    { 0x327, ADDEVCLK_OUT},  /* OUT13: N/A */
    { 0x328, 0x00},
    { 0x329, 0x09},
    { 0x32a, 0x00},
    { 0x32b, 0x00},
    { 0x32c, 0x00},
    { 0x32d, 0x00},  /* SYSREF resampling Bypass 0xA2 */
    { 0x32e, 0x00},  /* SYSREF resampling Bypass 0x01 */
    { 0x400, 0x00},
    { 0x401, 0x08},  /* SYSREF Div 0x800 => 122.88/(2*2048) => 30KHz (2 => 122.88/1024 => 120KHz) */
    { 0x402, 0x00},
    { 0x403, 0x80},
    { 0x404, 0x04},
    { 0x500, 0x10},
    { 0x501, 0x00}, /*  Default: All power UP (else SYSREF does not work)*/
    { 0x502, 0x22}, /* Power down out 9 and 13 */
    { 0x503, 0xff},
    { 0x504, 0xdd},
    { 0x505, 0x07},
    { 0x506, 0x01},
    { 0x507, 0x0c},

    { 0x0F, 0x01},   /* Update */
};

ad9528_profile ad9528_FreeRun_profile = {
     "FreeRun VCXO",
     30720000,
     ad9528_FreeRun_regs,
     ARRAY_SIZE(ad9528_FreeRun_regs),
     AD9528_REFB_SATA,
     0xf2
};

/****************/

/* AD FMC eval board */
/* Ref = Internal VCXO 122.88MHz  Lock Mask = 0xe7 */
static const uint16_t ad9528_AD_FMC_regs[][2] = {
    { 0x00, 0x3c},
    { 0x01, 0x80},
    { 0x100, 0x01},  /* RefA div = 1 */
    { 0x101, 0x00},
    { 0x102, 0x01},  /* RefB div = 1 */
    { 0x103, 0x00},
    { 0x104, 0x04},  /* N1 div = 4    122.88MHz / 4 = 30.72MHz */
    { 0x105, 0x00},
    { 0x106, 0x0a},
    { 0x107, 0x03},  /* Auto holdover */
    { 0x108, 0x02},  /* REFA disabled, VCXO Neg Single Ended */
    { 0x109, 0x04},  /* 4: PPL1  from VCXO, 0: PLL1 from PPL2 output */
    { 0x10a, 0x0a},  /* Holdover at VCC/2 */
    { 0x10b, 0x00},
    { 0x200, 0xe6},
    { 0x201, 0x87},  /* CAL div = 30 */
    { 0x202, 0x03},
    { 0x203, 0x00},
    { 0x204, 0x03},  /* M1 = 3 */
    { 0x205, 0x2a},
    { 0x206, 0x00},
    { 0x207, 0x00},
    { 0x208, 0x09},  /* N2 Div = 10 */
    { 0x209, 0x00},
    { 0x300, 0x00}, /* OUT0: */
    { 0x301, 0x00},
    { 0x302, 0x09},
    { 0x303, 0x00}, /* OUT1: FPGA DEV_CLK */
    { 0x304, 0x00},
    { 0x305, 0x09},
    { 0x306, 0x00}, /* OUT2: */
    { 0x307, 0x00},
    { 0x308, 0x09},
    { 0x309, 0x40}, /* OUT3: FPGA SYSREF */
    { 0x30a, 0x00},
    { 0x30b, 0x09},
    { 0x30c, 0x00}, /* OUT4: */
    { 0x30d, 0x00},
    { 0x30e, 0x09},
    { 0x30f, 0x00}, /* OUT5: */
    { 0x310, 0x00},
    { 0x311, 0x09},
    { 0x312, 0x00}, /* OUT6: */
    { 0x313, 0x00},
    { 0x314, 0x09},
    { 0x315, 0x00}, /* OUT7: */
    { 0x316, 0x00},
    { 0x317, 0x09},
    { 0x318, 0x00}, /* OUT8 */
    { 0x319, 0x00},
    { 0x31a, 0x09},
    { 0x31b, 0x00}, /* OUT9 */
    { 0x31c, 0x00},
    { 0x31d, 0x09},
    { 0x31e, 0x00}, /* OUT10 */
    { 0x31f, 0x00},
    { 0x320, 0x09},
    { 0x321, 0x00}, /* OUT11 */
    { 0x322, 0x00},
    { 0x323, 0x09},
    { 0x324, 0x40}, /* OUT12: AD9371 SYSREF */
    { 0x325, 0x00},
    { 0x326, 0x09},
    { 0x327, 0x00}, /* OUT13: AD9371 DEV CLK */
    { 0x328, 0x00},
    { 0x329, 0x09},
    { 0x32a, 0x00},
    { 0x32b, 0x00},
    { 0x32c, 0x00},
    { 0x32d, 0x00},
    { 0x32e, 0x00},
    { 0x400, 0x00},
    { 0x401, 0x08},  /* SYSREF Div 0x800 => 122.88/(2*2048) => 30KHz (2 => 122.88/1024 => 120KHz) */
    { 0x402, 0x00}, /* SPI trigger for SYSREF */
    { 0x403, 0x90}, /* continous mode */
    { 0x404, 0x04}, /* no SYSREF input */
    { 0x500, 0x10}, /* Both PLL up */
    { 0x501, 0xf5}, /* POwer down all except OUT1 and OUT3 */
    { 0x502, 0xcf}, /* Power down all except OUT12 and OUT13 */
    { 0x503, 0xff},
    { 0x504, 0xff},
    { 0x505, 0x07},
    { 0x506, 0x01},
    { 0x507, 0x0c},

    { 0x0F, 0x01},   /* Update */
};

ad9528_profile ad9528_AD_FMC_profile = {
     "AD FMC 122.88MHz",
     122880000,
     ad9528_AD_FMC_regs,
     ARRAY_SIZE(ad9528_AD_FMC_regs),
     0,
     AD9528_LOCK_INT
};

/****************/

#if 0
/* CPRI 40G board R01 (obsolete) */
/* 30.72MHz on REFA, 122.88MHz on OUT2/9/10 */
static const uint16_t ad9528_RefA_30M72_CPRI_40G_regs[][2] = {
    { 0x00, 0x3c},
    { 0x01, 0x80},
    { 0x100, 0x01},  /* RefA div = 1 */
    { 0x101, 0x00},
    { 0x102, 0x01},
    { 0x103, 0x00},
    { 0x104, 0x04},  /* N1 div = 4    122.88MHz / 4 = 30.72MHz */
    { 0x105, 0x00},
    { 0x106, 0x0a},  /* PLL1 Charge Pump current: 10uA */
    { 0x107, 0x03},  /* Auto holdover */
    { 0x108, 0x08},  /* REFA on, single ended */
    { 0x109, 0x04},  /* 4: PPL1  from VCXO, 0: PLL1 from PPL2 output */
    { 0x10a, 0x02},  /* Ref = REFA, tristate holdover */
    { 0x10b, 0x00},
    { 0x200, 0xe6},
    { 0x201, 0x87},  /* CAL div = 30 */
    { 0x202, 0x03},
    { 0x203, 0x00},
    { 0x204, 0x03},  /* M1 = 3 */
    { 0x205, 0x2a},  /* PLL2 loop filter: 900R/2500R/16pF */
    { 0x206, 0x00},
    { 0x207, 0x00},
    { 0x208, 0x09},  /* N2 Div = 10 */
    { 0x209, 0x00},
    { 0x300, 0x00}, /* OUT0:  */
    { 0x301, 0x00},
    { 0x302, 0x09},
    { 0x303, 0x00}, /* OUT1:  */
    { 0x304, 0x00},
    { 0x305, 0x09},
    { 0x306, 0x00}, /* OUT2: AD DEV_CLK */
    { 0x307, 0x00},
    { 0x308, 0x09},   /* divide by 10 */
    { 0x309, 0x00}, /* OUT3: */
    { 0x30a, 0x00},
    { 0x30b, 0x09},
    { 0x30c, 0x00}, /* OUT4:  */
    { 0x30d, 0x00},
    { 0x30e, 0x09},
    { 0x30f, 0x00}, /* OUT5:  */
    { 0x310, 0x00},
    { 0x311, 0x09},
    { 0x312, 0x00}, /* OUT6:  */
    { 0x313, 0x00},
    { 0x314, 0x09},
    { 0x315, 0x00}, /* OUT7:  */
    { 0x316, 0x00},
    { 0x317, 0x09},
    { 0x318, 0x00}, /* OUT8:  */
    { 0x319, 0x00},
    { 0x31a, 0x09},
    { 0x31b, 0x00},  /* OUT9: MGT REFCLK*/
    { 0x31c, 0x80},   /* HSTL mode to workaround missing caps */
    { 0x31d, 0x09},
    { 0x31e, 0x00},  /* OUT10: MGT REFCMK 2 */
    { 0x31f, 0x80},   /* HSTL mode to workaround missing caps */
    { 0x320, 0x09},
    { 0x321, 0x00},  /* OUT11:  */
    { 0x322, 0x00},
    { 0x323, 0x09},
    { 0x324, 0x00},  /* OUT12:  */
    { 0x325, 0x00},
    { 0x326, 0x09},
    { 0x327, 0x00},  /* OUT13: */
    { 0x328, 0x00},
    { 0x329, 0x09},
    { 0x32a, 0x00},
    { 0x32b, 0x00},
    { 0x32c, 0x00},
    { 0x32d, 0x00}, //0xFE},  /* SYSREF resampling Bypass 0xA2 */
    { 0x32e, 0x00}, //0xFF},  /* SYSREF resampling Bypass 0x01 */
    { 0x400, 0x00},
    { 0x401, 0x08},  /* SYSREF Div 0x800 => 122.88/(2*2048) => 30KHz (2 => 122.88/1024 => 120KHz) */
    { 0x402, 0x00},
    { 0x403, 0x80},
    { 0x404, 0x04}, /* no SYSREF input */
    { 0x500, 0x10}, /* Both PLL up */
    { 0x501, 0x00}, /*  Default: All power UP (else SYSREF does not work)*/
    { 0x502, 0x00}, /* All up , optimize later */
    { 0x503, 0xff},
    { 0x504, 0xff}, /* All up, optimize later */
    { 0x505, 0x07},
    { 0x506, 0x01},
    { 0x507, 0x0c},

    { 0x0F, 0x01},   /* Update */
};

#endif

/* CPRI 40G board R02 */
/* 30.72MHz on REFA; 122.88MHz on OUT2/13; 245,76MHz on OUT7/9 */
static const uint16_t ad9528_RefA_30M72_CPRI_40G_regs[][2] = {
    { 0x00, 0x3c},
    { 0x01, 0x80},
    { 0x100, 0x01},  /* RefA div = 1 */
    { 0x101, 0x00},
    { 0x102, 0x01},
    { 0x103, 0x00},
    { 0x104, 0x04},  /* N1 div = 4    122.88MHz / 4 = 30.72MHz */
    { 0x105, 0x00},
    { 0x106, 0x0a},  /* PLL1 Charge Pump current: 10uA */
    { 0x107, 0x03},  /* Auto holdover */
    { 0x108, 0x08},  /* REFA on, single ended */
    { 0x109, 0x04},  /* 4: PPL1  from VCXO, 0: PLL1 from PPL2 output */
    { 0x10a, 0x02},  /* Ref = REFA, tristate holdover */
    { 0x10b, 0x00},
    { 0x200, 0xe6},
    { 0x201, 0x87},  /* CAL div = 30 */
    { 0x202, 0x03},
    { 0x203, 0x00},
    { 0x204, 0x03},  /* M1 = 3 */
    { 0x205, 0x2a},  /* PLL2 loop filter: 900R/2500R/16pF */
    { 0x206, 0x00},
    { 0x207, 0x00},
    { 0x208, 0x09},  /* N2 Div = 10 */
    { 0x209, 0x00},
    { 0x300, 0x00}, /* OUT0:  */
    { 0x301, 0x00},
    { 0x302, 0x09},
    { 0x303, 0x00}, /* OUT1:  */
    { 0x304, 0x00},
    { 0x305, 0x09},
    { 0x306, 0x00}, /* OUT2: MASTER OUT sync connector */
    { 0x307, 0x00},
    { 0x308, 0x09},   /* divide by 10 => 122.88 */
    { 0x309, 0x00}, /* OUT3: */
    { 0x30a, 0x00},
    { 0x30b, 0x09},
    { 0x30c, 0x00}, /* OUT4:  */
    { 0x30d, 0x00},
    { 0x30e, 0x09},
    { 0x30f, 0x00}, /* OUT5:  */
    { 0x310, 0x00},
    { 0x311, 0x09},
    { 0x312, 0x00}, /* OUT6:  */
    { 0x313, 0x00},
    { 0x314, 0x09},
    { 0x315, 0x00}, /* OUT7: MGT REFCMK 2 */
    { 0x316, 0x00},
    { 0x317, 0x04},   /* divide by 5 => 245.76 */
    { 0x318, 0x00}, /* OUT8:  */
    { 0x319, 0x00},
    { 0x31a, 0x09},
    { 0x31b, 0x00},  /* OUT9: MGT REFCLK*/
    { 0x31c, 0x00},
    { 0x31d, 0x04},   /* divide by 5 => 245.76 */
    { 0x31e, 0x00},  /* OUT10: */
    { 0x31f, 0x00},
    { 0x320, 0x09},
    { 0x321, 0x00},  /* OUT11:  */
    { 0x322, 0x00},
    { 0x323, 0x09},
    { 0x324, 0x00},  /* OUT12:  */
    { 0x325, 0x00},
    { 0x326, 0x09},
    { 0x327, 0x00},  /* OUT13: */
    { 0x328, 0x00},
    { 0x329, 0x09},   /* divide by 10 => 122.88 */
    { 0x32a, 0x00},
    { 0x32b, 0x00},
    { 0x32c, 0x00},
    { 0x32d, 0x00}, //0xFE},  /* SYSREF resampling Bypass 0xA2 */
    { 0x32e, 0x00}, //0xFF},  /* SYSREF resampling Bypass 0x01 */
    { 0x400, 0x00},
    { 0x401, 0x08},  /* SYSREF Div 0x800 => 122.88/(2*2048) => 30KHz (2 => 122.88/1024 => 120KHz) */
    { 0x402, 0x00},
    { 0x403, 0x80},
    { 0x404, 0x04}, /* no SYSREF input */
    { 0x500, 0x10}, /* Both PLL up */
    { 0x501, 0x00}, //0x7B}, /*  Default: All power UP (else SYSREF does not work)*/
    { 0x502, 0x1C}, /* power down 8, 10, 12 */
    { 0x503, 0xff},
    { 0x504, 0xE2}, /* power up 9 and 13 */
    { 0x505, 0x07},
    { 0x506, 0x01},
    { 0x507, 0x0c},

    { 0x0F, 0x01},   /* Update */
};


ad9528_profile ad9528_RefA_30M72_CPRI_40G_profile = {
     "RefA_30M72",
     122880000,
     ad9528_RefA_30M72_CPRI_40G_regs,
     ARRAY_SIZE(ad9528_RefA_30M72_CPRI_40G_regs),
     0,
     AD9528_LOCK_REFA
};

/* 30.72MHz on REFA; 122.88MHz on OUT2/13; 245,76MHz on OUT7/9 */
static const uint16_t ad9528_RefB_122M88_CPRI_40G_regs[][2] = {
    { 0x00, 0x3c},
    { 0x01, 0x80},
    { 0x100, 0x01},  /* RefA div = 1 */
    { 0x101, 0x00},
    { 0x102, 0x02},  /* REFB div = 2 */
    { 0x103, 0x00},
    { 0x104, 0x02},  /* N1 div = 4    122.88MHz / 2 = 61.44MHz */
    { 0x105, 0x00},
    { 0x106, 0x0a},  /* PLL1 Charge Pump current: 10uA */
    { 0x107, 0x03},  /* Auto holdover */
    { 0x108, 0x50},  /* REFB on, diff */
    { 0x109, 0x04},  /* 4: PPL1  from VCXO, 0: PLL1 from PPL2 output */
    { 0x10a, 0x03},  /* Ref = REFB, tristate holdover */
    { 0x10b, 0x00},
    { 0x200, 0xe6},
    { 0x201, 0x87},  /* CAL div = 30 */
    { 0x202, 0x03},
    { 0x203, 0x00},
    { 0x204, 0x03},  /* M1 = 3 */
    { 0x205, 0x2a},  /* PLL2 loop filter: 900R/2500R/16pF */
    { 0x206, 0x00},
    { 0x207, 0x00},
    { 0x208, 0x09},  /* N2 Div = 10 */
    { 0x209, 0x00},
    { 0x300, 0x00}, /* OUT0:  */
    { 0x301, 0x00},
    { 0x302, 0x09},
    { 0x303, 0x00}, /* OUT1:  */
    { 0x304, 0x00},
    { 0x305, 0x09},
    { 0x306, 0x00}, /* OUT2: MASTER OUT sync connector */
    { 0x307, 0x00},
    { 0x308, 0x09},   /* divide by 10 => 122.88 */
    { 0x309, 0x00}, /* OUT3: */
    { 0x30a, 0x00},
    { 0x30b, 0x09},
    { 0x30c, 0x00}, /* OUT4:  */
    { 0x30d, 0x00},
    { 0x30e, 0x09},
    { 0x30f, 0x00}, /* OUT5:  */
    { 0x310, 0x00},
    { 0x311, 0x09},
    { 0x312, 0x00}, /* OUT6:  */
    { 0x313, 0x00},
    { 0x314, 0x09},
    { 0x315, 0x00}, /* OUT7: MGT REFCMK 2 */
    { 0x316, 0x00},
    { 0x317, 0x04},   /* divide by 5 => 245.76 */
    { 0x318, 0x00}, /* OUT8:  */
    { 0x319, 0x00},
    { 0x31a, 0x09},
    { 0x31b, 0x00},  /* OUT9: MGT REFCLK*/
    { 0x31c, 0x00},
    { 0x31d, 0x04},   /* divide by 5 => 245.76 */
    { 0x31e, 0x00},  /* OUT10: */
    { 0x31f, 0x00},
    { 0x320, 0x09},
    { 0x321, 0x00},  /* OUT11:  */
    { 0x322, 0x00},
    { 0x323, 0x09},
    { 0x324, 0x00},  /* OUT12:  */
    { 0x325, 0x00},
    { 0x326, 0x09},
    { 0x327, 0x00},  /* OUT13: */
    { 0x328, 0x00},
    { 0x329, 0x09},   /* divide by 10 => 122.88 */
    { 0x32a, 0x00},
    { 0x32b, 0x00},
    { 0x32c, 0x00},
    { 0x32d, 0x00}, //0xFE},  /* SYSREF resampling Bypass 0xA2 */
    { 0x32e, 0x00}, //0xFF},  /* SYSREF resampling Bypass 0x01 */
    { 0x400, 0x00},
    { 0x401, 0x08},  /* SYSREF Div 0x800 => 122.88/(2*2048) => 30KHz (2 => 122.88/1024 => 120KHz) */
    { 0x402, 0x00},
    { 0x403, 0x80},
    { 0x404, 0x04}, /* no SYSREF input */
    { 0x500, 0x10}, /* Both PLL up */
    { 0x501, 0x00}, //0x7B}, /*  Default: All power UP (else SYSREF does not work)*/
    { 0x502, 0x1C}, /* power down 8, 10, 12 */
    { 0x503, 0xff},
    { 0x504, 0xE2}, /* power up 9 and 13 */
    { 0x505, 0x07},
    { 0x506, 0x01},
    { 0x507, 0x0c},

    { 0x0F, 0x01},   /* Update */
};


ad9528_profile ad9528_RefB_122M88_CPRI_40G_profile = {
     "RefB_122M88",
     122880000,
     ad9528_RefB_122M88_CPRI_40G_regs,
     ARRAY_SIZE(ad9528_RefB_122M88_CPRI_40G_regs),
     0,
     AD9528_LOCK_REFB
};

/****************/
/* SDR100V2 R02 register map */

/* Ref = 30.72MHz on REFA (VCXO)  Lock Mask = 0xe7 */
static const uint16_t ad9528_V2_RefA_30M72_regs[][2] = {
    { 0x00, 0x3c},
    { 0x01, 0x80},
    { 0x100, 0x01},  /* RefA div = 1 */
    { 0x101, 0x00},
    { 0x102, 0x01},
    { 0x103, 0x00},
    { 0x104, 0x04},  /* N1 div = 4    122.88MHz / 4 = 30.72MHz */
    { 0x105, 0x00},
    { 0x106, 0x0a},  /* PLL1 Charge Pump current: 10uA */
    { 0x107, 0x03},  /* Auto holdover */
    { 0x108, 0x08},  /* REFA on, single ended */
    { 0x109, 0x04},  /* 4: PPL1  from VCXO, 0: PLL1 from PPL2 output */
    { 0x10a, 0x02},  /* Ref = REFA, tristate holdover */
    { 0x10b, 0x00},
    { 0x200, 0xe6},
    { 0x201, 0x87},  /* CAL div = 30 */
    { 0x202, 0x03},
    { 0x203, 0x00},
    { 0x204, 0x03},  /* M1 = 3 */
    { 0x205, 0x2a},  /* PLL2 loop filter: 900R/2500R/16pF */
    { 0x206, 0x00},
    { 0x207, 0x00},
    { 0x208, 0x09},  /* N2 Div = 10 */
    { 0x209, 0x00},
    { 0x300, ADSYSREF_OUT}, /* OUT0: FPGA0_SYSREF */
    { 0x301, 0x00},
    { 0x302, 0x09},
    { 0x303, ADSYSREF_OUT}, /* OUT1: FPGA1_SYSREF */
    { 0x304, 0x00},
    { 0x305, 0x09},
    { 0x306, ADSYSREF_OUT}, /* OUT2: AD_A_SYSREF */
    { 0x307, 0x00},
    { 0x308, 0x09},
    { 0x309, ADDEVCLK_OUT}, /* OUT3: AD_B_DEV_CLK */
    { 0x30a, 0x00},
    { 0x30b, 0x09},
    { 0x30c, ADDEVCLK_OUT}, /* OUT4: FPGA1_DEV_CLK */
    { 0x30d, 0x00},
    { 0x30e, 0x09},
    { 0x30f, ADDEVCLK_OUT}, /* OUT5: FPGA0_DEV_CLK */
    { 0x310, 0x00},
    { 0x311, 0x09},
    { 0x312, ADDEVCLK_OUT}, /* OUT6: AD_B_DEV_CLK */
    { 0x313, 0x00},
    { 0x314, 0x09},
    { 0x315, ADSYSREF_OUT}, /* OUT7: AD_B_SYSREF */
    { 0x316, 0x00},
    { 0x317, 0x09},
    { 0x318, ADDEVCLK_OUT},  /* OUT8: CLKOUT0 */
    { 0x319, 0x00},
    { 0x31a, 0x09},   // 0x01 to output 614.4 MHz */
    { 0x31b, ADSYSREF_OUT},  /* OUT9: SYSREFOUT, N/A */
    { 0x31c, 0x00},
    { 0x31d, 0x09},
    { 0x31e, ADDEVCLK_OUT},  /* OUT10: CLKOUT1 */
    { 0x31f, 0x00},
    { 0x320, 0x09},
    { 0x321, ADDEVCLK_OUT},  /* OUT11: CLKOUT2 */
    { 0x322, 0x00},
    { 0x323, 0x09},
    { 0x324, ADDEVCLK_OUT},  /* OUT12: CY22150 for SDR100-V2 */
    { 0x325, 0x00},         /* 00 = LVDS  80 = HSTL */
    { 0x326, 0x27},         /* 30.72MHz out */
    { 0x327, ADDEVCLK_OUT},  /* OUT13: N/A */
    { 0x328, 0x00},
    { 0x329, 0x09},
    { 0x32a, 0x00},
    { 0x32b, 0x00},
    { 0x32c, 0x00},
    { 0x32d, 0x00},  /* SYSREF resampling Bypass 0xA2 */
    { 0x32e, 0x00},  /* SYSREF resampling Bypass 0x01 */
    { 0x400, 0x00},
    { 0x401, 0x08},  /* SYSREF Div 0x800 => 122.88/(2*2048) => 30KHz (2 => 122.88/1024 => 120KHz) */
    { 0x402, 0x00},
    { 0x403, 0x80},
    { 0x404, 0x04},
    { 0x500, 0x10},
    { 0x501, 0x00}, /*  Default: All power UP (else SYSREF does not work)*/
    { 0x502, 0x22}, /* Power down outputs 9 and 13    0x32 for 9, 12 and 13 donw */ 
    { 0x503, 0xff},
    { 0x504, 0xdd}, /* Power down outputs 9 and 13    0xcd for 9, 12 and 13 down */
    { 0x505, 0x07},
    { 0x506, 0x01},
    { 0x507, 0x0c},

    { 0x0F, 0x01},   /* Update */
};

ad9528_profile ad9528_V2_RefA_30M72_1_profile = {
     "RefA 30.72MHz",
     30720000,
     ad9528_V2_RefA_30M72_regs,
     ARRAY_SIZE(ad9528_V2_RefA_30M72_regs),
     AD9528_REFB_SATA,
     AD9528_LOCK_REFA
};

/****************/

/* Ref = 122.88MHz on REFB (SATA),  Lock Mask = 0xeB */
static const uint16_t ad9528_V2_RefB_122M88_regs[][2] = {
    { 0x00, 0x3c},
    { 0x01, 0x80},
    { 0x100, 0x01},
    { 0x101, 0x00},
    { 0x102, 0x02},  /* REFB div = 2 */
    { 0x103, 0x00},
    { 0x104, 0x02},  /* N1 div = 2    122.88MHz / 2 = 61.44MHz PFD freq */
    { 0x105, 0x00},
    { 0x106, 0x0a},  /* 0x0a normal, 0x8a to force holdover */
    { 0x107, 0x03},  /* auto Holdover */
    { 0x108, 0x50},  /* REFB on, diff */
    { 0x109, 0x04},
    { 0x10a, 0x03},  /* Ref = REFB, tristate holdover */
    { 0x10b, 0x00},
    { 0x200, 0xe6},
    { 0x201, 0x87},  /* CAL div = 30 */
    { 0x202, 0x03},
    { 0x203, 0x00},
    { 0x204, 0x03},  /* M1 = 3 */
    { 0x205, 0x2a},
    { 0x206, 0x00},
    { 0x207, 0x00},
    { 0x208, 0x09},  /* N2 Div = 10 */
    { 0x209, 0x00},
    { 0x300, ADSYSREF_OUT}, /* OUT0: FPGA0_SYSREF */
    { 0x301, 0x00},
    { 0x302, 0x09},
    { 0x303, ADSYSREF_OUT}, /* OUT1: FPGA1_SYSREF */
    { 0x304, 0x00},
    { 0x305, 0x09},
    { 0x306, ADSYSREF_OUT}, /* OUT2: AD_A_SYSREF */
    { 0x307, 0x00},
    { 0x308, 0x09},
    { 0x309, ADDEVCLK_OUT}, /* OUT3: AD_B_DEV_CLK */
    { 0x30a, 0x00},
    { 0x30b, 0x09},
    { 0x30c, ADDEVCLK_OUT}, /* OUT4: FPGA1_DEV_CLK */
    { 0x30d, 0x00},
    { 0x30e, 0x09},
    { 0x30f, ADDEVCLK_OUT}, /* OUT5: FPGA0_DEV_CLK */
    { 0x310, 0x00},
    { 0x311, 0x09},
    { 0x312, ADDEVCLK_OUT}, /* OUT6: AD_B_DEV_CLK */
    { 0x313, 0x00},
    { 0x314, 0x09},
    { 0x315, ADSYSREF_OUT}, /* OUT7: AD_B_SYSREF */
    { 0x316, 0x00},
    { 0x317, 0x09},
    { 0x318, ADDEVCLK_OUT},  /* OUT8: CLKOUT0 */
    { 0x319, 0x00},
    { 0x31a, 0x09},   // 0x01 to output 614.4 MHz */
    { 0x31b, ADSYSREF_OUT},  /* OUT9: SYSREFOUT, N/A */
    { 0x31c, 0x00},
    { 0x31d, 0x09},
    { 0x31e, ADDEVCLK_OUT},  /* OUT10: CLKOUT1 */
    { 0x31f, 0x00},
    { 0x320, 0x09},
    { 0x321, ADDEVCLK_OUT},  /* OUT11: CLKOUT2 */
    { 0x322, 0x00},
    { 0x323, 0x09},
    { 0x324, ADDEVCLK_OUT},  /* OUT12: CY22150 for SDR100-V2 */
    { 0x325, 0x00},         /* 00 = LVDS  80 = HSTL */
    { 0x326, 0x27},         /* 30.72MHz out */
    { 0x327, ADDEVCLK_OUT},  /* OUT13: N/A */
    { 0x328, 0x00},
    { 0x329, 0x09},
    { 0x32a, 0x00},
    { 0x32b, 0x00},
    { 0x32c, 0x00},
    { 0x32d, 0x00},
    { 0x32e, 0x00},
    { 0x400, 0x00},
    { 0x401, 0x08},  /* SYSREF Div 0x800 => 122.88/(2*2048) => 30KHz (2 => 122.88/1024 => 120KHz) */
    { 0x402, 0x00},  /* SPI trigger */
    { 0x403, 0x90},  /* Continous mode */
    { 0x404, 0x04},
    { 0x500, 0x10},
    { 0x501, 0x00}, /*  Default: All power UP (else SYSREF does not work)*/
    { 0x502, 0x22}, /* Power down outputs 9 and 13    0x32 for 9, 12 and 13 donw */ 
    { 0x503, 0xff},
    { 0x504, 0xdd}, /* Power down outputs 9 and 13    0xcd for 9, 12 and 13 down */
    { 0x505, 0x07},
    { 0x506, 0x01},
    { 0x507, 0x0c},

    { 0x00F, 0x01},   /* Update */
};

ad9528_profile ad9528_V2_RefB_122M88_1_profile = {
     "RefB 122.88MHz",
     122880000,
     ad9528_V2_RefB_122M88_regs,
     ARRAY_SIZE(ad9528_V2_RefB_122M88_regs),
     AD9528_REFB_SATA,           /* Select SATA connector on Rev1 */
     AD9528_LOCK_REFB
};


/****************/
/* Ref = 30.72MHz on REFB (from PLL)  Lock Mask = 0xeB */
static const uint16_t ad9528_V2_RefB_30M72_regs[][2] = {
    { 0x00, 0x3c},
    { 0x01, 0x80},
    { 0x100, 0x01},
    { 0x101, 0x00},
    { 0x102, 0x01},  /* RefB div = 1 */
    { 0x103, 0x00},
    { 0x104, 0x04},  /* N1 div = 4    122.88MHz / 4 = 30.72MHz */
    { 0x105, 0x00},
    { 0x106, 0x0a},  /* PLL1 Charge Pump current: 10uA */
    { 0x107, 0x03},  /* Auto holdover */
    { 0x108, 0x50},  /* REFB on, diff */
    { 0x109, 0x04},  /* 4: PPL1  from VCXO, 0: PLL1 from PPL2 output */
    { 0x10a, 0x03},  /* Ref = REFB, tristate holdover */
    { 0x10b, 0x00},
    { 0x200, 0xe6},
    { 0x201, 0x87},  /* CAL div = 30 */
    { 0x202, 0x03},
    { 0x203, 0x00},
    { 0x204, 0x03},  /* M1 = 3 */
    { 0x205, 0x2a},  /* PLL2 loop filter: 900R/2500R/16pF */
    { 0x206, 0x00},
    { 0x207, 0x00},
    { 0x208, 0x09},  /* N2 Div = 10 */
    { 0x209, 0x00},
    { 0x300, ADSYSREF_OUT}, /* OUT0: FPGA0_SYSREF */
    { 0x301, 0x00},
    { 0x302, 0x09},
    { 0x303, ADSYSREF_OUT}, /* OUT1: FPGA1_SYSREF */
    { 0x304, 0x00},
    { 0x305, 0x09},
    { 0x306, ADSYSREF_OUT}, /* OUT2: AD_A_SYSREF */
    { 0x307, 0x00},
    { 0x308, 0x09},
    { 0x309, ADDEVCLK_OUT}, /* OUT3: AD_B_DEV_CLK */
    { 0x30a, 0x00},
    { 0x30b, 0x09},
    { 0x30c, ADDEVCLK_OUT}, /* OUT4: FPGA1_DEV_CLK */
    { 0x30d, 0x00},
    { 0x30e, 0x09},
    { 0x30f, ADDEVCLK_OUT}, /* OUT5: FPGA0_DEV_CLK */
    { 0x310, 0x00},
    { 0x311, 0x09},
    { 0x312, ADDEVCLK_OUT}, /* OUT6: AD_B_DEV_CLK */
    { 0x313, 0x00},
    { 0x314, 0x09},
    { 0x315, ADSYSREF_OUT}, /* OUT7: AD_B_SYSREF */
    { 0x316, 0x00},
    { 0x317, 0x09},
    { 0x318, ADDEVCLK_OUT},  /* OUT8: CLKOUT0 */
    { 0x319, 0x00},
    { 0x31a, 0x09},   // 0x01 to output 614.4 MHz */
    { 0x31b, ADSYSREF_OUT},  /* OUT9: SYSREFOUT, N/A */
    { 0x31c, 0x00},
    { 0x31d, 0x09},
    { 0x31e, ADDEVCLK_OUT},  /* OUT10: CLKOUT1 */
    { 0x31f, 0x00},
    { 0x320, 0x09},
    { 0x321, ADDEVCLK_OUT},  /* OUT11: CLKOUT2 */
    { 0x322, 0x00},
    { 0x323, 0x09},
    { 0x324, ADDEVCLK_OUT},  /* OUT12: CY22150 for SDR100-V2 */
    { 0x325, 0x00},         /* 00 = LVDS  80 = HSTL */
    { 0x326, 0x27},         /* 30.72MHz out */
    { 0x327, ADDEVCLK_OUT},  /* OUT13: N/A */
    { 0x328, 0x00},
    { 0x329, 0x09},
    { 0x32a, 0x00},
    { 0x32b, 0x00},
    { 0x32c, 0x00},
    { 0x32d, 0x00},  /* SYSREF resampling Bypass 0xA2 */
    { 0x32e, 0x00},  /* SYSREF resampling Bypass 0x01 */
    { 0x400, 0x00},
    { 0x401, 0x08},  /* SYSREF Div 0x800 => 122.88/(2*2048) => 30KHz (2 => 122.88/1024 => 120KHz) */
    { 0x402, 0x00},
    { 0x403, 0x80},
    { 0x404, 0x04},
    { 0x500, 0x10},
    { 0x501, 0x00}, /*  Default: All power UP (else SYSREF does not work)*/
    { 0x502, 0x22}, /* Power down outputs 9 and 13    0x32 for 9, 12 and 13 donw */ 
    { 0x503, 0xff},
    { 0x504, 0xdd}, /* Power down outputs 9 and 13    0xcd for 9, 12 and 13 down */
    { 0x505, 0x07},
    { 0x506, 0x01},
    { 0x507, 0x0c},

    { 0x0F, 0x01},   /* Update */
};

ad9528_profile ad9528_V2_RefB_30M72_1_profile = {
     "RefB 30.72MHz from PLL",
     30720000,
     ad9528_V2_RefB_30M72_regs,
     ARRAY_SIZE(ad9528_V2_RefB_30M72_regs),
     AD9528_REFB_UFL,
     AD9528_LOCK_REFB
};

/****************/
/* Ref = 38.40MHz on REFB (SATA)  Lock Mask = 0xeB */
static const uint16_t ad9528_V2_RefB_38M40_regs[][2] = {
    { 0x00,  0x3c},
    { 0x01,  0x80},
    { 0x100, 0x01},  /* REFA div = 1 */
    { 0x101, 0x00},
    { 0x102, 0x05},  /* REFB div = 5    38.40Mhz / 5  = 7.68MHz */
    { 0x103, 0x00},  /* REFB div = 5 */
    { 0x104, 0x10},  /* N1 div = 16    122.88MHz / 16 = 7.68MHz */
    { 0x105, 0x00},  /* N1 div = 16 */
    { 0x106, 0x0a},  /* PLL1 Charge Pump current: 10uA */
    { 0x107, 0x03},  /* Auto holdover */
    { 0x108, 0x50},  /* REFB on, diff */
    { 0x109, 0x04},  /* 4: PPL1  from VCXO, 0: PLL1 from PPL2 output */
    { 0x10a, 0x03},  /* Ref = REFB, tristate holdover */
    { 0x10b, 0x00},
    { 0x200, 0xe6},
    { 0x201, 0x87},  /* CAL div = 30 */
    { 0x202, 0x03},
    { 0x203, 0x00},
    { 0x204, 0x03},  /* M1 = 3 */
    { 0x205, 0x2a},  /* PLL2 loop filter: 900R/2500R/16pF */
    { 0x206, 0x00},
    { 0x207, 0x00},
    { 0x208, 0x09},  /* N2 Div = 10 */
    { 0x209, 0x00},
    { 0x300, ADSYSREF_OUT}, /* OUT0: FPGA0_SYSREF */
    { 0x301, 0x00},
    { 0x302, 0x09},
    { 0x303, ADSYSREF_OUT}, /* OUT1: FPGA1_SYSREF */
    { 0x304, 0x00},
    { 0x305, 0x09},
    { 0x306, ADSYSREF_OUT}, /* OUT2: AD_A_SYSREF */
    { 0x307, 0x00},
    { 0x308, 0x09},
    { 0x309, ADDEVCLK_OUT}, /* OUT3: AD_B_DEV_CLK */
    { 0x30a, 0x00},
    { 0x30b, 0x09},
    { 0x30c, ADDEVCLK_OUT}, /* OUT4: FPGA1_DEV_CLK */
    { 0x30d, 0x00},
    { 0x30e, 0x09},
    { 0x30f, ADDEVCLK_OUT}, /* OUT5: FPGA0_DEV_CLK */
    { 0x310, 0x00},
    { 0x311, 0x09},
    { 0x312, ADDEVCLK_OUT}, /* OUT6: AD_B_DEV_CLK */
    { 0x313, 0x00},
    { 0x314, 0x09},
    { 0x315, ADSYSREF_OUT}, /* OUT7: AD_B_SYSREF */
    { 0x316, 0x00},
    { 0x317, 0x09},
    { 0x318, ADDEVCLK_OUT},  /* OUT8: CLKOUT0 */
    { 0x319, 0x00},
    { 0x31a, 0x09},   // 0x01 to output 614.4 MHz */
    { 0x31b, ADSYSREF_OUT},  /* OUT9: SYSREFOUT, N/A */
    { 0x31c, 0x00},
    { 0x31d, 0x09},
    { 0x31e, ADDEVCLK_OUT},  /* OUT10: CLKOUT1 */
    { 0x31f, 0x00},
    { 0x320, 0x09},
    { 0x321, ADDEVCLK_OUT},  /* OUT11: CLKOUT2 */
    { 0x322, 0x00},
    { 0x323, 0x09},
    { 0x324, ADDEVCLK_OUT},  /* OUT12: CY22150 for SDR100-V2 */
    { 0x325, 0x00},         /* 00 = LVDS  80 = HSTL */
    { 0x326, 0x27},         /* 30.72MHz out */
    { 0x327, ADDEVCLK_OUT},  /* OUT13: N/A */
    { 0x328, 0x00},
    { 0x329, 0x09},
    { 0x32a, 0x00},
    { 0x32b, 0x00},
    { 0x32c, 0x00},
    { 0x32d, 0x00},  /* SYSREF resampling Bypass 0xA2 */
    { 0x32e, 0x00},  /* SYSREF resampling Bypass 0x01 */
    { 0x400, 0x00},
    { 0x401, 0x08},  /* SYSREF Div 0x800 => 122.88/(2*2048) => 30KHz (2 => 122.88/1024 => 120KHz) */
    { 0x402, 0x00},
    { 0x403, 0x80},
    { 0x404, 0x04},
    { 0x500, 0x10},
    { 0x501, 0x00}, /*  Default: All power UP (else SYSREF does not work)*/
    { 0x502, 0x22}, /* Power down outputs 9 and 13    0x32 for 9, 12 and 13 donw */ 
    { 0x503, 0xff},
    { 0x504, 0xdd}, /* Power down outputs 9 and 13    0xcd for 9, 12 and 13 down */
    { 0x505, 0x07},
    { 0x506, 0x01},
    { 0x507, 0x0c},

    { 0x0F, 0x01},   /* Update */
};

ad9528_profile ad9528_V2_RefB_38M40_1_profile = {
     "RefB 30.72MHz from SATA",
     38400000,
     ad9528_V2_RefB_38M40_regs,
     ARRAY_SIZE(ad9528_V2_RefB_38M40_regs),
     AD9528_REFB_SATA,
     AD9528_LOCK_REFB
};

/****************/


/* Returns 0 if PLL is locked, -1 if not locked */
static int AD9528_initialize(SDRState *s, int profile)
{
    const uint16_t (*regs)[2];
    int size;
    int vco_fpga;
    int lock_mask;
    uint8_t i;
    uint8_t reg203, reg508, reg509;
    int ret = 0;
    int loop = 0;
    ad9528_profile *p = NULL;
    int rev;
    uint32_t reg_config;

    switch (s->sysid) {
    case SYSID_RF_5G:
        rev = s->board_rev;
        break;
    case SYSID_RF_5G_V2:
        rev = s->board_rev;
        rev += 20;
        break;
    case SYSID_CPRI_40G:
        rev = 10;
        break;
    default:
        printk(KERN_ERR SDR_NAME " AD9528_initialize minor %d invalid SYSID(%x)\n",
               s->minor, s->sysid);
        return -1;
    }

    switch (rev) {
    case -1:
        /* FMC Eval board */
        p = &ad9528_AD_FMC_profile;
        break;
    case 0:
        /* SDR-5G board R01 to R03 */
        /* 122.88MHz VCXO is controlled by AD9528 or FPGA */
        /* RefA is Slave (SATA connector), RefB is EXT (UFL connector) */
        switch (profile) {
        default:
        case PROFILE_INTERNAL:
            p = &ad9528_internal_122M88_1_profile;
            break;
        case PROFILE_SLAVE_122M88:
            p = &ad9528_RefA_122M88_0_profile;
            break;
        case PROFILE_SLAVE_38M40:
            p = &ad9528_RefA_38M40_0_profile;
            break;
        case PROFILE_EXT_38M40:
            p = &ad9528_RefB_38M40_0_profile;
            break;
        case PROFILE_EXT_30M72:
            p = &ad9528_RefB_30M72_0_profile;
            break;
        }
        break;
    case 1:
        /* SDR-100 board R04, R05, R06, R07 */
    case 20:
        /* SDR100V2 R01 (rev 0) */
    case 2:
        /* SDR-100 R08 */
        /* RefA is internal 30.72MHz VCXO controlled by FPGA */
        /* RefB is Slave (SATA connector), or EXT (UFL connector) according to vcxo_fpga flag, or PLL for SDR100-V2 */
        switch (profile) {
        default:
        case PROFILE_INTERNAL:
            p = &ad9528_RefA_30M72_1_profile;
            break;
        case PROFILE_SLAVE_122M88:
            p = &ad9528_RefB_122M88_1_profile;
            break;
        case PROFILE_SLAVE_38M40:
            p = &ad9528_RefB_38M40_1_profile;
            break;
        case PROFILE_EXT_38M40:
            if (rev == 20)
                return -1;
            p = &ad9528_RefB_38M40_0_profile;
            break;
        case PROFILE_EXT_30M72:
            if (rev == 20)
                return -1;
            p = &ad9528_RefB_30M72_0_profile;
            break;
        }
        break;
    case 10:  /* CPRI_40G */
        switch(profile) {
        default:
        case PROFILE_INTERNAL:
            p = &ad9528_RefA_30M72_CPRI_40G_profile;
            break;
        case PROFILE_SLAVE_122M88:
            p = &ad9528_RefB_122M88_CPRI_40G_profile;
            break;
        }        
        break;
    case 21:   /* SDR100V2 R02, R03, R04, ... (rev 1) */
        switch (profile) {
        default:
        case PROFILE_INTERNAL:
            p = &ad9528_V2_RefA_30M72_1_profile;
            break;
        case PROFILE_SLAVE_122M88:
            p = &ad9528_V2_RefB_122M88_1_profile;
            break;
        case PROFILE_EXT_30M72:
            /* EXT CLK 30,72MHz from PLL from 10MHz SMA input */
            p = &ad9528_V2_RefB_30M72_1_profile;
            break;
        case PROFILE_SLAVE_38M40:
        case PROFILE_EXT_38M40:
            /* factory CLKIN_TEST */
            p = &ad9528_V2_RefB_38M40_1_profile;
            break;
        }
        break;
    default:
        printk(KERN_ERR SDR_NAME " AD9528_initialize invalid board revision(%d)\n", rev);
        return -1;
    }

    if (!p) {
        printk(KERN_ERR SDR_NAME " AD9528_initialize invalid profile(%d)\n", profile);
        return -1;
    }
    
    printk(KERN_INFO SDR_NAME " AD9528_initialize minor=%d (%d => %s)\n",
           s->minor, profile, p->name);
    
    regs = p->regs;
    size = p->size;
    vco_fpga = p->vcxo_flag;
    lock_mask = p->lock_mask;

    if (profile == s->profile) {
        sdr_ad9528_read(s, AD9528_ADDR_STATUS_READBACK0, &reg508);
        if ((reg508 & lock_mask) == lock_mask) {
            printk(KERN_INFO SDR_NAME "      profile locked\n");
            return 0;
        }
        return -1;
    }

    /* On Rev0 Set VCXO control by FPGA if 1, AD9528 if 0 */
    /* On Rev1 Enable PWM for REFA and Select RefB input: SATA connector if 1 and UFL connector if 0 */
    sdr_writel(s, CSR_SYNCHRO_TCXO_ENABLE_ADDR, vco_fpga);

    switch (s->sysid) {
    case SYSID_RF_5G:
    case SYSID_RF_5G_V2:
        reg_config = CSR_AD937X0_BASE + CSR_AD937X_CONFIG_ADDR_REL;
        break;
    case SYSID_CPRI_40G:
        reg_config = CSR_AD9528_BASE + CSR_AD9528_CONTROL_ADDR;
        break;
    }

    for (loop = 0; loop < 3; loop++) {
        /* Hardware Reset on AD9528 */
        if (s->sysid == SYSID_CPRI_40G) {
            sdr_writel(s, CSR_AD9528_BASE + CSR_AD9528_CONTROL_ADDR,
                       AD9528_REF_SEL_REFA | 0*AD9528_RESET);
            udelay(1000);
            sdr_writel(s, CSR_AD9528_BASE + CSR_AD9528_CONTROL_ADDR,
                       AD9528_REF_SEL_REFA | 1*AD9528_RESET);
            udelay(1000);
            sdr_writel(s, CSR_AD9528_BASE + CSR_AD9528_CONTROL_ADDR,
                       AD9528_REF_SEL_REFA | 0*AD9528_RESET);            
        }
        else {
            sdr_writel(s, CSR_AD937X0_BASE + CSR_AD937X_CONFIG_ADDR_REL,
                       1*AD937X_CONFIG_AD937X_RST_N | 1*AD937X_CONFIG_AD9528_RST_N);
            udelay(1000);
            sdr_writel(s, CSR_AD937X0_BASE + CSR_AD937X_CONFIG_ADDR_REL,
                       1*AD937X_CONFIG_AD937X_RST_N | 0*AD937X_CONFIG_AD9528_RST_N);
            udelay(1000);
            sdr_writel(s, CSR_AD937X0_BASE + CSR_AD937X_CONFIG_ADDR_REL,
                       1*AD937X_CONFIG_AD937X_RST_N | 1*AD937X_CONFIG_AD9528_RST_N);
        }
        /* Initialize all registers */
        /* default Internal Clock 122.88MHz */
        for(i = 0; i < size; i++) {
            sdr_ad9528_write(s, regs[i][0], regs[i][1]);
        }

        /* Start Manual VCO Calibration */
        sdr_ad9528_read(s, AD9528_ADDR_PLL2_VCO_CTRL, &reg203);
        sdr_ad9528_write(s, AD9528_ADDR_PLL2_VCO_CTRL, reg203 & ~0x01);
        sdr_ad9528_write(s, AD9528_ADDR_IO_UPDATE, 0x01);
        sdr_ad9528_write(s, AD9528_ADDR_PLL2_VCO_CTRL, reg203 | 0x01); //Manual VCO CAL On
        sdr_ad9528_write(s, AD9528_ADDR_IO_UPDATE, 0x01);

        /* Wait for Lock */
        i = 0;
        do {
            sdr_ad9528_read(s, AD9528_ADDR_STATUS_READBACK0, &reg508);
            msleep(10);
            i++;
            if (i >= 50) {
                ret = -1;
                break;
            }
        } while(((reg508 & lock_mask) != lock_mask));
        if (ret == 0)
            break;
    }
    s->lock_mask = lock_mask;

    sdr_ad9528_read(s, AD9528_ADDR_STATUS_READBACK1, &reg509);
    if (ret == 0) {
        printk(KERN_INFO SDR_NAME " AD9528 Locked reg[0x508]=0x%02x reg[0x509]=0x%02x\n", reg508, reg509);

#ifdef FREERUN
        sdr_ad9528_write(s, 0x106, 0x8a);
        sdr_ad9528_write(s, AD9528_ADDR_IO_UPDATE, 0x01);
        s->lock_mask = 0xf2;
        /* Wait for Lock */
        i = 0;
        do {
            sdr_ad9528_read(s, AD9528_ADDR_STATUS_READBACK0, &reg508);
            msleep(10);
            i++;
            if (i >= 100) {
                ret = -1;
                break;
            }
        } while(((reg508 & lock_mask) != s->lock_mask));
        sdr_ad9528_read(s, AD9528_ADDR_STATUS_READBACK1, &reg509);
        printk(KERN_INFO SDR_NAME " AD9528 FreeRun Locked reg[0x508]=0x%02x reg[0x509]=0x%02x\n", reg508, reg509);
#endif
        if (s->board_rev == -1) {
            /* SPI trigger SYSREF generator */
            sdr_ad9528_write(s, AD9528_ADDR_SYSREF_CTRL4, 0x91);
            /* Update regs */
            sdr_ad9528_write(s, AD9528_ADDR_IO_UPDATE, 0x01);
        }
        else {
            /* Set SYSREF generator in Continous mode and wait on Pin Control */
            sdr_ad9528_write(s, AD9528_ADDR_SYSREF_CTRL3, 0xC0);
            sdr_ad9528_write(s, AD9528_ADDR_SYSREF_CTRL4, 0x90);
            /* Power Down AD SYSREF */
            sdr_ad9528_write(s, AD9528_ADDR_OUT_POWERDOWN0, 0x90);
            /* Update regs */
            sdr_ad9528_write(s, AD9528_ADDR_IO_UPDATE, 0x01);

            /* Force RESYNC */
            sdr_ad9528_write(s, 0x32A, 0x01);
            sdr_ad9528_write(s, AD9528_ADDR_IO_UPDATE, 0x01);
            sdr_ad9528_write(s, 0x32A, 0x00);
            sdr_ad9528_write(s, AD9528_ADDR_IO_UPDATE, 0x01);

            /* Now set FPGA to output next PPS pulse on SYSREF control pin */
            sdr_writel(s, CSR_AD937X0_BASE + CSR_AD937X_SYSREF_ADDR_REL,
                       CSR_AD937X_SYSREF_REQ);
        }
        s->sync_state.clock_freq = p->clock_freq;
    }
    else {
        uint8_t reg108;
        sdr_ad9528_read(s, AD9528_ADDR_INPUT_RECEIVERS1, &reg108);
        if ((reg108 & 0x08) && !(reg508 & 0x08)) {
            /* RefA selected but no signal detected */
            printk(KERN_ERR SDR_NAME " AD9528 Lock ERROR: VCXO clock invalid (reg[0x508]=0x%02x)\n", reg508);
        } else if ((reg108 & 0x10) && !(reg508 & 0x10)) {
            /* RefB selected but no signal detected */
            printk(KERN_ERR SDR_NAME " AD9528 Lock ERROR: Slave/Ext clock invalid (reg[0x508]=0x%02x)\n", reg508);
        } else {
            printk(KERN_ERR SDR_NAME " AD9528 Lock ERROR: reg[0x508]=0x%02x reg[0x509]=0x%02x\n", reg508, reg509);
        }
    }
    if (ret == 0)
        s->profile = profile;
    else
        s->profile = -1;
    
    return ret;
}


static int ad9528_is_locked(SDRState *s)
{
    uint8_t reg508;

    sdr_ad9528_read(s, AD9528_ADDR_STATUS_READBACK0, &reg508);
    return ((reg508 & s->lock_mask) == s->lock_mask) ? 1: 0;
}

/***************************/
/* I2C */

#define I2C_ADDR_WR(addr)  ((addr) << 1)
#define I2C_ADDR_RD(addr) (((addr) << 1) | 1u)

static void i2c_delay(int n) {
    udelay(n);
}

static inline void i2c_oe_scl_sda(SDRState *s, bool oe, bool scl, bool sda)
{
    sdr_writel(s, CSR_CY22150_I2C_W_ADDR,
        ((oe & 1)  << CSR_CY22150_I2C_W_OE_OFFSET)  |
        ((scl & 1) << CSR_CY22150_I2C_W_SCL_OFFSET) |
        ((sda & 1) << CSR_CY22150_I2C_W_SDA_OFFSET)
    );
}

static void i2c_start(SDRState *s)
{
    i2c_oe_scl_sda(s, 1, 1, 1);
    i2c_delay(1);
    i2c_oe_scl_sda(s, 1, 1, 0);
    i2c_delay(1);
    i2c_oe_scl_sda(s, 1, 0, 0);
    i2c_delay(1);
}

static void i2c_stop(SDRState *s)
{
    i2c_oe_scl_sda(s, 1, 0, 0);
    i2c_delay(1);
    i2c_oe_scl_sda(s, 1, 1, 0);
    i2c_delay(1);
    i2c_oe_scl_sda(s, 1, 1, 1);
    i2c_delay(1);
    i2c_oe_scl_sda(s, 0, 1, 1);
}

static void i2c_transmit_bit(SDRState *s, int value)
{
    i2c_oe_scl_sda(s, 1, 0, value);
    i2c_delay(1);
    i2c_oe_scl_sda(s, 1, 1, value);
    i2c_delay(2);
    i2c_oe_scl_sda(s, 1, 0, value);
    i2c_delay(1);
    i2c_oe_scl_sda(s, 0, 0, 0);
}

static int i2c_receive_bit(SDRState *s)
{
    int value;
    i2c_oe_scl_sda(s, 0, 0, 0);
    i2c_delay(1);
    i2c_oe_scl_sda(s, 0, 1, 0);
    i2c_delay(1);
    value = sdr_readl(s, CSR_CY22150_I2C_R_ADDR) & 1;
    i2c_delay(1);
    i2c_oe_scl_sda(s, 0, 0, 0);
    i2c_delay(1);
    return value;
}

/* Transmit byte and return 1 if slave sends ACK */

static bool i2c_transmit_byte(SDRState *s, uint8_t data)
{
    int i;
    int ack;

    /* SCL should have already been low for 1/4 cycle */
    i2c_oe_scl_sda(s, 0, 0, 0);
    for (i = 0; i < 8; ++i) {
        /* MSB first */
        i2c_transmit_bit(s, (data & (1 << 7)) != 0);
        data <<= 1;
    }
    ack = i2c_receive_bit(s);

    /* 0 from Slave means ACK */
    return ack == 0;
}

/* Receive byte and send ACK if ack=1 */
static uint8_t i2c_receive_byte(SDRState *s, bool ack)
{
    int i;
    uint8_t data = 0;

    for (i = 0; i < 8; ++i) {
        data <<= 1;
        data |= i2c_receive_bit(s);
    }
    i2c_transmit_bit(s, !ack);

    return data;
}

/* Reset line state */
static __maybe_unused void i2c_reset(SDRState *s)
{
    int i;
    i2c_oe_scl_sda(s, 1, 1, 1);
    i2c_delay(8);
    for (i = 0; i < 9; ++i) {
        i2c_oe_scl_sda(s, 1, 0, 1);
        i2c_delay(2);
        i2c_oe_scl_sda(s, 1, 1, 1);
        i2c_delay(2);
    }
    i2c_oe_scl_sda(s, 0, 0, 1);
    i2c_delay(1);
    i2c_stop(s);
    i2c_oe_scl_sda(s, 0, 1, 1);
    i2c_delay(8);
}

/*
 * Read slave memory over I2C starting at given address
 *
 * First writes the memory starting address, then reads the data:
 *   START WR(slaveaddr) WR(addr) STOP START WR(slaveaddr) RD(data) RD(data) ... STOP
 * Some chips require that after transmiting the address, there will be no STOP in between:
 *   START WR(slaveaddr) WR(addr) START WR(slaveaddr) RD(data) RD(data) ... STOP
 */

static bool i2c_read(SDRState *s, uint8_t slave_addr, uint8_t addr, uint8_t *data, uint32_t len, bool send_stop)
{
    int i;

    i2c_start(s);

    if(!i2c_transmit_byte(s, I2C_ADDR_WR(slave_addr))) {
        i2c_stop(s);
        return false;
    }
    if(!i2c_transmit_byte(s, addr)) {
        i2c_stop(s);
        return false;
    }

    if (send_stop) {
        i2c_stop(s);
    }
    i2c_start(s);

    if(!i2c_transmit_byte(s, I2C_ADDR_RD(slave_addr))) {
        i2c_stop(s);
        return false;
    }
    for (i = 0; i < len; ++i) {
        data[i] = i2c_receive_byte(s, i != (len - 1));
    }

    i2c_stop(s);

    return true;
}

static  __maybe_unused uint8_t i2c_read_byte(SDRState *s, uint8_t slave_addr, uint8_t addr)
{
    uint8_t data;
    
    if (!i2c_read(s, slave_addr, addr, &data, 1, true))
        data = 0;
    return data;
}

/*
 * Write slave memory over I2C starting at given address
 *
 * First writes the memory starting address, then writes the data:
 *   START WR(slaveaddr) WR(addr) WR(data) WR(data) ... STOP
 */

static bool i2c_write(SDRState *s, uint8_t slave_addr, uint8_t addr, const uint8_t *data, uint32_t len)
{
    int i;

    i2c_start(s);

    if(!i2c_transmit_byte(s, I2C_ADDR_WR(slave_addr))) {
        i2c_stop(s);
        return false;
    }
    if(!i2c_transmit_byte(s, addr)) {
        i2c_stop(s);
        return false;
    }
    for (i = 0; i < len; ++i) {
        if(!i2c_transmit_byte(s, data[i])) {
            i2c_stop(s);
            return false;
        }
    }

    i2c_stop(s);

    return true;
}

static  __maybe_unused bool i2c_write_byte(SDRState *s, uint8_t slave_addr, uint8_t addr, uint8_t val)
{
    uint8_t data[1];

    data[0] = val;
    return i2c_write(s, slave_addr, addr, data, 1);
}

/*
 * Poll I2C slave at given address, return true if it sends an ACK back
 */
static bool i2c_poll(SDRState *s, uint8_t slave_addr)
{
    bool result;

    i2c_start(s);
    result  = i2c_transmit_byte(s, I2C_ADDR_WR(slave_addr));
    result |= i2c_transmit_byte(s, I2C_ADDR_RD(slave_addr));
    i2c_stop(s);

    return result;
}

/****************/

#define SMA_PLL_PROFILE_OFF          0
#define SMA_PLL_PROFILE_OUT_10M      1
#define SMA_PLL_PROFILE_IN_10M       2
#define SMA_PLL_PROFILE_IN_10M_50R   3

typedef struct _cy22150_profile {
    const char *name;
    uint32_t in_freq;
    uint32_t out_freq;
    const uint8_t (*regs)[2];
    int size;
    uint32_t pll_input;  /* bit 0 = MUX_SEL  bit 1 = 10MHZ_OUT_ENABLE */
    
} cy22150_profile;

static const uint8_t cy22150_off_regs[][2] = {
    { 0x09, 0x00},   /* disable outputs */
    { 0x0C, 0x28},
    { 0x12, 0x28},
    { 0x13, 0x00},
    { 0x40, 0xD1},
    { 0x41, 0x34},
    { 0x42, 0xAE},
    { 0x44, 0xE7},
    { 0x45, 0xFF},
    { 0x46, 0xFF},
    { 0x47, 0x84},
};

cy22150_profile cy22150_off_profile = {
    "OFF",
    30720000,
    10000000,
    cy22150_off_regs,
    ARRAY_SIZE(cy22150_off_regs),
    CY22150_MUX_SEL_AD9528_XIN,
};

static const uint8_t cy22150_out_10M_regs[][2] = {
    { 0x09, 0x02},
    { 0x0C, 0x28},
    { 0x12, 0x28},
    { 0x13, 0x00},
    { 0x40, 0xD1},
    { 0x41, 0x34},
    { 0x42, 0xAE},
    { 0x44, 0xE7},
    { 0x45, 0xFF},
    { 0x46, 0xFF},
    { 0x47, 0x84},
};

cy22150_profile cy22150_out_10M_profile = {
    "Output 10MHz",
    30720000,
    10000000,
    cy22150_out_10M_regs,
    ARRAY_SIZE(cy22150_out_10M_regs),
    CY22150_MUX_SEL_AD9528_XIN | CY22150_10MHZ_OUT_ENABLE,
};

static const uint8_t cy22150_in_10M_regs[][2] = {
    { 0x09, 0x01},
    { 0x0C, 0x0A},
    { 0x12, 0x20},
    { 0x13, 0x00},
    { 0x40, 0xD1},
    { 0x41, 0x7C},
    { 0x42, 0x17},
    { 0x44, 0x3F},
    { 0x45, 0xFF},
    { 0x46, 0xFF},
    { 0x47, 0x84},
};

cy22150_profile cy22150_in_10M_profile = {
    "Input 10MHz",
    10000000,
    30720000,
    cy22150_in_10M_regs,
    ARRAY_SIZE(cy22150_in_10M_regs),
    CY22150_MUX_SEL_SMA_XIN,
};

cy22150_profile cy22150_in_10M_50R_profile = {
    "Input 10MHz 50R",
    10000000,
    30720000,
    cy22150_in_10M_regs,
    ARRAY_SIZE(cy22150_in_10M_regs),
    CY22150_MUX_SEL_SMA_XIN | CY22150_50R_IN_ENABLE,
};

static int sdr_pll_mode_2_profile(int mode, uint32_t freq, uint32_t flags)
{
    switch(mode) {
    case SMA_PLL_IDLE:
        return SMA_PLL_PROFILE_OFF;
    case SMA_PLL_OUT:
        if (freq != 10000000)
            return -1;
        return SMA_PLL_PROFILE_OUT_10M;
    case SMA_PLL_IN:
        if (freq != 10000000)
            return -1;
        if (flags & PLL_IN_50R)
            return SMA_PLL_PROFILE_IN_10M_50R;
        else
            return SMA_PLL_PROFILE_IN_10M;
    default:
        break;
    }
    return -1;
}

static __maybe_unused int sdr_pll_profile_2_mode(int profile, int *mode, int *flags)
{
    *flags = 0;
    switch(profile) {
    case SMA_PLL_PROFILE_OFF:
        *mode = SMA_PLL_IDLE;
        break;
    case SMA_PLL_PROFILE_OUT_10M:
        *mode = SMA_PLL_OUT;
        break;
    case SMA_PLL_PROFILE_IN_10M:
        *mode = SMA_PLL_IN;
        break;
    case SMA_PLL_PROFILE_IN_10M_50R:
        *mode = SMA_PLL_IN;
        *flags = PLL_IN_50R;
    default:
        return -1;
    }
    return 0;
}

static int sdr_cy22150_init(SDRState *s, int profile)
{
    const uint8_t (*regs)[2];
    cy22150_profile *p = NULL;
    int slave_addr;
    int size, i, loop, fail;
    
    switch (s->sysid) {
    case SYSID_RF_5G_V2:
        slave_addr = 0x69;
        break;
    default:
        printk(KERN_ERR SDR_NAME " CY22150_init invalid SYSID(%x)\n", s->sysid);
        return -1;
    }
    if (profile == s->sma_pll_profile)
        return 0;

    i2c_reset(s);
    if (i2c_poll(s, slave_addr) == 0) {
        printk(KERN_ERR SDR_NAME " CY22150 not found at 0x%x\n", slave_addr);
        return -1;
    }
    //printk(KERN_INFO SDR_NAME " CY2250 init: prof=%d\n", profile);
    switch(profile) {
    case SMA_PLL_PROFILE_OFF:
    default:
        p = &cy22150_off_profile;
        break;
    case SMA_PLL_PROFILE_OUT_10M:
        p = &cy22150_out_10M_profile;
        break;
    case SMA_PLL_PROFILE_IN_10M:
        p = &cy22150_in_10M_profile;
        break;
    case SMA_PLL_PROFILE_IN_10M_50R:
        p = &cy22150_in_10M_50R_profile;
        break;
    }
    
    /* Set PLL input MUX */
    sdr_writel(s, CSR_CY22150_CONTROL_ADDR, p->pll_input);

    /* Initialize all registers */
    regs = p->regs;
    size = p->size;
    for(loop= 0; loop < 3; loop++) {
        fail = 0;
        for(i = 0; i < size; i++) {
            if (! i2c_write_byte(s, slave_addr, regs[i][0], regs[i][1])) {
                fail++;
            }
        }
        if (fail == 0)
            break;
    }
    if (fail) {
        s->sma_pll_profile = -1;
        printk(KERN_ERR SDR_NAME " Cannot initialize CY22150 at 0x%x\n", slave_addr);
    }
    else {
        s->sma_pll_profile = profile;
        //printk(KERN_INFO SDR_NAME " SMA 10MHz set for %s\n", p->name);
    }
    msleep(50);
    
    return fail;
}

/***************************/

/* Adjusted values for 4G board and 20KHz PWM frequency */
#define SYNC_RETROACTION_COEF 5
#define SYNC_RETROACTION_COEF_FINE 1
/* if the PPS timing difference is larger than this value,
   we consider it is a large error */
/* Unit is per 10 Million for better precision */
#define TCXO_LARGE_THRESHOLD_PP10M    20     /*   2 ppm */
#define TCXO_FINE_THRESHOLD_PP10M     5      /* 0.5 ppm */

#define SYNC_COEF_SHIFT             8

/* returns 0 if OK, -1 if Fail */
static int sdr_clock_init(SDRState *s)
{
    SDRSyncState *ss = &s->sync_state;
    uint32_t pwm_freq, pwm_width;
    int PPM, PPM_R05;

    pwm_freq = 20000;

    ss->tcxo_pwm_period = s->system_clock_frequency / pwm_freq;
    pwm_width = ss->tcxo_pwm_period / 2; /* initial value: center */
    ss->pwm_min = 0;
    ss->pwm_max = ss->tcxo_pwm_period;

    /* force first init */
    s->profile = -1;
    
    if (s->has_cdcm6208) {   /* SDR4G and CPRI */
        if (cdcm6208_initialize(s, PROFILE_INTERNAL) < 0)
            return -1;
        ss->tcxo_freq = 38400000; /* in Hz */
        PPM = 10;
    }
    if (s->has_si5324) {   /* CPRI 10G */
        if (si5324_init(s, PROFILE_INTERNAL) < 0)
            return -1;
        ss->tcxo_freq = 122880000; /* in Hz */
        /* SITime VCXO control range is 0.1V to 3.2V */
        ss->pwm_min = (ss->tcxo_pwm_period * 200) / 6666;
        ss->pwm_max = (ss->tcxo_pwm_period * 6466) / 6666;
        PPM = 350;
        /* Start with large PPM, and adjust during tuning */
        /* For CPRI KINTEX R05, Connor Winfield T604 */
        /* (PPM=25, min=0.3V, max=3.0V, mid=1.65V) */
        PPM_R05 = 25;
        ss->pwm_min_R05 = (ss->tcxo_pwm_period * 606) / 6666;
        ss->pwm_max_R05 = (ss->tcxo_pwm_period * 6060) / 6666;
        /* Same pwm_width initial value */
    }
    if (s->has_ad9528) {   /* SDR5G, SDR5G_V2 and CPRI_40G */
        if ((s->sysid != SYSID_RF_5G && s->sysid != SYSID_RF_5G) || s->is_master) {
            if (AD9528_initialize(s, PROFILE_INTERNAL) < 0)
                return -1;
        }
        ss->tcxo_freq = 122880000; /* in Hz */
        PPM = 25;

        /* Abracon VCXO has a 0.5V-2.5V range, initial value for 0.5ppm is 1.5V */
        /* XtalTQ BT0507B VCXO has a ~0V-2.5V range, initial value for 0.5ppm is 1.5V */
        if (s->sysid == SYSID_CPRI_40G) {
            /* Adjust for measured max Voltage = 2.69V */
            //ss->pwm_min = (ss->tcxo_pwm_period * 1150) / 6666;
            ss->pwm_min = (ss->tcxo_pwm_period * 100) / 6666;
            ss->pwm_max = (ss->tcxo_pwm_period * 6250) / 6666;
            /* Set start point at 1.5V */
            pwm_width = (ss->tcxo_pwm_period * 3700) / 6666;
        }
        else {
            /* Adjust for measured max Voltage = 3.19V */
            //ss->pwm_min = (ss->tcxo_pwm_period * 1045) / 6666;
            ss->pwm_min = (ss->tcxo_pwm_period * 100) / 6666;
            ss->pwm_max = (ss->tcxo_pwm_period * 5224) / 6666;
            /* Set start point at 1.5V */
            pwm_width = (ss->tcxo_pwm_period * 3170) / 6666;
        }
    }

    ss->sync_source = -1;
    ss->state = SYNC_STATE_STARTING;
    ss->last_pps_clock = 0;

    ss->tcxo_range_max = ((int64_t)ss->tcxo_freq * PPM) / 1000000;

    /* About 250 ns in tcxo clock ticks */
    ss->error_threshold = ((int64_t)ss->tcxo_freq) / 4000000;

    ss->retroaction_coef = ((((int64_t)(ss->pwm_max - ss->pwm_min)) << SYNC_COEF_SHIFT) * 1000000 / PPM) / ss->tcxo_freq;
    if (PPM < 20)
        ss->retroaction_coef_fine = (ss->retroaction_coef + 2) / 6;
    else
        ss->retroaction_coef_fine = (ss->retroaction_coef + 1) / 3;

#ifdef DEBUG_PPS
    printk(" tcxo_freq=%d tcxo_pwm_period=%d PPM=%d tcxo_range_max=%d coeff=%d / %d\n",
           ss->tcxo_freq, ss->tcxo_pwm_period, PPM, ss->tcxo_range_max,
           ss->retroaction_coef, ss->retroaction_coef_fine);
#endif
    /* For CPRI 10G, also compute alternate retroaction_coeff for R05 */
    if (s->has_si5324)
    {
        ss->tcxo_range_max_R05 = ((int64_t)ss->tcxo_freq * PPM_R05) / 1000000;

        ss->retroaction_coef_R05 = ((((int64_t)(ss->pwm_max_R05 - ss->pwm_min_R05)) << SYNC_COEF_SHIFT) * 1000000 / PPM_R05) / ss->tcxo_freq;
        ss->retroaction_coef_fine_R05 = (ss->retroaction_coef_R05 + 2) / 4;

        /* compute medium value between the two coef */
        ss->has_CPRI_R05 = 0;
        ss->last_width = 0;
        ss->last_diff = 0;
        ss->last_slope = 0;
#ifdef DEBUG_PPS
        printk(" R05: PPM=%d tcxo_range_max=%d coeff=%d / %dn",
           PPM_R05, ss->tcxo_range_max_R05,
               ss->retroaction_coef_R05, ss->retroaction_coef_fine_R05);
#endif
    }

    /* Prevent overflow */
    ss->tcxo_large_threshold = ((ss->tcxo_freq / 1000) * TCXO_LARGE_THRESHOLD_PP10M)  / 10000;
    ss->tcxo_fine_threshold = ((ss->tcxo_freq / 1000) * TCXO_FINE_THRESHOLD_PP10M)  / 10000;

    /* Shut down PWM before setting period and width */
    sdr_writel(s, CSR_SYNCHRO_TCXO_ENABLE_ADDR, 0);
    
    sdr_writel(s, CSR_SYNCHRO_TCXO_PERIOD_ADDR, ss->tcxo_pwm_period);

    /* On all boards except SDR100 (V1 & V2) Slave */
    if ((s->sysid != SYSID_RF_5G && s->sysid != SYSID_RF_5G_V2) || s->is_master) {
        uint16_t ratio;
        /* Call once at driver load to read Calibration TCXO value */
        ratio = sdr_flash_config_read_vcxocal(s);
        if (ratio != 0) {
            pwm_width = (((uint64_t)ss->tcxo_pwm_period * ratio) + (1 << 15)) >> 16;
            printk(KERN_INFO SDR_NAME " VCXOCAL PWM width: %d\n", pwm_width);
        }
    }
    sdr_writel(s, CSR_SYNCHRO_TCXO_WIDTH_ADDR, pwm_width);

    /* Start the PWM for the TCXO now */
    /* Will be overwritten later in ad9528_init depending on profile */
    sdr_writel(s, CSR_SYNCHRO_TCXO_ENABLE_ADDR, 1);
    
    /* Init System Clock counter for alternate GEN_SYS PPS source*/
    sdr_writel(s, CSR_SYNCHRO_PPS_SYS_GEN_PERIOD_ADDR, s->system_clock_frequency);
    sdr_writel(s, CSR_SYNCHRO_PPS_SYS_GEN_WIDTH_ADDR, s->system_clock_frequency / 2);
    sdr_writel(s, CSR_SYNCHRO_PPS_SYS_GEN_ENABLE_ADDR, 1);


    /* initial internal PPS generator */
    //sdr_writel(s, CSR_SYNCHRO_PPS_GEN_WIDTH_ADDR, (ss->tcxo_freq/100)*80); /* 80% duty cycle */
    sdr_writel(s, CSR_SYNCHRO_PPS_GEN_WIDTH_ADDR, (ss->tcxo_freq/100)*10); /* 10% duty cycle */
    sdr_writel(s, CSR_SYNCHRO_PPS_GEN_PERIOD_ADDR, ss->tcxo_freq);
    sdr_writel(s, CSR_SYNCHRO_PPS_GEN_ENABLE_ADDR, 1);

    /* set internal sync by default */
    if ((s->sysid == SYSID_RF_5G || s->sysid == SYSID_RF_5G_V2) && ! s->is_master) {
        /* Slave FPGA on SDR5G is always set for EXTERNAL sync source */
        ss->sync_source = SDR_SYNC_SOURCE_EXTERNAL;
        sdr_writel(s, CSR_SYNCHRO_PPS_INPUT0_CTRL_ADDR, SYNCHRO_PPS_INPUT_CTRL_PREVIOUS);
        /* ON SDR5G, always set PPS_OUTPUT on INT0 */
        sdr_writel(s, CSR_SYNCHRO_PPS_OUTPUT_CTRL_ADDR, SYNCHRO_PPS_OUTPUT_CTRL_INT0);
    }
    else {
        ss->sync_source = SDR_SYNC_SOURCE_INTERNAL;
        sdr_writel(s, CSR_SYNCHRO_PPS_INPUT0_CTRL_ADDR, SYNCHRO_PPS_INPUT_CTRL_GEN);
        sdr_writel(s, CSR_SYNCHRO_PPS_OUTPUT_CTRL_ADDR, SYNCHRO_PPS_OUTPUT_CTRL_INT0);
    }

    sdr_writel(s, CSR_SYNCHRO_PPS_DEMOD_ENABLE_ADDR, 0);
    /* Modulated PPS input on SATA connector for SDR100 and SDR100V2 */
    /* because Si53306 blocks DC */
    switch(s->sysid) {
    case SYSID_RF_5G:
        if (! s->is_master)
            break;
        sdr_writel(s, CSR_SYNCHRO_PPS_DEMOD_ENABLE_ADDR, 1);
        break;
    case SYSID_RF_5G_V2:
        sdr_writel(s, CSR_SYNCHRO_PPS_DEMOD_ENABLE_ADDR, 1);
        break;
    }
    
    switch(s->sysid) {
    case SYSID_RF_35T:
    case SYSID_RF_15T:
    case SYSID_RF_5G:
    case SYSID_RF_5G_V2:
        /* Shut down FPGA PPS led on R02/R03 and 4G also */
        sdr_writel(s, CSR_SYNCHRO_LED_PWM_WIDTH_ADDR, 0);
        sdr_writel(s, CSR_SYNCHRO_LED_PWM_PERIOD_ADDR, 256);
        sdr_writel(s, CSR_SYNCHRO_LED_PWM_ENABLE_ADDR, 1);
        break;
    default:
        break;
    }
    if (s->has_ad9528) {   /* SDR5G: shut Down PCI Bridge leds after init */
        sdr_writel(s, CSR_PLX_LEDS_ENABLE_ADDR, 0);
    }

    switch(s->sysid) {
    case SYSID_RF_5G_V2:
        if (! s->is_master)
            break;
        s->sma_pll_mode = sdr_flash_config_read_pll(s, &s->sma_pll_freq, &s->sma_pll_flags);
        if (s->sma_pll_mode == SMA_PLL_IN)
            s->sma_pll_mode = SMA_PLL_IDLE;
        /* force first setup */
        s->sma_pll_profile = -1;
        sdr_cy22150_init(s, sdr_pll_mode_2_profile(s->sma_pll_mode, s->sma_pll_freq, s->sma_pll_flags));
        s->sma_pps_mode = SMA_PPS_IN;
        sdr_writel(s, CSR_SYNCHRO_PPS_EXT_TRISTATE_ADDR, SYNCHRO_PPS_EXT_DIRECTION_INPUT);
        break;
    case SYSID_CPRI_40G:
        sdr_writel(s, CSR_SYNCHRO_PPS_EXT_CONTROL_ADDR, 0x00);
        break;
    default:
        break;
    }
    return 0;
}

static int sdr_clock_set_sync_source(SDRState *s, int sync_source)
{
    SDRSyncState *ss = &s->sync_state;
    int input_ctrl;
    int ret = 0;

#ifdef DEBUG_PPS
    printk(KERN_INFO " Clock_set_sync_source(minor=%d sysid=0x%x) sync_src=%d (cur=%d)\n",
           s->minor, s->sysid, sync_source, ss->sync_source);
#endif
    switch(s->sysid) {
    case SYSID_RF_5G:
        if (! s->is_master) {
            /* SDR100 Slave AD9371 must sync on his master */
            sync_source = SDR_SYNC_SOURCE_EXTERNAL;
        }
        break;
    case SYSID_RF_5G_V2:
        if (! s->is_master) {
            /* Single FPGA: do not mess with Master settings */
            //ss->sync_source = sync_source;
            ss->sync_source = SDR_SYNC_SOURCE_EXTERNAL;
            return 0;            
        }
        break;
    case SYSID_CPRI_40G:
        /* Reset 50 ohms load */
        sdr_writel(s, CSR_SYNCHRO_PPS_EXT_CONTROL_ADDR, 0x00);
        break;
    }

    /* Optimize "ots_init" case */
    if (sync_source == SDR_SYNC_SOURCE_EXTERNAL &&
        ss->sync_source == SDR_SYNC_SOURCE_EXTERNAL) {
        /* on SDR100 master, V2 and CPRI_40, make sure the clock is already locked */
        if (s->has_ad9528 && ((s->sysid != SYSID_RF_5G && s->sysid != SYSID_RF_5G_V2) || s->is_master)) {
            if (ad9528_is_locked(s)) {
                return 0;
            }
        } else {
            /* on other boards: done */
            return 0;
        }
    }
#ifdef DEBUG_PPS
    printk(KERN_INFO "     set_sync_source 2(minor=%d) src=%d (cur=%d)\n", s->minor, sync_source,
           ss->sync_source);
#endif
    switch(sync_source) {
    case SDR_SYNC_SOURCE_INTERNAL: /* Src = INT, PPS= INT */
    case SDR_SYNC_SOURCE_EXTERNAL_CLOCK: /* Src = EXT, PPS = INT */
        input_ctrl = SYNCHRO_PPS_INPUT_CTRL_GEN;
        break;
    case SDR_SYNC_SOURCE_GPS: /* Src = INT slaved on GPS PPS */
        /* GPS optimisation */
        if (sync_source == SDR_SYNC_SOURCE_GPS) {
            if (ss->state == SYNC_STATE_FINE && ss->abs_error <= ss->tcxo_fine_threshold) {
                return 0;
            }
        }
        
        input_ctrl = SYNCHRO_PPS_INPUT_CTRL_GPS;
        if (sdr_readl(s, CSR_IDENTIFIER_REVISION_ADDR) >= MK_ID_REVISION(2023, 1, 16)) {
            /* Src = INT slaved on GPS PPS with fallback on VCXO if GPS lost */
            input_ctrl = SYNCHRO_PPS_INPUT_CTRL_GEN_VCXO_GPS;
        }
        break;
    case SDR_SYNC_SOURCE_EXTERNAL_PPS: /* Src = INT slaved on Ext PPS */
        switch (s->sysid) {
        case SYSID_RF_5G_V2:
            /* EXT_PPS on top SMA connector */
            if (s->sma_pps_mode == SMA_PPS_OUT) {
                printk(KERN_ERR SDR_NAME " SMA PPS be input\n");
                return -EINVAL;
            }
            input_ctrl = SYNCHRO_PPS_INPUT_CTRL_EXT;
            
            break;
        case SYSID_CPRI_10G:
            /* No EXT PPS input: use SATA */
            input_ctrl = SYNCHRO_PPS_INPUT_CTRL_PREVIOUS;
            break;
        case SYSID_CPRI_40G:
            /* EXT_PPS on GPS antenna SMA connector */
            input_ctrl = SYNCHRO_PPS_INPUT_CTRL_EXT;
            break;
        default:
            /* UFL Ext for SDR5G */
            /* PR10 MCX for SDR50 */
            input_ctrl = SYNCHRO_PPS_INPUT_CTRL_EXT;
            break;
        }
        break;
    case SDR_SYNC_SOURCE_EXTERNAL_PPS_50: /* Src = INT slaved on Ext PPS with 50 ohms */
        switch (s->sysid) {
        case SYSID_CPRI_40G:
            /* EXT_PPS on GPS antenna SMA connector with 50 ohms */
            sdr_writel(s, CSR_SYNCHRO_PPS_EXT_CONTROL_ADDR, 0x01);
            input_ctrl = SYNCHRO_PPS_INPUT_CTRL_EXT;
            break;
        default:
            printk(KERN_ERR SDR_NAME " Not supported\n");
            return -EINVAL;
        }
        break;
    case SDR_SYNC_SOURCE_EXTERNAL: /* Src = EXT, PPS = EXT (Slave) */
    case SDR_SYNC_SOURCE_PREV_PPS: /* Src = INT slaved on PREV PPS (SATA) */
    case SDR_SYNC_SOURCE_PREV_PPS_MOD: /* Src = INT slaved on modulated PREV PPS (SATA) */
    case SDR_SYNC_SOURCE_EXTERNAL_4G: /* Src = EXT, PPS = EXT unmodulated (5G slave on 4G master) */
        input_ctrl = SYNCHRO_PPS_INPUT_CTRL_PREVIOUS;
        break;
    case SDR_SYNC_SOURCE_RESET:
        sdr_clock_init(s);
        return 0;
    case SDR_SYNC_SOURCE_CPRI:    /* Src = Recovery from Master CPRI (Slave mode) */
        input_ctrl = SYNCHRO_PPS_INPUT_CTRL_GEN;
        break;
    case SDR_SYNC_SOURCE_EXTERNAL_10MHZ: /* Src = 10MHZ (SMA), PPS = Ext (SMA) */
        switch (s->sysid) {
        case SYSID_RF_5G_V2:
            /* EXT_PPS on top SMA connector */
            if (s->sma_pps_mode == SMA_PPS_OUT) {
                printk(KERN_ERR SDR_NAME " SMA PPS must be input\n");
                return -EINVAL;
            }
            input_ctrl = SYNCHRO_PPS_INPUT_CTRL_EXT;
            break;
        default:
            return -EINVAL;
            break;
        }
        break;

    case SDR_SYNC_SOURCE_PCIE: /* Src & PPS = PCIE synchro (for sync slave) */
        input_ctrl = SYNCHRO_PPS_INPUT_CTRL_PCIE;
        break;
    default:
        return -EINVAL;
    }

    /* Stop PPS tunning before starting Oscillator lock  */
    if (s->sysid == SYSID_CPRI_40G) {
        sdr_writel(s, CSR_GPS_CONTROL_ADDR, 0);
    }
    sdr_disable_interrupt(s, PPS0_INTERRUPT);
    
    if (s->sysid == SYSID_RF_5G_V2) {
        int prof;
        switch (sync_source) {
        case SDR_SYNC_SOURCE_EXTERNAL_CLOCK:
        case SDR_SYNC_SOURCE_EXTERNAL_10MHZ:
            /* EXT 10MHz clock on top SMA connector */
            if (s->sma_pll_mode == SMA_PLL_OUT) {
                printk(KERN_ERR SDR_NAME " 10MHz clock must be input\n");
                return -EINVAL;
            }
            /* initialize PLL for active input */
            prof = SMA_PLL_PROFILE_IN_10M_50R;
            s->sma_pll_mode = SMA_PLL_IN;
            break;
        default:
            /* Restore profile from saved parameters */
            /* Make sure we are not using PLL when asking internal Clock */
            if (s->sma_pll_mode == SMA_PLL_IN) {
                s->sma_pll_mode = SMA_PLL_IDLE;
                prof = SMA_PLL_PROFILE_OFF;
            }
            else
                prof = sdr_pll_mode_2_profile(s->sma_pll_mode, s->sma_pll_freq, s->sma_pll_flags);
            break;
        }
        sdr_cy22150_init(s, prof);
    }
            
    if (sync_source == SDR_SYNC_SOURCE_CPRI) {
        /* CPRI Clock slaved on Master */
        if (s->has_si5324) {   /* CPRI 10G */
            /* Output RecoveryClock on CLKIN1 */
            if (si5324_init(s, PROFILE_INTERNAL) < 0) {
                ret = -1;
            }
            else {
                sdr_writel(s, CSR_SI5324_RECOVERY_CLK_ENABLE_ADDR, 1);
            }
        }
        else
        if (s->has_ad9528) {
            /* Output recovery clock from FPGA */
            int val = (1 << CSR_AD9528_RECOVERY_CLK_ENABLE_OFFSET);
            sdr_writel(s, CSR_AD9528_RECOVERY_CLK_ADDR, val);
            
            /* set REFB input switch for recovered clock */
            val = sdr_readl(s, CSR_AD9528_CONTROL_ADDR);
            val &= ~(1 << CSR_AD9528_CONTROL_IN_SEL_OFFSET);
            sdr_writel(s, CSR_AD9528_CONTROL_ADDR, val);

            /* Now init AD9528 on REFB 122.88 */
            if (AD9528_initialize(s, PROFILE_SLAVE_122M88) != 0) {
                printk(KERN_INFO SDR_NAME " fallback to Internal\n");
                sync_source = SDR_SYNC_SOURCE_INTERNAL;
                ret = -1;
            }
        }
    }
    
    if (s->sysid == SYSID_CPRI_40G) {
        /* Set RefB input on SATA CLK IN */
        int val = sdr_readl(s, CSR_AD9528_CONTROL_ADDR);
        val |= (1 << CSR_AD9528_CONTROL_IN_SEL_OFFSET);
        sdr_writel(s, CSR_AD9528_CONTROL_ADDR, val);
    }
    
    if (sync_source == SDR_SYNC_SOURCE_EXTERNAL ||
        sync_source == SDR_SYNC_SOURCE_EXTERNAL_CLOCK ||
        sync_source == SDR_SYNC_SOURCE_EXTERNAL_10MHZ ||
        sync_source == SDR_SYNC_SOURCE_EXTERNAL_4G) {
        /* use external clock source */
        if (s->has_cdcm6208) {
            /* Try 38.4MHz and 10MHz: CMOS and LVDS */
            if ((cdcm6208_initialize(s, PROFILE_SLAVE_38M40) != 0) &&
                (cdcm6208_initialize(s, PROFILE_SLAVE_10M00_CMOS) != 0) &&
                (cdcm6208_initialize(s, PROFILE_SLAVE_10M00) != 0)) {
                /* external lock failed: return to internal vcxo */
                printk(KERN_INFO SDR_NAME " fallback to Internal\n");
                cdcm6208_initialize(s, PROFILE_INTERNAL);
                sync_source = SDR_SYNC_SOURCE_INTERNAL;
                input_ctrl = SYNCHRO_PPS_INPUT_CTRL_GEN;
                ret = -1;
            }
        }
        if (s->has_si5324) {
            if (si5324_init(s, PROFILE_SLAVE_122M88) < 0
                /* && si5324_init(s, PROFILE_SLAVE_38M40) < 0 */
                   ) {
                printk(KERN_INFO SDR_NAME " fallback to Internal\n");
                si5324_init(s, PROFILE_INTERNAL);
                sync_source = SDR_SYNC_SOURCE_INTERNAL;
                input_ctrl = SYNCHRO_PPS_INPUT_CTRL_GEN;
                ret = -1;
            }
        }

        if (s->has_ad9528 && (s->sysid == SYSID_CPRI_40G || s->is_master)) {
            if (s->sysid == SYSID_CPRI_40G) {
                /* set REFB input switch for SATA CLK IN */
                int val = sdr_readl(s, CSR_AD9528_CONTROL_ADDR);
                val |= (1 << CSR_AD9528_CONTROL_IN_SEL_OFFSET);
                sdr_writel(s, CSR_AD9528_CONTROL_ADDR, val);
            }
            
            if (sync_source != ss->sync_source || !ad9528_is_locked(s)) {
                ret = -1;
                if (sync_source == SDR_SYNC_SOURCE_EXTERNAL) {
                    /* MBU: Use External clock on AD9528 REFA (SATA connectors) */
                    /* Check 122.88MHz (SDR5G) and 38.40MHz clock (SDR4G) */
                    if (AD9528_initialize(s, PROFILE_SLAVE_122M88) == 0)
                        ret = 0;
                    else {
                        /* For factory test */
                        /* Try external 38.4MHz from SDR4G */
                        sync_source = SDR_SYNC_SOURCE_EXTERNAL_4G;
                    }
                }
                if (sync_source == SDR_SYNC_SOURCE_EXTERNAL_4G) {
                    /* MBU: Use External clock on AD9528 REFA (SATA connectors) */
                    /* Check 38.40MHz clock */
                    if (AD9528_initialize(s, PROFILE_SLAVE_38M40) == 0)
                        ret = 0;
                }
                if (sync_source == SDR_SYNC_SOURCE_EXTERNAL_CLOCK) {
                    switch (s->sysid) {
                    default:
                        break;
                    case SYSID_RF_5G:
                        /* MBU: Use External clock on AD9528 REFB (EXT CLK UFL input)*/
                        /* Check 38.40MHz and 30.72MHz clock */
                        if ((AD9528_initialize(s, PROFILE_EXT_38M40) == 0) ||
                            (AD9528_initialize(s, PROFILE_EXT_30M72) == 0))
                            ret = 0;
                        break;
                    case SYSID_RF_5G_V2:
                        /* MBU: Use SMA External clock on SDR100V2 */
                        /* With 10MHz on SMA => PLL => 30.72MHz RefB input */
                        if (AD9528_initialize(s, PROFILE_EXT_30M72) == 0)
                            ret = 0;
                        break;
                    }
                }
                if (sync_source == SDR_SYNC_SOURCE_EXTERNAL_10MHZ) {
                    switch (s->sysid) {
                    default:
                        printk(KERN_INFO SDR_NAME " 10MHz not supported\n");
                        ret = -1;
                        break;
                    case SYSID_RF_5G_V2:
                        /* MBU: Use SMA External clock on SDR100V2 */
                        /* With 10MHz on SMA => PLL => 30.72MHz RefB input */
                        if (AD9528_initialize(s, PROFILE_EXT_30M72) == 0)
                            ret = 0;
                        break;
                    }
                }
                /* return to default mode if could not Lock */
                if (ret < 0) {
                    printk(KERN_INFO SDR_NAME " fallback to Internal\n");
                    AD9528_initialize(s, PROFILE_INTERNAL);
                    sync_source = SDR_SYNC_SOURCE_INTERNAL;
                    input_ctrl = SYNCHRO_PPS_INPUT_CTRL_GEN;

                    if (s->sysid == SYSID_RF_5G_V2) {
                        if (s->sma_pll_mode == SMA_PLL_IN) {
                            s->sma_pll_mode = SMA_PLL_IDLE;
                            sdr_cy22150_init(s, SMA_PLL_PROFILE_OFF);
                        }
                    }
                }
            }
        }
    } else {
        /* use internal clock source */
        if (s->has_si5324) {
            si5324_init(s, PROFILE_INTERNAL);
            if (sync_source == SDR_SYNC_SOURCE_CPRI) {
                /* Output RecoveryClock on CLKIN1 */
                sdr_writel(s, CSR_SI5324_RECOVERY_CLK_ENABLE_ADDR, 1);
            }
        }
        if (s->has_cdcm6208) {
            cdcm6208_initialize(s, PROFILE_INTERNAL);
            if (sync_source == SDR_SYNC_SOURCE_CPRI) {
                /* Select Primary Input (LVCMOS) */
                cdcm_write(s, 4, 0x20af | (2 << 3));
            }
        }
        if (s->has_ad9528 && ((s->sysid != SYSID_RF_5G && s->sysid != SYSID_RF_5G_V2) || s->is_master)) {
            if (sync_source != ss->sync_source) {
                ret = -1;
                /* MBU: Standard setting */
#ifdef DEBUG_PPS
                printk(KERN_INFO SDR_NAME "AD9528_initialize(%d)\n", PROFILE_INTERNAL);
#endif
                if (AD9528_initialize(s, PROFILE_INTERNAL) == 0)
                    ret = 0;
            }
        }
    }

#ifdef DEBUG_PPS
    printk(KERN_INFO SDR_NAME " set input_ctrl=0x%x\n", input_ctrl);
#endif
    
    sdr_writel(s, CSR_SYNCHRO_PPS_INPUT0_CTRL_ADDR, input_ctrl);
        /* ON SDR5G, always set PPS_OUTPUT on INT0 */
    if (!s->has_ad9528 && input_ctrl == SYNCHRO_PPS_INPUT_CTRL_PREVIOUS) {
        sdr_writel(s, CSR_SYNCHRO_PPS_OUTPUT_CTRL_ADDR, SYNCHRO_PPS_OUTPUT_CTRL_PREVIOUS);
    } else {
        sdr_writel(s, CSR_SYNCHRO_PPS_OUTPUT_CTRL_ADDR, SYNCHRO_PPS_OUTPUT_CTRL_INT0);
    }
    ss->sync_source = sync_source;

    sdr_writel(s, CSR_SYNCHRO_PPS_DEMOD_ENABLE_ADDR, 0);
    if ((sync_source != SDR_SYNC_SOURCE_PREV_PPS) &&
        (sync_source != SDR_SYNC_SOURCE_EXTERNAL_4G)) {
        /* Non modulated SYSREF input for factory calibration and SDR5G slaved on SDR4G */

        switch(s->sysid) {
        case SYSID_RF_5G:
            if (! s->is_master)
                break;
            sdr_writel(s, CSR_SYNCHRO_PPS_DEMOD_ENABLE_ADDR, 1);
            break;
        case SYSID_RF_5G_V2:
            sdr_writel(s, CSR_SYNCHRO_PPS_DEMOD_ENABLE_ADDR, 1);
            break;
        }
    }
    
    ss->state = SYNC_STATE_STARTING;

    switch(sync_source) {
    case SDR_SYNC_SOURCE_INTERNAL:
    case SDR_SYNC_SOURCE_GPS:
    case SDR_SYNC_SOURCE_EXTERNAL_PPS:
    case SDR_SYNC_SOURCE_EXTERNAL_PPS_50:
    case SDR_SYNC_SOURCE_PREV_PPS:
    case SDR_SYNC_SOURCE_PREV_PPS_MOD:
        {
            int wid = sdr_readl(s, CSR_SYNCHRO_TCXO_WIDTH_ADDR);
            /* Force TCXO anyway here ! */
            sdr_writel(s, CSR_SYNCHRO_TCXO_ENABLE_ADDR, 0);
            sdr_writel(s, CSR_SYNCHRO_TCXO_WIDTH_ADDR, wid);
            sdr_writel(s, CSR_SYNCHRO_TCXO_ENABLE_ADDR, 1);
        }
        break;
    default:
        break;
    }

    switch (sync_source) {
    case SDR_SYNC_SOURCE_GPS:
    case SDR_SYNC_SOURCE_EXTERNAL_PPS:
    case SDR_SYNC_SOURCE_EXTERNAL_PPS_50:
        /* Also enable for SOURCE_EXTERNAL since some code checks LATCH0 */
    case SDR_SYNC_SOURCE_EXTERNAL:
    case SDR_SYNC_SOURCE_EXTERNAL_4G:
    case SDR_SYNC_SOURCE_PREV_PPS:
    case SDR_SYNC_SOURCE_PREV_PPS_MOD:
#ifdef CONFIG_CPRI
    case SDR_SYNC_SOURCE_CPRI:
#endif
        /* retroaction needed to adjust the clock frequency. For
           internal sync, the clock frequency is always adjusted by
           definition. When using another board as sync source, the
           clock also comes from it so no adjustment is needed. */
        if (s->has_si5324 && ss->has_CPRI_R05 == 0) {
            /* First time we try to tune CPRI 10G VCXO */
            /* Offset VCXO setting to force changes and allow slope detection */
            sdr_writel(s, CSR_SYNCHRO_TCXO_ENABLE_ADDR, 0);
            sdr_writel(s, CSR_SYNCHRO_TCXO_WIDTH_ADDR, 2000);
            sdr_writel(s, CSR_SYNCHRO_TCXO_ENABLE_ADDR, 1);
        }
        if (s->sysid == SYSID_CPRI_40G) {
            sdr_writel(s, CSR_GPS_CONTROL_ADDR, 0);
        }
        sdr_enable_interrupt(s, PPS0_INTERRUPT);
#ifdef DEBUG_PPS
        printk(KERN_INFO SDR_NAME " Enable PPS interrupts\n");
#endif
        break;
    default:
        break;
    }
    
    if (ret < 0) {
        return -EAGAIN;
    }
    
    return 0;
}

static void sdr_clock_get_sync_state(SDRState *s,
                                     struct sdr_ioctl_sync_state *m)
{
    SDRSyncState *ss = &s->sync_state;
    uint32_t diff, reg;

    m->sync_source = ss->sync_source;

    m->clock_freq = ss->clock_freq;
    if (s->sysid == SYSID_RF_5G || s->sysid == SYSID_RF_5G_V2) {
        ss->tcxo_freq = 122880000;
        if (! s->is_master)
            m->clock_freq = 122880000;
    }
       
    diff = sdr_readl(s, CSR_SYNCHRO_CLOCK_COUNTER_VALUE_ADDR) -
        sdr_readl(s, CSR_SYNCHRO_PPS_INT0_LATCH_VALUE_ADDR);
    
    /* last PPS should be recent enough */
    m->pps_locked = 0;
    if (diff < (ss->tcxo_freq * 2)) {
        m->pps_locked = 1;
        switch (ss->sync_source) {
        case SDR_SYNC_SOURCE_EXTERNAL_CLOCK: /* Src = EXT, PPS = INT */
        case SDR_SYNC_SOURCE_EXTERNAL: /* Src = EXT, PPS = EXT (Slave) */
        case SDR_SYNC_SOURCE_EXTERNAL_4G: /* Src = EXT, PPS = EXT (Slave) */
        case SDR_SYNC_SOURCE_EXTERNAL_10MHZ:
        default:
            break;
        case SDR_SYNC_SOURCE_GPS: /* internal CLock, PPS from GPS */
        case SDR_SYNC_SOURCE_EXTERNAL_PPS: /* internal Clock, PPS from UFL */
        case SDR_SYNC_SOURCE_EXTERNAL_PPS_50: /* internal Clock, PPS from UFL */
        case SDR_SYNC_SOURCE_PREV_PPS: /* internal Clock, PPS from PREV (SATA/5pin) (for factory cal) */
        case SDR_SYNC_SOURCE_PREV_PPS_MOD: /* internal Clock, PPS from modulated PREV (SATA)  */
#ifdef DEBUG_PPS
            printk(KERN_INFO SDR_NAME "Get_sync_state(sdr%d): source=%d  state=%d abs_err=%d thres=%d\n",
                   s->minor, ss->sync_source, ss->state, ss->abs_error, (ss->tcxo_fine_threshold * 2));
#endif
            
            /* Check that the tuning is stabilized */
            if (ss->state != SYNC_STATE_FINE ||
                abs(ss->abs_error) > (ss->tcxo_fine_threshold * 2)) {
                m->pps_locked = 3;
            }
            break;
        }
        if (m->pps_locked >= 1 && ss->sync_source == SDR_SYNC_SOURCE_GPS) {
            if (sdr_readl(s, CSR_IDENTIFIER_REVISION_ADDR) >= MK_ID_REVISION(2023, 1, 16) &&
                (sdr_readl(s, CSR_GPS_STATUS_ADDR) & GPS_PPS_ACTIVE) == 0) {
                /* Locked but GPS_PPS inactive */
                m->pps_locked = 2;
            }
        }
    }

    if (s->has_cdcm6208) {
        reg = cdcm_read(s, 21);
        m->clock_pll_locked = ((reg >> 2) & 1) ^ 1; /* PLL_UNLOCK */
        m->clock_source = ((reg >> 0) & 1) ^ 1; /* SEL_REF */
    }
    if (s->has_si5324) {
        reg = si5324_read(s, 0);
        m->clock_source = ((reg >> 6) & 1) ^ 1; /* FREE_RUN / EXTERNAL */
        
        reg = si5324_read(s, 130);
        m->clock_pll_locked = ((reg >> 0) & 1) ^ 1; /* PLL_UNLOCK */
    }
    if (s->has_ad9528) {
        uint8_t reg508;
        sdr_ad9528_read(s, AD9528_ADDR_STATUS_READBACK0, &reg508);
        m->clock_pll_locked = ((reg508 & s->lock_mask) == s->lock_mask) ? 1: 0;
        
        if (! m->clock_pll_locked) {
            uint8_t reg509;
            sdr_ad9528_read(s, AD9528_ADDR_STATUS_READBACK1, &reg509);
            printk(KERN_INFO SDR_NAME " AD9528 state reg[0x508]=0x%02x reg[0x509]=0x%02x (lock=0x%02x)\n", reg508, reg509, s->lock_mask);
        }

        switch (ss->sync_source) {
        default:
        case SDR_SYNC_SOURCE_INTERNAL: /* Src = INT, PPS= INT */
        case SDR_SYNC_SOURCE_GPS: /* Src = INT asservi sur GPS PPS */
        case SDR_SYNC_SOURCE_EXTERNAL_PPS: /* Src = INT asservi sur Ext PPS */
        case SDR_SYNC_SOURCE_EXTERNAL_PPS_50: /* Src = INT asservi sur Ext PPS */
            m->clock_source = 0;
            break;
        case SDR_SYNC_SOURCE_EXTERNAL_CLOCK: /* Src = EXT, PPS = INT */
        case SDR_SYNC_SOURCE_EXTERNAL_10MHZ:
            if (s->sysid == SYSID_RF_5G_V2) {
                /* EXT 10MHz clock on top SMA connector */
                if (s->sma_pll_mode == SMA_PLL_IN) {
                    m->clock_source = 2;   /* SDR_CLOCK_EXT_10MHZ */
                    break;
                }
            }
            m->clock_source = 1;
            break;
        case SDR_SYNC_SOURCE_EXTERNAL: /* Src = EXT, PPS = EXT (Slave) */
        case SDR_SYNC_SOURCE_EXTERNAL_4G: /* Src = EXT, PPS = EXT unmodulated (Slave) */
            m->clock_source = 1;
            break;
        }
    }
}

static int sdr_set_cpri_slave(SDRState *s, int slave)
{
    int val;
    
    //printk(KERN_INFO " Set CPRI slave (minor=%d) slave=%d\n", s->minor, slave);
    switch (s->sysid) {
    case SYSID_CPRI_10G:
        if (slave) {
            /* Output RecoveryClock on CLKIN1 */
            sdr_writel(s, CSR_SI5324_RECOVERY_CLK_ENABLE_ADDR, 1);
        }
        else {
            sdr_writel(s, CSR_SI5324_RECOVERY_CLK_ENABLE_ADDR, 0);
        }
        break;
    case SYSID_CPRI_40G:
        if (slave) {
            val = (1 << CSR_AD9528_RECOVERY_CLK_ENABLE_OFFSET);
            sdr_writel(s, CSR_AD9528_RECOVERY_CLK_ADDR, val);
            
            /* set REFB input switch on recovered clock */
            val = sdr_readl(s, CSR_AD9528_CONTROL_ADDR);
            val &= ~(1 << CSR_AD9528_CONTROL_IN_SEL_OFFSET);
            sdr_writel(s, CSR_AD9528_CONTROL_ADDR, val);

            s->cpri_slave = 1;
            /* Switch to RefB on AD9528 */
            if (s->profile != PROFILE_SLAVE_122M88) {
                msleep(1);
                AD9528_initialize(s, PROFILE_SLAVE_122M88);
            }
        }
        else {
            val = (0 << CSR_AD9528_RECOVERY_CLK_ENABLE_OFFSET);
            sdr_writel(s, CSR_AD9528_RECOVERY_CLK_ADDR, val);

            val = sdr_readl(s, CSR_AD9528_CONTROL_ADDR);
            val |= (1 << CSR_AD9528_CONTROL_IN_SEL_OFFSET);
            sdr_writel(s, CSR_AD9528_CONTROL_ADDR, val);

            if (s->cpri_slave) {
                /* Revert to Input A on AD9528 */
                msleep(1);
                AD9528_initialize(s, PROFILE_INTERNAL);
                s->cpri_slave = 0;
            }
        }
        break;
    default:
        break;
    }
    return 0;
}

static int sdr_get_cpri_slave(SDRState *s)
{
    return (sdr_readl(s, CSR_SI5324_RECOVERY_CLK_ENABLE_ADDR) & 1);
}

static void sdr_clock_pps0_interrupt(SDRState *s)
{
    SDRSyncState *ss = &s->sync_state;
    uint32_t pps_clock, dt;
    int diff, diff1, val, coef, corr, prod;
    int hfr_clk = ss->tcxo_freq / 150;
    int32_t new_error;

    pps_clock = sdr_readl(s, CSR_SYNCHRO_PPS_INT0_LATCH_VALUE_ADDR);
#ifdef DEBUG_PPS
    {
        int i;
        uint32_t value;
        for (i = 0; i < 3; i++) {
            value = sdr_readl(s, CSR_SYNCHRO_PPS_INT0_LATCH_VALUE_ADDR);
            if (value != pps_clock)
                printk(KERN_INFO SDR_NAME " PPS INT0_LATCH mismatch i=%d (clk=0x%x val=0x%x)\n",
                       i, pps_clock, value);
        }
    }
#endif
    
    /* MBU: do not adjust VCXO on external SYNC if internal Clock is not used */
    /* In this case, just update last_pps_clock */
    switch (ss->sync_source) {
    case SDR_SYNC_SOURCE_EXTERNAL_CLOCK: /* Src = EXT, PPS = INT */
    case SDR_SYNC_SOURCE_EXTERNAL: /* Src = EXT, PPS = EXT (Slave) */
    case SDR_SYNC_SOURCE_EXTERNAL_4G: /* Src = EXT, PPS = EXT (Slave) */
    case SDR_SYNC_SOURCE_EXTERNAL_10MHZ:
    default:
        goto done;
    case SDR_SYNC_SOURCE_GPS: /* internal CLock, PPS from GPS */
    case SDR_SYNC_SOURCE_EXTERNAL_PPS: /* internal Clock, PPS from UFL */
    case SDR_SYNC_SOURCE_EXTERNAL_PPS_50: /* internal Clock, PPS from UFL */
    case SDR_SYNC_SOURCE_PREV_PPS: /* internal Clock, PPS from PREV (SATA/5pin) (for factory cal) */
    case SDR_SYNC_SOURCE_PREV_PPS_MOD: /* internal Clock, PPS from modulated PREV (SATA)  */
#ifdef CONFIG_CPRI
    case SDR_SYNC_SOURCE_CPRI:  /* TBD !!! */
#endif
        break;
    }

    if (ss->state == SYNC_STATE_STARTING) {
        ss->warm_count = 3;
        ss->state = SYNC_STATE_WARMING;
        ss->abs_error = 0;
        goto done;
    }
    
    dt = pps_clock - ss->last_pps_clock;
    diff1 = dt - ss->tcxo_freq;
    /* keep cumulative error */
    ss->abs_error += diff1;

    
    if (ss->state == SYNC_STATE_WARMING) {
#ifdef DEBUG_PPS
        printk(KERN_INFO SDR_NAME " PPS state=%d warm_count=%d\n", ss->state, ss->warm_count);
#endif
        if (--ss->warm_count <= 0) {
            /* Starting: go into LARGE diff state and reset cumulative error */
            ss->state = SYNC_STATE_LARGE;
            ss->consecutive_large_errors = 0;
            ss->consecutive_small_errors = 0;
            ss->abs_error = 0;
        }
    } else {
        
#ifdef DEBUG_PPS
        printk(KERN_INFO SDR_NAME " PPS state=%d dt=%d diff1=%d integ=%d error=%d (thresh: %d/%d)\n",
               ss->state, pps_clock - ss->last_pps_clock, diff1, ss->integral, ss->abs_error,
               ss->tcxo_large_threshold, ss->tcxo_fine_threshold);
#endif

        if (ss->state == SYNC_STATE_LARGE) {
            /* Handle missed pulse in STATE_LARGE */
            if (abs(diff1) >= (ss->tcxo_freq / 2)) {
#ifdef DEBUG_PPS
                printk(KERN_INFO SDR_NAME  " PPS: missed Pulse\n");
#endif
                goto no_update;
            }
        } else {
            if (diff1 < - ss->tcxo_range_max) {
                /* early IRQ: problem in GPS module or FPGA */
#ifdef DEBUG_PPS
                printk(KERN_INFO SDR_NAME  " PPS: early Pulse\n");
#endif
                ss->abs_error -= ss->tcxo_freq;
                if (ss->abs_error > -ss->tcxo_freq * 5)
                    goto no_update;
                /* After 5 consecutive early pulse, go to LARGE_STATE */
                ss->state = SYNC_STATE_LARGE;                    
                ss->consecutive_large_errors = 0;
                ss->consecutive_small_errors = 0;
            }
            else
            if (diff1 > ss->tcxo_range_max) {
                /* late IRQ: problem in GPS module or FPGA */
#ifdef DEBUG_PPS
                printk(KERN_INFO SDR_NAME  " PPS: late Pulse\n");
#endif
                ss->abs_error += ss->tcxo_freq;
                if (ss->abs_error < ss->tcxo_freq * 5)
                    goto no_update;
                /* After 5 consecutive late pulse, go to LARGE_STATE */
                ss->state = SYNC_STATE_LARGE;                    
                ss->consecutive_large_errors = 0;
                ss->consecutive_small_errors = 0;
            }
        }

        diff = diff1;
        if (diff > ss->tcxo_range_max)
            diff = ss->tcxo_range_max;
        else if (diff < -ss->tcxo_range_max)
            diff = -ss->tcxo_range_max;

        if (ss->state == SYNC_STATE_LARGE) {
            if (abs(diff) <= ss->tcxo_fine_threshold) {
                ss->consecutive_small_errors++;
                if (ss->consecutive_small_errors >= 8) {
                    
                    ss->state = SYNC_STATE_FINE;
                    ss->consecutive_large_errors = 0;
                    ss->consecutive_small_errors = 0;
                    /* Init integral part */
                    ss->integral = 0;
                    ss->zero_corr = 0;
                    
#ifdef DEBUG_PPS
                    printk(KERN_INFO SDR_NAME " PPS: Large to Fine: (error=%d)\n", ss->abs_error);
#endif
                    /* Reset abs_error here to prevent drift */
                    ss->abs_error = 0;
                }
            } else {
                ss->consecutive_small_errors = 0;
            }
            
        } else {
            if (abs(diff) >= ss->tcxo_large_threshold) {
                /* large error: it can be a glitch, so we ignore a number of
                   consecutive large ones */
                ss->consecutive_large_errors++;
                if (ss->consecutive_large_errors >= 6) {
#ifdef DEBUG_PPS
                    printk(KERN_INFO SDR_NAME " PPS: Fine to Large\n");
#endif
                    ss->state = SYNC_STATE_LARGE;
                    ss->consecutive_large_errors = 0;
                    ss->consecutive_small_errors = 0;
                } else {
#ifdef DEBUG_PPS
                    printk(KERN_INFO SDR_NAME " PPS: glitch: no update\n");
#endif
                    goto no_update;
                }
            } else {
                ss->consecutive_large_errors = 0;
                
            }
        }
        /* adjust the current period depending on the error */
        val = sdr_readl(s, CSR_SYNCHRO_TCXO_WIDTH_ADDR);

        /* CPRI 10G boards can have a variety of VCXO, from 25 to 350 PPM */
        /* So guesstimate the actual PPM value from variations slope */
        if (s->has_si5324 && ss->has_CPRI_R05 == 0) {
            int acorr = abs(val - ss->last_width) << SYNC_COEF_SHIFT;
            int adiff = abs(diff - ss->last_diff);

            /* ignore first loop */
            if (ss->last_width == 0)
                acorr = adiff = 0;
            
            if (acorr != 0 && adiff != 0) {
                int slope = (acorr + (adiff >> 1)) / adiff;
#ifdef DEBUG_PPS
                printk(KERN_INFO SDR_NAME " PPS acorr=%d adiff=%d => slope=%d (last=%d)\n",
                       acorr, adiff, slope, ss->last_slope);
#endif
                /* reject aberrant values */
                if (slope > 0 && slope < (ss->retroaction_coef_R05 << 1)) {
                    if (ss->last_slope > (ss->retroaction_coef_R05 >> 1)
                        && slope > (ss->retroaction_coef_R05 >> 1)) {
                        /* Switch to R05 mode, stop testing */
                        ss->has_CPRI_R05 = 1;
                        ss->pwm_min = ss->pwm_min_R05;
                        ss->pwm_max = ss->pwm_max_R05;
                        ss->retroaction_coef = ss->retroaction_coef_R05;
                        ss->retroaction_coef_fine = ss->retroaction_coef_fine_R05;
                        ss->tcxo_range_max = ss->tcxo_range_max_R05;
                        printk(KERN_INFO SDR_NAME " CPRI R05 detected\n");
                    }
                    else
                    if (ss->last_slope != 0
                        && ss->last_slope < (ss->retroaction_coef << 1)
                        && slope < (ss->retroaction_coef << 1)) {
                        /* stay in R04 mode, stop testing */
                        ss->has_CPRI_R05 = -1;
                        printk(KERN_INFO SDR_NAME " CPRI R04 detected\n");
                    }
                    ss->last_slope = slope;
                }
            }
            ss->last_width = val;
            ss->last_diff = diff;
        }

        /* round abs_error to closest HyperFrame */
        new_error = ss->abs_error;
        if (new_error <= - hfr_clk)
            new_error = - ((-new_error) % hfr_clk);
        else
        if (new_error >= hfr_clk) {
            new_error = (new_error % hfr_clk);
        }
        if (new_error <= -hfr_clk/2)
            new_error += hfr_clk;
        else
        if (new_error >= hfr_clk/2)
            new_error -= hfr_clk;
#ifdef DEBUG_PPS
        if (new_error != ss->abs_error)
            printk(KERN_INFO SDR_NAME " after correction (hfr=%d): error=%d\n",
                   hfr_clk, new_error);
#endif
        ss->abs_error = new_error;
        
        corr = 0;
        if (ss->state == SYNC_STATE_LARGE) {
            /* large error: strong correction */
            coef = ss->retroaction_coef;
            prod = diff * coef;
            if (prod > 0) {
                if (ss->abs_error < 0)
                    prod /= 2;
                corr = -((prod + (1 << (SYNC_COEF_SHIFT-1))) >> SYNC_COEF_SHIFT);
            } else
            if (prod < 0) {
                if (ss->abs_error > 0)
                    prod /= 2;
                corr = ((-prod + (1 << (SYNC_COEF_SHIFT-1))) >> SYNC_COEF_SHIFT);
            }
        }
        else {
            int extra = 0;

            if (ss->zero_corr >= 8) {
                /* Add correction to reduce cumulative abs_error */
                if (ss->abs_error >= ss->error_threshold)
                    extra = 1 << (SYNC_COEF_SHIFT-1);
                else if (ss->abs_error >= ss->error_threshold / 2)
                    extra = 1 << (SYNC_COEF_SHIFT-2);
                else if (ss->abs_error >= ss->error_threshold / 4)
                    extra = 1 << (SYNC_COEF_SHIFT-3);
                else if (ss->abs_error <= -ss->error_threshold)
                    extra = - (1 << (SYNC_COEF_SHIFT-1));
                else if (ss->abs_error <= -(ss->error_threshold / 2))
                    extra = - (1 << (SYNC_COEF_SHIFT-2));
                else if (ss->abs_error <= -(ss->error_threshold / 4))
                    extra = - (1 << (SYNC_COEF_SHIFT-3));

                if (extra) {
                    ss->integral += extra;
                }
            }
            
            /* Measured jitter from GPS pulse is about 20ns (0.02 us) (1us = 1PPM) */
            /* At 122,88MHz, one clock tick is ~ 8 ns */
            /* So integrate over several seconds to reach better accuracy */
            coef = ss->retroaction_coef_fine;
#define PPS_INT_SHIFT 3
#define PPS_INT_N (1 << PPS_INT_SHIFT)
            prod = (diff * coef) + (ss->integral * (PPS_INT_N - 1));
            if (prod > 0) {
                prod = (prod + (PPS_INT_N / 2)) / PPS_INT_N;
            }
            else {
                prod = -((-prod + (PPS_INT_N / 2)) / PPS_INT_N);
            }
            ss->integral = prod;

            /* Prevent going in the wrong direction relative to cumulative abs_error */
            if (prod > 0 && ss->abs_error > 0) {
                corr = -((prod + (1 << (SYNC_COEF_SHIFT-1))) >> SYNC_COEF_SHIFT);
            }
            else
            if (prod < 0 && ss->abs_error < 0) {
                corr = ((-prod + (1 << (SYNC_COEF_SHIFT-1))) >> SYNC_COEF_SHIFT);
            }

            if (corr == 0) {
                ss->zero_corr++;
            }
        }
        if (corr != 0) {
            int max_corr = ss->tcxo_pwm_period / 16;
            ss->zero_corr = 0;

            if (corr < -max_corr) {
                corr = -max_corr;
            } else
            if (corr > max_corr) {
                corr = max_corr;
            }
                
            val += corr;
            if (val < ss->pwm_min)
                val = ss->pwm_min;
            else if (val > ss->pwm_max)
                val = ss->pwm_max;
            sdr_writel(s, CSR_SYNCHRO_TCXO_ENABLE_ADDR, 0);
            sdr_writel(s, CSR_SYNCHRO_TCXO_WIDTH_ADDR, val);
            sdr_writel(s, CSR_SYNCHRO_TCXO_ENABLE_ADDR, 1);
        }
#ifdef DEBUG_PPS
        printk(KERN_INFO SDR_NAME " PPS: => corr=%d tcxo_width=%d (%d/%d) (integ=%d coef=%d zc=%d) error=%d\n",
               corr, val, ss->pwm_min, ss->pwm_max, ss->integral, coef, ss->zero_corr, ss->abs_error);
#endif
    no_update: ;

        if (s->sysid == SYSID_CPRI_40G) {
            int gps_ctrl = 0;
            if (ss->sync_source == SDR_SYNC_SOURCE_GPS) {
                gps_ctrl = GPS_CONTROL_LED_RED;
                if (dt < (ss->tcxo_freq * 2)) {
                    gps_ctrl = GPS_CONTROL_LED_GREEN;
                    
                    if (ss->state != SYNC_STATE_FINE ||
                        ss->abs_error > (ss->tcxo_fine_threshold * 2)) {
                        gps_ctrl = GPS_CONTROL_LED_GREEN | GPS_CONTROL_LED_RED;
                    }
                    if (sdr_readl(s, CSR_IDENTIFIER_REVISION_ADDR) >= MK_ID_REVISION(2023, 1, 16) &&
                        (sdr_readl(s, CSR_GPS_STATUS_ADDR) & GPS_PPS_ACTIVE) == 0) {
                        gps_ctrl = GPS_CONTROL_LED_RED;
                    }
                }
            }
            sdr_writel(s, CSR_GPS_CONTROL_ADDR, gps_ctrl);  
        }
    }
 done:
    ss->last_pps_clock = pps_clock;
}

static int sdr_spi_check(SDRState *s, int spi_type)
{
    switch (spi_type) {
    case SDR_SPI_TYPE_AD9361:
        if (s->has_ad9361)
            return 0;
        break;
    case SDR_SPI_TYPE_AD9528:
        if (s->has_ad9528)
            return 0;
        break;
    case SDR_SPI_TYPE_AD937x:
        if (s->has_ad937x)
            return 0;
        break;
    default:
        printk(KERN_INFO SDR_NAME " unknown spi %d\n", spi_type);
        return -EINVAL;
    }
    printk(KERN_INFO SDR_NAME " device has no spi %d\n", spi_type);
    return -EINVAL;
}

static int ad9528_master_minor(SDRState *s, int minor) {
    switch(s->sysid) {
    case SYSID_RF_5G:
    case SYSID_RF_5G_V2:
        minor = (minor >> 1) << 1;
    default:
        break;
    }
    return minor;
}

static int sdr_spi_read(SDRState *s, struct sdr_ioctl_spi_rw *m)
{
    int ret = sdr_spi_check(s, m->spi_type);
    if (ret < 0)
        return ret;

    switch (m->spi_type) {
    case SDR_SPI_TYPE_AD9361:
        m->val = sdr_ad9361_read(s, m->addr);
        break;
    case SDR_SPI_TYPE_AD9528:
        /* one ad9528 for master/slave, access is done through master */
        s = sdr_minor_table[ad9528_master_minor(s, s->minor)];
        if (!s)
            return -ENODEV;
        if (sdr_ad9528_read(s, m->addr, &m->val) < 0)
            ret = -EINVAL;
        break;
    case SDR_SPI_TYPE_AD937x:
        m->val = sdr_ad937x_read(s, m->addr);
        break;
    default:
        ret = -EINVAL;
        break;
    }
    return ret;
}

static int sdr_spi_write(SDRState *s, struct sdr_ioctl_spi_rw *m)
{
    int ret = sdr_spi_check(s, m->spi_type);
    if (ret < 0)
        return ret;

    switch (m->spi_type) {
    case SDR_SPI_TYPE_AD9361:
        sdr_ad9361_write(s, m->addr, m->val);
        break;
    case SDR_SPI_TYPE_AD9528:
        /* one ad9528 for master/slave, access is done through master */
        s = sdr_minor_table[ad9528_master_minor(s, s->minor)];
        if (!s)
            return -ENODEV;
        if (sdr_ad9528_write(s, m->addr, m->val) < 0)
            ret = -EINVAL;
        break;
    case SDR_SPI_TYPE_AD937x:
        sdr_ad937x_write(s, m->addr, m->val);
        break;
    default:
        ret = -EINVAL;
        break;
    }
    return ret;
}

static int sdr_spi_reset(SDRState *s, int spi_type)
{
    int ret = sdr_spi_check(s, spi_type);
    int addr;

    if (ret < 0)
        return ret;

    /* MBU: separate reset of AD9528 clock chip and AD9371 RF chip */
    /* Also use sequence proposed by AD, with 1ms delays */
    switch (spi_type) {
    case SDR_SPI_TYPE_AD937x:
        addr = s->ad937x_base + CSR_AD937X_CONFIG_ADDR_REL;
        sdr_writel(s, addr, 1*AD937X_CONFIG_AD937X_RST_N | 1*AD937X_CONFIG_AD9528_RST_N);
	udelay(1000);
        sdr_writel(s, addr, 0*AD937X_CONFIG_AD937X_RST_N | 1*AD937X_CONFIG_AD9528_RST_N);
	udelay(1000);
        sdr_writel(s, addr, 1*AD937X_CONFIG_AD937X_RST_N | 1*AD937X_CONFIG_AD9528_RST_N);
	udelay(1000);
        break;
    case SDR_SPI_TYPE_AD9528:
        addr = CSR_AD937X0_BASE + CSR_AD937X_CONFIG_ADDR_REL;
        s = sdr_minor_table[ad9528_master_minor(s, s->minor)];
        sdr_writel(s, addr, 1*AD937X_CONFIG_AD937X_RST_N | 1*AD937X_CONFIG_AD9528_RST_N);
	udelay(1000);
        sdr_writel(s, addr, 1*AD937X_CONFIG_AD937X_RST_N | 0*AD937X_CONFIG_AD9528_RST_N);
	udelay(1000);
        sdr_writel(s, addr, 1*AD937X_CONFIG_AD937X_RST_N | 1*AD937X_CONFIG_AD9528_RST_N);
	udelay(1000);
        break;
    case SDR_SPI_TYPE_AD9361:
    default:
        /* XXX ? */
        ret = -EINVAL;
        break;
    }
    return ret;
}

static int sdr_ad9371_set_sysref(SDRState *s, int state)
{
    uint8_t reg501, mask;
    SDRState *s0;

    s0 = sdr_minor_table[ad9528_master_minor(s, s->minor)];
    if (!s0)
        return -ENODEV;

    /* Not for FMC */
    if (s->board_rev == -1)
        return 0;
    
    sdr_ad9528_read(s0, AD9528_ADDR_OUT_POWERDOWN0, &reg501);
    if (s->is_master)
        mask = 0x10; // 0x10 /* Output 4 */
    else
        mask = 0x80; // 0x80 /* Output 7 */
    
    if (state)
        reg501 &= ~mask;
    else
        reg501 |= mask;
    sdr_ad9528_write(s0, AD9528_ADDR_OUT_POWERDOWN0, reg501);
    /* Update regs */
    sdr_ad9528_write(s0, AD9528_ADDR_IO_UPDATE, 0x01);

    return 0;
}

/* For ARM architecture, need to explicitly clean / flush cache for DMA */
/* mode = 0: RX; 1: TX */
static int sdr_dma_sync(SDRState *s, struct sdr_ioctl_sync_dma_buf *sd)
{
    SDRDMAChannel *dc;
    int buffer_size;

    if (sd->dma_channel >= s->dma_channel_count)
        return -EINVAL;
    
    /* DMA channel 0 for now */
    dc = &s->dma_channels[sd->dma_channel];

    if (sd->buf_num < 0 || sd->buf_num >= DMA_BUFFER_COUNT)
        return -EINVAL;
    if (sd->buf_prev < 0 || sd->buf_prev >= DMA_BUFFER_COUNT)
        return -EINVAL;
        
    if (sd->mode) {  /* TX */
        /* Use buffer_size specified in dma_start and align on 32 bytes */
        buffer_size = (dc->dma_tx_buf_size + 0x1F) & ~0x1F;
        dma_sync_single_for_cpu(&s->dev->dev, dc->dma_tx_bufs_addr[sd->buf_num],
                                    buffer_size, DMA_TO_DEVICE);
        dma_sync_single_for_device(&s->dev->dev, dc->dma_tx_bufs_addr[sd->buf_prev],
                                       buffer_size, DMA_TO_DEVICE);
    }
    else {   /* RX */
        /* Use buffer_size specified in dma_start and align on 32 bytes */
        buffer_size = (dc->dma_rx_buf_size + 0x1F) & ~0x1F;
        /* RX: set current buffer to CPU and return previous one to Device */
        dma_sync_single_for_cpu(&s->dev->dev, dc->dma_rx_bufs_addr[sd->buf_num],
                                    buffer_size, DMA_FROM_DEVICE);
        dma_sync_single_for_device(&s->dev->dev, dc->dma_rx_bufs_addr[sd->buf_prev],
                                       buffer_size, DMA_FROM_DEVICE);
    }
    return 0;
}

static int sdr_dma_cpri_speed(SDRState *s, struct sdr_ioctl_cpri_speed *sd)
{
    SDRDMAChannel *dc;
    int i;

    if (sd->dma_channel >= s->dma_channel_count)
        return -EINVAL;

    switch(s->sysid) {
    default:
        break;
    case SYSID_CPRI_10G:
        /* max speed mult: 16 */
        if (sd->speed_mult > 16)
            return -EINVAL;

        /* DMA channels 2 and 3 are speed limited */
        if (sd->dma_channel >= 2 && sd->speed_mult > 8)
            return -EINVAL;

        if (sd->speed_mult != 0) {
            /* Check other channels for identical speed */
            for (i = 0; i < s->dma_channel_count; i++) {
                dc = &s->dma_channels[i];
                if (dc->cpri_speed_mult && dc->cpri_speed_mult != sd->speed_mult) {
                    /* If PLL already set on different speed, return EBUSY */
                    return -EBUSY;
                }
            }
        }
        break;
    case SYSID_CPRI_40G:
        if ((s->fpga_caps >> CSR_IDENTIFIER_CAPABILITIES_CODING_OFFSET)
            & IDENTIFIER_CAPABILITIES_CODING_64B66B) {
            /* Only supports link rate 7a(x16), 8(x20), 9(x24) and 10(x48) */
            switch (sd->speed_mult) {
            case 16:
            case 20:
            case 24:
            case 48:
                break;
            default:
                return -EINVAL;
            }
        }
        else
        {
            /* Only supports link rate 1 to 7 (x1 to x16) */
            /* max speed mult: 16 */
            switch (sd->speed_mult) {
            case 1:
            case 2:
            case 4:
            case 5:
            case 8:
            case 10:
            case 16:
                break;
            default:
                return -EINVAL;
            }
        }
        break;
    }
    dc = &s->dma_channels[sd->dma_channel];
    dc->cpri_speed_mult = sd->speed_mult;
    
    return 0;
}

static long sdr_ioctl(struct file *file, unsigned int cmd,
                      unsigned long arg)
{
    SDRState *s = file->private_data;
    long ret;

    switch(cmd) {
    case SDR_IOCTL_GET_MMAP_INFO:
        {
            struct sdr_ioctl_mmap_info m;
            memset(&m, 0, sizeof(m));
            m.reg_offset = REG_MAP_OFFSET;
            m.reg_size = s->bar0_size;
            m.smem_offset = SHARED_MEM_OFFSET;
            m.smem_size = SHARED_MEM_BUFSIZE;
            m.dma_channel_count = s->dma_channel_count;
            m.numa_node = s->numa_node;
            m.bus_num = s->dev->bus->number;
#ifdef USE_DMA64
            m.dma_64 = s->dma_64;
#endif

            if (copy_to_user((void *)arg, &m, sizeof(m))) {
                ret = -EFAULT;
                break;
            }
            ret = 0;
        }
        break;
#ifdef USE_SHARED_MEM
    case SDR_IOCTL_GET_SYNC_MEM:
        {
            struct sdr_ioctl_sync_mem sa;
            dma_addr_t addr = s->shared_sync_mem_addr;
            sa.addr_lsb = ((addr >>  0) & 0xffffffff);
            sa.addr_msb = ((addr >>  32) & 0xffffffff);
            sa.size = s->shared_sync_mem_size;
                
            if (copy_to_user((void *)arg, &sa, sizeof(sa))) {
                ret = -EFAULT;
                break;
            }        
            ret = 0;
        }
        break;
#endif
    case SDR_IOCTL_GET_OLD_DMA_INFO:
        {
            struct sdr_ioctl_old_dma_info m;
        
            if (copy_from_user(&m, (void *)arg, sizeof(m))) {
                ret = -EFAULT;
                break;
            }
            if (m.dma_channel >= s->dma_channel_count) {
                ret = -EINVAL;
                break;
            }
            m.dma_tx_buf_offset = (2 * m.dma_channel) * s->dma_buffer_map_size;
            m.dma_tx_buf_size = s->dma_buffer_size;
            m.dma_tx_buf_count = DMA_BUFFER_COUNT;

            m.dma_rx_buf_offset = (2 * m.dma_channel + 1) * s->dma_buffer_map_size;
            m.dma_rx_buf_size = s->dma_buffer_size;
            m.dma_rx_buf_count = DMA_BUFFER_COUNT;

            m.dma_smem_offset = m.dma_channel * SHARED_MEM_SIZE;
            m.dma_smem_size = SHARED_MEM_SIZE;
            
            if (copy_to_user((void *)arg, &m, sizeof(m))) {
                ret = -EFAULT;
                break;
            }
            ret = 0;
        }
        break;
    case SDR_IOCTL_GET_DMA_INFO:
        {
            struct sdr_ioctl_dma_info m;
            SDRDMAChannel *dc;
        
            if (copy_from_user(&m, (void *)arg, sizeof(m))) {
                ret = -EFAULT;
                break;
            }
            if (m.dma_channel >= s->dma_channel_count) {
                ret = -EINVAL;
                break;
            }
            m.dma_tx_buf_offset = (2 * m.dma_channel) * s->dma_buffer_map_size;
            m.dma_tx_buf_size = s->dma_buffer_size;
            m.dma_tx_buf_count = DMA_BUFFER_COUNT;

            m.dma_rx_buf_offset = (2 * m.dma_channel + 1) * s->dma_buffer_map_size;
            m.dma_rx_buf_size = s->dma_buffer_size;
            m.dma_rx_buf_count = DMA_BUFFER_COUNT;

            m.dma_smem_offset = m.dma_channel * SHARED_MEM_SIZE;
            m.dma_smem_size = SHARED_MEM_SIZE;
            dc = &s->dma_channels[m.dma_channel];
            m.dma_base = dc->dma_base;
            
            if (copy_to_user((void *)arg, &m, sizeof(m))) {
                ret = -EFAULT;
                break;
            }
            ret = 0;
        }
        break;
    case SDR_IOCTL_DMA_START:
        {
            struct sdr_ioctl_dma_start m;

            if (copy_from_user(&m, (void *)arg, sizeof(m))) {
                ret = -EFAULT;
                break;
            }
            ret = sdr_dma_start(s, &m);
        }
        break;
    case SDR_IOCTL_DMA_STOP:
        {
            struct sdr_ioctl_dma_stop m;

            if (copy_from_user(&m, (void *)arg, sizeof(m))) {
                ret = -EFAULT;
                break;
            }
            ret = sdr_dma_stop(s, m.dma_channel);
        }
        break;
    case SDR_IOCTL_DMA_WAIT:
        {
            struct sdr_ioctl_dma_wait m;

            if (copy_from_user(&m, (void *)arg, sizeof(m))) {
                ret = -EFAULT;
                break;
            }
            ret = sdr_dma_wait(s, &m);
            if (ret == 0) {
                if (copy_to_user((void *)arg, &m, sizeof(m))) {
                    ret = -EFAULT;
                    break;
                }
            }
        }
        break;
    case SDR_IOCTL_GET_DMA_CH_CNT:
        {
            struct sdr_ioctl_dma_ch_cnt m;
            
            m.dma_channel_count = s->dma_channel_count;
            if (copy_to_user((void *)arg, &m, sizeof(m))) {
                ret = -EFAULT;
                break;
            }
            ret = 0;
        }
        break;
    case SDR_IOCTL_BOARD_RW:
        {
            struct sdr_ioctl_board_rw m;

            ret = 0;
            if (copy_from_user(&m, (void *)arg, sizeof(m))) {
                ret = -EFAULT;
                break;
            }
            if (m.is_write) {
                sdr_writel(s, m.addr, m.val);
            } else {
                m.val = sdr_readl(s, m.addr);
            }
            if (copy_to_user((void *)arg, &m, sizeof(m))) {
                ret = -EFAULT;
                break;
            }
        }
        break;
    case SDR_IOCTL_SPI_RW:
        {
            struct sdr_ioctl_spi_rw m;

            if (copy_from_user(&m, (void *)arg, sizeof(m))) {
                ret = -EFAULT;
                break;
            }
            if (m.is_write) {
                ret = sdr_spi_write(s, &m);
            } else {
                ret = sdr_spi_read(s, &m);
            }
            if (ret == 0) {
                if (copy_to_user((void *)arg, &m, sizeof(m))) {
                    ret = -EFAULT;
                    break;
                }
            }
        }
        break;
    case SDR_IOCTL_SPI_RESET:
        {
            int type;

            if (get_user(type, (int *)arg)) {
                ret = -EFAULT;
                break;
            }
            ret = sdr_spi_reset(s, type);
        }
        break;
    case SDR_IOCTL_FLASH_SPI:
        {
            struct sdr_ioctl_flash_spi m;

            if (copy_from_user(&m, (void *)arg, sizeof(m))) {
                ret = -EFAULT;
                break;
            }
            ret = sdr_flash_spi(s, &m);
            if (ret == 0) {
                if (copy_to_user((void *)arg, &m, sizeof(m))) {
                    ret = -EFAULT;
                    break;
                }
            }
        }
        break;
    case SDR_IOCTL_FLASH_PAGE_PROGRAM:
        {
            struct sdr_ioctl_flash_page_program pm;   /* 4Byte adress + 256 byte data */

            if (copy_from_user(&pm, (void *)arg, sizeof(pm))) {
                ret = -EFAULT;
                break;
            }
            ret = sdr_flash_page_program(s, &pm);
        }
        break;
    case SDR_IOCTL_FLASH_PAGE_READ:
        {
            struct sdr_ioctl_flash_page_read pm;   /* 4Byte adress + 256 byte data */

            if (copy_from_user(&pm, (void *)arg, sizeof(pm))) {
                ret = -EFAULT;
                break;
            }
            ret = sdr_flash_page_read(s, &pm);
            if (ret == 0) {
                if (copy_to_user((void *)arg, &pm, sizeof(pm))) {
                    ret = -EFAULT;
                    break;
                }
            }
        }
        break;
    case SDR_IOCTL_GPS_WRITE:
        {
            struct sdr_ioctl_gps_write m;

            if (copy_from_user(&m, (void *)arg, sizeof(m))) {
                ret = -EFAULT;
                break;
            }
            ret = sdr_gps_write(s, (uint8_t *)(uintptr_t)m.tx_buf,
                                m.tx_buf_len);
        }
        break;
    case SDR_IOCTL_GPS_RX_ENABLE:
        {
            int val;

            if (get_user(val, (int *)arg)) {
                ret = -EFAULT;
                break;
            }
            sdr_gps_rx_enable(s, val);
            ret = 0;
        }
        break;
    case SDR_IOCTL_GPS_READ:
        {
            struct sdr_ioctl_gps_read m;
            struct sdr_ioctl_gps_read * m_user;

            m_user = (void *)arg;
            if (copy_from_user(&m, (void *)arg, sizeof(m))) {
                ret = -EFAULT;
                break;
            }
            ret = sdr_gps_read(s, (uint8_t *)(uintptr_t)m.rx_buf,
                               m.rx_buf_max_len);
            if (ret < 0)
                break;
            put_user(ret, &(m_user->rx_buf_len));
            ret = 0;
        }
        break;
    case SDR_IOCTL_SET_SYNC_SOURCE:
        ret = sdr_clock_set_sync_source(s, (long)arg);
        break;
    case SDR_IOCTL_GET_SYNC_STATE:
        {
            struct sdr_ioctl_sync_state m;

            sdr_clock_get_sync_state(s, &m);
            if (copy_to_user((void *)arg, &m, sizeof(m))) {
                ret = -EFAULT;
                break;
            }
            ret = 0;
        }
        break;
    case SDR_IOCTL_AD9371_SET_SYSREF:
        {
            int state;

            if (get_user(state, (int *)arg)) {
                ret = -EFAULT;
                break;
            }
            if (s->has_ad9528) {
                sdr_ad9371_set_sysref(s, state);
                ret = 0;
            }
            else
                ret = -EINVAL;
        }
        break;
    case SDR_IOCTL_SET_CPRI_SLAVE:
        ret = sdr_set_cpri_slave(s, (long)arg);
        break;
    case SDR_IOCTL_GET_CPRI_SLAVE:
        {
            int m = sdr_get_cpri_slave(s);
            if (copy_to_user((void *)arg, &m, sizeof(m))) {
                ret = -EFAULT;
                break;
            }
            ret = 0;
        }
        break;
    case SDR_IOCTL_RESERVE_DMA_CH:
        {
            int ch = (int)arg;

            if (ch < 0 || ch > s->dma_channel_count)
                ret = -EINVAL;
            else
            if (s->reserved_channels[ch]) {
                ret = -EBUSY;
            }
            else {
                s->reserved_channels[ch] = 1;
                s->reserved_files[ch] = file;
                ret = 0;
            }
        }
        break;
    case SDR_IOCTL_RELEASE_DMA_CH:
        {
            int ch = (int)arg;
            
            if (ch < 0 || ch > s->dma_channel_count)
                ret = -EINVAL;
            else {
                s->reserved_channels[ch] = 0;
                s->reserved_files[ch] = NULL;
                ret = 0;
            }
        }
        break;
    case SDR_IOCTL_SYNC_DMA_BUF:
        {
            struct sdr_ioctl_sync_dma_buf sd;
            if (copy_from_user(&sd, (void *)arg, sizeof(sd))) {
                ret = -EFAULT;
                break;
            }
            ret = sdr_dma_sync(s, &sd);
        }
        break;
    case SDR_IOCTL_SET_CPRI_SPEED:
        {
            struct sdr_ioctl_cpri_speed sd;
            if (copy_from_user(&sd, (void *)arg, sizeof(sd))) {
                ret = -EFAULT;
                break;
            }
            ret = sdr_dma_cpri_speed(s, &sd);
        }
        break;
    case SDR_IOCTL_GET_STATUS:
        {
            struct sdr_ioctl_status ss;

            ss.sysid = s->sysid;
            ss.rev = s->board_rev;
            ss.ad937x_base = s->ad937x_base;
            ss.flags = 0;
            if (s->has_ad9361)
                ss.flags |= SDR_STATUS_AD9361;
            if (s->has_ad937x)
                ss.flags |= SDR_STATUS_AD9371;
            if (s->has_ad9528)
                ss.flags |= SDR_STATUS_AD9528;
            if (s->has_cdcm6208)
                ss.flags |= SDR_STATUS_CDCM6208;
            if (s->has_si5324)
                ss.flags |= SDR_STATUS_SI5324;
            if (s->has_cpri)
                ss.flags |= SDR_STATUS_CPRI;
            if (s->is_master)
                ss.flags |= SDR_STATUS_MASTER;

            if (sdr_readl(s, CSR_FLASH_SPI_STATUS_ADDR) & FLASH_SPI_STATUS_ALIGNED_MODE)
                ss.flags |= SDR_STATUS_FLASH_4BYTES;

            if ((s->fpga_caps >> CSR_IDENTIFIER_CAPABILITIES_PACKING_OFFSET)
                & IDENTIFIER_CAPABILITIES_PACKING_FP8)
                ss.flags |= SDR_STATUS_FP8;
            if ((s->fpga_caps >> CSR_IDENTIFIER_CAPABILITIES_PACKING_OFFSET)
                & IDENTIFIER_CAPABILITIES_PACKING_BF2)
                ss.flags |= SDR_STATUS_BF2;
            
            if ((s->fpga_caps >> CSR_IDENTIFIER_CAPABILITIES_DMA_HEADER_OFFSET)
                & IDENTIFIER_CAPABILITIES_DMA_HEADER_TX_RX) {
            
                int version;

                ss.flags |= SDR_STATUS_DMA_RX_HEADER;
                
                version = (s->fpga_caps >> CSR_IDENTIFIER_CAPABILITIES_DMA_HEADER_VERSION_OFFSET);
                version &= 0xFF >> (8 - CSR_IDENTIFIER_CAPABILITIES_DMA_HEADER_VERSION_SIZE);

                switch(version) {
                case 0:
                default:
                    break;
                case 1:
                    ss.flags |= SDR_STATUS_DMA_HEADER_V2;
                    break;
                }
            }
            if ((s->fpga_caps >> CSR_IDENTIFIER_CAPABILITIES_CODING_OFFSET)
                & IDENTIFIER_CAPABILITIES_CODING_64B66B) {
                ss.flags |= SDR_STATUS_CPRI_64B66B;
            }
            
            switch ((s->fpga_caps >> CSR_IDENTIFIER_CAPABILITIES_JESD_LANES) & 0x07) {
            case 2:
                ss.flags |= SDR_STATUS_JESD_2LANES;
                break;
            case 4: 
                ss.flags |= SDR_STATUS_JESD_4LANES;
                break;
            default:
                break;
            }
            
            /* These are "live" flags, not capabilities */
            if (s->sysid == SYSID_RF_5G_V2) {
                SDRState *sl, *sm;
                SDRDMAChannel *sldc, *smdc;
                
                if (s->is_master) {
                    sm = s;
                    if (s->minor >= SDR_MINOR_COUNT-1) {
                        ret = -EBADF;
                        break;
                    }
                    sl = sdr_minor_table[s->minor+1];
                    if (!sl) {
                        ret = -EBADF;
                        break;
                    }
                }
                else {
                    sl = s;
                    if (s->minor < 1) {
                        ret = -EBADF;
                        break;
                    }
                    sm = sdr_minor_table[s->minor-1];
                    if (!sm) {
                        ret = -EBADF;
                        break;
                    }
                }
                smdc = &sm->dma_channels[0];
                sldc = &sl->dma_channels[0];
                if (smdc->tx_dma_started || smdc->rx_dma_started)
                    ss.flags |= SDR_STATUS_V2_MASTER_DMA;
                if (sldc->tx_dma_started || sldc->rx_dma_started)
                    ss.flags |= SDR_STATUS_V2_SLAVE_DMA;
            }
            if (copy_to_user((void *)arg, &ss, sizeof(ss))) {
                ret = -EFAULT;
                break;
            }
            ret = 0;
        }
        break;
    case SDR_IOCTL_SET_PLL:
        {
            struct sdr_ioctl_pll sp;
            SDRSyncState *ss = &s->sync_state;
            int prof;

            if (s->sysid != SYSID_RF_5G_V2) {
                ret = -EINVAL;
                break;
            }            
            if (copy_from_user(&sp, (void *)arg, sizeof(sp))) {
                ret = -EFAULT;
                break;
            }
            switch(ss->sync_source) {
            case SDR_SYNC_SOURCE_EXTERNAL_CLOCK:
            case SDR_SYNC_SOURCE_EXTERNAL_10MHZ:
                if (sp.mode == SMA_PLL_IDLE) {
                    sp.mode = SMA_PLL_IN;
                }
                break;
            default:
                if (sp.mode == SMA_PLL_IN) {
                    sp.mode = SMA_PLL_IDLE;
                }
                break;
            }
            prof = sdr_pll_mode_2_profile(sp.mode, sp.freq, sp.flags);
            if (prof < 0) {
                ret = -EINVAL;
                break;
            }
            s->sma_pll_mode = sp.mode;
            s->sma_pll_freq = sp.freq;
            s->sma_pll_flags = sp.flags;
            ret = sdr_cy22150_init(s, prof);
            break;
        }
    case SDR_IOCTL_GET_PLL:
        {
            struct sdr_ioctl_pll sp;
            
            if (s->sysid != SYSID_RF_5G_V2) {
                ret = -EINVAL;
                break;
            }
            sp.mode = s->sma_pll_mode;
            sp.freq = s->sma_pll_freq;
            sp.flags = s->sma_pll_flags;
            if (copy_to_user((void *)arg, &sp, sizeof(sp))) {
                ret = -EFAULT;
                break;
            }
            ret = 0;
            break;
        }
    case SDR_IOCTL_SET_SMA_PPS:
        {
            struct sdr_ioctl_sma_pps sp;
            
            if (s->sysid != SYSID_RF_5G_V2) {
                ret = -EINVAL;
                break;
            }
            if (copy_from_user(&sp, (void *)arg, sizeof(sp))) {
                ret = -EFAULT;
                break;
            }
            switch(sp.mode) {
            case SMA_PPS_IN:
                sdr_writel(s, CSR_SYNCHRO_PPS_EXT_TRISTATE_ADDR, SYNCHRO_PPS_EXT_DIRECTION_INPUT);
                break;
            case SMA_PPS_OUT:
                sdr_writel(s, CSR_SYNCHRO_PPS_EXT_TRISTATE_ADDR, SYNCHRO_PPS_EXT_DIRECTION_OUTPUT);
                break;
            default:
                return -EINVAL;
            }
            s->sma_pps_mode = sp.mode;
            s->sma_pps_flags = sp.flags;
            ret = 0;
            break;
        }
    case SDR_IOCTL_GET_SMA_PPS:
        {
            struct sdr_ioctl_sma_pps sp;
            
            if (s->sysid != SYSID_RF_5G_V2) {
                ret = -EINVAL;
                break;
            }
            sp.mode = s->sma_pps_mode;
            sp.flags = s->sma_pps_flags;
            if (copy_to_user((void *)arg, &sp, sizeof(sp))) {
                ret = -EFAULT;
                break;
            }
            ret = 0;
            break;
        }
    default:
        ret = -ENOIOCTLCMD;
        break;
    }
    return ret;
}

static const struct file_operations sdr_fops = {
    .owner = THIS_MODULE,
    .unlocked_ioctl = sdr_ioctl,
#ifdef CONFIG_COMPAT
    .compat_ioctl = sdr_ioctl,
#endif
    .open = sdr_open,
    .release = sdr_release,
    .mmap = sdr_mmap,
#if LINUX_VERSION_CODE < KERNEL_VERSION(6, 12, 0)
    .llseek = no_llseek,
#endif
};

typedef struct SDRDMABlock {
#ifdef USE_ALLOC_PAGES
    struct page *page;
#else
    uint8_t *ptr;
#endif
    struct SDRDMABlock *next;
    int size_log2;
} SDRDMABlock;


#ifdef USE_ALLOC_PAGES

static struct page * sdr_dma_page_alloc(SDRState *s, SDRDMABlock **pb, int size)
{
    struct page *page;
    SDRDMABlock *b;
    int size_log2;
    int gfp_flags;

    gfp_flags = GFP_KERNEL | GFP_DMA32;
#ifdef USE_DMA64
    if (s->dma_64)
        gfp_flags = GFP_KERNEL;
#endif
    /* size can be DMA_BUFFER_SIZE or SHARED_MEM_BUFSIZE */
    if (size == DMA_5_BUFFER_SIZE) {
        size_log2 = DMA_5_BUFFER_SIZE_LOG2;
    }
    else
    if (size == DMA_10_BUFFER_SIZE) {
        size_log2 = DMA_10_BUFFER_SIZE_LOG2;
    }
    else
    if (size == DMA_25_BUFFER_SIZE) {
        size_log2 = DMA_25_BUFFER_SIZE_LOG2;
    }
    else
    if (size == SHARED_MEM_BUFSIZE) {
        size_log2 = SHARED_MEM_BUFSIZE_LOG2;
    }
    else {
        printk(KERN_ERR SDR_NAME " sdr_dma_page_alloc: invalid size %x\n", size);
        return NULL;
    }

    for(;;) {
        page = alloc_pages_node(s->numa_node, gfp_flags, size_log2);
        if (! page)
            break;
#ifdef CONFIG_LOW_1MB_WORKAROUND
        /* Bug seen on Skylake based PC with Linux 3.19.0 : memory
           below 1MB are forced to uncached */
        if (page_to_phys(page) >= 0x100000)
            break;
#else
        break;
#endif
        /* add block in the free list */
        b = kmalloc(sizeof(SDRDMABlock), GFP_KERNEL);
        if (!b) {
            __free_pages(page, size_log2);            
            return NULL;
        }
        b->page = page;
        b->next = *pb;
        b->size_log2 = size_log2;
        *pb = b;            
    }
    
    if (page) {
        if (s->numa_node != NUMA_NO_NODE && page_to_nid(page) != s->numa_node
            && !s->numa_node_warn) {
            printk(KERN_INFO SDR_NAME "Allocate DMA buffer on node %d instead of %d\n", page_to_nid(page), s->numa_node);
            s->numa_node_warn = 1;
        }
    }
    return page;
}

#else  /* USE_ALLOC_PAGES */

static uint8_t *sdr_dma_alloc(SDRState *s, SDRDMABlock **pb, int size)
{
    uint8_t *ptr;
    SDRDMABlock *b;
    int size_log2;
    int gfp_flags;

    /* size can be DMA_BUFFER_SIZE or SHARED_MEM_BUFSIZE */
    if (size == DMA_5_BUFFER_SIZE) {
        size_log2 = DMA_5_BUFFER_SIZE_LOG2;
    }
    else
    if (size == DMA_10_BUFFER_SIZE) {
        size_log2 = DMA_10_BUFFER_SIZE_LOG2;
    }
    else
    if (size == DMA_25_BUFFER_SIZE) {
        size_log2 = DMA_25_BUFFER_SIZE_LOG2;
    }
    else
    if (size == SHARED_MEM_BUFSIZE) {
        size_log2 = SHARED_MEM_BUFSIZE_LOG2;
    }
    else {
        printk(KERN_ERR SDR_NAME " sdr_dma_alloc: invalid size %x\n", size);
        return NULL;
    }

    gfp_flags = GFP_KERNEL | GFP_DMA32;
#ifdef USE_DMA64
    if (s->dma_64)
        gfp_flags = GFP_KERNEL;
#endif
    
    for(;;) {
#ifdef USE_GETFREEPAGES
        ptr = (uint8_t*)__get_free_pages(gfp_flags, size_log2);
        if (!ptr)
            return NULL;
        memset((void*)ptr, 0, size);
#else
        ptr = kzalloc(size, gfp_flags);
        if (!ptr)
            return NULL;
#endif

#ifdef CONFIG_LOW_1MB_WORKAROUND
        /* Bug seen on Skylake based PC with Linux 3.19.0 : memory
           below 1MB are forced to uncached */
        if (__pa(ptr) >= 0x100000)
            break;
#else
        break;
#endif
        /* add block in the free list */
        b = kmalloc(sizeof(SDRDMABlock), GFP_KERNEL);
        if (!b) {
#ifdef USE_GETFREEPAGES
            free_pages((unsigned long)ptr, size_log2);
#else
            kfree(ptr);
#endif
            return NULL;
        }
        b->ptr = ptr;
        b->next = *pb;
        b->size_log2 = size_log2;
        *pb = b;
    }
    return ptr;
}
#endif

/* free the unused blocks */
static void sdr_dma_free_unused_blocks(SDRDMABlock *b)
{
    SDRDMABlock *b_next;

    while (b) {
        b_next = b->next;
#ifdef USE_ALLOC_PAGES
        printk(KERN_INFO SDR_NAME " freeing unused DMA page at 0x%llx\n",
               page_to_phys(b->page));
        __free_pages(b->page, b->size_log2);
#else

#if defined(__aarch64__)
        printk(KERN_INFO SDR_NAME " freeing unused DMA block at 0x%llx\n",
	   __pa(b->ptr));
#else
        printk(KERN_INFO SDR_NAME " freeing unused DMA block at 0x%08lx\n",
	   __pa(b->ptr));
#endif
#ifdef USE_GETFREEPAGES        
        free_pages((unsigned long)b->ptr, b->size_log2);
#else
        kfree(b->ptr);
#endif
#endif
        kfree(b);
        b = b_next;
    }
}


static int sdr_dma_channel_init(SDRState *s, SDRDMAChannel *dc,
                                SDRDMABlock **pdma_blocks)
{
    int i;

    /* allocate DMA buffers */
    for(i = 0; i < DMA_BUFFER_COUNT; i++) {
#ifdef USE_ALLOC_PAGES
        dc->dma_tx_pages[i] = sdr_dma_page_alloc(s, pdma_blocks, s->dma_buffer_size);
        if (!dc->dma_tx_pages[i]) {
            printk(KERN_ERR SDR_NAME " Failed to allocate dma_tx_page (i=%d)\n", i);
            /* should unmap and free all pages already alloced */
            return -ENOMEM;
        }
        dc->dma_tx_bufs_addr[i] = dma_map_page(&s->dev->dev, dc->dma_tx_pages[i],
                                                 0, s->dma_buffer_size,
                                                 DMA_TO_DEVICE);
#else
        dc->dma_tx_bufs[i] = sdr_dma_alloc(s, pdma_blocks, s->dma_buffer_size);
        if (!dc->dma_tx_bufs[i]) {
            printk(KERN_ERR SDR_NAME " Failed to allocate dma_tx_buf (i=%d)\n", i);
            return -ENOMEM;
        }
        dc->dma_tx_bufs_addr[i] = dma_map_single(&s->dev->dev, dc->dma_tx_bufs[i],
                                                 s->dma_buffer_size,
                                                 DMA_TO_DEVICE);
#endif
        if (dma_mapping_error(&s->dev->dev, dc->dma_tx_bufs_addr[i])) {
            printk(KERN_ERR SDR_NAME " Failed to map dma_tx_buf (i=%d)\n", i);
            return -ENOMEM;
        }
    }

    for(i = 0; i < DMA_BUFFER_COUNT; i++) {
#ifdef USE_ALLOC_PAGES
        dc->dma_rx_pages[i] = sdr_dma_page_alloc(s, pdma_blocks, s->dma_buffer_size);
        if (!dc->dma_rx_pages[i]) {
            printk(KERN_ERR SDR_NAME " Failed to allocate dma_rx_page (i=%d)\n", i);
            /* should unmap and free all pages already alloced */
            return -ENOMEM;
        }
        dc->dma_rx_bufs_addr[i] = dma_map_page(&s->dev->dev, dc->dma_rx_pages[i],
                                                 0, s->dma_buffer_size,
                                                 DMA_FROM_DEVICE);
#else
        dc->dma_rx_bufs[i] = sdr_dma_alloc(s, pdma_blocks, s->dma_buffer_size);
        if (!dc->dma_rx_bufs[i]) {
            printk(KERN_ERR SDR_NAME " Failed to allocate dma_rx_buf (i=%d=\n", i);
            return -ENOMEM;
        }
        dc->dma_rx_bufs_addr[i] = dma_map_single(&s->dev->dev, dc->dma_rx_bufs[i],
                                                 s->dma_buffer_size,
                                                 DMA_FROM_DEVICE);
#endif
        if (dma_mapping_error(&s->dev->dev, dc->dma_rx_bufs_addr[i])) {
            printk(KERN_ERR SDR_NAME " Failed to map dma_rx_buf (i=%d)\n", i);
            return -ENOMEM;
        }
    }
    init_waitqueue_head(&dc->dma_waitqueue);
    return 0;
}

static void sdr_dma_channel_free(SDRState *s, SDRDMAChannel *dc)
{
    int i;

    for(i = 0; i < DMA_BUFFER_COUNT; i++) {
#ifdef USE_ALLOC_PAGES
        if (dc->dma_tx_pages[i]) {
            dma_unmap_page(&s->dev->dev, dc->dma_tx_bufs_addr[i],
                             s->dma_buffer_size, DMA_TO_DEVICE);
            __free_pages(dc->dma_tx_pages[i], s->dma_buffer_size_log2);
            dc->dma_tx_pages[i] = NULL;
        }
#else
        if (dc->dma_tx_bufs_addr[i]) {
            dma_unmap_single(&s->dev->dev, dc->dma_tx_bufs_addr[i],
                             s->dma_buffer_size, DMA_TO_DEVICE);
        }
#ifdef USE_GETFREEPAGES
        free_pages((unsigned long)dc->dma_tx_bufs[i], s->dma_buffer_size_log2);
#else
        kfree(dc->dma_tx_bufs[i]);
#endif
#endif
    }

    for(i = 0; i < DMA_BUFFER_COUNT; i++) {
#ifdef USE_ALLOC_PAGES
        if (dc->dma_rx_pages[i]) {
            dma_unmap_page(&s->dev->dev, dc->dma_rx_bufs_addr[i],
                             s->dma_buffer_size, DMA_FROM_DEVICE);
            __free_pages(dc->dma_rx_pages[i], s->dma_buffer_size_log2);
            dc->dma_rx_pages[i] = NULL;
        }
#else
        if (dc->dma_rx_bufs_addr[i]) {
            dma_unmap_single(&s->dev->dev, dc->dma_rx_bufs_addr[i],
                             s->dma_buffer_size, DMA_FROM_DEVICE);
        }
#ifdef USE_GETFREEPAGES
        free_pages ((unsigned long)dc->dma_rx_bufs[i], s->dma_buffer_size_log2);
#else
        kfree(dc->dma_rx_bufs[i]);
#endif
#endif
    }
    
}

static int sdr_smem_init(SDRState *s, SDRDMABlock **pdma_blocks)
{
    uint8_t *ptr;
#ifdef USE_ALLOC_PAGES
    struct page *page;

    page = sdr_dma_page_alloc(s, pdma_blocks, SHARED_MEM_BUFSIZE);
    if (! page) {
        printk(KERN_ERR SDR_NAME " Failed to allocate smem\n");
        return -ENOMEM;
    }
    ptr = (uint8_t*)page_address(page);
    s->shared_mem = ptr;
    
    s->shared_page = page;
    /* Map a physical address for PCI DMA */
    s->shared_mem_addr = dma_map_page(&s->dev->dev, page,
                                      0L, SHARED_MEM_BUFSIZE,
                                      DMA_FROM_DEVICE);
#else
    ptr = sdr_dma_alloc(s, pdma_blocks, SHARED_MEM_BUFSIZE);
    if (! ptr) {
        printk(KERN_ERR SDR_NAME " Failed to allocate smem\n");
        return -ENOMEM;
    }
    s->shared_mem = ptr;
    /* Map a physical address for PCI DMA */
    s->shared_mem_addr = dma_map_single(&s->dev->dev, ptr,
                                        SHARED_MEM_BUFSIZE,
                                        DMA_FROM_DEVICE);
#endif


    if (! s->shared_mem_addr) {
        printk(KERN_ERR SDR_NAME " Failed to map smem\n");
        return -ENOMEM;
    }
    
#if defined(__arm__) || defined(__aarch64__)
    /* For ARM: give zone ownership to Device */
    dma_sync_single_for_device(&s->dev->dev, s->shared_mem_addr,
                                   SHARED_MEM_BUFSIZE, DMA_FROM_DEVICE);
#endif

#ifdef USE_SHARED_MEM
    {
        int ch;
        
        /* For each DMA channel (up to 4 for CPRI) */
        for (ch = 0; ch < s->dma_channel_count; ch++) {
            dma_addr_t addr;
            uint8_t *chptr;
            int i, csr_addr_lsb, csr_addr_msb, csr_control;
            
            addr = s->shared_mem_addr + (ch * SHARED_MEM_SIZE);
            chptr = s->shared_mem + (ch * SHARED_MEM_SIZE);
            /* Clear buffer magic to prevent false detection */
            *(int32_t*)chptr = 0x00;
            
            if (s->sysid == SYSID_RF_5G_V2 && !s->is_master) {
                /* USe DMA1 registers for Slave SDR100v2 */
                csr_addr_lsb = CSR_DMA1_STATUS_ADDRESS_LSB_ADDR;
                csr_addr_msb = CSR_DMA1_STATUS_ADDRESS_MSB_ADDR;
                csr_control = CSR_DMA1_STATUS_CONTROL_ADDR;
            }
            else {
                switch(ch) {
                default:
                case 0:
                    csr_addr_lsb = CSR_DMA0_STATUS_ADDRESS_LSB_ADDR;
                    csr_addr_msb = CSR_DMA0_STATUS_ADDRESS_MSB_ADDR;
                    csr_control = CSR_DMA0_STATUS_CONTROL_ADDR;
                    break;
                case 1:
                    csr_addr_lsb = CSR_DMA1_STATUS_ADDRESS_LSB_ADDR;
                    csr_addr_msb = CSR_DMA1_STATUS_ADDRESS_MSB_ADDR;
                    csr_control = CSR_DMA1_STATUS_CONTROL_ADDR;
                    break;
                case 2:
                    csr_addr_lsb = CSR_DMA2_STATUS_ADDRESS_LSB_ADDR;
                    csr_addr_msb = CSR_DMA2_STATUS_ADDRESS_MSB_ADDR;
                    csr_control = CSR_DMA2_STATUS_CONTROL_ADDR;
                    break;
                case 3:
                    csr_addr_lsb = CSR_DMA3_STATUS_ADDRESS_LSB_ADDR;
                    csr_addr_msb = CSR_DMA3_STATUS_ADDRESS_MSB_ADDR;
                    csr_control = CSR_DMA3_STATUS_CONTROL_ADDR;
                    break;
                }
            }
            /* Workaround for weird CPRI behaviour: loop */
            for (i = 0; i < 10; i++) {
                if (s->dma_64)
                    sdr_writel(s, csr_addr_msb, (addr >> 32) & 0xffffffff);
                sdr_writel(s, csr_addr_lsb, (addr >>  0) & 0xffffffff);
                /* Force first update for detection in libsdr */
                sdr_writel(s, csr_control, DMA_STATUS_ENABLE);
                sdr_writel(s, csr_control, DMA_STATUS_ENABLE | DMA_STATUS_UPDATE_MODE_SOFTWARE);
                msleep(5);
                if (*(int32_t*)chptr != 0)
                    break;
            }
            /* Do not use WRITER and READER ! they are not bits, just values in a 2 bit field */
            sdr_writel(s, csr_control, DMA_STATUS_ENABLE |
                       DMA_STATUS_UPDATE_MODE_DMA_WRITER_IRQ);
        }
        /* Set shared Sync mem after all channels DMA */
        s->shared_sync_mem_addr = s->shared_mem_addr + (SHARED_MEM_SIZE * DMA_CHANNEL_MAX);
        s->shared_sync_mem_size = SHARED_MEM_SYNC_SIZE;
        //printk("Shared Mem Physical Address      0x%016llx\n", s->shared_sync_mem_addr);
        
    }
#endif
    return 0;
}

static void sdr_smem_free(SDRState *s)
{
#ifdef USE_ALLOC_PAGES
    if (s->shared_mem_addr) {
        dma_unmap_page(&s->dev->dev, s->shared_mem_addr,
                       SHARED_MEM_BUFSIZE, DMA_FROM_DEVICE);
        __free_pages(s->shared_page, SHARED_MEM_BUFSIZE_LOG2);
        s->shared_mem_addr = 0;
    }
#else
    if (s->shared_mem_addr) {
        dma_unmap_single(&s->dev->dev, s->shared_mem_addr,
                         SHARED_MEM_BUFSIZE, DMA_FROM_DEVICE);
    }
#ifdef USE_GETFREEPAGES
    free_pages((unsigned long)s->shared_mem, SHARED_MEM_BUFSIZE_LOG2);
#else
    kfree(s->shared_mem);
#endif
#endif    
}

static __maybe_unused void dump_minors(char *title)
{
    int i;
    printk("Minor_tab (%s)\n", title);
    for (i = 0; i < SDR_MINOR_COUNT; i++) {
        if (sdr_minor_table[i] != NULL) {
            if (failed_minor_table[i] != 0)
                printk("  %d: SDR && FAILED\n", i);
            else
                printk("  %d: SDR\n", i);
        }
        else {
            if (failed_minor_table[i] != 0)
                printk("  %d: FAILED\n", i);
        }
    }
}

#define MINOR_TYPE_STD     0
#define MINOR_TYPE_MASTER  1
#define MINOR_TYPE_SLAVE   2

/* Returns -1 on error */
static int find_minor(int type)
{
    SDRState *s;
    int minor;

    for(minor = 0; minor < SDR_MINOR_COUNT; minor++) {
        /* Skip already assigned minors */
        if (sdr_minor_table[minor])
            continue;
        /* Skip Failed minors */
        if (failed_minor_table[minor])
            continue;
        /* For Standard boards, use first free minor */
        if (type == MINOR_TYPE_STD) {
            return minor;
        }
        /* Method to accomodate Master / Slave probing in any order */
        /* For Master, assign first free even minor if next is free or slave sdr */
        /* For Slave, assign first free odd minor if prev is free or master sdr */
        if (type == MINOR_TYPE_MASTER) {
            if ((minor & 1) != 0)
                continue;
            if (minor + 1 >= SDR_MINOR_COUNT)
                break;
            s = sdr_minor_table[minor+1];
            if (s == 0) {
                return minor;
            }
            if (s->has_ad937x && !s->is_master) {
                return minor;
            }
        }
        if (type == MINOR_TYPE_SLAVE) {
            if ((minor & 1) == 0)
                continue;
            s = sdr_minor_table[minor-1];
            if (s == 0) {
                return minor;
            }
            if (s->has_ad937x && s->is_master) {
                return minor;
            }
        }
    }
    return -1;
}

static int sdr_pci_probe(struct pci_dev *dev, const struct pci_device_id *id)
{
    SDRState *s = NULL;
    uint8_t rev_id;
    int ret, minor, i, dma;
    uint32_t sysid;
    SDRDMABlock *dma_blocks;
    char *BName;
    uint32_t fpga_rev, fpga_time;
    uint32_t fpga_caps;
    uint32_t freq;

    printk(KERN_INFO SDR_NAME " Probing device\n");

    /* find available minor */
    minor = find_minor(MINOR_TYPE_STD);
    if (minor < 0) {
        printk(KERN_ERR SDR_NAME " Cannot allocate a minor (max=%d)\n", SDR_MINOR_COUNT);
        ret = -ENODEV;
        goto fail1;
    }

    s = kzalloc(sizeof(SDRState), GFP_KERNEL);
    if (!s) {
        printk(KERN_ERR SDR_NAME " Cannot allocate memory\n");
        ret = -ENOMEM;
        goto fail1;
    }
    s->minor = minor;
    s->dev = dev;
    atomic_set(&s->open_count, 0);
    pci_set_drvdata(dev, s);

    ret = pci_enable_device(dev);
    if (ret != 0) {
        printk(KERN_ERR SDR_NAME " Cannot enable device\n");
        ret = -ENODEV;
        goto fail1;
    }

    /* check device version */
    pci_read_config_byte(dev, PCI_REVISION_ID, &rev_id);
    /* support rev ID 0 for CPRI40 prototype */
    if (rev_id != 1 && rev_id != 0) {
        printk(KERN_ERR SDR_NAME " Unsupported device version %d\n", rev_id);
        ret = -ENODEV;
        goto fail2;
    }

    if (pci_request_regions(dev, SDR_NAME) < 0) {
        printk(KERN_ERR SDR_NAME " Could not request regions\n");
        ret = -ENOMEM;
        goto fail2;
    }

    /* check BAR0 config */
    if (!(pci_resource_flags(dev, 0) & IORESOURCE_MEM)) {
        printk(KERN_ERR SDR_NAME " Invalid BAR0 config\n");
        ret = -ENOMEM;
        goto fail3;
    }

    s->bar0_size = pci_resource_len(dev, 0);
    s->bar0_phys_addr = pci_resource_start(dev, 0);
    s->bar0_addr = pci_ioremap_bar(dev, 0);
    if (!s->bar0_addr) {
        printk(KERN_ERR SDR_NAME " Could not map BAR0\n");
        ret = -ENOMEM;
        goto fail3;
    }

    pci_set_master(dev);

    /* soft reset */
    sdr_writel(s, CSR_CRG_SOFT_RST_ADDR, 1);
    udelay(1000);

    sysid = sdr_readl(s, CSR_IDENTIFIER_SYSID_ADDR);
    fpga_rev = sdr_readl(s, CSR_IDENTIFIER_REVISION_ADDR);
    fpga_time = sdr_readl(s, CSR_IDENTIFIER_REVISION_TIME_ADDR);
    if (fpga_time == sysid)  /* not supported by bitstream */
        fpga_time = 0;
    
    /* Default */
    s->max_open_count = 1;
    s->dma_channel_count = 1;
    s->has_cdcm6208 = 0;
    s->has_ad9361 = 0;
    s->has_ad9528 = 0;
    s->has_ad937x = 0;
    s->has_cpri = 0;
    s->has_si5324 = 0;
    s->is_master = 0;

    BName = "";

    s->board_rev = 0;  /* only on SDR5G so far */
    s->sysid = sysid;
#if 0
    printk(KERN_INFO SDR_NAME "sysid=0x%x master=0x%x rev=0x%x\n",
           sysid,
           sdr_readl(s, CSR_IDENTIFIER_BOARD_MASTER_ADDR),
           sdr_readl(s, CSR_IDENTIFIER_BOARD_REVISION_ADDR));
#endif
    switch(sysid) {
    case SYSID_RF_35T:
    case SYSID_RF_15T:
        s->has_cdcm6208 = 1;
        s->has_ad9361 = 1;
        s->system_clock_frequency = SYSTEM_CLOCK_FREQUENCY_RFIC;
        BName = "RF_SDR50";
        break;
    case SYSID_CPRI:
        s->has_cpri = 1;
        s->has_cdcm6208 = 1;
        s->dma_channel_count = 2;
        s->system_clock_frequency = SYSTEM_CLOCK_FREQUENCY_CPRI;
        BName = "CPRI";
        break;
    case SYSID_CPRI_10G:
        s->has_cpri = 1;
        s->has_si5324 = 1;
        s->dma_channel_count = 2;    /* default: only 2 SFP ports supported */
        s->system_clock_frequency = SYSTEM_CLOCK_FREQUENCY_CPRI;
        BName = "CPRI_10G";
        break;
    case SYSID_CPRI_40G:
        s->has_cpri = 1;
        s->has_ad9528 = 1;
        s->dma_channel_count = 4;
        s->system_clock_frequency = SYSTEM_CLOCK_FREQUENCY_CPRI_40G;
        BName = "CPRI_40G";
        break;
    case SYSID_ETH_10G:
        s->max_open_count = 1;
        s->has_si5324 = 1;
        s->dma_channel_count = 1;    /* default: only 1 SFP port supported */
        s->system_clock_frequency = SYSTEM_CLOCK_FREQUENCY_ETH;
        BName = "ETH_10G";
        break;
    case SYSID_RF_5G:
        s->has_ad9528 = 1;
        s->has_ad937x = 1;
        s->ad937x_base = CSR_AD937X0_BASE;
        s->dma_channel_count = 1;
        s->system_clock_frequency = SYSTEM_CLOCK_FREQUENCY_RFIC_5G;
        s->is_master = sdr_readl(s, CSR_IDENTIFIER_BOARD_MASTER_ADDR);
        s->board_rev = sdr_readl(s, CSR_IDENTIFIER_BOARD_REVISION_ADDR);

        /* Make sure RX_ENABLE is cleared to prevent RX amp oscillations */
        /* SDR100: Set TDD mode to force DTS to 0V */
        sdr_writel(s, CSR_AD937X0_BASE + CSR_AD937X_RF1_CONFIG_ADDR_REL,
                   AD937X_RF_CONFIG_RX_TX_ISOLATION | AD937X_RF_CONFIG_RX_TX_TDD);
        sdr_writel(s, CSR_AD937X0_BASE + CSR_AD937X_RF2_CONFIG_ADDR_REL,
                   AD937X_RF_CONFIG_RX_TX_ISOLATION | AD937X_RF_CONFIG_RX_TX_TDD);

        if (s->is_master)
            BName = "RF_SDR100_Master";
        else
            BName = "RF_SDR100_Slave";

        minor = find_minor(s->is_master ? MINOR_TYPE_MASTER : MINOR_TYPE_SLAVE);
        if (minor < 0) {
            printk(KERN_ERR SDR_NAME " Cannot allocate a minor\n");
            ret = -ENODEV;
            goto fail4;
        }
        if (s->is_master) {
            /* Check slave status */
            if (failed_minor_table[(minor | 1)]) {
                printk(KERN_ERR SDR_NAME " Slave was not initialized correctly\n");
                ret = -ENODEV;
                failed_minor_table[minor] = 1;
                goto fail4;
            }
        }
        else {
            /* Check master status */
            if (failed_minor_table[(minor & ~1)]) {
                printk(KERN_ERR SDR_NAME " Master was not initialized correctly\n");
                ret = -ENODEV;
                failed_minor_table[minor] = 1;
                goto fail4;
            }
        }
        break;
    case SYSID_RF_5G_V2:
        s->has_ad9528 = 1;
        s->has_ad937x = 1;
        s->ad937x_base = CSR_AD937X0_BASE;
        s->dma_channel_count = 1;
        s->system_clock_frequency = SYSTEM_CLOCK_FREQUENCY_RFIC_5G_V2;
        s->is_master = 1;
        s->board_rev = sdr_readl(s, CSR_IDENTIFIER_BOARD_REVISION_ADDR);

        /* Make sure RX_ENABLE is cleared to prevent RX amp oscillations */
        /* SDR100: Set TDD mode to force DTS to 0V */
        sdr_writel(s, CSR_AD937X0_BASE + CSR_AD937X_RF1_CONFIG_ADDR_REL,
                   AD937X_RF_CONFIG_RX_TX_ISOLATION | AD937X_RF_CONFIG_RX_TX_TDD);
        sdr_writel(s, CSR_AD937X0_BASE + CSR_AD937X_RF2_CONFIG_ADDR_REL,
                   AD937X_RF_CONFIG_RX_TX_ISOLATION | AD937X_RF_CONFIG_RX_TX_TDD);

        /* Also on second AD9371 */
        sdr_writel(s, CSR_AD937X1_BASE + CSR_AD937X_RF1_CONFIG_ADDR_REL,
                   AD937X_RF_CONFIG_RX_TX_ISOLATION | AD937X_RF_CONFIG_RX_TX_TDD);
        sdr_writel(s, CSR_AD937X1_BASE + CSR_AD937X_RF2_CONFIG_ADDR_REL,
                   AD937X_RF_CONFIG_RX_TX_ISOLATION | AD937X_RF_CONFIG_RX_TX_TDD);

        BName = "RF_SDR100V2";
        minor = find_minor(MINOR_TYPE_MASTER);
        break;
    case SYSID_RF_FMC_5G:    /* AnalogDevice FMC eval board */
        s->has_ad9528 = 1;
        s->has_ad937x = 1;
        s->dma_channel_count = 1;
        s->system_clock_frequency = SYSTEM_CLOCK_FREQUENCY_RFIC_5G;
        s->is_master = 1;
        s->board_rev = -1;

        BName = "AD9371_FMC";
        break;
        
    default:
        printk(KERN_ERR SDR_NAME " Unknown hardware ID=0x%x\n", sysid);
        if (sysid == 0xffffffff)
            printk(KERN_ERR SDR_NAME " Please reboot your system\n");
        ret = -ENODEV;
        goto fail4;
    }
    
    /* Read system clock register (starting 2024/02/26) */
    freq = sdr_readl(s, CSR_IDENTIFIER_SYS_CLK_FREQ_ADDR);
    if (freq != 0 && freq != 0xFFFF)
        s->system_clock_frequency = freq;
        
    /* Here minor is selected, set failed init until correct load */
    failed_minor_table[minor] = 1;
    
    /* Check new Capabilities register with number of DMA channels on 4 bits */
    fpga_caps = sdr_readl(s, CSR_IDENTIFIER_CAPABILITIES_ADDR);
    if (fpga_caps != 0xFFFF && fpga_caps != 0) {
        int nch = (fpga_caps >> CSR_IDENTIFIER_CAPABILITIES_NCHANNELS_OFFSET) & 0x0F;
        if (nch >= 1 && nch <= 4) {
            s->dma_channel_count = nch;
        }
        /* Check 64 bits mode (available after June 13th 2022) */
        if (fpga_rev >= MK_ID_REVISION(2022, 6, 13)) {
            if ((fpga_caps >> CSR_IDENTIFIER_CAPABILITIES_DMA64BIT_OFFSET) & 1) {
                /* If 64 bit is set, it means the FPGA need 64 bit DMA */
                s->dma_64 = 1;
            }
        }
        
    }
    else {
        /* Avoid 0xFFFF */
        fpga_caps = 0;
    }
    s->fpga_caps = fpga_caps;
    
    if (s->sysid == SYSID_RF_5G_V2) {
        /* Don't initialize DMA1 on master SDR100V2 */
        s->dma_channel_count = 1;
    }

    /* Allow one extra open to get information */
    s->max_open_count = s->dma_channel_count + 1;

    
#ifndef USE_ALLOC_PAGES
    if (s->dma_64) {
        printk(KERN_ERR SDR_NAME " DMA64 not supported: rebuild with USE_ALLOC_PAGES\n");
        ret = -ENODEV;
        goto fail4;
    }
#endif

    if (s->has_cpri) {
        for (i = 0; i < s->dma_channel_count; i++) {
            switch(i) {
            case 0:  
                sdr_writel(s, CSR_CPRI0_PHY_RST_ADDR, 0xf);
                break;
            case 1:
                sdr_writel(s, CSR_CPRI1_PHY_RST_ADDR, 0xf);
                break;
            case 2:
                sdr_writel(s, CSR_CPRI2_PHY_RST_ADDR, 0xf);
                break;
            case 3:
                sdr_writel(s, CSR_CPRI3_PHY_RST_ADDR, 0xf);
                break;
            default:
                break;
            }
        }
        /* Clear CPRI40 leds */
        if (sysid == SYSID_CPRI_40G) {
            sdr_writel(s, CSR_CPRI0_BASE + CSR_CPRI_PHY_CTRL_OFFSET, 0x0);
            sdr_writel(s, CSR_CPRI1_BASE + CSR_CPRI_PHY_CTRL_OFFSET, 0x0);
            sdr_writel(s, CSR_CPRI2_BASE + CSR_CPRI_PHY_CTRL_OFFSET, 0x0);
            sdr_writel(s, CSR_CPRI3_BASE + CSR_CPRI_PHY_CTRL_OFFSET, 0x0);
        }
    }
    
#ifdef USE_DMA64
    ret = dma_set_mask(&dev->dev, (s->dma_64)? DMA_BIT_MASK(64): DMA_BIT_MASK(32));
#else
    ret = dma_set_mask(&dev->dev, DMA_BIT_MASK(32));
#endif
    if (ret) {
        printk(KERN_ERR SDR_NAME " Failed to set DMA mask\n");
        ret = -ENOMEM;
        goto fail4;
    }

    ret = pci_enable_msi(dev);
    if (ret) {
        printk(KERN_ERR SDR_NAME " Failed to enable MSI\n");
        ret = -ENOMEM;
        goto fail4;
    }

    
    if (request_irq(dev->irq, sdr_interrupt, IRQF_SHARED, SDR_NAME, s) < 0) {
        printk(KERN_ERR SDR_NAME " Failed to allocate irq %d\n", dev->irq);
        ret = -ENOMEM;
        goto fail5;
    }

#if !defined(__arm__) && !defined(__aarch64__)
    s->numa_node = dev->dev.numa_node;
#endif

    /* Adjust DMA_BUFFER_SIZE depending on CPRI max speed */
    s->dma_buffer_size = DMA_10_BUFFER_SIZE;
    s->dma_buffer_size_log2 = DMA_10_BUFFER_SIZE_LOG2;
    s->dma_buffer_map_size = DMA_10_BUFFER_MAP_SIZE;

    if (s->has_ad9361) {
        /* SDR50: 5Gb/s max */
        s->dma_buffer_size = DMA_5_BUFFER_SIZE;
        s->dma_buffer_size_log2 = DMA_5_BUFFER_SIZE_LOG2;
        s->dma_buffer_map_size = DMA_5_BUFFER_MAP_SIZE;
    }
    else
    if ((s->fpga_caps >> CSR_IDENTIFIER_CAPABILITIES_CODING_OFFSET)
        & IDENTIFIER_CAPABILITIES_CODING_64B66B) {
        /* CPRI40 in 25Gb mode */
        s->dma_buffer_size = DMA_25_BUFFER_SIZE;
        s->dma_buffer_size_log2 = DMA_25_BUFFER_SIZE_LOG2;
        s->dma_buffer_map_size = DMA_25_BUFFER_MAP_SIZE;
    }
    
    dma_blocks = NULL;
    for(i = 0; i < s->dma_channel_count; i++) {
        SDRDMAChannel *dc = &s->dma_channels[i];
        if (i == 0) {
            dc->dma_base = CSR_DMA0_BASE;
            dc->dma_reader_interrupt = DMA0_READER_INTERRUPT;
            dc->dma_writer_interrupt = DMA0_WRITER_INTERRUPT;
        } else if (i == 1) {
            dc->dma_base = CSR_DMA1_BASE;
            dc->dma_reader_interrupt = DMA1_READER_INTERRUPT;
            dc->dma_writer_interrupt = DMA1_WRITER_INTERRUPT;
        } else if (i == 2) {
            dc->dma_base = CSR_DMA2_BASE;
            dc->dma_reader_interrupt = DMA2_READER_INTERRUPT;
            dc->dma_writer_interrupt = DMA2_WRITER_INTERRUPT;
        } else {
            dc->dma_base = CSR_DMA3_BASE;
            dc->dma_reader_interrupt = DMA3_READER_INTERRUPT;
            dc->dma_writer_interrupt = DMA3_WRITER_INTERRUPT;
        }
        if (sdr_dma_channel_init(s, dc, &dma_blocks) < 0) {
            sdr_dma_free_unused_blocks(dma_blocks);
            ret = -ENOMEM;
            goto fail6;
        }
    }

    sdr_dma_free_unused_blocks(dma_blocks);
    if (sdr_smem_init(s, &dma_blocks) < 0) {
        ret = -ENOMEM;
        goto fail7;
    }

    init_waitqueue_head(&s->flash_waitqueue);

    if (sdr_gps_init(s) < 0) {
        ret = -ENODEV;
        goto fail7;
    }

    sdr_enable_interrupt(s, FLASH_INTERRUPT);
    sdr_minor_table[minor] = s;
    s->minor = minor;

    /* For SDR100_V2, allocate a "ghost" device on next minor */
    if (s->sysid == SYSID_RF_5G_V2 && s->is_master) {
        SDRState *ss = kzalloc(sizeof(SDRState), GFP_KERNEL);
        SDRDMAChannel *dc;
        
        if (!ss) {
            printk(KERN_ERR SDR_NAME " Cannot allocate memory\n");
            ret = -ENOMEM;
            goto fail7;
        }
        memcpy(ss, s, sizeof(*ss));
        ss->minor = minor + 1;
        /* Same pci_dev */
        ss->is_master = 0;
        ss->ad937x_base = CSR_AD937X1_BASE;
        sdr_minor_table[ss->minor] = ss;

        /* Map hardware DMA1 as DMA on this device */
        dma_blocks = NULL;
        dc = &ss->dma_channels[0];
        dc->dma_base = CSR_DMA1_BASE;
        dc->dma_reader_interrupt = DMA1_READER_INTERRUPT;
        dc->dma_writer_interrupt = DMA1_WRITER_INTERRUPT;
        if (sdr_dma_channel_init(ss, dc, &dma_blocks) < 0) {
            sdr_dma_free_unused_blocks(dma_blocks);
            ret = -ENOMEM;
            goto fail6;
        }
        sdr_dma_free_unused_blocks(dma_blocks);
        if (sdr_smem_init(ss, &dma_blocks) < 0) {
            ret = -ENOMEM;
            goto fail7;
        }
        mutex_init(&ss->sdr_mutex);
        init_waitqueue_head(&ss->flash_waitqueue);        
        sdr_enable_interrupt(s, FLASH_INTERRUPT);
    }
    
    mutex_init(&s->sdr_mutex);
    spin_lock_init(&s->gps_lock);

    spi_flash_init(s);
    
    if (sdr_clock_init(s) < 0) {
#if 0
        ret = -ENODEV;
        goto fail7;
#endif
    }

#ifdef USE_DMA64
    dma = s->dma_64 ? 64: 32;
#else
    dma = 32;
#endif
    if (s->sysid == SYSID_RF_5G_V2) {
        printk(KERN_INFO SDR_NAME " PCI device %02x:%02x.%d assigned to minor %d/%d, type=%s (rev %d) numa=%d dma:%dch %db (%dMB) caps=0x%x\n",
               dev->bus->number, PCI_SLOT(dev->devfn), PCI_FUNC(dev->devfn),
               minor, minor+1, BName, s->board_rev, s->numa_node, s->dma_channel_count, dma, s->dma_buffer_map_size / (1024*1024),
               s->fpga_caps);
    }
    else {
        printk(KERN_INFO SDR_NAME " PCI device %02x:%02x.%d assigned to minor %d, type=%s (rev %d) numa=%d dma:%dch %db (%dMB) caps=0x%x\n",
               dev->bus->number, PCI_SLOT(dev->devfn), PCI_FUNC(dev->devfn),
               minor, BName, s->board_rev, s->numa_node, s->dma_channel_count, dma, s->dma_buffer_map_size / (1024*1024),
               s->fpga_caps);
    }
    if (fpga_time) {
        /* Also print Time if available */
        printk(KERN_INFO SDR_NAME " FPGA Revision: %d-%02d-%02d %02d:%02d:%02d\n",
               fpga_rev >> 16, (fpga_rev >> 8) & 0xff, fpga_rev & 0xff,
               (fpga_time >> 16) & 0xff, // HH,
               (fpga_time >>  8) & 0xff, // MM,
               (fpga_time >>  0) & 0xff  // SS
        );
    }
    else {
        printk(KERN_INFO SDR_NAME " FPGA Revision: %d-%02d-%02d\n",
               fpga_rev >> 16, (fpga_rev >> 8) & 0xff, fpga_rev & 0xff);
    }
    /* minor is correcty initialized, clear failed flag */
    failed_minor_table[minor] = 0;
    //dump_minors("probe SUCCESS");
    return 0;

 fail7:
    sdr_end(dev, s);
 fail6:
    free_irq(dev->irq, s);
 fail5:
    pci_disable_msi(dev);
 fail4:
    pci_iounmap(dev, s->bar0_addr);
 fail3:
    pci_release_regions(dev);
 fail2:
    pci_disable_device(dev);
    ret = -EIO;
 fail1:
    /* relase ref to prevent invalid references */
    if (sdr_minor_table[minor] == s)
        sdr_minor_table[minor] = NULL;
    kfree(s);
    printk(KERN_ERR SDR_NAME " Error while probing device\n");
    //dump_minors("probe ERROR");
    return ret;
}

static void sdr_end(struct pci_dev *dev, SDRState *s)
{
    int i, hw;

    hw = sdr_readl(s, CSR_IDENTIFIER_SYSID_ADDR);
    if ((hw & 0xffff) != 0xffff) {
        /* Here, the SDR FPGA registers are not accessible: do not write anything */
        /* probably after ICAP reload */
        
        sdr_gps_end(s);
        switch (s->sysid) {
        case SYSID_RF_5G_V2:    /* cleanup SDR100V2 PLL */
            sdr_cy22150_init(s, SMA_PLL_PROFILE_OFF);
            sdr_writel(s, CSR_SYNCHRO_PPS_EXT_TRISTATE_ADDR, SYNCHRO_PPS_EXT_DIRECTION_INPUT);        
            break;
        case SYSID_CPRI_40G:
            sdr_writel(s, CSR_SYNCHRO_PPS_EXT_CONTROL_ADDR, 0x00);
            sdr_writel(s, CSR_CPRI0_BASE + CSR_CPRI_PHY_CTRL_OFFSET, 0x0);
            sdr_writel(s, CSR_CPRI1_BASE + CSR_CPRI_PHY_CTRL_OFFSET, 0x0);
            sdr_writel(s, CSR_CPRI2_BASE + CSR_CPRI_PHY_CTRL_OFFSET, 0x0);
            sdr_writel(s, CSR_CPRI3_BASE + CSR_CPRI_PHY_CTRL_OFFSET, 0x0);
            break;    
        default:
            break;
        }
    
        /* disable all interrupts */
        sdr_writel(s, CSR_MSI_ENABLE_ADDR, 0);
    }
    for(i = 0; i < s->dma_channel_count; i++) {
        sdr_dma_channel_free(s, &s->dma_channels[i]);
    }

    sdr_smem_free(s);
}

static void sdr_pci_remove(struct pci_dev *dev)
{
    SDRState *s;

    s = pci_get_drvdata(dev);

    sdr_minor_table[s->minor] = NULL;
    failed_minor_table[s->minor] = 0;

    sdr_end(dev, s);
    free_irq(dev->irq, s);
    pci_disable_msi(dev);
    pci_iounmap(dev, s->bar0_addr);
    pci_disable_device(dev);
    pci_release_regions(dev);
    pci_set_drvdata(dev, NULL);

    if (s->sysid == SYSID_RF_5G_V2 && s->is_master) {
        SDRState *ss = sdr_minor_table[s->minor+1];
        /* Free Slave ghost device */
        if (ss) {
            sdr_minor_table[s->minor+1] = NULL;
            failed_minor_table[s->minor+1] = 0;
            kfree(ss);
        }
    }
    kfree(s);
}

static const struct pci_device_id sdr_pci_ids[] = {
    { PCI_DEVICE(0x10ee, 0x7021), },
    { PCI_DEVICE(0x10ee, 0x7022), },
    { PCI_DEVICE(0x10ee, 0x7024), },
    { PCI_DEVICE(0x10ee, 0x8038), },
    { PCI_DEVICE(0x10ee, 0x9034), },
    { PCI_DEVICE(0x10ee, 0x9038), },
    { 0, }
};
MODULE_DEVICE_TABLE(pci, sdr_pci_ids);

static struct pci_driver sdr_pci_driver = {
	.name = SDR_NAME,
	.id_table = sdr_pci_ids,
	.probe = sdr_pci_probe,
	.remove = sdr_pci_remove,
};

static int __init sdr_module_init(void)
{
    int ret;

    printk("Amarisoft SDR kernel driver version " CONFIG_VERSION "\n");

    ret = pci_register_driver(&sdr_pci_driver);
    if (ret < 0) {
        printk(KERN_ERR SDR_NAME " Error while registering PCI driver\n");
        goto fail1;
    }

    ret = alloc_chrdev_region(&sdr_cdev, 0, SDR_MINOR_COUNT, SDR_NAME);
    if (ret < 0) {
        printk(KERN_ERR SDR_NAME " Could not allocate char device\n");
        goto fail2;
    }

    cdev_init(&sdr_cdev_struct, &sdr_fops);
    ret = cdev_add(&sdr_cdev_struct, sdr_cdev, SDR_MINOR_COUNT);
    if (ret < 0) {
        printk(KERN_ERR SDR_NAME " Could not register char device\n");
        goto fail3;
    }
    return 0;
 fail3:
    unregister_chrdev_region(sdr_cdev, SDR_MINOR_COUNT);
 fail2:
    pci_unregister_driver(&sdr_pci_driver);
 fail1:
    return ret;
}

static void __exit sdr_module_exit(void)
{
    cdev_del(&sdr_cdev_struct);
    unregister_chrdev_region(sdr_cdev, SDR_MINOR_COUNT);

    pci_unregister_driver(&sdr_pci_driver);
}


module_init(sdr_module_init);
module_exit(sdr_module_exit);

MODULE_LICENSE("GPL");
