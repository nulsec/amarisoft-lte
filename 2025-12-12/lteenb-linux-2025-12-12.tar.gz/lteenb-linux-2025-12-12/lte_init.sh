#!/bin/bash
# Copyright (C) 2021-2025 Amarisoft
# lte_init.sh.head system config version 2025-12-12

# Run once as root after the boot

# Check root access
if [ "$(id -u)" != 0 ] ; then
    echo -e "\033[33mWarning, script must be run with root permissions\033[0m"
    exit 1
fi

function Log
{
    echo "$1: $2"
}

LINUX_SERVICE=""
LINUX_PACKAGE=""
LINUX_DISTRIB="<unknown>"
LINUX_VERSION=""

if [ -e "/etc/os-release" ] ; then
    LINUX_DISTRIB=$(grep "^ID=" /etc/os-release | cut -d '=' -f2 | sed -e 's/"//g')
    LINUX_VERSION=$(grep "^VERSION_ID=" /etc/os-release | cut -d '=' -f2 | sed -e 's/"//g')
    LINUX_NAME=$(grep "^PRETTY_NAME=" /etc/os-release | cut -d '=' -f2 | sed -e 's/"//g')
fi
if [ "$LINUX_VERSION" = "" ] || [ "$LINUX_DISTRIB" = "" ] ; then
    if [ -e "/etc/lsb-release" ] ; then
        LINUX_DISTRIB=$(grep "^DISTRIB_ID=" /etc/lsb-release | cut -d '=' -f2 | sed -e 's/"//g')
        LINUX_VERSION=$(grep "^DISTRIB_RELEASE=" /etc/lsb-release | cut -d '=' -f2 | sed -e 's/"//g')
        LINUX_NAME=$(grep "^DISTRIB_DESCRIPTION=" /etc/lsb-release | cut -d '=' -f2 | sed -e 's/"//g')
    elif [ -e "/etc/fedora-release" ]; then
        LINUX_DISTRIB="fedora"
        LINUX_VERSION=$(cut -d " " -f3 /etc/fedora-release)
        LINUX_NAME="Fedora"
    fi
fi

if [ "$TARGET" = "" ] ; then
    TARGET="$(uname -m)"
    if [ "$TARGET" = "x86_64" ] ; then
        TARGET="linux"
    fi
fi

LINUX_VERSION=$(echo "$LINUX_VERSION" | cut -d '.' -f1)
LINUX_DISTRIB=$(echo "$LINUX_DISTRIB" | tr '[:upper:]' '[:lower:]')

case "$LINUX_DISTRIB" in
fedora)
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94mFedora $LINUX_VERSION found\033[0m"
    fi
    if [ "$LINUX_VERSION" -gt 20 ] ; then
        LINUX_PACKAGE="dnf"
    else
        LINUX_PACKAGE="yum"
    fi
    LINUX_SERVICE="systemd"
    ;;
rhel)
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94m$LINUX_NAME found\033[0m"
    fi
    LINUX_PACKAGE="dnf"
    LINUX_SERVICE="systemd"
    ;;
ubuntu)
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94mUbuntu $LINUX_VERSION found\033[0m"
    fi
    if [ "$LINUX_VERSION" -lt "15" ] ; then
        LINUX_SERVICE="initd"
    else
        LINUX_SERVICE="systemd"
    fi
    LINUX_PACKAGE="apt"
    ;;
centos)
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94mCent OS $LINUX_VERSION found\033[0m"
    fi
    LINUX_SERVICE="systemd"
    LINUX_PACKAGE="yum"
    ;;
raspbian)
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94mRaspbian OS $LINUX_VERSION found\033[0m"
    fi
    LINUX_SERVICE="systemd"
    LINUX_PACKAGE="apt"
    ;;
debian)
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94mDebian OS $LINUX_VERSION found\033[0m"
    fi
    LINUX_SERVICE="systemd"
    LINUX_PACKAGE="apt"
    ;;
*)
    echo "Sorry, $LINUX_DISTRIB distribution not supported only available on Fedora, Ubuntu and CentOS distributions."
    exit 1
    ;;
esac

function service_cmd
{
    local name="$1"
    local cmd="$2"

    case $LINUX_SERVICE in
    systemd)
        if [ -e "/lib/systemd/system/${name}.service" ] ; then
            if [ "$VERBOSE" = "" ] ; then
                systemctl -q "${cmd}" "${name}" 1>/dev/null
            else
                systemctl -q "${cmd}" "${name}"
            fi
        fi
        ;;
    initd)
        if [ -e "/etc/init/${name}.conf" ] ; then
            if [ "$VERBOSE" = "" ] ; then
                service "${name}" "${cmd}" 1>/dev/null
            else
                service "${name}" "${cmd}"
            fi
        fi
        ;;
    esac
}

function service_install
{
    local name="$1"
    local path="$2"
    local user="$3"
    local enable="$4"

    case $LINUX_SERVICE in
    systemd)
        rm -f "/lib/systemd/system/${name}.service"
        sed -e "s/<USER>/$user/" -e "s'<PATH>'$path'" "${path}/${name}.service" > "/lib/systemd/system/${name}.service"
        systemctl -q --system daemon-reload

        if [ "$enable" = "y" ] ; then
            systemctl -q enable "${name}"
            #systemctl -q enable NetworkManager-wait-online.service
        else
            systemctl -q disable "${name}"
        fi
        ;;
    initd)
        # Remove legacy
        local deamon="/etc/init.d/${name}.d"
        if [ -e "$deamon" ]; then
            $deamon stop
            update-rc.d "${name}.d" disable
            rm -f "$deamon"
        fi

        if [ "$enable" = "y" ] ; then
            rm -f "/etc/init/${name}.conf"
            sed -e "s/<USER>/$user/" -e "s'<PATH>'$path'" "${path}/${name}.conf" > "/etc/init/${name}.conf"
        else
            rm "/etc/init/${name}.conf"
        fi
        ;;
    esac
}

# Package manager state
LINUX_PACKAGE_READY="y"
function check_package_manager
{
    # Disable error
    if [[ $- =~ e ]] ; then
        ERR="1"
    fi
    set +e

    case "$LINUX_PACKAGE" in
    yum|dnf)
        # XXX
        ;;
    apt)
        LOCKED=$(lsof /var/lib/dpkg/lock 2>/dev/null)
        if [ "$LOCKED" != "" ] ; then
            LINUX_PACKAGE_READY="n"
        fi
        ;;
    esac

    # Re-enable error ?
    if [ "$ERR" = "1" ] ; then
        set -e
    fi
}
check_package_manager

function install_package
{
    if [ "$LINUX_PACKAGE" = "" ] ; then return; fi

    if [ "$(whoami)" != "root" ] ; then
        echo "\031[93mRoot access needed to install package.[0m"
        exit 1
    fi

    # Disable error
    if [[ $- =~ e ]] ; then
        ERR="1"
    fi
    set +e

    while [ "$1" != "" ] ; do
        case "$LINUX_PACKAGE" in
        yum|dnf)
            if ! $LINUX_PACKAGE list installed "$1" &>/dev/null ; then
                echo "  Install package $1 (this may take a while)..."
                if [ "$VERBOSE" = "" ] ; then
                    $LINUX_PACKAGE -qq -y install "$1"
                else
                    $LINUX_PACKAGE -y install "$1"
                fi
            fi
            ;;
        apt)
            if ! apt-cache --quiet=0 policy "$1" | grep "Installed" | grep -v none &>/dev/null ; then
                echo "  Install package $1 (this may take a while)..."
                if [ "$VERBOSE" = "" ] ; then
                    apt-get -qq install -y "$1" &>/dev/null
                else
                    apt-get install -y "$1"
                fi
            fi
            ;;
        esac

        if [ "$?" != "0" ] ; then
            echo -e "  \033[93mCan't install package $1\033[0m"
            break
        fi
        shift;
    done

    # Re-enable error ?
    if [ "$ERR" = "1" ] ; then
        set -e
    fi
}

function GetHTState
{
    if [ "$HT_SYS_STATE" = "" ] ; then
        if [ -e "/sys/devices/system/cpu/smt/control" ] ; then
            HT_SYS_STATE=$(cat "/sys/devices/system/cpu/smt/control")
            if [ "$HT_SYS_STATE" = "on" ] ; then
                # Control on but only 1 thread per core
                TPC=$(lscpu | grep -oP "Thread.+per core:.+\K\d+")
                if [ "$TPC" = "1" ] ; then
                    HT_SYS_STATE="off"
                fi
            fi
        fi
    fi
}

function SetHTState
{
    echo "$1" > "/sys/devices/system/cpu/smt/control" 2>&1
}
function ParseProduct
{
    ResetProduct
    if [[ $1 =~ ([A-Z]+)-([0-9]{8})([0-9]{2}) ]] ; then
        PROD_MODEL="${BASH_REMATCH[1]}"
        PROD_DATE="${BASH_REMATCH[2]}"
        PROD_REV="${BASH_REMATCH[3]}"
    fi
}

function ResetProduct
{
    PROD_MODEL=""
    PROD_DATE=""
    PROD_REV=""
    PROD_NAME=""
}

function UpdateProduct
{
    if [ "$MOTHERBOARD" = "" ] ; then
        DMIDECODE=$(which dmidecode)
        if [ "$DMIDECODE" ] ; then
            MOTHERBOARD=$($DMIDECODE -t 2 2>/dev/null | grep -P "Manufacturer:|Product Name:" | cut -d ':' -f2 | sed -e 's/^\s*//' | xargs echo)
        else
            MOTHERBOARD="Unknown"
        fi
    fi

    # Amarisoft products
    if [ "$PROD_REF" = "" ] ; then
        if [ -e "/etc/.amarisoft-product/hostname" ] ; then
            PROD_REF="$(cat /etc/.amarisoft-product/hostname)"
        else
            PROD_REF="$(hostname)"
        fi
        if [ -e "/etc/.amarisoft-product/host-id" ] ; then
            PROD_HOSTID="$(cat /etc/.amarisoft-product/host-id)"
        fi
        if [ -e "/etc/.amarisoft-product/dongle-id" ] ; then
            PROD_DONGLEID="$(cat /etc/.amarisoft-product/dongle-id)"
        fi
    fi

    ParseProduct "$PROD_REF"
    if [ "$PROD_MODEL" = "" ] ; then return; fi

    case "$PROD_MODEL" in
    UESB)
        PROD_NAME="UE Simbox"
        SDR_COUNT="4"
        if [ "$MOTHERBOARD" = "ASRockRack X299 WS/IPMI" ] ; then
            SDR_MAP="0 1 2 3"
        elif [ "$MOTHERBOARD" = "ASRockRack X299 Creator" ] ; then
            SDR_MAP="3 1 0 2"
        fi
        ;;
    UESBE)
        PROD_NAME="UE Simbox E"
        SDR_COUNT="2"
        if [ "$MOTHERBOARD" = "ASRockRack X299 WS/IPMI" ] ; then
            SDR_MAP="0 1 2 3"
        elif [ "$MOTHERBOARD" = "ASRockRack X299 Creator" ] ; then
            SDR_MAP="0 1 2 3"
        fi
        ;;
    UESBNG|UEMBS|UESBMBS)
        PROD_MODEL="UESBMBS"
        PROD_NAME="UE Simbox Macro Base Station"
        SDR_COUNT="3"
        if [ "$MOTHERBOARD" = "ASRockRack WRX80D8-2T" ] ; then
            SDR_MAP="2 3 0 1 4 5"
        fi
        ;;
    CBM)
        PROD_NAME="Callbox Mini"
        SDR_COUNT="1"
        if [ "$MOTHERBOARD" = "Shuttle Inc. XH410G" ] ; then
            SDR_MAP="0"
        elif [ "$MOTHERBOARD" = "Shuttle Inc. XH510G" ] ; then
            SDR_MAP="0"
        fi
        ;;
    CBC)
        PROD_NAME="Callbox Classic"
        SDR_COUNT="3"
        if [ "$MOTHERBOARD" = "ASRock Z790M-PLUS" ] ; then
            SDR_MAP="0 1 2"
        elif [ "$MOTHERBOARD" = "ASRock Z590M-PRO4" ] ; then
            SDR_MAP="0 2 1"
        elif [ "$MOTHERBOARD" = "ASRock Z590M-PLUS/Z490M-PLUS" ] ; then
            SDR_MAP="0 1 2"
        fi
        ;;
    CBP)
        PROD_NAME="Callbox Pro"
        SDR_COUNT="6"
        if [ "$MOTHERBOARD" = "ASRockRack OC Formula" ] ; then
            SDR_MAP="5 0 4 3 2 1"
        fi
        ;;
    CBU)
        PROD_NAME="Callbox Ultimate"
        SDR_COUNT="4"
        if [ "$MOTHERBOARD" = "ASRockRack X299 WS/IPMI" ] ; then
            SDR_MAP="0 1 2 3 4 5 6 7"
        elif [ "$MOTHERBOARD" = "ASRockRack OC Formula" ] ; then
            SDR_MAP="4 5 2 3 0 1 6 7"
        elif [ "$MOTHERBOARD" = "ASRockRack X299 Creator" ] ; then
            SDR_MAP="2 3 6 7 0 1 4 5"
        fi
        ;;
    CBX|CBE)
        PROD_MODEL="CBX"
        PROD_NAME="Callbox Extreme"
        SDR_COUNT="6"
        if [ "$MOTHERBOARD" = "ASRockRack WRX80D8-2T" ] ; then
            SDR_MAP="2 3 0 1 10 11 8 9 4 5 6 7"
        fi
        ;;
    CBA)
        PROD_NAME="Callbox Advanced"
        SDR_COUNT="2"
        if [ "$MOTHERBOARD" = "ASRockRack X299 WS/IPMI" ] ; then
            SDR_MAP="0 1 2 3"
        fi
        ;;
    XXX)
        ResetProduct
        if [ "$SCRIPT_SILENT" != "1" ] ; then
            echo -e "\033[94mRecovery image found\033[0m"
        fi
        return
        ;;
    *)
        PROD_NAME="$PROD_MODEL"
        ;;
    esac
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94m$PROD_NAME model found\033[0m"
    fi
}
UpdateProduct

RT_CPUSET=""
function RTCPUInit1
{
    BID FILE CT tries NB_LAT
    BID=$(cat /proc/sys/kernel/random/boot_id)
    FILE="/etc/.amarisoft-product/cpuset"
    RT_CPUSET0="$RT_CPUSET"

    if [ "$LINUX_DISTRIB" = "fedora" ] ; then
        if [[ $LINUX_VERSION -ge 40 ]] ; then
            rm -f $FILE
            return
        fi
    fi

    if [ -e "$FILE" ] ; then
        source "$FILE"
        if [ "$BOOT_ID" != "$BID" ] ; then
            RT_CPUSET=""
            rm -f $FILE
        else
            if [ "$RT_CPUSET0" != "$RT_CPUSET" ] ; then
                Log "OTS" "Recover cpuset: $RT_CPUSET"
            fi
            return
        fi
    fi

    CT=$(which cyclictest)
    if [ "$CT" = "" ] ; then return; fi

    tries="0"
    while true ; do
        RT_CPUSET="0x0"
        NB_LAT="0"
        Log "OTS" "Detecting CPU latency [$tries]"
        while read -r line ; do
            P=$(echo "$line" | grep -Po "T:\s*\K\d+")
            if [ "$P" != "" ] ; then
                MAX=$(echo "$line" | grep -Po "Max:\s+\K\d+")
                if [[ $MAX -lt 450 ]] ; then
                    RT_CPUSET=$(perl -e "printf '0x%x', $RT_CPUSET | (1<<$P);")
                else
                    Log "OTS" "High latency detected on core $P ($MAX us)"
                    NB_LAT=$(( NB_LAT + 1 ))
                    RT_SKIP_CORE=$P
                fi
            fi
        done < <($CT --smp -p50 -i200 -d0 -m -D8s -q)
        if [ "$NB_LAT" != "1" ] ; then
            if [ "$NB_LAT" != "0" ] ; then
                Log "OTS" "Too much CPU latencies found: $NB_LAT"
            else
                Log "OTS" "No CPU latencies found"
            fi
            if [[ $tries -lt 4 ]] ; then
                tries=$(( tries + 1 ))
                sleep 5
                continue
            fi
            if [ "$NB_LAT" = "0" ] ; then
                RT_CPUSET=""
            else
                return # Try later
            fi
        else
            Log "OTS" "Latency found on CPU: $RT_SKIP_CORE"
        fi

        echo "# Generated on $(date -u)" > $FILE
        echo "BOOT_ID=$BID" >> $FILE
        echo "RT_CPUSET=$RT_CPUSET # !$RT_SKIP_CORE" >> $FILE
        break
    done
}

function RTCPUInit
{
    case "$PROD_MODEL" in
    CBX|CBE|UESBMBS|UESBNG)
        RTCPUInit1
        ;;
    esac
}



# Disable on demand service on Ubuntu
if [ -e "/etc/lsb-release" ] ; then
    if grep -i Ubuntu /etc/lsb-release 1>/dev/null ; then
        service ondemand stop
    fi
fi

########################################################################
# set the "performance" governor for all CPUs to have the highest
# clock frequency
if [ -e "/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor" ] ; then
    CPUS0=$(ls /sys/devices/system/cpu/ | grep -oP "cpu\K\d+")
    CPUS1=""
    for cpu in $CPUS0 ; do
        if [ -e "/sys/devices/system/cpu/cpu${cpu}/online" ] ; then
            if [ "$(cat "/sys/devices/system/cpu/cpu${cpu}/online")" = "0" ] ; then continue; fi
        fi
        CPUS1="$CPUS1 $cpu"
    done
    echo "Set performance scaling governor for cpus$CPUS1"
    for cpu in $CPUS1 ; do
        echo performance > "/sys/devices/system/cpu/cpu${cpu}/cpufreq/scaling_governor"
    done
fi

########################################################################
# With some video drivers (DRM KMS drivers), the cable polling blocks
# one CPU during a few tens of ms every few seconds. We disable it
# here.
if [ -f /sys/module/drm_kms_helper/parameters/poll ] ; then
  echo N > /sys/module/drm_kms_helper/parameters/poll
fi

########################################################################
# increase network buffers
sysctl -w net.core.rmem_max=50000000
sysctl -w net.core.wmem_max=5000000

########################################################################
# Product specific
function SetHP
{
    if [ -e "/sys/kernel/mm/hugepages/hugepages-2048kB/nr_hugepages" ] ; then
        echo "$1" > /sys/kernel/mm/hugepages/hugepages-2048kB/nr_hugepages
    fi
    echo never > /sys/kernel/mm/transparent_hugepage/enabled
    echo 0 > /sys/kernel/mm/ksm/run
    echo 0 > /proc/sys/kernel/numa_balancing
    echo 0 > /proc/sys/kernel/nmi_watchdog
}

if [[ $(type -t RTCPUInit) == function ]] ; then
    RTCPUInit
fi

case "$PROD_MODEL" in
CBM)
    SetHP 600
    ;;
CBP|CBU|CBC)
    SetHP 1000
    ;;
CBX|CBE|UESBMBS|UESBNG)
    SetHP 1500
    ;;
UESB|UESBE)
    SetHP 1200
    ;;
esac

exit 0;
