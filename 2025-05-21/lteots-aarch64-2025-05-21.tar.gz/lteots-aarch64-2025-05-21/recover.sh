#!/bin/bash
# Amarisoft product recovery tool version 2025-05-21
# Use it after restoring product SSD

cd $(dirname $(readlink -f $0))

SDR_MAP=""
SDR_COUNT="0"

echo "Recovery script version 2025-05-21, Copyright (C) 2024-2025 Amarisoft"

function question
{
    local i
    local var="$3"
    local opt_list=`echo "$2" | sed -e 's/\B/ /g'`

    # Already set ?
    if [ "${!var}" != "" ] ; then
        echo -e "$1 [$2] ${!var}"
        return
    fi

    if [ "$USE_DEFAULT" = "y" ] ; then
        for i in $opt_list ; do
            opt=`echo $i | tr '[:upper:]' '[:lower:]'`
            if [ "$opt" != "$i" ] ; then
                echo -e "$1 [$2] $opt"
                eval "$var=$opt"
                return
            fi
        done
    fi

    read -t 0.2 -n 1000 discard || true; # Flush STDIN
    echo -n -e "$1 [$2] "
    while [ true ] ; do
        read -n 1 -s $var

        eval "$var=$(echo \"${!var}\" | tr '[:upper:]' '[:lower:]')"

        for i in $opt_list ; do
            opt=`echo $i | tr '[:upper:]' '[:lower:]'`
            if [ "$opt" = "${!var}" ] ; then
                echo "$opt"
                return
            fi
            if [ "$opt" != "$i" -a "${!var}" = "" ] ; then
                echo "$opt"
                eval "$var=$opt"
                return
            fi
        done
    done
}

function choice
{
    local C
    local choice
    local txt="$1"
    local var="$2"
    local choices="$3"
    local indent=$(echo "$txt" | sed -e "s/[^ ].*//")

    # Default
    local def="${!var}"
    for choice in $choices ; do
        if [ "$def" = "" -o "${!var}" = "$choice" ] ; then
            def="$choice"
        fi
    done

    # Header
    read -t 0.2 -n 1000 discard || true ; # Flush STDIN
    echo "$txt"
    declare -a A=({1..9} {a..z})
    local i=0
    for choice in $choices ; do
        local ctxt=$(echo $choice | sed -e "s/_/ /g")
        local a=${A[$i]}
        if [ "$def" = "$choice" ] ; then
            echo "$indent  $a) $ctxt (default)"
            local defC="$a"
        else
            echo "$indent  $a) $ctxt"
        fi
        i=$(( i + 1 ))
    done

    echo -n "$indent  > "
    while [ true ] ; do
        if [ "$USE_DEFAULT" = "y" ] ; then
            C=""
        else
            read -n 1 -s C
        fi

        if [ "$C" = "" -a "$defC" != "" ] ; then
            echo "$defC ($def)"
            eval "$var=\"$def\""
            return
        fi

        local i=0
        for choice in $choices ; do
            if [ "${A[$i]}" = "$C" ] ; then
                echo "$C ($choice)"
                eval "$var=\"$choice\""
                return
            fi
            i=$(( i + 1 ))
        done
    done
}

function prompt
{
    while [ true ] ; do
        read -t 0.2 -n 1000 discard || true; # Flush STDIN
        echo -e "$1"
        read -p "    > " "$2"

        if [ "${!2}" != "" -o "$3" = "null" ] ; then
            break;
        fi
    done
}
function ParseProduct
{
    ResetProduct
    if [[ $1 =~ ([A-Z]+)-([0-9]{8})([0-9]{2}) ]] ; then
        PROD_MODEL="${BASH_REMATCH[1]}"
        PROD_DATE="${BASH_REMATCH[2]}"
        PROD_REV="${BASH_REMATCH[3]}"
    fi
}

function ResetProduct
{
    PROD_MODEL=""
    PROD_DATE=""
    PROD_REV=""
    PROD_NAME=""
}

function UpdateProduct
{
    if [ "$MOTHERBOARD" = "" ] ; then
        DMIDECODE=$(which dmidecode)
        if [ "$DMIDECODE" ] ; then
            MOTHERBOARD=$($DMIDECODE -t 2 2>/dev/null | grep -P "Manufacturer:|Product Name:" | cut -d ':' -f2 | sed -e 's/^\s*//' | xargs echo)
        else
            MOTHERBOARD="Unknown"
        fi
    fi

    # Amarisoft products
    if [ "$PROD_REF" = "" ] ; then
        if [ -e "/etc/.amarisoft-product/hostname" ] ; then
            PROD_REF="$(cat /etc/.amarisoft-product/hostname)"
        else
            PROD_REF="$(hostname)"
        fi
        if [ -e "/etc/.amarisoft-product/host-id" ] ; then
            PROD_HOSTID="$(cat /etc/.amarisoft-product/host-id)"
        fi
        if [ -e "/etc/.amarisoft-product/dongle-id" ] ; then
            PROD_DONGLEID="$(cat /etc/.amarisoft-product/dongle-id)"
        fi
    fi

    ParseProduct "$PROD_REF"
    if [ "$PROD_MODEL" = "" ] ; then return; fi

    case "$PROD_MODEL" in
    UESB)
        PROD_NAME="UE Simbox"
        SDR_COUNT="4"
        if [ "$MOTHERBOARD" = "ASRockRack X299 WS/IPMI" ] ; then
            SDR_MAP="0 1 2 3"
        elif [ "$MOTHERBOARD" = "ASRockRack X299 Creator" ] ; then
            SDR_MAP="3 1 0 2"
        fi
        ;;
    UESBE)
        PROD_NAME="UE Simbox E"
        SDR_COUNT="2"
        if [ "$MOTHERBOARD" = "ASRockRack X299 WS/IPMI" ] ; then
            SDR_MAP="0 1 2 3"
        elif [ "$MOTHERBOARD" = "ASRockRack X299 Creator" ] ; then
            SDR_MAP="0 1 2 3"
        fi
        ;;
    UESBNG|UEMBS|UESBMBS)
        PROD_MODEL="UESBMBS"
        PROD_NAME="UE Simbox Macro Base Station"
        SDR_COUNT="3"
        if [ "$MOTHERBOARD" = "ASRockRack WRX80D8-2T" ] ; then
            SDR_MAP="2 3 0 1 4 5"
        fi
        ;;
    CBM)
        PROD_NAME="Callbox Mini"
        SDR_COUNT="1"
        if [ "$MOTHERBOARD" = "Shuttle Inc. XH410G" ] ; then
            SDR_MAP="0"
        elif [ "$MOTHERBOARD" = "Shuttle Inc. XH510G" ] ; then
            SDR_MAP="0"
        fi
        ;;
    CBC)
        PROD_NAME="Callbox Classic"
        SDR_COUNT="3"
        if [ "$MOTHERBOARD" = "ASRock Z790M-PLUS" ] ; then
            SDR_MAP="0 1 2"
        elif [ "$MOTHERBOARD" = "ASRock Z590M-PRO4" ] ; then
            SDR_MAP="0 2 1"
        elif [ "$MOTHERBOARD" = "ASRock Z590M-PLUS/Z490M-PLUS" ] ; then
            SDR_MAP="0 1 2"
        fi
        ;;
    CBP)
        PROD_NAME="Callbox Pro"
        SDR_COUNT="6"
        if [ "$MOTHERBOARD" = "ASRockRack OC Formula" ] ; then
            SDR_MAP="5 0 4 3 2 1"
        fi
        ;;
    CBU)
        PROD_NAME="Callbox Ultimate"
        SDR_COUNT="4"
        if [ "$MOTHERBOARD" = "ASRockRack X299 WS/IPMI" ] ; then
            SDR_MAP="0 1 2 3 4 5 6 7"
        elif [ "$MOTHERBOARD" = "ASRockRack OC Formula" ] ; then
            SDR_MAP="4 5 2 3 0 1 6 7"
        elif [ "$MOTHERBOARD" = "ASRockRack X299 Creator" ] ; then
            SDR_MAP="2 3 6 7 0 1 4 5"
        fi
        ;;
    CBX|CBE)
        PROD_MODEL="CBX"
        PROD_NAME="Callbox Extreme"
        SDR_COUNT="6"
        if [ "$MOTHERBOARD" = "ASRockRack WRX80D8-2T" ] ; then
            SDR_MAP="2 3 0 1 10 11 8 9 4 5 6 7"
        fi
        ;;
    CBA)
        PROD_NAME="Callbox Advanced"
        SDR_COUNT="2"
        if [ "$MOTHERBOARD" = "ASRockRack X299 WS/IPMI" ] ; then
            SDR_MAP="0 1 2 3"
        fi
        ;;
    XXX)
        ResetProduct
        if [ "$SCRIPT_SILENT" != "1" ] ; then
            echo -e "\033[94mRecovery image found\033[0m"
        fi
        return
        ;;
    *)
        PROD_NAME="$PROD_MODEL"
        ;;
    esac
    if [ "$SCRIPT_SILENT" != "1" ] ; then
        echo -e "\033[94m$PROD_NAME model found\033[0m"
    fi
}
UpdateProduct

RT_CPUSET=""
function RTCPUInit
{
    local BID=$(cat /proc/sys/kernel/random/boot_id)
    local FILE="/etc/.amarisoft-product/cpuset"
    local RT_CPUSET0="$RT_CPUSET"

    if [ -e "$FILE" ] ; then
        source "$FILE"
        if [ "$BOOT_ID" != "$BID" ] ; then
            RT_CPUSET=""
        elif [ "$RT_CPUSET0" = "" ] ; then
            Log "OTS" "Recover cpuset: $RT_CPUSET"
        fi
    fi

    local CT=$(which cyclictest)
    if [ "$CT" = "" ] ; then return; fi

    local tries="0"
    while [ "$RT_CPUSET" = "" ] ; do
        RT_CPUSET="0x0"
        local NB_LAT="0"
        Log "OTS" "Detecting CPU latency"
        while read -r line ; do
            P=$(echo "$line" | grep -Po "T:\s*\K\d+")
            if [ "$P" != "" ] ; then
                MAX=$(echo "$line" | grep -Po "Max:\s+\K\d+")
                if [[ $MAX -lt 450 ]] ; then
                    RT_CPUSET=$(perl -e "printf '0x%x', $RT_CPUSET | (1<<$P);")
                else
                    Log "OTS" "High latency detected on core $P ($MAX us)"
                    NB_LAT=$(( $NB_LAT + 1 ))
                    RT_SKIP_CORE=$P
                fi
            fi
        done < <($CT --smp -p50 -i200 -d0 -m -D8s -q)
        if [ "$NB_LAT" != "1" ] ; then
            RT_CPUSET=""
            if [[ $tries -gt 4 ]] ; then
                Log "OTS" "Can't detect high latency CPU: $NB_LAT"
                break
            fi
            tries=$(( $tries + 1 ))
            sleep 5
        else
            rm -f $FILE
            echo "# Generated on $(date -u)" > $FILE
            echo "BOOT_ID=$BID" >> $FILE
            echo "RT_CPUSET=$RT_CPUSET # !$RT_SKIP_CORE" >> $FILE
        fi
    done
}



if [ -e "/etc/sdr-mapping" ] ; then
    SDR_MAP0=$(cat "/etc/sdr-mapping");
fi

function Help
{
    echo "Usage"
    echo "$0 [options]"
    echo "Recover product configuration if lost"
    echo "  options:"
    echo "    -f|--force: force reconfiguration"
    echo "    -h|--help: show this menu"
    exit $1
}

while [ "$1" != "" ] ; do
    case "$1" in
    -f|--force)
        SDR_COUNT="0"
        PROD_MODEL=""
        PROD_REV=""
        PROD_DATE=""
        SDR_MAP0=""
        ;;
    -h|--help)
        Help 0
        ;;
    *)
        echo "Unknown argument $1" >&2
        Help 1
        ;;
    esac
    shift
done

if [ "$SDR_COUNT" = "0" ] ; then
    service lte stop 1>/dev/null 2>&1
    SDR_COUNT=$(/root/trx_sdr/sdr_util version 2>/dev/null | grep Device | wc -l)
    SDR_SLAVE=$(/root/trx_sdr/sdr_util version 2>/dev/null | grep Slave | wc -l)
    SDR_COUNT=$(( $SDR_COUNT - $SDR_SLAVE ))
fi

function GetType
{
    if [ "${PROD_MODEL:0:2}" = "CB" ] ; then
        TYPE="Callbox"
    elif [ "${PROD_MODEL:0:2}" = "UE" ] ; then
        TYPE="Simbox"
    else
        choice "Select your product type" "TYPE" "Callbox Simbox"
    fi
}

case "$MOTHERBOARD" in
ASRockRack\ WRX80D8-2T)
    if [ "$SDR_COUNT" = "0" ] ; then
        GetType
        if [ "$TYPE" = "Callbox" ] ; then
            SDR_COUNT="6"
        elif [ "$TYPE" = "Simbox" ] ; then
            SDR_COUNT="3"
        fi
    fi
    if [ "$SDR_COUNT" = "6" ] ; then
        PROD_MODEL1="CBX"
    elif [ "$SDR_COUNT" = "3" ] ; then
        PROD_MODEL1="UESBMBS"
    fi
    ;;
ASRockRack\ X299\ WS\/IPMI)
    if [ "$SDR_COUNT" = "0" ] ; then
        GetType
        if [ "$TYPE" = "Callbox" ] ; then
            prompt "How many SDR board do you have (2 or 4) ?" "SDR_COUNT"
            if [ "$SDR_COUNT" = "4" ] ; then
                PROD_MODEL1="CBU"
            elif [ "$SDR_COUNT" = "2" ] ; then
                PROD_MODEL1="CBA"
            fi
        elif [ "$TYPE" = "Simbox" ] ; then
            prompt "How many SDR board do you have (2 or 4) ?" "SDR_COUNT"
            if [ "$SDR_COUNT" = "4" ] ; then
                PROD_MODEL1="UESB"
            elif [ "$SDR_COUNT" = "2" ] ; then
                PROD_MODEL1="UESBE"
            fi
        fi
    elif [ "$SDR_COUNT" = "4" ] ; then
        PROD_MODEL1="CBU"
    elif [ "$SDR_COUNT" = "2" ] ; then
        GetType
        if [ "$TYPE" = "Callbox" ] ; then
            PROD_MODEL1="CBA"
        elif [ "$TYPE" = "Simbox" ] ; then
            PROD_MODEL1="UESBE"
        fi
    elif [ "$SDR_COUNT" = "4" ] ; then
        PROD_MODEL1="UESB"
    fi
    ;;
ASRockRack\ OC\ Formula)
    if [ "$SDR_COUNT" = "0" ] ; then
        prompt "How many SDR board do you have (2 or 4) ?" "SDR_COUNT"
    fi
    if [ "$SDR_COUNT" = "4" ] ; then
        PROD_MODEL1="CBU"
    elif [ "$SDR_COUNT" = "6" ] ; then
        PROD_MODEL1="CBP"
    fi
    ;;
ASRockRack\ X299\ Creator)
    if [ "$SDR_COUNT" = "0" ] ; then
        GetType
        if [ "$TYPE" = "Callbox" ] ; then
            PROD_MODEL1="CBU"
        elif [ "$TYPE" = "Simbox" ] ; then
            prompt "How many SDR board do you have (2 or 4) ?" "SDR_COUNT"
            if [ "$SDR_COUNT" = "4" ] ; then
                PROD_MODEL1="UESB"
            elif [ "$SDR_COUNT" = "2" ] ; then
                PROD_MODEL1="UESBE"
            fi
        fi
    elif [ "$SDR_COUNT" = "4" ] ; then
        GetType
        if [ "$TYPE" = "Callbox" ] ; then
            PROD_MODEL1="CBU"
        elif [ "$TYPE" = "Simbox" ] ; then
            PROD_MODEL1="UESB"
        fi
    elif [ "$SDR_COUNT" = "2" ] ; then
        PROD_MODEL1="UESBE"
    fi
    ;;
ASRock\ Z790M-PLUS)
    PROD_MODEL1="CBC"
    ;;
ASRock\ Z790M-PRO4)
    PROD_MODEL1="CBC"
    ;;
ASRock\ Z790M-PLUS/Z490M-PLUS)
    PROD_MODEL1="CBC"
    ;;
Shuttle\ Inc.\ XH410G)
    PROD_MODEL1="CBM"
    ;;
Shuttle\ Inc.\ XH510G)
    PROD_MODEL1="CBM"
    ;;
*)
    echo "Unknown motherboard $MOTHERBOARD" >&2
    exit 1
    ;;
esac

if [ "$PROD_MODEL1" = "" ] ; then
    echo "Can't recover product model" >&2
    exit 1
fi

if [ "$PROD_MODEL" != "" ] ; then
    if [ "$PROD_MODEL" = "$PROD_NAME" ] ; then
        echo "Invalid model detected"
        ResetProduct
        echo ""
    elif [ "$PROD_MODEL" != "$PROD_MODEL1" ] ; then
        question "Suspicious model found: $PROD_MODEL, should be $PROD_MODEL1.\nDo you want to fix it ?" "Yn" "Q"
        if [ "$Q" = "n" ] ; then
            exit 0
        fi
        Q=""
        ResetProduct
        echo ""
    fi
fi

if [ "$PROD_MODEL" = "" ] ; then
    if [ "$PROD_REV" = "" -o "$PROD_DATE" = "" ] ; then
        MSG="What is your product serial number ?\nYou should see a label on the back of the test equipment with this information.\nAs an example if you have a Callbox Ultimate, you should see something like ${PROD_MODEL1}-2024031200\nKeep this field empty if you can't find it."
        while [ true ] ; do
            prompt "$MSG" "SERIAL" "null"

            if [ "$SERIAL" = "" ] ; then
                PROD_DATE=$(date +"%Y%m%d")
                PROD_REV="99"
                break
            fi
            ParseProduct "$SERIAL"
            if [ "$PROD_MODEL" != "" ] ; then
                if [ "$PROD_MODEL" != "$PROD_MODEL1" ] ; then
                    Q=""
                    question "The entered serial number does not match the detected model ($PROD_MODEL1).\nDo you want to proceed and use model from serial ?" "yN" "Q"
                    if [ "$Q" = "y" ] ; then
                        PROD_MODEL1="$PROD_MODEL"
                    fi
                fi
                if [ "$PROD_MODEL" = "$PROD_MODEL1" ] ; then
                    break
                fi
                MSG="Please retry"
            else
                MSG="Invalid serial number, please retry"
            fi
        done
    fi

    PROD_REF="${PROD_MODEL1}-${PROD_DATE}${PROD_REV}"
    UpdateProduct
    if [ "$PROD_NAME" = "" ] ; then
        echo "Internal error" >&2
        exit 1
    fi

    question "Do you want to recover $PROD_REF ?" "Yn" "REC"
    if [ "$REC" = "y" ] ; then
        mkdir -p /etc/.amarisoft-product/
        rm -f /etc/.amarisoft-product/hostname
        echo "$PROD_REF" > /etc/.amarisoft-product/hostname

        rm -f /etc/hostname
        echo "$PROD_REF" > /etc/hostname
        hostname $PROD_REF
    fi
else
    echo "Product information found"
    SCRIPT_SILENT="1"
    UpdateProduct
fi

if [ "$SDR_MAP" != "" ] ; then
    if [ "$SDR_MAP0" != "$SDR_MAP" ] ; then
        if [ "$REC" != "n" ] ; then
            REC=""
            question "Do you want to recover SDR mapping ?" "Yn" "REC"
            if [ "$REC" = "y" ] ; then
                rm -f /etc/sdr-mapping
                echo "$SDR_MAP" > /etc/sdr-mapping
            fi
        fi
    else
        echo "SDR mapping OK"
    fi
fi

