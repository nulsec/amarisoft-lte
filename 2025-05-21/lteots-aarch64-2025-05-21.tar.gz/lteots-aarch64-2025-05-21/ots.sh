#!/bin/bash
# Amarisoft OTS service component tool version 2025-05-21

set -e

echo "ots.sh version 2025-05-21, Copyright (C) 2024-2025 Amarisoft"

FIFO=".lte.event"

function Help
{
    if [ "$1" != "" ] ; then
        echo "$1"
    fi

    echo "Usage"
    echo "$0 stop|start <component>"
    echo "    stop/start component"

    if [ "$1" != "" ] ; then
        exit 1
    fi
    exit 0
}

cd $(dirname $(readlink -f $0))
case "$1" in
stop|start)
    comp=$(echo "$2" | tr -cd '[:alnum:]._-' | tr '[:lower:]' '[:upper:]')
    if [ "$2" = "" ] ; then Help "Missing component" ; fi

    if [ ! -e "/tmp/lte.log" ] ; then
        echo "OTS service not started"
        exit 1
    fi
    (
        set +e
        timeout 5 tail -f -n 0 /tmp/lte.log
        set -e
    ) &
    echo "OTS|comp|$comp|$1" >> $FIFO
    wait
    ;;
*)
    Help "Unknown parameter $1"
    ;;
esac

