#!/bin/bash
# Copyright (C) 2020-2025 Amarisoft
# LTE component launcher version 2025-05-21

COMP="$1"

source ".launch.$1"
rm -f ".launch.$1"

function Notify
{
    echo "$COMP|$1|$2" > $FIFO
}

# Notify
Notify "starting" "$$"

case "$OUTPUT_TYPE" in
stdout)
    set -o pipefail
    $PROG $CONFIG 2>&1 | tee $OUTPUT_FILE
    RET="$?"
    ;;
stderr)
    set -o pipefail
    $PROG $CONFIG 3>&1 1>&2 2>&3 | tee $OUTPUT_FILE
    RET="$?"
    ;;
*)
    $PROG $CONFIG
    RET="$?"
    ;;
esac

if [ "$RET" = "0" ] ; then
    Notify "stop"
else
    Notify "error" "$RET"
fi


