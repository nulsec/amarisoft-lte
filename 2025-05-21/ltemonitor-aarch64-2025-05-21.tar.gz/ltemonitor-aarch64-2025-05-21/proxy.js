/*
 * Copyright (C) 2020-2025 Amarisoft
 * LTE Monitor proxy version 2025-05-21
 */

const fs = require('fs');
const WebSocket = require('nodejs-websocket');
const utilsModule = global.loadLib('utils');


/*
 * Remote proxy
 */
var Proxy = module.exports.Instance = function (monitor, config)
{
    monitor.utilsInit(this);
    utilsModule.timerInit(this);
    utilsModule.initFs(this);

    this.timerCreate('start', this.onStart);
    this.timerCreate('poll', this.sendPoll, { restart: false, delay: 1000 });
    this.timerCreate('connection-timeout', this.connectionTimeoutCb);

    this.keepalive = config.getNumber('keepalive', { min: 1, max: 3600, default: WS_KEEPALIVE / 1000 }) * 1000;

    // Connection check
    this.timerCreate('keepalive-send', this.keepaliveSendCb);
    this.timerCreate('keepalive-timeout', this.keepaliveTimeoutCb);

    var address = config.getIP('addr');
    this.timeout = config.getNumber('timeout', { min: 0, max: 3600 * 24 * 30}) * 1000;

    this.storeDir = config.getFile('store', {optional: true, noexist: true, type: 'dir'});
    this.storeFiles = [];
    this.storeData = []; // List of data to be sent

    this.sendBulkSize = config.getNumber('bulk', { optional: true, default: 20 });

    this.wsError = null;

    if (this.storeDir) {
        if (!fs.existsSync(this.storeDir)) {
            fs.mkdirSync(this.storeDir);
        }

        this.storeParsing = true;
        fs.readdir(this.storeDir, (err, files) => {
            if (!err) {
                files.forEach( (file) => {
                    this.storeFileAdd(this.storeDir + file);
                });
            } else {
                this.log(LOG_ERROR, "Can't read cache directory: " + err);
            }
            this.storeParsing = false;
            this.sendPoll();
        });
    }

    this.connected = false;
    this.url = 'ws://' + address.host + ':' + (address.port || WS_DEFAULT_PORT);

    this.timerStart('start');
};

Proxy.prototype.id = 'PROXY';

Proxy.prototype.onStart = function ()
{
    this.log(LOG_DEBUG, 'Connecting to ' + this.url);
    var ws = this.ws = WebSocket.connect(this.url, { extraHeaders: { origin: MON_TYPE }});

    ws.on('connect', this.onConnect.bind(this));
    ws.on('text', this.onMessage.bind(this));
    ws.on('close', this.onClose.bind(this));
    ws.on('error', this.onError.bind(this));
    utilsModule.setWSBinHandler(ws, this.onBin.bind(this));

    this.timerStart('connection-timeout', this.keepalive);
};

Proxy.prototype.connectionTimeoutCb = function ()
{
    this.log(LOG_DEBUG, 'Connection timeout');
    this.timerStart('start', PROXY_RETRY_DELAY);
}

Proxy.prototype.sendMsg = function (message, msg)
{
    if (this.connected) {
        msg.message = message;
        this.ws.send(JSON.stringify(msg));
        this.keepaliveSendRestart();
    }
};

Proxy.prototype.keepaliveSendCb = function ()
{
    this.sendMsg('proxy-ping', {});
    this.keepaliveSendRestart();
};

Proxy.prototype.keepaliveTimeoutCb = function ()
{
    this.log(LOG_INFO, 'Keep alive failure');
    this.ws.close();
};

Proxy.prototype.keepaliveSendRestart = function ()
{
    var delay = this.keepalive / 2 + Math.random() * this.keepalive / 6;

    this.timerStart('keepalive-send', delay);
};

Proxy.prototype.onConnect = function ()
{
    this.log(LOG_INFO, 'Connected');
    this.wsError = null;
    this.connected = true;
    this.timerStop('connection-timeout');
    this.sendMsg('proxy-init', { hostname: this.monitor.hostname, keepalive: this.keepalive });

    // Send
    this.monitor.remoteProxyConnected();
};

Proxy.prototype.onMessage = function (txt)
{
    var msg = this.parseJSONData(txt);
    if (!msg)
        return;

    // Keep alive handling
    this.timerStart('keepalive-timeout', this.keepalive);

    switch (msg.message) {
    case 'proxy-init':
        this.sendLock = false;
        this.sendPoll();
        break;
    case 'proxy-data':
        if (msg.error) {
            // XXX
        }
        this.sendLock = false;
        this.sendPoll();
        break;
    case 'proxy-ping':
        this.log(LOG_DEBUG, 'Connection alive');
        break;
    case 'ready':
        this.log(LOG_DEBUG, 'Connection ready');
        break;
    case 'proxy-components':
        break;
    case 'proxy-remove-host':
        this.monitor.removeHost(msg.host);
        break;
    case 'proxy-config-file-get':
    case 'proxy-config-file-set':
    case 'proxy-backup':
        this.monitor.onCompMsg(msg, msg.message.replace('proxy-', ''), (type, data) => {
            if (type === 'error')
                this.respMsg(msg, { error: data });
            else
                this.respMsg(msg, data);
        });
        break;
    case 'proxy-license-set':
    case 'proxy-reboot-host':
    case 'proxy-restart-service':
    case 'proxy-restart-host':
    case 'proxy-software-upgrade-check':
    case 'proxy-software-upgrade-start':
        this.monitor.onHostMsg(msg, msg.message.replace('proxy-', ''), null, (type, data) => {
            if (type === 'error')
                this.respMsg(msg, { error: data });
            else
                this.respMsg(msg, data || {});
        });
        break;
    default:
        this.log(LOG_ERROR, 'Unknown message: ' + msg.message);
        break;
    }
};

Proxy.prototype.onBin = function (type, msg, bin)
{
    switch (type) {
    case 'chunk':
        this.timerStart('keepalive-timeout', this.keepalive);
        break;

    case 'error':
        this.log(LOG_ERROR, 'Binary error: ' + msg);
        break;

    case 'end':
        switch (msg.message) {
        case 'proxy-software-upgrade-prepare':
            this.monitor.onHostMsg(msg, msg.message.replace('proxy-', ''), bin, (type, data) => {
                if (type === 'error')
                    this.respMsg(msg, { error: data });
                else
                    this.respMsg(msg, data || {});
            });
            break;
        default:
            this.log(LOG_ERROR, 'Unknown binary message: ' + msg.message);
            break;
        }
        break;
    }
};

Proxy.prototype.respMsg = function (msg0, msg)
{
    if (this.connected) {
        if (!msg) msg = {};
        msg.message = msg0.message;
        if (msg0.message_id)
            msg.message_id = msg0.message_id;
        this.ws.send(JSON.stringify(msg));
    }
};

Proxy.prototype.onClose = function ()
{
    if (this.connected) {
        this.log(LOG_INFO, 'Disconnected');
        this.sendLock = false;
        this.connected = false;
        this.storeSyncPoll();
        this.ws.close();
        this.ws = null;
        this.timerStop('keepalive-timeout');
        this.timerStop('keepalive-send');
        this.timerStart('start', PROXY_RETRY_DELAY);
    }
};

Proxy.prototype.onError = function (error)
{
    // Error
    var errno = error.errno;
    this.log(errno !== this.wsError ? LOG_ERROR : LOG_WARN, 'Connection error: ' + (error.errno || error), error);
    this.wsError = error.errno;
    this.timerStop('connection-timeout');

    switch (error.errno) {
    case 'ECONNREFUSED':
        this.timerStart('start', PROXY_RETRY_DELAY);
        break;
    default:
        this.timerStart('start', PROXY_RETRY_DELAY);
        break;
    }
};

Proxy.prototype.dataPush = function (data)
{
    var count = this.storeData.push(data);

    // Cache
    if (this.connected) {
        this.timerStart('poll');
    } else {
        this.storeSyncPoll();
    }
};

Proxy.prototype.storeFileCheck = function (filename)
{
    var m = filename.match(/(\d{4})(\d{2})(\d{2})-(\d+:\d+:\d+\.\d+)/)
    if (m) {
        var time = new Date(m[1] + '-' + m[2] + '-' + m[3] + ' ' + m[4] + 'Z') * 1;
        var now = new Date() * 1 - this.timeout;
        if (time >= now) {
            return true;
        }

        this.log(LOG_WARN, filename + ' has expired for ' + ((now - time) / 1000).toFixed(0) + 's');
    }
    return false;
};

Proxy.prototype.storeFileAdd = function (filename)
{
    if (this.storeFileCheck(filename)) {
        this.storeFiles.push(filename);
        return true;
    }
    this.storeFileRemove(filename);
    return false;
};

Proxy.prototype.storeFileRemove = function (filename)
{
    fs.unlink(filename, (err) => {
        if (err)
            this.log(LOG_ERROR, "Can't delete " + filename + ': ' + err);
    });
};

Proxy.prototype.sendPoll = function ()
{
    if (!this.connected || this.storeParsing || this.sendLock) return;

    // First try, to flush store
    while (this.storeFiles.length) {
        var filename = this.storeFiles.shift();

        // Load data
        var data = this.parseJSONFile(filename);

        // Remove file
        this.storeFileRemove(filename);

        // Send ?
        if (data) {
            var threshold = new Date() * 1 - this.timeout;

            // Remove too old data
            data = data.filter( (d) => {
                return d.time > threshold;
            });

            if (data.length > 0) {
                this.sendRemote(data);
                return data.length;
            }
        } else {
            this.log(LOG_ERROR, 'Can\'t load file: ' + this.fsError);
        }
    }

    // Send pending messages messages
    var data = this.storeData.splice(0, this.sendBulkSize);
    if (data.length) {
        this.sendRemote(data);
    }
    return data.length;
};

Proxy.prototype.sendRemote = function (data)
{
    this.sendLock = true;
    this.sendMsg('proxy-data', { data: data });
    // XXX: keep track of data in case of failure ?
};

Proxy.prototype.storeSyncPoll = function ()
{
    if (this.storeSync(this.sendBulkSize))
        this.storeCheck();
}

Proxy.prototype.storeSync = function (threshold)
{
    var storeDir = this.storeDir;
    if (storeDir && this.storeData.length >= threshold) {

        var filename = storeDir + utilsModule.formatDate(new Date(), true);

        fs.writeFileSync(filename, JSON.stringify(this.storeData));

        this.storeFiles.push(filename);
        this.storeData = [];
        return true;
    }
    return false;
};

Proxy.prototype.storeCheck = function ()
{
    // Flush deprecated old files
    while (this.storeFiles.length && !this.storeFileCheck(this.storeFiles[0])) {
        var filename = this.storeFiles.shift();
        this.storeFileRemove(filename);
    };
};

Proxy.prototype.terminate = function ()
{
    this.timerKill();

    if (this.ws) {
        this.ws.close();
        this.ws = null;
    }

    // Save current files
    this.storeSync(1);
};


