#!/bin/bash
# Copyright (C) 2020-2025 Amarisoft
# email sender test version 2025-05-21

HOSTNAME=$(hostname)

if [ ! -e "$3" ] ; then
    echo "Usage:"
    echo "> $0 <sender email> <receiver email> <ssmtp config file>"
    exit 1
fi

/usr/sbin/ssmtp -v -t -C $3 <<MAIL
From: $1
To: $2
Subject: Amarisoft monitor e-mail test

Sent from $(hostname) at $(date)

MAIL




