/*
 * Split 7.2 Transceiver version 2025-05-21
 *
 * Copyright (C) 2023-2025 Amarisoft
 */
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <inttypes.h>
#include <string.h>
#include <getopt.h>
#include <math.h>
#include <assert.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <fcntl.h>
#include <errno.h>
#include <stdatomic.h>
#include <sys/mman.h>
#include <linux/mman.h>
#include <linux/net_tstamp.h>
#include <poll.h>
#include <limits.h>

#include "cutils.h"
#include "trx_driver.h"


#include <net/if.h>
#include <sys/ioctl.h>
#include <linux/if_packet.h>
#include <linux/if_ether.h>
#include <pthread.h>

typedef struct {
    float re, im;
} Complex;


#define ORAN_FRAME_ETHERTYPE 0xAEFE
#define MAX_PACKET_COUNT     64
#define SOCKET_RESET_TIME    1000 /* ms */


#include "oran.h"

#define ECPRI_DEFAULT_PORT 2000
#define DEFAULT_PACKET_SIZE 1472
#define CLOCK_FACTOR_SHIFT 16

//#define GET_PACKET

typedef struct tpacket2_hdr TRXPacketHeader;

typedef struct TRXECPRIState       TRXECPRIState;
typedef struct TRXECPRIRFPortState TRXECPRIRFPortState;
typedef struct TRXPacketFIFO       TRXPacketFIFO;

/* Mimic PACKET_MMAP */
typedef struct {
    __u32 tp_status;
    struct iovec io_vec;

} TRXPacketHeaderUDP;

struct TRXPacketFIFO {
    TRXPacketFIFO *next;
    TRXECPRIRFPortState *rf_port;

    uint8_t *buf;
    int count;
    int size;
    int fd;

    /* TX */
    int margin;
    int window;
    int stalled;
    int64_t reset_time;

    /* Stats */
    int64_t total_size;
    int total_count;
    int drop_count;
    int send_error;

    /* Align to avoid false sharing */
    int head __attribute__((aligned(64)));
    int tail;
    int used __attribute__((aligned(64)));
};

typedef struct {
    TRXECPRIState *ecpri_state;
    pthread_t tid;
    TRXPacketFIFO *tx_fifo;

} TRXECPRITXThread;


typedef struct {
    FILE *file;
    int64_t file_size;
    int packets;
    int loops;
    int slots;

    uint8_t mac[6];
    uint8_t dir;

    /* Current buffer */
    uint8_t *buf;
    int buf_size;
    int buf_len;
    int buf_pos;
    int64_t buf_offset;

} PCAPFile;

struct TRXECPRIRFPortState {
    TRXECPRIState *ecpri_state;
    BOOL first_slot;
    BOOL8 is_ethernet;
    int socket_fd;
    struct sockaddr_storage remote_addr;
    size_t remote_addr_len;
    int scs;
    int numa_node;

    int64_t slot_duration; /* ns */

    uint16_t max_pdu_size;
    int rx_packet_count;

    struct mmsghdr *rx_msg_vec;
    int packet_size;
    struct sockaddr_ll bind_addr;

    /* Ethernet: packet_mmap ring buffer
     * UDP: mimic ethernet
     */
    TRXPacketFIFO rx_fifo;

    PCAPFile *rx_pcap;

    int ta3_max;
    int ta3_min;

    /* Generate start of frame packets locally */
    struct {
        BOOL8 on;
        BOOL8 held;
        uint16_t n_f;
        uint8_t n_sf;
        uint8_t slot_num;
        int64_t next_slot_time; /* ns */
        uint8_t buf[64];

        int64_t timestamp0;
        double ns_per_sample;
    } local_sof;

    struct {
        struct ethhdr header;
        int header_size;
        TRXPacketFIFO tx_fifo;
        char *ifname;
    } eth;

    struct {
        int rf_port_index;
        TRXECPRITXThread *tx_thread;

        TRXPacketFIFO *tx_fifo_up;
        TRXPacketFIFO *tx_fifo_cp;
        TRXPacketFIFO tx_fifo_up1;
        TRXPacketFIFO tx_fifo_cp1;
    } async;

    int64_t stats_time;

    uint8_t slots_per_subframe;
    int rf_port_index;
    char debug_name[32]; /* used in the debug traces */
};

struct TRXECPRIState {
    TRXState *trx_state;

    double clock_factor;
    uint32_t clock_factor_mult; /* clock_factor multiplied by 2^CLOCK_FACTOR_SHIFT */
    int64_t realtime_offset; /* in nanoseconds */
    int tai_offset; /* in seconds */
    int alpha_offset; /* in 1/1.2288 ns unit */
    int beta_offset; /* in 10 ms unit */

    int rf_port_count;
    int stop;
    TRXECPRIRFPortState *rf_ports;
};


static void trx_s72_end(TRXState *s1);

static inline int trx_atomic_get32(int *ptr)
{
    return atomic_load((_Atomic(int) *)ptr);
}

static inline void trx_atomic_set32(int *ptr, int val)
{
    atomic_store((_Atomic(int) *)ptr, val);
}

static inline int trx_atomic_add32(int *ptr, int val)
{
    return atomic_fetch_add((_Atomic(int) *)ptr, val) + val;
}

static inline int trx_atomic_inc32(int *ptr)
{
    return trx_atomic_add32(ptr, 1);
}


static void s72_err(const TRXECPRIRFPortState *s, const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    if (s) {
        fprintf(stderr, "[S72][%s] ", s->debug_name);
    } else {
        fprintf(stderr, "[S72] ");
    }
    vfprintf(stderr, fmt, ap);
    va_end(ap);
}

static int build_ecpri_start_of_slot(uint8_t *buf, int buf_len_max,
                                     int n_f, int n_sf, int slot_num)
{
    ECPRI_Header *ch;
    ECPRI_PrivateStartOfSlot *sof;
    uint8_t *p;
    int buf_len;

    buf_len = sizeof(ECPRI_Header) + sizeof(ECPRI_PrivateStartOfSlot);
    assert(buf_len_max >= buf_len);

    p = buf;
    ch = (ECPRI_Header *)p;
    p += sizeof(ECPRI_Header);
    ch->msg_header = 0x10;
    ch->msg_type = CPRI_SOF;
    ch->ecpri_size = htons(sizeof(ECPRI_PrivateStartOfSlot));

    sof = (ECPRI_PrivateStartOfSlot *)p;
    p += sizeof(ECPRI_PrivateStartOfSlot);
    sof->n_f = htons(n_f);
    sof->n_sf = n_sf;
    sof->slot_num = slot_num;

    return buf_len;
}


#define rfport_log(s, level, dir, fmt, ...) \
    trx_log1( (s)->ecpri_state->trx_state, level, dir, "port=%d " fmt, (s)->rf_port_index, ## __VA_ARGS__)

static inline void* trx_s72_malloc(size_t size)
{
    void *ptr;
    if (posix_memalign((void**)&ptr, 32, size))
        return NULL;
    return ptr;
}

static inline void* trx_s72_mallocz(size_t size)
{
    void *ptr = trx_s72_malloc(size);
    if (ptr)
        memset(ptr, 0, size);
    return ptr;
}

static inline void trx_s72_free(void *ptr)
{
    free(ptr);
}

static inline char *trx_s72_strdup(const char *str)
{
    return strdup(str);
}

/* Nanoseconds from the frame epoch */
static no_inline int64_t get_time_local(TRXECPRIState *es)
{
    struct timespec ts;
    int64_t ti;
    clock_gettime(CLOCK_REALTIME, &ts);
    ti = (int64_t)ts.tv_sec * 1000000000 + ts.tv_nsec + es->realtime_offset;
    /* apply the clock factor */
    ti = ((__int128)ti * es->clock_factor_mult) >> CLOCK_FACTOR_SHIFT;
    return ti;
}

static inline int64_t get_time_ms(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (int64_t)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
}

static inline  __attribute__((format(printf, 2, 3))) void trx_s72_error(TRXState *s, const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    s->trx_log_func(s->app_opaque2, TRX_LOG_ERROR, TRX_LOG_DIR_UNKNOWN, fmt, ap);
    va_end(ap);
}

typedef struct {
    int64_t local_time;
    int64_t slot_time;
    int slot_pos;
} ClockState;

static inline TRXPacketHeader *fifo_get_packet1(const TRXPacketFIFO *fifo, int idx)
{
    return (TRXPacketHeader*)(fifo->buf + idx * fifo->size);
}

static inline TRXPacketHeader *fifo_get_packet(const TRXPacketFIFO *fifo, int head)
{
    return fifo_get_packet1(fifo, head ? fifo->head : fifo->tail);
}

static inline void fifo_next_packet_head(TRXPacketFIFO *fifo)
{
    if (++fifo->head == fifo->count) fifo->head = 0;
}

static inline void fifo_next_packet_tail(TRXPacketFIFO *fifo)
{
    if (++fifo->tail == fifo->count) fifo->tail = 0;
}

static inline uint8_t *get_packet_data(TRXPacketHeader *h)
{
    return (uint8_t*)h + TPACKET_ALIGN(sizeof(*h));
}

static void *trx_s72_fifo_tx_thread(void *arg)
{
    TRXECPRITXThread *tx_thread = arg;
    TRXECPRIRFPortState *s, *s0;
    TRXECPRIState *es = tx_thread->ecpri_state;
    TRXState *s1 = es->trx_state;
    TRXPacketHeader *h;
    TRXPacketFIFO *fifo;
    int64_t delay, now = 0;
    int n, ret, policy, late, sleep, used;
    struct sched_param sp;
    int64_t window, usleep_delay, size;
    TRXPThreadConfig tcfg;

    memset(&tcfg, 0, sizeof(tcfg));
    tcfg.name = "s72-tx";
    s1->trx_pthread_init(s1->app_opaque2, &tcfg);

    /* Configure thread */
    policy = SCHED_FIFO;
    sp.sched_priority = 45;
    if (pthread_setschedparam(pthread_self(), policy, &sp)) {
        s72_err(NULL, "Can't set real time scheduling: %s.\n", strerror(errno));
        exit(1);
    }

    while (!trx_atomic_get32(&es->stop)) {

        sleep = 1;
        s0 = NULL;
        for (fifo = tx_thread->tx_fifo; fifo; fifo = fifo->next) {
            s = fifo->rf_port;

            if (s0 != s) {
                /* Use same time for fifo of same rf port */
                now = get_time_local(es);
                s0 = s;
            }

            window = fifo->window;
            usleep_delay = window + s->slot_duration / 2;

            delay = usleep_delay;
            late = 0;
            size = 0;
            used = trx_atomic_get32(&fifo->used);
            for (n = 0; n < s->rx_packet_count && used; n++) {

                h = fifo_get_packet(fifo, 0);
                delay = *(uint64_t*)(&h->tp_sec) - now;

                /* Wait timestamp */
                if (delay > window)
                    break;

                if (delay < 0)
                    late++;

                size += h->tp_len;
                if (s->is_ethernet) {
                    h->tp_status = TP_STATUS_SEND_REQUEST;
                    *(uint64_t*)(&h->tp_sec) = 0;
                } else {
                    /* XXX: use sendmmsg */
                    ret = sendto(fifo->fd, get_packet_data(h) + s->eth.header_size, h->tp_len - s->eth.header_size, 0,
                                (struct sockaddr *)&s->remote_addr, s->remote_addr_len);
                    if (ret < 0)
                        s72_err(s, "Can't send UDP packet async: %s\n", strerror(errno));

                    h->tp_status = TP_STATUS_AVAILABLE;
                }
                used = trx_atomic_add32(&fifo->used, -1);
                fifo_next_packet_tail(fifo);
            }

            if (unlikely(late)) {
                rfport_log(s, TRX_LOG_WARN, TRX_LOG_TX, "%d packet(s) late\n", late);
                late = 0;
            }

            if (!n) {
                if (delay < usleep_delay)
                    sleep = 0;
                continue;
            }
            fifo->total_count += n;
            fifo->total_size += size;
            if (s->is_ethernet) {
                ret = send(fifo->fd, NULL, 0, 0);
                if (ret < 0) {
                    if (errno != EAGAIN && errno != EWOULDBLOCK && errno != ENOBUFS)
                        s72_err(s, "Can't send %d packet(s) async: %s (%d)\n", n, strerror(errno), fifo->used);
                    if (errno == ENOBUFS)
                        rfport_log(s, TRX_LOG_ERROR, TRX_LOG_TX, "Can't send, interface may be down\n");
                    trx_atomic_add32(&fifo->send_error, n);
                }
            }
            sleep = 0;
        }
        if (sleep)
            usleep(30);
    }

    s1->trx_pthread_terminate(s1->app_opaque2);

    return NULL;
}

static TRXPacketHeader *trx_s72_add_packet(TRXECPRIRFPortState *s, TRXPacketFIFO *fifo,
                                           const TRXPacketVec *packet, TRXWritePacketMetadata *md)
{
    TRXPacketHeader *h;
    uint8_t *data;
    int status, used, i;
    int64_t now;

    used = trx_atomic_get32(&fifo->used);
    if (likely(used < fifo->count)) {
        h = fifo_get_packet(fifo, 1);
        if (likely(h->tp_status == TP_STATUS_AVAILABLE)) {
            if (unlikely(fifo->stalled)) {
                rfport_log(s, TRX_LOG_WARN, TRX_LOG_TX, "TX fifo running again\n");
                fifo->stalled = 0;
            }

            data = get_packet_data(h);
            h->tp_len = packet->len + s->eth.header_size;
            memcpy(data + s->eth.header_size, packet->data, packet->len);
            return h;
        }
        status = h->tp_status;
    } else {
        status = TP_STATUS_AVAILABLE;
    }

    trx_atomic_inc32(&fifo->drop_count);

    now = get_time_ms();
    if (!fifo->stalled) {
        rfport_log(s, TRX_LOG_WARN, TRX_LOG_TX, "TX fifo stalled @%d status=%x\n", fifo->head, status);
        trx_atomic_set32(&fifo->stalled, 1);
        fifo->reset_time = now + SOCKET_RESET_TIME;

    } else if (!used && fifo->reset_time <= now) {
        rfport_log(s, TRX_LOG_INFO, TRX_LOG_TX, "Reset TX fifo\n");
        for (i = 0; i < fifo->count; i++) {
            h = fifo_get_packet1(fifo, i);
            h->tp_status = TP_STATUS_AVAILABLE;
        }
        fifo->reset_time = now + SOCKET_RESET_TIME;
    }

    if (md->flags & TRX_WRITE_PACKET_MD_UNDERFLOWS)
        md->underflows++;
    return NULL;
}

#ifdef GET_PACKET
static int trx_s72_get_packet(TRXState *s, TRXPacketVec *packet, size_t size, int tx_port_index)
{
    packet->data = trx_s72_malloc(size);
    packet->user_data = NULL;
    return -1;
}
#endif

static void trx_s72_write_packets(TRXState *s1, const TRXPacketVec **packets,
                                  int count, int tx_port_index,
                                  TRXWritePacketMetadata *md)
{
    TRXECPRIState *es = s1->opaque;
    TRXECPRIRFPortState *s;
    TRXPacketHeader *h;
    int64_t tb, timestamp, now, size = 0;
    int i, n, ret;
    struct mmsghdr msg_vec[MAX_PACKET_COUNT], *msg;
    struct iovec io_vec[MAX_PACKET_COUNT], *io;
    TRXPacketFIFO *tx_fifo;

    if (unlikely((unsigned int)tx_port_index >= es->rf_port_count))
        return;
    s = &es->rf_ports[tx_port_index];

    now = get_time_local(es);
    for (i = n = 0; i < count; i++) {
        const TRXPacketVec *packet = packets[i];
        tx_fifo = &s->eth.tx_fifo;

        if (s->local_sof.on && packet->timestamp >= 0) {

            timestamp = s->local_sof.ns_per_sample * packet->timestamp + s->local_sof.timestamp0;

            if (s->async.rf_port_index >= 0) {
                if (packet->is_cp)
                    tx_fifo = s->async.tx_fifo_cp;
                else
                    tx_fifo = s->async.tx_fifo_up;
                timestamp -= tx_fifo->margin;
            }

            /* Time budget */
            tb = timestamp - now + s->ta3_min;
            if (md->flags & TRX_WRITE_PACKET_MD_FLAG_TIME_BUDGET) {
                md->time_budget_set = 1;
                md->time_budget_us  = tb / 1000;
            }
            if (tb <= 0) {
                md->underflows++;
                continue;
            }

            if (s->async.rf_port_index >= 0) {
                h = trx_s72_add_packet(s, tx_fifo, packet, md);
                if (h) {
                    *(uint64_t*)(&h->tp_sec) = timestamp;
                    fifo_next_packet_head(tx_fifo);
                    trx_atomic_inc32(&tx_fifo->used);
                }
                continue;
            }
        }

        size += packet->len;
        if (s->is_ethernet) {
            h = trx_s72_add_packet(s, tx_fifo, packet, md);
            if (h) {
                h->tp_status = TP_STATUS_SEND_REQUEST;
                fifo_next_packet_head(tx_fifo);
                n++;
            }

        } else {
            msg = &msg_vec[n];
            io = &io_vec[n];

            msg->msg_hdr.msg_flags = 0;
            msg->msg_hdr.msg_iov = io;
            msg->msg_hdr.msg_iovlen = 1;
            msg->msg_hdr.msg_name = (struct sockaddr *)&s->remote_addr;
            msg->msg_hdr.msg_namelen = s->remote_addr_len;
            msg->msg_hdr.msg_control = NULL;
            msg->msg_hdr.msg_controllen = 0;
            io->iov_base = packet->data;
            io->iov_len = packet->len;
            n++;
        }
    }
    if (n) {
        tx_fifo = &s->eth.tx_fifo;
        tx_fifo->total_count += n;
        tx_fifo->total_size += size;
        if (s->is_ethernet) {
            ret = send(tx_fifo->fd, NULL, 0, 0);
        } else {
            ret = sendmmsg(s->socket_fd, msg_vec, n, 0);
        }

        if (ret < 0) {
            if (errno != EAGAIN && errno != EWOULDBLOCK)
                trx_s72_error(s1, "Can't send %d packet(s) @%d: %s\n", n, tx_fifo->head, strerror(errno));
        } else if (ret < n) {
            trx_s72_error(s1, "Only %d packets out of %d sent @%d\n", ret, n, tx_fifo->head);
            if (md->flags & TRX_WRITE_PACKET_MD_UNDERFLOWS)
                md->underflows += (n - ret);
        }
    }

#ifdef GET_PACKET
    for (i = 0; i < count; i++) {
        trx_s72_free(packets[i]->data);
    }
#endif
}

/* use the PC clock to time the eCPRI */
static int master_build_ecpri_start_of_slot(TRXECPRIState *es, TRXECPRIRFPortState *s,
                                            uint8_t *buf, int buf_len_max)
{
    if (get_time_local(es) >= s->local_sof.next_slot_time) {
        /* increment time by one slot */
        s->local_sof.next_slot_time += s->slot_duration;
        if (++s->local_sof.slot_num == s->slots_per_subframe) {
            s->local_sof.slot_num = 0;
            if (++s->local_sof.n_sf == 10) {
                s->local_sof.n_sf = 0;
                s->local_sof.n_f = (s->local_sof.n_f + 1) & 1023;
            }
        }
        return build_ecpri_start_of_slot(buf, buf_len_max, s->local_sof.n_f,
                                         s->local_sof.n_sf, s->local_sof.slot_num);
    }
    return -1;
}

static BOOL trx_s72_check_packet(TRXState *s1, TRXECPRIRFPortState *s, const uint8_t *buf, int buf_len)
{
    const ECPRI_Header *ch;

    if (buf_len < sizeof(*ch))
        return FALSE;

    if (!s->local_sof.on)
        return TRUE;

    if (buf_len >= sizeof(*ch) + sizeof(ECPRI_PrivateStartOfSlot)) {
        ch = (const ECPRI_Header*)buf;
        if (ntohs(ch->ecpri_size) == sizeof(ECPRI_PrivateStartOfSlot) &&
            ch->msg_header == 0x10 &&
            ch->msg_type == CPRI_SOF) {
            return FALSE;
        }
    }
    return TRUE;
}

struct pcap_timeval {
    int32_t tv_sec;		/* seconds */
    int32_t tv_usec;		/* microseconds */
};

struct pcap_sf_pkthdr {
    struct pcap_timeval ts;	/* time stamp */
    uint32_t caplen;		/* length of portion present */
    uint32_t len;		/* length this packet (off wire) */
};

struct pcap_file_header {
    uint32_t magic;
    uint16_t version_major;
    uint16_t version_minor;
    int32_t thiszone;	/* gmt to local correction */
    uint32_t sigfigs;	/* accuracy of timestamps */
    uint32_t snaplen;	/* max length saved portion of each pkt */
    uint32_t linktype;	/* data link type (LINKTYPE_*) */
};

static int trx_s72_pcap_load_at(PCAPFile *pf, int64_t offset, int min_size)
{
    int64_t size;

    size = pf->file_size - offset;
    if (size > pf->buf_size)
        size = pf->buf_size;

    //printf("Load at %"PRId64", size=%"PRId64"\n", offset, size);
    if (size < min_size) {
        if (!pf->packets) {
            fprintf(stderr, "No packet found in pcap\n");
            return -1;
        }
        if (!pf->loops++) {
            printf("%d packets in %d slots found in pcap\n", pf->packets, pf->slots);
        }
        offset = sizeof(struct pcap_file_header);
    }

    fseek(pf->file, offset, SEEK_SET);

    pf->buf_len = fread(pf->buf, 1, size, pf->file);
    if (pf->buf_len != size) {
        fprintf(stderr, "Can't read pcap file\n");
        return -1;
    }
    pf->buf_offset = offset;
    pf->buf_pos = 0;
    return 0;
}

static int trx_s72_read_pcap(TRXECPRIRFPortState *s, TRXPacketVec **packets, int max_packets)
{
    struct ethhdr *eth;
    struct pcap_sf_pkthdr *ph;
    const ECPRI_Header *ech;
    const ORAN_Header *oh;
    uint8_t *p;
    int n_f, n_sf, slot_num, symb, n = 0, dir;
    uint16_t proto;
    PCAPFile *pf = s->rx_pcap;

    for (; n < max_packets; pf->buf_pos += ph->caplen + sizeof(*ph)) {

        /* Load enough data */
        if (pf->buf_len - pf->buf_pos < sizeof(*ph) &&
            trx_s72_pcap_load_at(pf, pf->buf_offset + pf->buf_pos, sizeof(*ph)) < 0)
            return -1;

        ph = (struct pcap_sf_pkthdr*)&pf->buf[pf->buf_pos];
        if (pf->buf_len - pf->buf_pos < ph->caplen + sizeof(*ph)) {
            if (trx_s72_pcap_load_at(pf, pf->buf_offset + pf->buf_pos, ph->caplen + sizeof(*ph)) < 0)
                return -1;
            ph = (struct pcap_sf_pkthdr*)&pf->buf[pf->buf_pos];
        }

        /* Ethernet */
        eth = (struct ethhdr*)(ph + 1);
        if (memcmp(eth->h_dest, pf->mac, 6)) continue;

        p = (uint8_t*)(eth + 1);
        proto = ntohs(eth->h_proto);
        if (proto == 0x8100) { // VLAN
            proto = ntohs(((uint16_t*)eth)[8]);
            p += 4;
        }
        if (proto != ORAN_FRAME_ETHERTYPE) continue;

        /* eCPRI */
        ech = (const ECPRI_Header *)p;
        if (ech->msg_header != 0x10) continue;
        if (ech->msg_type != CPRI_IQ && ech->msg_type != CPRI_Control) continue;

        /* ORAN */
        oh = (const ORAN_Header *)(ech + 1);
        dir = oh->payload_dir >> 7;
        if (dir != pf->dir) continue;

        symb = ntohs(oh->slot_symb);
        n_f = oh->frame_id;
        n_sf = symb >> 12;
        slot_num = (symb >> 6) & 0x3f;

        if (ech->msg_type == CPRI_Control || ((s->local_sof.n_f & 0xff) == n_f && s->local_sof.n_sf == n_sf && s->local_sof.slot_num == slot_num)) {
            packets[n]->data = p;
            packets[n]->len = ph->caplen + (p - (uint8_t*)eth);
            packets[n]->user_data = NULL;
            if (!pf->loops) {
                if (n == 0)
                    pf->slots++; /* Not fully true if more than max_packets */
                pf->packets++;
            }
            n++;

        } else {
            break;
        }
    }
    return n;
}


static int trx_s72_read_packets(TRXState *s1,
                                TRXPacketVec **packets, int max_packets,
                                int rx_port_index, TRXReadPacketMetadata *md)
{
    TRXECPRIState *es = s1->opaque;
    TRXECPRIRFPortState *s;
    TRXPacketFIFO *fifo;
    TRXPacketHeader *h;
    int ret, i, idx, n = 0;
    int64_t slot_num, size = 0;

    if (unlikely((unsigned int)rx_port_index >= es->rf_port_count))
        return -1;
    s = &es->rf_ports[rx_port_index];

    if (unlikely(s->first_slot)) {
        s->stats_time = get_time_local(es);
        slot_num = s->stats_time / s->slot_duration;
        s->local_sof.next_slot_time = (slot_num + 1) * s->slot_duration;
        s->local_sof.slot_num = slot_num % s->slots_per_subframe;
        s->local_sof.n_sf = (slot_num / s->slots_per_subframe) % 10;
        s->local_sof.n_f = (slot_num / (10 * s->slots_per_subframe)) & 1023;
        s->local_sof.timestamp0 = s->local_sof.next_slot_time;
        s->local_sof.next_slot_time += s->ta3_max;
        s->first_slot = FALSE;
    }

    fifo = &s->rx_fifo;

    /* Send previous buffers back to kernel */
    if (md->flags & TRX_READ_PACKET_MD_FLAG_RELEASE) {
        for (i = 0; i < md->release_count; i++) {
            idx = (intptr_t)packets[i]->user_data;
            if (idx > 0) {
                h = fifo_get_packet1(fifo, --idx);
                h->tp_status = TP_STATUS_KERNEL;
                fifo->used--;
            } else {
                s->local_sof.held = FALSE;
            }
        }
    }

    if (unlikely(s->rx_pcap)) {
        n = trx_s72_read_pcap(s, packets, max_packets);
        if (n < 0)
            return n;

    } else if (s->is_ethernet) {

        /* Read as many packets as possible */
        while (n < max_packets) {
            h = fifo_get_packet(fifo, 1);
            if (h->tp_status == TP_STATUS_KERNEL)
                break;

            packets[n]->data = ((uint8_t*)h) + h->tp_mac + sizeof(s->eth.header);
            packets[n]->len = h->tp_len - sizeof(s->eth.header);
            packets[n]->user_data = (void*)(intptr_t)(fifo->head + 1);

            size += h->tp_len;
            if (trx_s72_check_packet(s1, s, packets[n]->data, packets[n]->len))
                n++;
            else
                h->tp_status = TP_STATUS_KERNEL; /* We don't need it */
            fifo_next_packet_head(fifo);
        }
    } else {
        TRXPacketHeaderUDP *h1;

        /* Read as many packets as possible */
        i = fifo->head;
        while (n < max_packets) {
            h = fifo_get_packet1(fifo, i);
            if (h->tp_status == TP_STATUS_USER)
                break;

            h1 = (TRXPacketHeaderUDP*)h;
            s->rx_msg_vec[n].msg_hdr.msg_iov = &h1->io_vec;
            if (++i == fifo->count)
                i = 0;
            n++;
        }
        if (!n) {
            s72_err(s, "No packet available for reception\n");
            return 0;
        }

        ret = recvmmsg(s->socket_fd, s->rx_msg_vec, n, MSG_TRUNC, NULL);
        if (ret < 0) {
            n = 0;
            switch (errno) {
            case EAGAIN:
#if EAGAIN != EWOULDBLOCK
            case EWOULDBLOCK:
#endif
            case EINTR:
                break;
            default:
                trx_s72_error(s1, "TRX s72 RX socket error: %s\n", strerror(errno));
                return ret;
            }

        } else {
            for (i = n = 0; i < ret; i++) {
                h = fifo_get_packet(fifo, 1);

                h1 = (TRXPacketHeaderUDP*)h;
                packets[n]->data = h1->io_vec.iov_base;
                packets[n]->len = min_int(s->rx_msg_vec[i].msg_len, s->packet_size);
                packets[n]->user_data = (void*)(intptr_t)(fifo->head + 1);

                if (trx_s72_check_packet(s1, s, packets[n]->data, packets[n]->len)) {
                    h->tp_status = TP_STATUS_USER;
                    n++;
                } else {
                    h->tp_status = TP_STATUS_KERNEL; /* We don't need it */
                }
                fifo_next_packet_head(fifo);
            }
        }
    }

    fifo->used += n;
    fifo->total_count += n;
    fifo->total_size += size;

    /* No more packets in socket so let's try to generate SOF packet */
    if (!s->local_sof.held && n < max_packets) {
        ret = master_build_ecpri_start_of_slot(es, s, s->local_sof.buf, sizeof(s->local_sof.buf));
        if (ret > 0) {
            packets[n]->data = s->local_sof.buf;
            packets[n]->len = ret;
            packets[n]->user_data = NULL;
            s->local_sof.held = TRUE;
            n++;
        }
    }

    if (n == 0) {
        /* Nothing so wait a bit to avoid busy polling */
        usleep(30);
    }
    return n;
}

static double trx_s72_get_symb_size(TRXECPRIState *es, TRXECPRIRFPortState *s, int bandwidth)
{
    double clock_factor = es->clock_factor;
    if (clock_factor < 0.1)
        clock_factor = 0.1;
    /* 4 bytes per IQ */
    return (4. * bandwidth / (s->scs * 1e3)) / clock_factor;
}

static int trx_s72_create_eth_socket(TRXECPRIRFPortState *s)
{
    int fd, packet_version = TPACKET_V2, bypass = 1;

    fd = socket(PF_PACKET, SOCK_RAW, htons(ORAN_FRAME_ETHERTYPE));
    if (fd < 0) {
        s72_err(s, "could not open RAW ethernet socket\n");
        return -1;
    }

    if (fcntl(fd, F_SETFL, O_NONBLOCK) < 0) {
        s72_err(s, "Can't set non blocking: %s\n", strerror(errno));
        close(fd);
        return -1;
    }

    if (setsockopt(fd, SOL_PACKET, PACKET_VERSION, &packet_version, sizeof(packet_version)) < 0) {
        s72_err(s, "Can't set packet version: %s\n", strerror(errno));
        close(fd);
        return -1;
    }

    if (bind(fd, (struct sockaddr *)&s->bind_addr, sizeof(s->bind_addr)) < 0) {
        s72_err(s, "Can't bind socket: %s\n", strerror(errno));
        close(fd);
        return -1;
    }

    if (setsockopt(fd, SOL_PACKET, PACKET_QDISC_BYPASS, &bypass, sizeof(bypass)) < 0)
        s72_err(s, "Can't bypass qdisc: %s\n", strerror(errno));

    return fd;
}

static void trx_s72_tx_fifo_init(TRXECPRIRFPortState *s, TRXPacketFIFO *fifo)
{
    TRXPacketHeader *h;
    int i;

    for (i = 0; i < fifo->count; i++) {
        h = fifo_get_packet(fifo, 1);
        h->tp_status = TP_STATUS_AVAILABLE;
        memcpy(get_packet_data(h), &s->eth.header, s->eth.header_size);
        fifo_next_packet_head(fifo);
    }
}

static int trx_s72_fifo_get_packet_config(TRXECPRIRFPortState *s, struct tpacket_req *req, int min_frame_nr)
{
    /* Cf https://www.kernel.org/doc/Documentation/networking/packet_mmap.txt, Frame strcuture */
    int tp_net = TPACKET_ALIGN(TPACKET_ALIGN(sizeof(TRXPacketHeader)) + sizeof(struct sockaddr_ll) + s->eth.header_size);

    if (min_frame_nr < s->rx_packet_count)
        min_frame_nr = s->rx_packet_count;

    req->tp_frame_size = TPACKET_ALIGN(s->packet_size + tp_net - s->eth.header_size);
    req->tp_block_size = 1 << (32 - clz32(min_frame_nr * req->tp_frame_size - 1)); /* Assume >= page size */
    req->tp_block_nr = 1;
    req->tp_frame_nr = req->tp_block_size / req->tp_frame_size;
    return req->tp_block_nr * req->tp_block_size;
}

static int get_tai_offset(void)
{
    time_t ti, ti1;
    char *tz;
    struct tm tm;

    ti = time(NULL);

    /* get the TAI time, assuming the tzdata is up to date */
    tz = getenv("TZ");
    if (tz)
        tz = strdup(tz);
    setenv("TZ", "right/UTC", 1);
    tzset();
    localtime_r(&ti, &tm);
    if (tz) {
        setenv("TZ", tz, 1);
        free(tz);
    } else
        unsetenv("TZ");
    tzset();

    /* convert back to seconds */
    ti1 = timegm(&tm);
    /* Note: +10 from the TAI definition in 1972 */
    return ti - ti1 + 10;
}

/* GPS epoch in seconds since the Unix epoch */
#define GPS_EPOCH 315964800 /* 1980-01-06 00:00:00 UTC */


static int trx_s72_configure_eth_fifo(TRXECPRIRFPortState *s,
                                      TRXPacketFIFO *rx_fifo, int rx_min_frame_nr,
                                      TRXPacketFIFO *tx_fifo, int tx_min_frame_nr)
{
    struct tpacket_req req_s, *req = &req_s;
    int fd, rx_size, tx_size;
    uint8_t *buf;

    fd = trx_s72_create_eth_socket(s);
    if (fd < 0)
        return -1;

    /* RX */
    if (rx_fifo) {
        rx_size = trx_s72_fifo_get_packet_config(s, req, rx_min_frame_nr);
        if (setsockopt(fd, SOL_PACKET, PACKET_RX_RING, (void*)req, sizeof(*req)) < 0) {
            s72_err(s, "Can't set RX ring: %s\n", strerror(errno));
            return -1;
        }
        rx_fifo->size  = req->tp_frame_size;
        rx_fifo->count = req->tp_frame_nr;

    } else {
        rx_size = 0;
        if (setsockopt(fd, SOL_SOCKET, SO_RCVBUF, &rx_size, sizeof(rx_size)) < 0) {
            s72_err(s, "Can't set empty recv buffer size\n");
            return -1;
        }
    }

    /* TX */
    tx_size = trx_s72_fifo_get_packet_config(s, req, tx_min_frame_nr);
    if (setsockopt(fd, SOL_PACKET, PACKET_TX_RING, (void *) req, sizeof(*req)) < 0) {
        s72_err(s, "Can't set TX ring: %s\n", strerror(errno));
        return -1;
    }
    tx_fifo->size  = req->tp_frame_size;
    tx_fifo->count = req->tp_frame_nr;

    buf = mmap(0, rx_size + tx_size, PROT_READ|PROT_WRITE, MAP_SHARED|MAP_LOCKED, fd, 0);
    if (buf == MAP_FAILED) {
        s72_err(s, "Can't mmap: %s\n", strerror(errno));
        return -1;
    }
    if (rx_fifo) {
        rx_fifo->rf_port = s;
        rx_fifo->fd = fd;
        rx_fifo->buf = buf;
        buf += rx_size;
    }
    tx_fifo->rf_port = s;
    tx_fifo->fd = fd;
    tx_fifo->buf = buf;

    trx_s72_tx_fifo_init(s, tx_fifo);
    return 0;
}

static void trx_s72_configure_udp_fifo(TRXECPRIRFPortState *s, int fd,
                                       TRXPacketFIFO *fifo, int count)
{
    fifo->rf_port = s;
    fifo->fd    = fd;
    fifo->count = count;
    fifo->size  = s->packet_size + sizeof(TRXPacketHeaderUDP);
    fifo->buf   = trx_s72_mallocz(fifo->count * fifo->size);
}

static int trx_s72_start(TRXState *s1, const TRXDriverParams2 *p)
{
    TRXECPRIState *es = s1->opaque;
    TRXECPRIRFPortState *s;
    TRXECPRITXThread *tx_thread;
    int pps_tx, pps_rx, rx_size, rx_size1, tx_size, tx_size1;
    int i, rx_count, tx_count_cp, tx_count_up, mu;
    socklen_t size_len;
    int rf_port_index, tx_idx, rx_idx;

    if (!p->s72_enable) {
        s72_err(NULL, "split 7.2 mode must be enabled\n");
        return -1;
    }
    if (p->rf_port_count != es->rf_port_count) {
        s72_err(NULL, "Bad rf port number: %d, should be %d\n", p->rf_port_count, es->rf_port_count);
        return -1;
    }

    /* Create thread contexts */
    for (rf_port_index = 0; rf_port_index < es->rf_port_count; rf_port_index++) {
        s = &es->rf_ports[rf_port_index];
        if (s->async.rf_port_index == rf_port_index) {
            s->async.tx_thread = trx_s72_mallocz(sizeof(*s->async.tx_thread));
            s->async.tx_thread->ecpri_state = es;
        }
    }

    for (rf_port_index = tx_idx = rx_idx = 0; rf_port_index < es->rf_port_count; rf_port_index++) {
        s = &es->rf_ports[rf_port_index];
        s->rf_port_index = rf_port_index;

        snprintf(s->debug_name, sizeof(s->debug_name), "#%d", rf_port_index);

        for (i = 0; i < p->cell_count; i++) {
            TRXCellInfo *ci = &p->cell_info[i];
            if (ci->rf_port_index != rf_port_index) continue;

            if (ci->type == TRX_NRCELL_TYPE_FDD) {
                mu = ci->u.nr_fdd.dl_subcarrier_spacing;
            } else if (ci->type == TRX_NRCELL_TYPE_TDD) {
                mu = ci->u.nr_tdd.dl_subcarrier_spacing;
            } else {
                s72_err(NULL, "Only NR cells allowed for split 7.2\n");
                return -1;
            }
            s->scs = 15 << mu;
            s->slots_per_subframe = 1 << mu;
            /* XXX: we assume all the slots have the same duration */
            s->slot_duration = 1000000 >> mu; /* ns */
            break;
        }
        assert(s->scs);

        if (s->async.rf_port_index < 0) {
            tx_thread = NULL;
        } else if (s->async.rf_port_index == rf_port_index) {
            tx_thread = s->async.tx_thread;
        } else {
            tx_thread = es->rf_ports[s->async.rf_port_index].async.tx_thread;
        }

        /* Packets per symbol */
        pps_tx = ceil(trx_s72_get_symb_size(es, s, p->tx_bandwidth[tx_idx]) / s->packet_size) * p->tx_port_channel_count[rf_port_index];
        pps_rx = ceil(trx_s72_get_symb_size(es, s, p->rx_bandwidth[rx_idx]) / s->packet_size) * p->rx_port_channel_count[rf_port_index];

        /* 3 slots */
        rx_count = max_int((pps_rx * 14 + p->rx_port_channel_count[rf_port_index]) * 3, s->rx_packet_count);

        /* 1ms */
        tx_count_cp = p->tx_port_channel_count[rf_port_index] * s->slots_per_subframe * 2 ;
        tx_count_up = (pps_tx * 14) * s->slots_per_subframe;
        if (tx_thread) {
            tx_count_cp *= 5;
            tx_count_up *= 5;
        }

        if (s->is_ethernet) {
            if (!tx_thread) {
                if (trx_s72_configure_eth_fifo(s, &s->rx_fifo, rx_count,
                                              &s->eth.tx_fifo, tx_count_cp + tx_count_up) < 0)
                    return -1;

            } else {
                if (trx_s72_configure_eth_fifo(s, &s->rx_fifo, rx_count, &s->eth.tx_fifo, tx_count_cp) < 0 ||
                    trx_s72_configure_eth_fifo(s, NULL, 0, s->async.tx_fifo_up, tx_count_up) < 0)
                        return -1;
                if (s->async.tx_fifo_up != s->async.tx_fifo_cp &&
                    trx_s72_configure_eth_fifo(s, NULL, 0, s->async.tx_fifo_cp, tx_count_cp) < 0)
                    return -1;
            }
            s->socket_fd = s->eth.tx_fifo.fd;

        } else {
            TRXPacketHeaderUDP *h;

            /* Send buffer size (1 slot + 10% control) */
            tx_size = (pps_tx * 14) * s->packet_size * 1.1;
            if (setsockopt(s->socket_fd, SOL_SOCKET, SO_SNDBUF, &tx_size, sizeof(tx_size)) < 0) {
                s72_err(s, "can't set send buffer size\n");
            }
            size_len = sizeof(tx_size1);
            if (getsockopt(s->socket_fd, SOL_SOCKET, SO_SNDBUF, &tx_size1, &size_len) < 0) {
                s72_err(s, "can't check send buffer size: %s\n", strerror(errno));
            }
            if (tx_size1 < tx_size) {
                s72_err(s, "warning, could not set send buffer size to %d (current value is %d)\n",
                        tx_size, tx_size1);
            }

            /* Receive buffer size (1 slot + 10% control) */
            rx_size = (pps_rx * 14) * s->packet_size * 4 * 1.1;
            if (setsockopt(s->socket_fd, SOL_SOCKET, SO_RCVBUF, &rx_size, sizeof(rx_size)) < 0) {
                s72_err(s, "can't set recv buffer size\n");
            }
            size_len = sizeof(rx_size1);
            if (getsockopt(s->socket_fd, SOL_SOCKET, SO_RCVBUF, &rx_size1, &size_len) < 0) {
                s72_err(s, "can't check recv buffer size: %s\n", strerror(errno));
            }
            if (rx_size1 < rx_size) {
                s72_err(s, "warning, could not set recv buffer size to %d (current value is %d)\n",
                        rx_size, rx_size1);
            }

            trx_s72_configure_udp_fifo(s, s->socket_fd, &s->rx_fifo, rx_count);
            for (i = 0; i < s->rx_fifo.count; i++) {
                h = (TRXPacketHeaderUDP*)fifo_get_packet1(&s->rx_fifo, i);
                h->tp_status = TP_STATUS_KERNEL;
                h->io_vec.iov_base = (h + 1);
                h->io_vec.iov_len = s->packet_size;
            }

            s->rx_msg_vec = trx_s72_mallocz(s->rx_packet_count * sizeof(*s->rx_msg_vec));
            for (i = 0; i < s->rx_packet_count; i++)
                s->rx_msg_vec[i].msg_hdr.msg_iovlen = 1;

            if (tx_thread) {
                if (s->async.tx_fifo_up != s->async.tx_fifo_cp) {
                    trx_s72_configure_udp_fifo(s, s->socket_fd, s->async.tx_fifo_cp, tx_count_cp);
                    trx_s72_tx_fifo_init(s, s->async.tx_fifo_cp);
                }
                trx_s72_configure_udp_fifo(s, s->socket_fd, s->async.tx_fifo_up, tx_count_up);
                trx_s72_tx_fifo_init(s, s->async.tx_fifo_up);
            }
        }

        if (tx_thread) {
            /* Add FIFO */
            if (s->async.tx_fifo_up != s->async.tx_fifo_cp) {
                s->async.tx_fifo_cp->next = s->async.tx_fifo_up;
                s->async.tx_fifo_up->next = tx_thread->tx_fifo;
                tx_thread->tx_fifo = s->async.tx_fifo_cp;
            } else {
                s->async.tx_fifo_up->next = tx_thread->tx_fifo;
                tx_thread->tx_fifo = s->async.tx_fifo_cp;
            }
        }
        tx_idx += p->tx_port_channel_count[rf_port_index];
        rx_idx += p->rx_port_channel_count[rf_port_index];
    }

    /* Flush */
    for (rf_port_index = 0; rf_port_index < es->rf_port_count; rf_port_index++) {
        s = &es->rf_ports[rf_port_index];
        if (s->is_ethernet) {
            for (;;) {
                TRXPacketHeader *h = fifo_get_packet(&s->rx_fifo, 1);
                if (!h->tp_status) {
                    s->rx_fifo.tail = s->rx_fifo.head;
                    break;
                }
                h->tp_status = TP_STATUS_KERNEL;
                fifo_next_packet_head(&s->rx_fifo);
            }
        } else {
            while (recv(s->socket_fd, s->rx_fifo.buf + sizeof(TRXPacketHeaderUDP), 64, MSG_TRUNC) > 0);
        }

        if (s->local_sof.on) {
            s->first_slot = TRUE;
            s->local_sof.ns_per_sample = 1000000000. * p->sample_rate[rf_port_index].den / p->sample_rate[rf_port_index].num;
        }
    }

    /* Async TX thread */
    for (rf_port_index = 0; rf_port_index < es->rf_port_count; rf_port_index++) {
        s = &es->rf_ports[rf_port_index];
        if (s->async.tx_thread && pthread_create(&s->async.tx_thread->tid, NULL,
                                                 trx_s72_fifo_tx_thread, s->async.tx_thread) < 0) {

            s72_err(s, "Can't start TX fifo thread: %s\n", strerror(errno));
            return -1;
        }
    }
    return 0;
}

static void trx_s72_set_tx_gain_internal(TRXState *s1, double gain, int channel_num)
{
}

static void trx_s72_set_rx_gain_internal(TRXState *s1, double gain, int channel_num)
{
}

static int trx_s72_get_abs_tx_power(TRXState *s1, float *presult,
                                    int channel_num)
{
    *presult = 0;
    return 0;
}

static int trx_s72_get_abs_rx_power(TRXState *s1, float *presult,
                                    int channel_num)
{
    *presult = 0;
    return 0;
}

/* This function can be used to automatically set the sample
 * rate.
 */
static int trx_s72_get_sample_rate(TRXState *s, TRXFraction *psample_rate,
                                   int *psample_rate_num, int sample_rate_min)
{
    static int sr[] = {
         1.920e6,
         7.68e6,
        15.360e6,
        30.720e6,
        61.440e6,
       122.880e6,
       230.400e6,
       245.760e6,
         0
    };
    int i;

    for (i = 0; sr[i]; i++) {
        if (sr[i] >= sample_rate_min * 1.15) {
            psample_rate->num = sr[i];
            psample_rate->den = 1;
            *psample_rate_num = sr[i] / 1.92e6;
            return sr[i];
        }
    }

    return -1;
}

static int trx_s72_get_param_ip(struct sockaddr_storage *addr, const char *str, int default_port)
{
    const char *p, *p1;
    char host_addr[256];
    struct addrinfo hints;
    struct addrinfo *result, *rp;
    int port, len;
    
    if (*str == '[') {
        str++;
        p = strchr(str, ']');
        if (!p)
            return -1;
        len = p - str;
        p++;
    } else {
        p = strchr(str, ':');
        if (p) {
            p1 = strchr(p + 1, ':');
            if (p1) {
                /* if two ':', then we consider it is a ipv6 address
                   without port */
                goto no_port;
            }
            len = p - str;
        } else {
        no_port:
            p = NULL;
            len = strlen(str);
        }
    }
    if (len >= sizeof(host_addr))
        return -1;
    memcpy(host_addr, str, len);
    host_addr[len] = '\0';

    memset(&hints, 0, sizeof(struct addrinfo));
    hints.ai_family = AF_UNSPEC;    /* Allow IPv4 or IPv6 */
    hints.ai_socktype = 0;
    hints.ai_flags = 0;
    hints.ai_protocol = SOCK_DGRAM; /* don't really care */
    hints.ai_canonname = NULL;
    hints.ai_addr = NULL;
    hints.ai_next = NULL;
    
    if (getaddrinfo(host_addr, NULL, &hints, &result) != 0)
        return -1;

    rp = result;
    if (!rp)
        return -1;
    memset(addr, 0, sizeof(*addr));
    memcpy(addr, rp->ai_addr, rp->ai_addrlen);

    freeaddrinfo(result);

    /* set the port */
    if (p && *p == ':') {
        port = strtoul(p + 1, NULL, 10);
    } else {
        port = default_port;
    }

    switch(addr->ss_family) {
    case AF_INET6:
        {
            struct sockaddr_in6 *sa = (struct sockaddr_in6 *)addr;
            sa->sin6_port = htons(port);
        }
        break;
    case AF_INET:
        {
            struct sockaddr_in *sa = (struct sockaddr_in *)addr;
            sa->sin_port = htons(port);
        }
        break;
    default:
        return -1;
    }
    return 0;
}

static size_t sockaddr_get_len(const struct sockaddr_storage *sa)
{
    switch(sa->ss_family) {
    case AF_INET6:
        return sizeof(struct sockaddr_in6);
    case AF_INET:
        return sizeof(struct sockaddr_in);
    default:
        break;
    }
    return 0;
}

static char *mac2str(uint8_t *mac, char *buf, int buf_len)
{
    snprintf(buf, buf_len, "%02x:%02x:%02x:%02x:%02x:%02x",
            mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
    return buf;
}

static void trx_s72_dump_info_fifo(const char *indent, TRXPacketFIFO *fifo,
                                   int64_t duration, trx_printf_cb cb, void *opaque)
{
    int drop_count, send_error;
    double bitrate = (double)fifo->total_size * 8e9 / duration;
    fifo->total_size = 0;
    fifo->total_count = 0;

    if (trx_atomic_get32(&fifo->stalled))
        cb(opaque, "%s    Stalled\n", indent);
    if (bitrate >= 1e9)
        cb(opaque, "%s    Bitrate:  %.3fgbps\n", indent, bitrate / 1e9);
    else if (bitrate >= 1e6)
        cb(opaque, "%s    Bitrate:  %.fmbps\n", indent, bitrate / 1e6);
    else
        cb(opaque, "%s    Bitrate:  %.fkbps\n", indent, bitrate / 1e3);
    cb(opaque, "%s    Packets:  %d\n", indent, fifo->total_count);
    if (fifo->size) {
        cb(opaque, "%s    Size:     %d\n", indent, fifo->size);
        cb(opaque, "%s    Count:    %d (%d%%)\n", indent, fifo->count, 100 * trx_atomic_get32(&fifo->used) / fifo->count);
    }
    drop_count = trx_atomic_get32(&fifo->drop_count);
    if (drop_count) {
        cb(opaque, "%s    Dropped   %d\n", indent, drop_count);
        trx_atomic_set32(&fifo->drop_count, 0);
    }
    send_error = trx_atomic_get32(&fifo->send_error);
    if (fifo->send_error) {
        cb(opaque, "%s    TX error  %d\n", indent, send_error);
        trx_atomic_set32(&fifo->send_error, 0);
    }
}

static void trx_s72_dump_info_tx_fifo(const char *name, TRXPacketFIFO *tx_fifo,
                                      int64_t duration, trx_printf_cb cb, void *opaque)
{
    cb(opaque, "    %s:\n", name);
    trx_s72_dump_info_fifo("  ", tx_fifo, duration, cb, opaque);
    cb(opaque, "      T1A max:  %dus\n", (tx_fifo->margin + tx_fifo->window) / 1000);
    cb(opaque, "      T1A min:  %dus\n", tx_fifo->margin / 1000);
}

static void trx_s72_dump_info(TRXState *s1, trx_printf_cb cb, void *opaque)
{
    TRXECPRIState *es = s1->opaque;
    char tmp[18];
    int i;
    int64_t duration, now;
    struct timespec ts;
    clock_gettime(CLOCK_REALTIME, &ts);

    cb(opaque, "TRX split 7.2 example version " CONFIG_VERSION "\n");
    cb(opaque, "Clock factor:   %g\n", es->clock_factor);
    cb(opaque, "Epoch:          %"PRId64"s\n", ts.tv_sec);
    cb(opaque, "TAI offset:     %ds\n", es->tai_offset);
    cb(opaque, "Apha offset:    %d\n", es->alpha_offset);
    cb(opaque, "Beta offset:    %d\n", es->beta_offset);

    now = get_time_local(es);
    for (i = 0; i < es->rf_port_count; i++) {
        TRXECPRIRFPortState *s = &es->rf_ports[i];

        duration = now - s->stats_time;
        s->stats_time = now;

        cb(opaque, "RF port %s\n", s->debug_name);
        cb(opaque, "  PDU max size: %d\n", s->max_pdu_size);
        if (s->is_ethernet) {
            cb(opaque, "  Ethernet mode\n");
            cb(opaque, "    Interface:  %s\n", s->eth.ifname);
            cb(opaque, "    Destination %s\n", mac2str(s->eth.header.h_dest, tmp, sizeof(tmp)));
        } else {
            cb(opaque, "  UDP mode\n");
        }
        cb(opaque, "  RX FIFO:\n");
        trx_s72_dump_info_fifo("", &s->rx_fifo, duration, cb,opaque);
        cb(opaque, "  TX FIFO:\n");
        trx_s72_dump_info_fifo("", &s->eth.tx_fifo, duration, cb,opaque);
        if (s->async.rf_port_index >= 0) {
            cb(opaque, "  Async\n");
            if (s->async.tx_fifo_up != s->async.tx_fifo_cp) {
                trx_s72_dump_info_tx_fifo("Control", s->async.tx_fifo_cp, duration, cb, opaque);
                trx_s72_dump_info_tx_fifo("User", s->async.tx_fifo_up, duration, cb, opaque);
            } else {
                trx_s72_dump_info_tx_fifo("Ctrl/User", s->async.tx_fifo_cp, duration, cb, opaque);
            }
        }
        if (s->local_sof.on) {
            cb(opaque, "  Local SOF:    %d.%d.%d\n",
               s->local_sof.n_f, s->local_sof.n_sf, s->local_sof.slot_num); /* XXX: not thread safe */
        }
        if (s->ta3_max)
            cb(opaque, "  Ta3 max:      %dus\n", s->ta3_max / 1000);
        if (s->ta3_min)
            cb(opaque, "  Ta3 min:      %dus\n", s->ta3_min / 1000);
        if (s->numa_node >= 0)
            cb(opaque, "  Numa node:    %d\n", s->numa_node);
    }
}

static int trx_s72_get_packet_config(TRXState *s1, int rf_port_index, TRXPacketConfig *cfg)
{
    const TRXECPRIState *es = s1->opaque;
    const TRXECPRIRFPortState *s;

    if ((unsigned int)rf_port_index >= es->rf_port_count)
        return -1;
    s = &es->rf_ports[rf_port_index];

    cfg->max_pdu_size = s->max_pdu_size;
    cfg->max_read_packets = s->rx_packet_count;
    cfg->rx_async_release = 1;
    return 0;
}

static void trx_s72_init_common(TRXState *s1, TRXECPRIState *s)
{
    s->trx_state = s1;
    s1->opaque = s;
    s1->trx_start_func2 = trx_s72_start;
    s1->trx_end_func = trx_s72_end;
    s1->trx_get_sample_rate_func = trx_s72_get_sample_rate;
    s1->trx_set_tx_gain_func = trx_s72_set_tx_gain_internal;
    s1->trx_set_rx_gain_func = trx_s72_set_rx_gain_internal;
    s1->trx_get_abs_tx_power_func = trx_s72_get_abs_tx_power;
    s1->trx_get_abs_rx_power_func = trx_s72_get_abs_rx_power;
    s1->trx_write_packet = trx_s72_write_packets;
    s1->trx_read_packet = trx_s72_read_packets;
    s1->trx_get_packet_config = trx_s72_get_packet_config;
}


int parse_mac(uint8_t *mac, const char *str)
{
    const char *p, *p1;
    int n = 0;

    for (p = str;; p = p1 + 1) {
        mac[n++] = strtoul(p, (char **)&p1, 16);
        if (p1 - p != 2)
            return -1;
        if (n == 6) {
            if (*p1)
                return -1;
            return 0;
        }
        if (*p1 != ':')
            return -1;
    }
    return -1;
}

static void trx_s72_end(TRXState *s1)
{
    TRXECPRIState *es = s1->opaque;
    TRXECPRIRFPortState *s;
    int i;

    trx_atomic_set32(&es->stop, 1);

    /* Stop threads */
    for (i = 0; i < es->rf_port_count; i++) {
        s = &es->rf_ports[i];
        if (s->async.tx_thread)
            pthread_join(s->async.tx_thread->tid, NULL);
    }

    for (i = 0; i < es->rf_port_count; i++) {
        s = &es->rf_ports[i];
        if (s->async.rf_port_index >= 0) {
            if (s->is_ethernet) {
                close(s->async.tx_fifo_cp->fd);
                if (s->async.tx_fifo_up != s->async.tx_fifo_cp)
                    close(s->async.tx_fifo_up->fd);
            } else {
                trx_s72_free(s->async.tx_fifo_cp->buf);
                if (s->async.tx_fifo_up != s->async.tx_fifo_cp)
                    trx_s72_free(s->async.tx_fifo_up->buf);
            }
            if (s->async.tx_thread)
                trx_s72_free(s->async.tx_thread);
        }
        /* XXX */
        if (!s->is_ethernet) {
            trx_s72_free(s->rx_fifo.buf);
        } else {
            trx_s72_free(s->eth.ifname);
        }
        if (s->socket_fd >= 0)
            close(s->socket_fd);
        trx_s72_free(s->rx_msg_vec);
    }
    trx_s72_free(es->rf_ports);
    trx_s72_free(es);
}

static int trx_driver_init_port_pcap(TRXState *s1, TRXECPRIRFPortState *s, JSONData *cfg)
{
    const char *filename, *pcap_mac, *dir_str;
    struct pcap_file_header *fh;
    uint8_t mac[6];
    int dir;
    PCAPFile *pf;

    filename = NULL;
    if (s1->json_object_get_string(cfg, "pcap_file", &filename, 1) < 0)
        return -1;
    if (!filename)
        return 0;

    if (s1->json_object_get_string(cfg, "pcap_mac", &pcap_mac, 0) < 0)
        return -1;

    if (parse_mac(mac, pcap_mac) < 0) {
        s1->json_error(cfg, "remote_addr", "invalid pcap_mac addr: '%s'", pcap_mac);
        return -1;
    }

    dir_str = "dl";
    if (s1->json_object_get_string(cfg, "pcap_dir", &dir_str, 1) < 0) {
     dir_error:
        s1->json_error(cfg, "pcap_dir", "invalid direction, must be dl or ul");
        return -1;
    }
    if (!strcmp(dir_str, "dl"))
        dir = 1;
    else if (!strcmp(dir_str, "ul"))
        dir = 0;
    else
        goto dir_error;

    pf = trx_s72_mallocz(sizeof(*pf));
    pf->file = fopen(filename, "r");
    if (!pf->file) {
        fprintf(stderr, "Can't open %s: %s\n", filename, strerror(errno));
        return -1;
    }

    fseek(pf->file, 0, SEEK_END);
    pf->file_size = ftell(pf->file);
    memcpy(pf->mac, mac, sizeof(mac));
    pf->dir = dir; /* DL */
    pf->buf_size = 16 * 1000 * 1000;
    pf->buf = trx_s72_malloc(pf->buf_size);
    if (!pf->buf) {
        fprintf(stderr, "Can't allocate memory for pcap file\n");
        goto fail;
    }

    if (trx_s72_pcap_load_at(pf, 0, sizeof(*fh)) < 0)
        goto fail;

    fh = (struct pcap_file_header*)pf->buf;
    switch (fh->magic) {
    case 0xa1b2c3d4: // PCAP_MAGIC:
    case 0xa1b23c4d: // PCAP_NSEC_MAGIC:
        break;
    default:
        fprintf(stderr, "Not a pcap file\n");
        goto fail;
    }
    pf->buf_pos += sizeof(*fh);
    s->rx_pcap = pf;
    return 0;

 fail:
    fclose(pf->file);
    trx_s72_free(pf->buf);
    trx_s72_free(pf);
    return -1;
}

static int trx_s72_get_numa_nodes2(TRXState *s1, uint64_t *numa_nodes)
{
    TRXECPRIState *es = s1->opaque;
    TRXECPRIRFPortState *s;
    char numa[128];
    FILE *f;
    int i, n;

    for (i = 0; i < es->rf_port_count; i++) {
        s = &es->rf_ports[i];
        numa_nodes[i] = 0;
        snprintf(numa, sizeof(numa), "/sys/class/net/%s/device/numa_node", s->eth.ifname);

        f = fopen(numa, "r");
        if (!f) continue;

        n = fread(numa, 1, sizeof(numa), f);
        if (n > 0 && numa[n-1] == '\n') {
            s->numa_node = strtoul(numa, NULL, 10);
            if (s->numa_node > 0 && s->numa_node < 64)
                numa_nodes[i] = UINT64_C(1) << s->numa_node;
        }
        fclose(f);
    }
    return 0;
}

static int trx_driver_init_port(TRXState *s1, TRXECPRIState *es, int rf_port_index, JSONData *cfg)
{
    struct sockaddr_storage saddr;
    TRXECPRIRFPortState *s;
    const char *str;
    int ret, val_i;
    int t1a_min_cp_dl, t1a_max_cp_dl, t1a_min_up_dl, t1a_max_up_dl;

    s = &es->rf_ports[rf_port_index];
    s->ecpri_state = es;

    str = NULL;
    if (s1->json_object_get_string(cfg, "transport", &str, 1) < 0)
        return -1;
    if (!str || !strcmp(str, "ethernet")) {
        s->is_ethernet = TRUE;
    } else if (!strcmp(str, "udp")) {
        s->is_ethernet = FALSE;
    } else {
        s1->json_error(cfg, "transport", "invalid transport mode");
        return -1;
    }

    /* Generate SOF private packets locally ? */
    val_i = 1;
    if (s1->json_object_get_int(cfg, "local_sof", &val_i, 1) < 0)
        return -1;
    s->local_sof.on = val_i;
    s->local_sof.held = !s->local_sof.on;

    val_i = DEFAULT_PACKET_SIZE;
    if (s1->json_object_get_int(cfg, "max_pdu_size", &val_i, 1) < 0)
        return -1;

    s->rx_packet_count = MAX_PACKET_COUNT;
    s->max_pdu_size = val_i;
    s->packet_size = s->max_pdu_size;

    if (s->is_ethernet) {
        struct ifreq ifr;
        int fd;

        fd = socket(PF_PACKET, SOCK_RAW, htons(ORAN_FRAME_ETHERTYPE));
        if (fd < 0) {
            s72_err(s, "could not open RAW ethernet socket\n");
            return -1;
        }

        if (s1->json_object_get_string(cfg, "bind_interface", &str, 0) < 0)
            return -1;

        s->eth.ifname = trx_s72_strdup(str);
        snprintf(ifr.ifr_name, sizeof(ifr.ifr_name), "%s", str);

        if (ioctl(fd, SIOCGIFHWADDR, &ifr)) {
            s72_err(s, "could not get bind interface MAC address for %s: %s\n",
                    strerror(errno), str);
            close(fd);
            return -1;
        }
        memcpy(s->eth.header.h_source, ifr.ifr_hwaddr.sa_data, ETH_ALEN);

        /* Fill bind_addr */
        memset(&s->bind_addr, 0, sizeof(s->bind_addr));
        s->bind_addr.sll_family = PF_PACKET;
        s->bind_addr.sll_protocol = htons(ORAN_FRAME_ETHERTYPE); 
        if (ioctl(fd, SIOCGIFINDEX, &ifr) < 0)
            s72_err(s, "could not get bind interface index\n");
        s->bind_addr.sll_ifindex = ifr.ifr_ifindex;

        if (s1->json_object_get_string(cfg, "remote_addr", &str, 0) < 0)
            return -1;
        if (parse_mac(s->eth.header.h_dest, str) < 0) {
            s1->json_error(cfg, "remote_addr", "invalid remote_addr: '%s'", str);
            return -1;
        }

        s->eth.header.h_proto = htons(ORAN_FRAME_ETHERTYPE); /* ORAN ethertype identifier */

        close(fd);

        s->eth.header_size = sizeof(s->eth.header);
        s->packet_size += s->eth.header_size;

    } else {
        str = NULL;
        if (s1->json_object_get_string(cfg, "bind_addr", &str, 1) < 0)
            return -1;

        if (!str)
            str = trx_s72_strdup("[::]");

        if (trx_s72_get_param_ip(&saddr, str, 0)) {
            s1->json_error(cfg, "bind_addr", "invalid bind_addr: '%s'", str);
            return -1;
        }

        if (s1->json_object_get_string(cfg, "remote_addr", &str, 0) < 0)
            return -1;

        if (trx_s72_get_param_ip(&s->remote_addr, str, ECPRI_DEFAULT_PORT)) {
            s1->json_error(cfg, "remote_addr", "invalid remote_addr: '%s'", str);
            return -1;
        }

        s->remote_addr_len = sockaddr_get_len(&s->remote_addr);

        s->socket_fd = socket(saddr.ss_family, SOCK_DGRAM, 0);
        if (s->socket_fd < 0) {
            s72_err(s, "could not open UDP socket\n");
            return -1;
        }
        if (fcntl(s->socket_fd, F_SETFL, O_NONBLOCK) < 0)
            perror("fcntl");

        ret = bind(s->socket_fd, (struct sockaddr *)&saddr, sizeof(saddr));
        if (ret < 0) {
            s1->json_error(cfg, "bind_addr", "can't bind socket: '%s'", strerror(errno));
            close(s->socket_fd);
            return -1;
        }
    }

    t1a_min_cp_dl = INT_MAX;
    t1a_max_cp_dl = 0;
    t1a_min_up_dl = 0;
    t1a_max_up_dl = 0;

    if (s1->json_object_get_int_range(cfg, "t1a_min_cp_dl", &t1a_min_cp_dl, 1, -2000, 2000) < 0)
        return -1;
    if (t1a_min_cp_dl != INT_MAX) {
        if (s1->json_object_get_int_range(cfg, "t1a_max_cp_dl", &t1a_max_cp_dl, 0, t1a_min_cp_dl, 2000) < 0 ||
            s1->json_object_get_int_range(cfg, "t1a_min_up_dl", &t1a_min_up_dl, 0, -2000, 2000) < 0 ||
            s1->json_object_get_int_range(cfg, "t1a_max_up_dl", &t1a_max_up_dl, 0, t1a_min_up_dl, 2000) < 0 )
            return -1;
    } else {
        /* Legacy */
        int margin, window;

        margin = 0;
        if (s1->json_object_get_int_range(cfg, "send_margin", &margin, 1, 0, 2000) < 0 ||
            s1->json_object_get_int_range(cfg, "send_window", &window, 1, 0, 2000) < 0)
            return -1;

        if (margin > 0) {
            t1a_min_cp_dl = margin;
            t1a_max_cp_dl = margin + window;
            t1a_min_up_dl = margin;
            t1a_max_up_dl = margin + window;
        } else {
            t1a_min_cp_dl = INT_MAX;
        }
    }

    if (t1a_min_cp_dl == INT_MAX) {
        s->async.rf_port_index = -1;
    } else {
        s->async.rf_port_index = rf_port_index;
        if (s1->json_object_get_int_range(cfg, "tx_thread", &s->async.rf_port_index, 1, 0, es->rf_port_count - 1) < 0)
            return -1;

        /* Convert to nanoseconds */
        t1a_min_cp_dl *= 1000;
        t1a_max_cp_dl *= 1000;
        t1a_min_up_dl *= 1000;
        t1a_max_up_dl *= 1000;

        s->async.tx_fifo_up = &s->async.tx_fifo_up1;
        s->async.tx_fifo_up->margin = t1a_min_up_dl;
        s->async.tx_fifo_up->window = t1a_max_up_dl - t1a_min_up_dl;

        if (t1a_min_cp_dl == t1a_min_up_dl && t1a_max_cp_dl == t1a_max_up_dl) {
            s->async.tx_fifo_cp = s->async.tx_fifo_up;
        } else {
            s->async.tx_fifo_cp = &s->async.tx_fifo_cp1;
            s->async.tx_fifo_cp->margin = t1a_min_cp_dl;
            s->async.tx_fifo_cp->window = t1a_max_cp_dl - t1a_min_cp_dl;
        }
    }

    s->ta3_max = 0;
    if (s1->json_object_get_int_range(cfg, "ta3_max", &s->ta3_max, 1, 0, 1000) < 0)
        return -1;
    s->ta3_max *= 1000;

    s->ta3_min = 0;
    if (s1->json_object_get_int_range(cfg, "ta3_min", &s->ta3_min, 1, 0, 1000) < 0)
        return -1;
    s->ta3_min *= 1000;

    if (trx_driver_init_port_pcap(s1, s, cfg) < 0)
        return -1;

    return 0;
}

int trx_driver_init(TRXState *s1)
{
    TRXECPRIState *es;
    JSONData *rf_ports_el, *rf_port_el;
    int i;

    es = trx_s72_mallocz(sizeof(TRXECPRIState));

    rf_ports_el = NULL;
    if (s1->json_object_get_array(s1->config_root, "rf_ports", &rf_ports_el, 1) < 0)
        return -1;

    if (rf_ports_el) {
        es->rf_port_count = s1->json_array_get_length(rf_ports_el);
        es->rf_ports = trx_s72_mallocz(es->rf_port_count * sizeof(*es->rf_ports));

        for (i = 0; i < es->rf_port_count; i++) {
            rf_port_el = s1->json_array_get(rf_ports_el, i);
            if (s1->json_get_type(rf_port_el) != JSON_TYPE_OBJECT) {
                s1->json_error(rf_port_el, NULL, "must be an object");
                return -1;
            }
            if (trx_driver_init_port(s1, es, i, rf_port_el) < 0)
                return -1;
        }
    } else {
        es->rf_ports = trx_s72_mallocz(sizeof(TRXECPRIRFPortState));
        es->rf_port_count = 1;
        if (trx_driver_init_port(s1, es, 0, s1->config_root) < 0)
            return -1;
    }

    es->tai_offset = get_tai_offset();
    if (s1->json_object_get_int_range(s1->config_root, "tai_offset", &es->tai_offset, 1, -1000, 1000) < 0)
        return -1;

    es->alpha_offset = 0; /* XXX: range */
    if (s1->json_object_get_int_range(s1->config_root, "alpha_offset", &es->alpha_offset, 1, 0, 12288000) < 0)
        return -1;

    es->beta_offset = 0; /* XXX: range */
    if (s1->json_object_get_int_range(s1->config_root, "beta_offset", &es->beta_offset, 1, -32768, 32768) < 0)
        return -1;

    /* add the TAI offset to get the TAI time then remove the TAI -
       GPS constant offset of 19 seconds and use the GPS epoch instead
       of the Unix epoch */
    es->realtime_offset = (int64_t)(es->tai_offset - 19 - GPS_EPOCH) * 1000000000;
    /* adjust with the alpha and beta offsets. See ORAN CUS section
       11.7.2 "System Frame Number Calculation from GPS Time". */
    es->realtime_offset = es->realtime_offset - lrint(es->alpha_offset / 1.2288) -
        (int64_t)es->beta_offset * 10000000;

    /* Clock factor is shared for everybody */
    es->clock_factor = 1.;
    if (s1->json_object_get_double_range(s1->config_root, "clock_factor", &es->clock_factor, 1,
                                         0.0001, (1 << (32 - CLOCK_FACTOR_SHIFT))) < 0)
        return -1;

    es->clock_factor_mult = max_int(lrint(es->clock_factor * (1 << CLOCK_FACTOR_SHIFT)), 1);
    /* set the real value */
    es->clock_factor = (double)es->clock_factor_mult / (1 << CLOCK_FACTOR_SHIFT);


    trx_s72_init_common(s1, es);
    s1->trx_dump_info = trx_s72_dump_info;
    s1->trx_get_numa_nodes2 = trx_s72_get_numa_nodes2;
#ifdef GET_PACKET
    s1->trx_get_packet = trx_s72_get_packet;
#endif

    return 0;
}
