/* 
 * ORAN utilities versio 2025-05-21
 *
 * Copyright (C) 2023-2025 Amarisoft
 */
#ifndef ORAN_H
#define ORAN_H

#define CPRI_IQ         0x00    /* IQ Data message */
#define CPRI_Control    0x02    /* Control message */
#define CPRI_Delay      0x05    /* Delay measurement message */

#define CPRI_SOF        0x40    /* private message: start of slot */

typedef struct {
    uint8_t msg_header;  /* 4b: 1 (protocol version), 3b: 0, 1b: C
                            (0=last, 1=another message follows) */
    uint8_t msg_type; /* see CPRI_x */
    uint16_t ecpri_size;
} ECPRI_Header;

typedef struct {
    uint16_t n_f; /* 0-1023 */
    uint8_t n_sf; /* 0-9 */
    uint8_t slot_num; /* 0-2^mu-1 */
} ECPRI_PrivateStartOfSlot;

typedef struct __attribute__((packed)) {
    /* ecpriRtcid : Antenna/ Carrier ID (PRACH and SRS must be different from normal data */
    uint16_t rtc_id;    /* DU_port / bandsector / CC/ RU_port: mapping defined by M-plane */
    
    uint8_t seq_id;     /* 8b: sequence id (separate for each port, and C/U and DL/UL */
    uint8_t subseq;     /* 8b: 0x80(last), and possible fragment subsequence for U-plane */
    uint8_t payload_dir;     /* 1b: dir (0=UL, 1=DL), 3b: payloadVersion (1), filterIndx: 4b */
    uint8_t frame_id;    /* 8b: frame */
    uint16_t slot_symb;  /* 4b: subframe, 6b: slot, 6b: symbol */
} ORAN_Header;

#endif

