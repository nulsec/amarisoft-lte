/*
 * Copyright (C) 2017-2025 Amarisoft
 *
 * Amarisoft Web interface 2025-05-21
 */

Ext.define("lte.graph", {

    extend: 'Ext.panel.Panel',
    layout: 'border',

    items: [],
    seriesSide: 'west',

    __persistentConfig__: {},

    constructor: function (config) {
        this._lockCount = 1;
        this._showValue = config.showValue;
        this._serieWidth = config.serieWidth || 250;
        this._serieStyle  = config.serieStyle || '';
        this._tagsDef = config.tags;
        this._toolTipSort = config.toolTipSort;
        this.title = config.title;
        this._serieCount = 0;

        this.callParent(arguments);

        var graph = this.graph = new Graph(
            Ext.Object.merge({
                x: {},
                y: {},
                onOver: this.onOver.bind(this),
                title: this.title
            },
            config.graph));

        this._localSeries = [];
        this._selectedTags = null;

        for (i in config.graph.series) {
            this.addSerie(i, config.graph.series[i]);
        }
        this._tagUpdate();
        this.applyPersistenConfig();
    },

    initComponent: function () {
        this.callParent(arguments);

        var serieItems = [];

        if (this._tagsDef) {
            var tagsStore = Ext.create('Ext.data.Store', {
                fields: ['title', 'hidden', 'tag'],
                data: this._tagsDef,
            });

            var tagsGrid = Ext.create('Ext.grid.Panel', {
                store: tagsStore,
                padding: 5,
                border: 0,
                flex: 1,
                bodyStyle: {
                    background: '#f0f0f0',
                },
                viewConfig:{
                    markDirty: false
                },
                width: '100%',
                hideHeaders: true,
                columns: [{
                    dataIndex: 'title',
                    flex: 1,
                    scope: this,
                    renderer: function (title, metaData, record, rowIndex, colIndex, store, view) {
                        var color = record.get('hidden') ? '#ffffff' : '#80C0ff';
                        metaData.style = 'background-color: ' + color + '; font-weight: bold;';
                        return title.trim();
                    }
                }],
                listeners: {
                    scope: this,
                    cellclick: function (grid, td, cellIndex, record, tr, rowIndex, e, eOpts) {
                        record.set('hidden', !record.get('hidden'));
                        this._tagUpdate();
                    },
                }
            });
            serieItems.push(tagsGrid);
        }

        var serieStore = this._serieStore = Ext.create('Ext.data.Store', {
            fields: ['config', 'serieId'],
            data: []
        });

        var tbar = [];
        if (this.resetFunc) {
            tbar.push(Ext.create('Ext.button.Button', {
                width: 32,
                tooltip: lteLogs.tooltip("Reset"),
                iconCls: "icon-sync",
                listeners: {
                    scope: this,
                    click: function(filter, e, eOpts) {
                        this.resetFunc();
                        this.graph.reset();
                    }
                }
            }));
        }
        if (!tbar.length) tbar = null;

        var serieGrid = this._serieGrid = Ext.create('Ext.grid.Panel', {
            store: serieStore,
            padding: 5,
            border: 0,
            bbar: tbar,
            bodyStyle: {
                background: '#f0f0f0',
            },
            viewConfig:{
                markDirty: false
            },
            width: '100%',
            hideHeaders: true,
            columns: [{
                dataIndex: 'config',
                flex: 1,
                scope: this,
                renderer: function(config, metaData, record, rowIndex, colIndex, store, view) {
                    var s = this._getLocalSerie(record.get('serieId'));
                    var color = this.graph.isEnabled(s.id) ? this.graph.getSerieColor(s.id) : '#f0f0f0';
                    metaData.style = 'background-color: ' + color + '; font-weight: bold; color: ' + lteLogs.getTextColor(color) + '; ' + this._serieStyle;
                    return config.title || id;
                }
            }, {
                dataIndex: 'serieId',
                scope: this,
                align: 'right',
                hidden: !this._showValue,
                renderer: function(id, metaData, record, rowIndex, colIndex, store, view) {
                    var s = this._getLocalSerie(record.get('serieId'));
                    var color = this.graph.isEnabled(s.id) ? this.graph.getSerieColor(s.id) : '#f0f0f0';
                    metaData.style = 'background-color: ' + color + '; font-weight: bold; color: ' + lteLogs.getTextColor(color);
                    return this.graph.getLastValue(id);
                }
            }],
            listeners: {
                scope: this,
                cellclick: function(grid, td, cellIndex, record, tr, rowIndex, e, eOpts) {
                    var s = this._getLocalSerie(record.get('serieId'));
                    var on = !this.graph.isEnabled(s.id);
                    this.graph.setSerie(s.id, on);
                    this.update();
                },
                celldblclick: function (grid, td, cellIndex, record, tr, rowIndex, e, eOpts) {
                    var id0 = record.get('serieId');
                    this._localSeries.forEach( (s) => {
                        if (s.graph)
                            this.graph.setSerie(s.id, s.id === id0);
                    });
                    this.update();
                },
            }
        });
        serieItems.push(serieGrid);

        if (this.toggleAxis) {
            var axis = Object.keys(this.config.graph.axis).filter((id) => {
                if (id === 'x') return false;
                if (!this.config.graph.axis[id].title) return false;
                return true;
            });
            if (axis.length > 1) {
                var axisStore = Ext.create('Ext.data.Store', {
                    fields: ['title', 'axisId', 'axis'],
                    data: axis.map((id) => {
                        var a = this.config.graph.axis[id];
                        return {
                            title: a.title,
                            axisId: id,
                            axis: a,
                            on: a.enabled === undefined ? true : a.enabled,
                        };
                    }),
                });
                var axisGrid = this._axisGrid = Ext.create('Ext.grid.Panel', {
                    store: axisStore,
                    padding: 5,
                    border: 0,
                    flex: 1,
                    bodyStyle: {
                        background: '#f0f0f0',
                    },
                    viewConfig:{
                        markDirty: false
                    },
                    width: '100%',
                    hideHeaders: true,
                    columns: [{
                        dataIndex: 'title',
                        scope: this,
                        renderer: function(title, metaData, record, rowIndex, colIndex, store, view) {
                            var on = record.get('on');
                            metaData.style = 'background-color: ' + (on ? '#c0c0ff' : '#f0f0f0') + ';';
                            return title;
                        }
                    }],
                    listeners: {
                        scope: this,
                        cellclick: function(grid, td, cellIndex, record, tr, rowIndex, e, eOpts) {
                            var id = record.get('axisId');
                            var on = !record.get('on');
                            record.set('on', on);
                            this.update();
                            this.graph.enableAxis(id, on);
                        },
                    },
                });
                serieItems.push(axisGrid);
            }
        }


        var graphPanel = Ext.create('Ext.panel.Panel', {
            html: '<canvas></canvas>',
            listeners: {
                scope: this,
                resize: function(cont, width, height) {

                    var canvas = graphPanel.el.down("canvas").dom;
                    if (this._canvas !== canvas) {
                        this._canvas = canvas;
                        var graph = this.graph;

                        canvas.addEventListener(lteLogs.getMouseWheelEvent(), function (event) { graph.mouseWheelEvent(event); }, {passive: true});
                        this._addMouseListener(canvas, graph, 'mouseout', 'mouseOutEvent');

                        var listener = this._mouseListener.bind(this, canvas, graph);
                        canvas.addEventListener('mousemove', listener, false);
                        canvas.addEventListener('mousedown', listener, false);
                        canvas.addEventListener('mouseup', listener, false);
                        canvas.addEventListener('contextmenu', listener, false);
                    }

                    lteLogs.setCanvasSize(canvas, width, height);
                    this.graph.invalidate();
                    this.update();
                }
            }
        });

        this.add({
            region: 'center',
            layout: 'fit',
            border: 0,
            items: [graphPanel],
        });
        this.add({
            region: this.seriesSide,
            layout: 'anchor',
            autoScroll: true,
            width: this._serieWidth,
            bodyStyle: {
                background: '#f0f0f0',
            },
            border: 0,
            items: serieItems,
        });
    },

    setPersistenConfig: function (name, value) {

        var id = this.persistentConfig;
        if (id) {
            var cfg = this.__persistentConfig__[id];
            if (!cfg) {
                if (value === undefined)
                    return;
                cfg = this.__persistentConfig__[id] = {};
            }
            if (value !== undefined) {
                cfg[name] = value;
            } else {
                delete cfg[name];
            }
        }
    },

    applyPersistenConfig: function () {

        var cfg = this.__persistentConfig__[this.persistentConfig];
        if (cfg) {
            for (var name in cfg) {
                this.applyPersistenConfigParam(name, cfg[name]);
            }
        }
    },

    applyPersistenConfigParam: function (name, value) {
        switch (name) {
        case 'axis':
            value.forEach( (a) => {
                this.graph.setWindow(a.id, a.from, a.to);
            });
            this.update();
            break;
        }
    },

    onOver: function (data, X, Y) {

        if (data) {
            data = data.filter( (d) => { return this._serieStore.findRecord('serieId', d.serie); });
            if (!data.length) return;

            var data0 = data[0];
            var graph = this.graph;

            switch (this._toolTipSort) {
            case 'asc':
                data.sort(function (a, b) { return a.Y - b.Y; });
                break;
            case 'desc':
                data.sort(function (a, b) { return b.Y - a.Y; });
                break;
            case 'title':
                data.sort(function (a, b) { return a.title > b.title ? -1 : 1; });
                break;
            }
            var text = 'At ' + data0.x + ':<br/><table>' + data.map(function (d, i) {
                var color = graph.getSerieColor(data[i].serie);
                var rect = '<div style="width:10px;height:10px;border:1px solid #000;background:' + color + '">';
                return '<tr><td>' + rect + '</td><td>' + lteLogs.tooltip(d.title) + ':</td><td align=right><b>' + d.y + '<b></td></tr>';
            }).join('') + '</table>';

            if (!this._tooltip) {
                this._tooltip = Ext.create('Ext.tip.ToolTip', {
                    target: this._canvas,
                    trackMouse: false,
                    autoHide: false,
                    html: text,
                });
            } else {
                this._tooltip.update(text);
            }
            this._tooltip.show([X + 10, Y + 10]);

        } else if (this._tooltip) {
            this._tooltip.hide();
        }
    },

    _addMouseListener: function (canvas, graph, eventName, funcName) {
        canvas.addEventListener(eventName, function (event) { graph[funcName](event); }, false);
    },

    _mouseListener: function (canvas, graph, event) {

        switch (event.type) {
        case 'mousemove':
            if (!this._mouseDown)
                graph.mouseMoveEvent(event);
            break;
        case 'mouseup':
            if (!this._mouseDown)
                graph.mouseUpEvent(event);
            break;
        case 'mousedown':
            lteLogs.registerMouseMove((function (event1) {
                switch (event1.type) {
                case 'mouseup':
                    graph.mouseUpEvent(event1);
                    this._mouseDown = false;
                    break;
                case 'mousemove':
                    graph.mouseMoveEvent(event1);
                    break;
                }
                event1.preventDefault();
            }).bind(this));
            graph.mouseDownEvent(event);
            this._mouseDown = true;
            break;
        case 'contextmenu':
            var items = [{
                text: 'Configure axis',
                iconCls: 'icon-report',
                handler: () => {
                    lteLogs.popup('lte.graph.axis', {
                        graph: this.graph,
                        callback: (axis) => {
                            if (axis) {
                                this.setPersistenConfig('axis', axis);
                                this.applyPersistenConfigParam('axis', axis);
                            } else {
                                this.setPersistenConfig('axis');
                            }
                        }
                    });
                }
            }, {
                xtype: 'menuseparator'
            }, {
                text: 'Save image',
                iconCls: 'icon-save',
                handler: () => {
                    canvas.toBlob( (blob) => {
                        var a = document.createElement('a');
                        var url = URL.createObjectURL(blob);
                        a.setAttribute('href', url);
                        a.setAttribute("download", lteLogs.fixFilename(this.title) + '.png');
                        document.body.appendChild(a);
                        a.click();
                        document.body.removeChild(a);
                    });
                },
            }, {
                text: 'Copy image to clipboard',
                iconCls: 'icon-copy',
                handler: () => {
                    canvas.toBlob( (blob) => {
                        const item = new ClipboardItem({ "image/png": blob });
                        navigator.clipboard.write([item]);
                    });
                },
            }, {
                xtype: 'menuseparator'
            }, {
                text: 'Download data set',
                iconCls: 'icon-report',
                handler: () => {
                    lteLogs.popup('lte.graph.export', {
                        filename: lteLogs.fixFilename(this.title) + '.csv',
                        series: getSeries(),
                        callback: (res) => {
                            if (res)
                                lteLogs.exportFile(res.output, res.filename, 'text/csv');
                        }
                    });
                }
            }, {
                text: 'Copy data set to clipboard',
                iconCls: 'icon-copy',
                handler: () => {
                    lteLogs.popup('lte.graph.export', {
                        filename: false,
                        series: getSeries(),
                        callback: (res) => {
                            if (res) {
                                var input = document.getElementById('clipboard');
                                input.value = res.output;
                                input.select();
                                document.execCommand('copy');
                            }
                        }
                    });
                },
            }];

            var getSeries = () => {
                return this._localSeries.filter( (s) => { return this.graph.isEnabled(s.id); })
                                        .map( (s) => { return this.graph.exportSerie(s.id); });
            };

            var menu = new Ext.menu.Menu({
                items: items
            });
            menu.showAt([event.clientX, event.clientY]);
            event.stopPropagation();
            event.preventDefault();

            break;
        }
    },

    listeners: {
        activate: function () {
            this.unlock();
        },

        deactivate: function() {
            this.lock();
        },
    },

    reset: function (keep) {

        if (keep) {
            this._localSeries.forEach( (s) => {
                s.record = null;
                s.graph = false;
                s.hidden = true;
            });
        } else {
            this._localSeries = [];
        }
        this._serieCount = 0;
        this._serieStore.loadData([]);
        this.graph.flushSeries();
        this.graph.reset();
    },

    flushSeries: function () {
        this.graph.flushSeries();
        this.update();
    },

    _getLocalSerie: function (id) {
        return this._localSeries.find( (ls) => { return ls.id == id; });
    },

    hasSerie: function () {
        return this._serieCount > 0;
    },

    addSerie: function (id, cfg, tags) {
        var ret = false;

        var s = this._getLocalSerie(id);
        if (s) {
            // Update config
            if (cfg.enabled !== undefined)
                s.cfg.enabled = cfg.enabled;
            if (cfg.hidden !== undefined)
                s.cfg.hidden = cfg.hidden;

            if (tags !== undefined) {
                if (!(tags instanceof Array))
                    s.tags = [tags];
                else
                    s.tags = tags;
            }
            if (cfg.values)
                this.graph.addValues(id, cfg.values);

        } else {
            if (!tags)
                tags = [''];
            else if (!(tags instanceof Array))
                tags = [tags];

            var s = {
                id: id,
                cfg: cfg,
                graph: false,
                tags: tags,
                hidden: true,
            };

            this._localSeries.push(s);
            ret = true;
        }

        if (!this._matchTag(s) && !s.cfg.hidden)
            s.cfg.hidden = true;

        if (!s.graph) {
            this.graph.addSerie(id, cfg);
            s.lastEnabled = this.graph.isEnabled(id);
            s.graph = true;
            if (s.cfg.hidden && s.lastEnabled)
                this.graph.setSerie(id, false);
        }

        var pos = this._serieStore.findBy( (rec) => { return rec.get('serieId') === id; });
        if (s.cfg.hidden) {
            if (pos >= 0)
                this._serieStore.removeAt(pos);
            if (!s.hidden) {
                s.lastEnabled = this.graph.isEnabled(id);
                this.graph.setSerie(id, false);
                this._serieCount--;
                s.hidden = true;
            }
        } else {
            if (s.hidden) {
                this.graph.setSerie(id, s.lastEnabled);
                this._serieCount++;
                s.hidden = false;
            }
            if (pos < 0 && !this._seriesDirty) {
                this._seriesDirty = setTimeout(() => {
                    this._seriesDirty = 0;
                    this._serieStore.loadData(this._localSeries.filter( (s) => { return !s.cfg.hidden; }).map( (s) => {
                        return {
                            config: s.cfg,
                            serieId: s.id,
                        };
                    }));
                }, 1);
            }
        }
        return ret;
    },

    _tagUpdate: function () {

        if (!this._tagsDef) return;

        var tags = {};
        this._tagsDef.forEach( (def) => {
            if (!def.hidden) {
                var t = tags[def.group];
                if (!t) tags[def.group] = [def.tag];
                else    t.push(def.tag);
            }
        });
        this.selectTags(Object.keys(tags).map( (group) => { return tags[group]; }));
    },

    _matchTag: function (s) {

        var tags = this._selectedTags;
        if (!tags)
            return true;
        if (!s.tags)
            return false;

        for (var i = 0; i < tags.length; i++) {
            if (tags[i].find( (t) => { return s.tags.indexOf(t) >= 0; }) === undefined)
                return false;
        }
        return tags.length > 0;
    },

    /* tags = [  [ t1 || ... || tn ] && ... && [ t1 || ... || tn ] ]
     */
    selectTags: function (tags) {

        if (!tags) {
            this._selectedTags = null;
        } else {
            if (!(tags instanceof Array))
                tags = [tags];
            this._selectedTags = tags.map( (t) => {
                if (!(t instanceof Array))
                    return [t];
                return t;
            });
        }

        this._localSeries.forEach( (s) => {
            this.addSerie(s.id, { hidden: !this._matchTag(s) });
        });
    },

    addValues: function (id, values, replace) {

        if (this.graph.addValues(id, values, replace)) {
            if (!this._lockCount)
                this.update(!this._showValue);
            return true;
        }
        return false;
    },

    getSeries: function () {
        var series = {};
        this._localSeries.forEach( (s) => {
            if (s.graph) {
                series[s.id] = {
                    enabled: this.graph.isEnabled(s.id)
                };
            }
        });
        return series;
    },

    lock: function () {
        this._lockCount++;
    },

    unlock: function () {
        if (!Math.max(0, --this._lockCount)) {
            this._lockCount = 0;
            this.update();
        }
    },

    _serieGridRefresh: function () {
        var view = this._serieGrid.getView();
        if (view)
            view.refresh();
    },

    update: function (noGrid) {
        if (this._lockCount)
            return;

        if (!noGrid)
            this._refreshGrid = true;

        if (!this._updateTimer && this._canvas) {
            this._updateTimer = setTimeout(() => {
                this._updateTimer = 0;
                if (this._lockCount)
                    return;

                this.graph.draw(this._canvas);
                if (this._refreshGrid && !this._serieGrid.isDestroyed) {
                    this._serieGridRefresh();
                }
                this._refreshGrid = false;
            }, 100);
        }
    },
});


Ext.define('lte.graph.export', {

    title: 'Export dataset',
    extend: 'lte.popup',
    width: 450,
    iconCls: 'icon-chart',

    constructor: function (options) {
        this.callParent(arguments);
    },

    initComponent: function () {

        var merge = this.series.length > 1;
        var x = this.series[0].x;
        for (var i = 1; i < this.series.length; i++) {
            if (this.series[i].x !== x) {
                merge = false;
                break;
            }
        }

        this.fields = [{
            xtype: 'textfield',
            name: 'filename',
            fieldLabel: 'Filename',
            value: this.filename || '',
            width: '100%',
            disabled: this.filename === false,
        }, {
            xtype: 'textfield',
            name: 'separator',
            fieldLabel: 'Separator',
            value: ',',
            width: '100%',
        }, , {
            fieldLabel: 'Merge series',
            xtype: 'checkbox',
            name: 'merge',
            value: merge,
            disabled: !merge,
        }];
        this.callParent(arguments);
    },

    onData: function (data) {

        var lines = [];
        var series = this.series;
        var sep = this.separator;

        series.forEach( (s) => {
            s.title = s.name + ' (' + s.y + ')';
        });

        if (data.merge) {
            var xmin = Infinity;
            var xmax = -Infinity;
            var range = Infinity;

            series.forEach( (s) => {
                for (var i = 0; i < s.values.length; i++) {
                    var x = s.values[i].x;
                    xmin = Math.min(xmin, x);
                    xmax = Math.max(xmax, x);
                    if (i)
                        range = Math.min(range, x - s.values[i-1].x);
                }
                s.idx = 0;
            });

            lines.push([series[0].x].concat(series.map( (s) => { return s.title; })).join(sep));
            for (var x = xmin; x <= xmax; x += range) {
                var line = [x];

                series.forEach( (s) => {
                    var values = s.values;
                    for (var v1 = values[s.idx]; s.idx < values.length && x > v1.x; v1 = values[++s.idx]);

                    if (s.idx === values.length) {
                        var y = 0;
                    } else if (x === v1.x) {
                        var y = v1.y;
                    } else if (!s.idx) {
                        var y = 0;
                    } else {
                        v0 = values[s.idx - 1];
                        var y = (x - v0.x) * (v1.y - v0.y) / (v1.x - v0.x) + v0.y;
                    }
                    line.push(y);
                });

                lines.push(line.join(sep));
            }


        } else {
            series.forEach( (s) => {
                lines.push([s.x, s.title].join(sep));
                s.values.forEach( (v) => {
                    lines.push([v.x, v.y].join(sep));
                });
                lines.push();
            });
        }
        data.output = lines.join("\n");
    },
});



Ext.define('lte.graph.axis', {

    title: 'Configure axis',
    extend: 'lte.popup',
    width: 500,
    iconCls: 'icon-chart',
    noChange: false,

    constructor: function (options) {
        this.callParent(arguments);
    },

    initComponent: function () {

        var axis = this._axis = this.graph.getAxis();

        for (var id in axis) {
            var a = axis[id];

            this.fields.push({
                xtype: 'fieldcontainer',
                fieldLabel: a.name,
                layout: 'hbox',
                items: [{
                    xtype: 'numberfield',
                    name: 'min',
                    value: a.from,
                    width: 120,
                }, {
                    xtype: 'displayfield',
                    fieldLabel: '&nbsp;&nbsp;to',
                    labelSeparator: '',
                    width: 25,
                }, {
                    xtype: 'numberfield',
                    name: 'max',
                    value: a.to,
                    width: 120,
                }, {
                    xtype: 'displayfield',
                    fieldLabel: '&nbsp;&nbsp;' + a.unit,
                    labelSeparator: '',
                }]
            });
        }
        this.callParent(arguments);
    },

    onData: function (data) {
        if (data) {
            this.data = this._axis.map( (a, i) => {
                return {
                    id: a.id,
                    from: data.min[i],
                    to: data.max[i],
                };
            });
        }
    },
});



