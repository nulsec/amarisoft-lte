
/*
 * XXX: Move all channel handling to LTESignal
 */
Ext.define("lte.signal.panel", {

    extend: 'Ext.tab.Panel',
    layout: 'border',
    height: 400,
    activeTab: 0,
    border: false,
    tabPosition: 'left',
    tabRotation: 0,

    _selectedLog: undefined,

    to_dB: function (val)
    {
        if (val == 0)
            return -100;
        else
            return Math.log10(val) * 10;
    },

    constructor: function (config) {
        this.callParent(arguments);

        this._logList = [];
    },

    initComponent: function () {
        this.callParent(arguments);
    },

    createChartTab: function (chartDef) {
        var series = [];
        var maxWidth   = 0;

        hiddenLabel = Ext.create('Ext.form.Label', {
            id: 'hiddenLabel',
            hidden:true
        })

        //var hiddenLabel = Ext.getCmp('hiddenLabel');
        var hiddenField = new Ext.util.TextMetrics(hiddenLabel.el);

        for (var paramId in chartDef.series) {
            var serie = chartDef.series[paramId];

            series.push({
                serie: serie,
                serieId: paramId,
                paramId: paramId,
                dataSamples: serie.dataSamples,
                complex: chartDef.complex,
                norm: chartDef.norm
            });

            maxWidth = Math.max(maxWidth, hiddenField.getWidth(serie.title));
        }

        Ext.getCmp('hiddenLabel').destroy();

        var chart = chartDef.chart = Ext.create('lte.graph', {
            title: chartDef.title,
            persistentConfig: 'signal.' + chartDef.title,
            chartDef: chartDef,
            mySeries: series,
            serieWidth: maxWidth + 50,
            toggleAxis: true,
            graph: {
                columns: 2,
                margin: {top: 20, left: 30, bottom: 25},
                axis: chartDef.axis,
                orthonormal: true,
            }
        });
        chart.unlock(); // Hack...

        series.forEach(function(serie) {
            var drawStyle = "points";
            if (!serie.serie.drawStyle)
                serie.serie.drawStyle = "points";
            chart.addSerie(serie.serieId, serie.serie);
        });

        this.updateChart(chart);
        this.add(chart);
        return chart;
    },

    updateChart: function (chart) {

        var series = chart.mySeries;

        series.forEach((function(serie) {
            var data = [];

            if (serie.complex)
            {
                for (var i=0; i<serie.dataSamples.length; i++)
                {
                    data.push({
                        x: serie.dataSamples[i].real,
                        y: serie.dataSamples[i].imag,
                        z: serie.dataSamples[i].imag,
                        dataSamples: serie.dataSamples
                    });
                }            

                chart.addValues(serie.serieId, data);
            }
            else if (serie.norm)
            {
                var graphCount = chart.graph.length;
                var tab = serie.dataSamples;

                var mult = 180 / Math.PI; /* convert to degrees */
                for (var i=0; i<tab.length; i++) {
                    var val_y = this.to_dB(tab[i].real * tab[i].real + tab[i].imag * tab[i].imag);
                    var val_z = Math.atan2(tab[i].imag, tab[i].real) * mult;

                    data.push({
                        x: i, y: val_y, z: val_z, dataSamples: tab
                    });
                }
                chart.addValues(serie.serieId, data);
            }
        }).bind(this));
    },

    listeners: {
        scope: this,
        close: function () {
            for (var i in this._logList) {
                this._logList[i].clean();
            }
        },
    },

    dataReady: function (result, name) {
        var chartDef_Constellation = {
            title: name + '<br/>Constellation',
            complex:1,
            //norm:1,
            series: {},
            axis: {
                x: {
                    unit: 'mag',
                    noUnit: true,
                    auto: 'zeroCentered',
                    min: -1,
                    max: 1,
                },
                y: {
                    unit: 'mag',
                    noUnit: true,
                    title: 'Constellation',
                    auto: 'zeroCentered',
                    min: -1,
                    max: 1,
                    index: 0,
                },
                z: {
                    unit: 'mag',
                    noUnit: true,
                    title: 'Trajectory',
                    auto: 'zeroCentered',
                    min: -1,
                    max: 1,
                    enabled: false,
                    index: 1,
                },
            },
        };
        
        for (var i = 0; i < result.symbols.length; i++) {
            var label = result.symbols[i].label;
            chartDef_Constellation.series[label] = {
                title: label,
                autoScale: true,
                colorMaxBrightness: 0.6,
                dataSamples: result.symbols[i],
                drawStyle: ['points', 'lines'],
                y: ['y', 'z']
            };
        }
        this.createChartTab(chartDef_Constellation);

        var chartDef_spectrum = {
            title: name + '<br/>Spectral Flatness',
            norm:1,
            series: {},
            axis: {
                x: {
                    unit: ' RE',
                    noUnit: true,
                    auto: 'fit',
                    unitPrecision: 0,
                },
                y: {
                    unit: 'dB',
                    noUnit: true,
                    auto: 'fit',
                    title: 'Norm',
                    min: -60,
                },
                z: {
                    unit: '&#176;',
                    //unit: 'dB',
                    noUnit: true,
                    title: 'Phase',
                    auto: 'fit',
                    min: -180,
                    max: 180,
                    index: 1,
                }
            },
        };
        
        for (var i = 0; i < result.symbols.length; i++) {
            var label = result.symbols[i].label;
            chartDef_spectrum.series[label] = { title: label, dataSamples: result.symbols[i], drawStyle: ['lines', 'points'], y: ['y', 'z']};
       }
       this.createChartTab(chartDef_spectrum);

    },

    channelReady: function (result, name) {
        var ChanConstellation = {
            id: 'CHAN_CONSTELLATION',
            title: name + ' Channel<br/>Constellation',
            complex:1,
            series: { },
            axis: {
                x: {
                    unit: '',
                    noUnit: true,
                    auto: 'zeroCentered',
                },
                y: {
                    unit: '',
                    noUnit: true,
                    title: 'Constellation',
                    auto: 'zeroCentered',
                },
                z: {
                    unit: '',
                    noUnit: true,
                    title: 'Trajectory',
                    auto: 'zeroCentered',
                    enabled: false,
                    index: 1,
                }
            },
        };

        var ChanNormPhase = {
            id: 'CHAN_NORM_PHASE',
            title: name + ' Channel<br/>Norm/Phase',
            norm:1,
            series: {},
            axis: {
                x: {
                    unit: ' RE',
                    noUnit: true,
                    auto: 'fit',
                    unitPrecision: 0,
                },
                y: {
                    unit: 'dB',
                    noUnit: true,
                    auto: 'fit',
                    title: 'Norm',
                    min: -60,
                },
                z: {
                    unit: '&#176;',
                    noUnit: true,
                    title: 'Phase',
                    auto: 'fit',
                    min: -180,
                    max: 180,
                    index: 1,
                }
            },
        };
        var ChanIR = {
            id: 'CHAN_IR',
            title: name + ' Channel<br/>Impulse Response',
            complex:1,
            series: { },
            axis: {
                x: {
                    unit: 'us',
                    auto: 'fit',
                },
                y: {
                    unit: 'dB',
                    noUnit: true,
                    auto: 'fit',
                    min: -60,
                }
            },
        };

        for (var c = 0; c < result.channels.length; c++) {
            var channel = result.channels[c];
            var label = channel.label;
            var dataSamples = channel.samples;
            var impulseResp = channel.ir;
            ChanConstellation.series[label] = { title: label, dataSamples: dataSamples, drawStyle: ["points", "lines"], y: ['y', 'z']};
            ChanNormPhase.series[label] = { title: label, dataSamples: dataSamples, drawStyle: ["lines", "lines_wrap"], y: ['y', 'z']};
            ChanIR.series[label] = { title: label, dataSamples: impulseResp, drawStyle: "lines" };
        }

        this.createChartTab(ChanConstellation);
        this.createChartTab(ChanNormPhase);
        this.createChartTab(ChanIR);
    },

    npuschDataReady: function (result) {
        switch (result.type) {
        case 're':
            this.createChartTab({
                title: 'NPUSCH<br/>Constellation',
                complex:1,
                series: {
                    'layer 1': { title: 'Layer 1', dataSamples: result.symbols[0] }
                },
                axis: {
                    x: {
                        unit: 'mag',
                        noUnit: true,
                        auto: 'zeroCentered',
                        min: -1,
                        max: 1,
                    },
                    y: {
                        unit: 'mag',
                        noUnit: true,
                        auto: 'zeroCentered',
                        min: -1,
                        max: 1,
                    }
                },
            });
            break;
        }
    },

    npdschDataReady: function(result) {
        switch (result.type) {
        case 're':
            this.createChartTab({
                title: 'NPDSCH<br/>Constellation',
                complex:1,
                series: {
                    'layer 1': { title: 'Layer 1', dataSamples: result.symbols[0] }
                },
                axis: {
                    x: {
                        unit: 'mag',
                        noUnit: true,
                        auto: 'zeroCentered',
                        min: -1,
                        max: 1,
                    },
                    y: {
                        unit: 'mag',
                        noUnit: true,
                        auto: 'zeroCentered',
                        min: -1,
                        max: 1,
                    }
                },
            });
            break;
        }
    },

    setLog: function (log, cb) {

        if (log === this._selectedLog)
            return;

        // Update log fifo
        var index = this._logList.indexOf(log);
        if (index >= 0)
            this._logList.splice(index, 1);
        if (this._logList.push(log) > 10) {
            this._logList.shift();
            log.clean();
        }
        this._selectedLog = log;
        this.removeAll();

        if (!log) {
            cb(false);
            return;
        }

        LTESignal.get(log, (function (result) {

            switch (result.type) {
            case 'success':
                cb(true);
                this.setActiveTab(0);
                return;
            case 'error':
                cb(false);
                return;
            }

            switch (result.log.channel) {
            case LTESignal.PUSCH:
                if (result.type == "re")
                    this.dataReady(result, "PUSCH");
                if (result.type == "chan")
                    this.channelReady(result, "PUSCH");
                break;
            case LTESignal.SRS:
                if (result.type == "chan")
                    this.channelReady(result, "SRS");
                break;
            case LTESignal.PDSCH:
            case LTESignal.PMCH:
                if (result.type == "re")
                    this.dataReady(result, "PDSCH");
                if (result.type == "chan")
                    this.channelReady(result, "PDSCH");
                break;
            case LTESignal.PDCCH:
                if (result.type == "re")
                    this.dataReady(result, "PDCCH");
                if (result.type == "chan")
                    this.channelReady(result, "PDCCH");
                break;
            case LTESignal.NPUSCH:
                this.npuschDataReady(result);
                break;
            case LTESignal.NPDSCH:
                this.npdschDataReady(result);
                break;
            }
        }).bind(this), {re: true, chan: true});
    },
});


var LTESignal = {

    PUSCH: lteLogs.string2id('PUSCH'),
    SRS:   lteLogs.string2id('SRS'),
    PDSCH: lteLogs.string2id('PDSCH'),
    PMCH:  lteLogs.string2id('PMCH'),
    PDCCH: lteLogs.string2id('PDCCH'),
    NPUSCH: lteLogs.string2id('NPUSCH'),
    NPDSCH: lteLogs.string2id('NPDSCH'),

    /*
     * cb(<result>)
     * type:
     *      - error
     *      - re => info = <symbol index>
     *      - rs => info = {antenna: <antenna index>, slot: <slot number>}
     *
     * samples: array
     */
    get: function (log, cb, config) {

        if (!log.signalRecord) {
            cb({type: 'error'});
            return;
        }
        
        switch (log.channel) {
        case this.PDCCH:
        case this.PUSCH:
        case this.PDSCH:
        case this.PMCH:
        case this.NPUSCH:
        case this.NPDSCH:
            if (!config.re && !config.chan) return false;
            break;
        case this.SRS:
            if (!config.chan) return false;
            break;
        default:
            return false;
        }

        // Download
        log.client.signalDataGet(log, (function (error) {

            if (error) {
                cb({type: 'error'});
                return;
            }

            var res = 0;
            switch (log.channel) {
            case this.PUSCH:
            case this.PDSCH:
            case this.PMCH:
            case this.PDCCH:
                res += this._parseSignal('re', config, this.dataRE, log, cb);
                res += this._parseSignal('chan', config, this.chanData, log, cb);
                break;
            case this.SRS:
                res += this._parseSignal('chan', config, this.chanData, log, cb);
                break;
            case this.NPUSCH:
                res += this._parseSignal('re', config, this.npuschRE, log, cb);
                break;
            case this.NPDSCH:
                res += this._parseSignal('re', config, this.npdschRE, log, cb);
                break;
            }
            cb({type: res > 0 ? 'success' : 'error'});

        }).bind(this));
    },

    _parseSignal: function (type, config, func, log, cb) {
        if (config[type]) {
            var signal = log.signalRecord[type];
            if (signal && signal.array) {
                func.call(this, log, signal, cb);
                return 1;
            }
        }
        return 0;
    },

    getImpulseResponse: function(tab, offset, n, carrier_spacing) {
        var fft_len, tab1, i, j, n2, x_mult, y_mult;
        var dataSamples = [];

        fft_len = 1;
        while (fft_len < n)
            fft_len <<= 1;
        tab1 = new Float32Array(fft_len * 2);
        for(i = 0; i < n * 2; i++)
            tab1[i] = tab[offset * 2 + i];
        CachedFFT(tab1, fft_len, 1);
        n2 = fft_len >> 1;

        /* convert to micro seconds */
        x_mult = 1e6 / (fft_len * carrier_spacing);
        /* normalize IFFT */
        y_mult = 1.0 / fft_len;
        for(i = -n2; i < n2; i++) {
            var x, y, val;
            j = i;
            if (j < 0)
                j += fft_len;
            x = tab1[2 * j];
            y = tab1[2 * j + 1];
            val = this.to_dB((x * x + y * y) * y_mult);
            dataSamples.push({
                real:  i * x_mult,
                imag:  val,
            });
        }
        return dataSamples;
    },

    to_dB: function (val) {
        if (val == 0)
            return -100;
        else
            return Math.log10(val) * 10;
    },

    dataRE: function (log, signal, cb) {
        var n_layer = log.nl || 1;
        var symbols = [];
        var m_symb;
        var mult = 1.0 / 2048; /* normalisation factor */
        var tab, i, j, start_symb, data, base;

        start_symb = log.symb.split(":")[0] | 0;
        tab = log.re_symb.split(",");
        base = 0;
        for(j = 0; j < tab.length; j++) {
            m_symb = tab[j] | 0;
            m_symb *= n_layer;
            if (m_symb != 0) {
                data = [];
                for(i = 0; i < m_symb; i++) {
                    x = signal.array[2 * (i + base)] * mult;
                    y = signal.array[2 * (i + base) + 1] * mult;
                    //  console.log("re " + i + ":" + x + " " + y);
                    data.push( {
                        real: x,
                        imag: y,
                    });
                }
                data.label = "Symbol " + (start_symb + j);
                symbols.push(data);
                base += m_symb;
            }
        }
        cb({type: 're', symbols: symbols, log: log});
    },

    chanData: function (log, signal, cb) {

        var chan_interp = log.chan_interp || 1;
        var n_ant = log.n_ant || 1;
        var symb_index, ant_index, port_index, i;
        var chan_symb, n_chan_symb, base;
        var channels = [], data;
        var n_port, n_ant_pbch, chan_port, l;
        var cell, cyclic_prefix, mu, m_sc;

        n_ant_pbch = log.n_ant_pbch;
        if (n_ant_pbch) {
            /* channel based on LTE CRS */
            n_port = Math.min(log.n_ant_pbch, 2);
        } else {
            n_ant_pbch = 0;
            n_port = log.nl || 1;
        }
        
        if (log.chan_symb) {
            /* PUSCH/PDSCH case: explicit channel symbols */
            chan_symb = log.chan_symb.split(",");
            n_chan_symb = chan_symb.length;
        } else {
            /* SRS case: no explicit channel symbols */
            var tab_symb = log.symb.split(":");
            start_symb = tab_symb[0] | 0;
            n_chan_symb = tab_symb[1];
            chan_symb = [];
            for(symb_index = 0; symb_index < n_chan_symb; symb_index++) {
                chan_symb.push(start_symb + symb_index);
            }
        }

        m_sc = signal.len / (n_chan_symb * n_ant * n_port);
            
        /* the SCS is needed for the impulse response plot. The cyclic
           prefix is only needed for LTE with n_ant_pbch = 4 to get
           the port numbers */
        cyclic_prefix = 0;
        mu = 0;
        cell = log.getCell();
        if (cell) {
            if (cell.dl_mu)
                mu = cell.dl_mu; /* dl_mu = ul_mu assumed */
            if (cell.cyclic_prefix)
                cyclic_prefix = cell.cyclic_prefix;
        }
        
        base = 0;
        for(symb_index = 0; symb_index < n_chan_symb; symb_index++) {
            for(ant_index = 0; ant_index < n_ant; ant_index++) {
                for(port_index = 0; port_index < n_port; port_index++) {
                    data = [];
                    for(i = 0; i < m_sc; i++) {
                        var x = signal.array[2 * (i + base)];
                        var y = signal.array[2 * (i + base) + 1];
                        //                            console.log("rs " + i + ":" + x + " " + y);
                        data.push( {
                            real:  x,
                            imag:  y,
                        });
                    }
                    l = chan_symb[symb_index];
                    chan_port = port_index;
                    if (n_ant_pbch == 4 && (l == 1 || l == (7 - cyclic_prefix + 1)))
                        chan_port += 2;
                    
                    channels.push({
                        label: "Symbol " + l + ", antenna " + ant_index + ", port " + chan_port,
                        samples: data,
                        ir: this.getImpulseResponse(signal.array, base, m_sc,
                                                    (15000 << mu) * chan_interp)
                    });
                    base += m_sc;
                }
            }
        }
        cb({type: 'chan', channels: channels, log: log});
    },

    npuschRE: function (log, signal, cb) {

        var m_symb = signal.len;
        var mult = 1.0 / 2048; /* normalisation factor */
        var symbols = [];
        var base = 0;
        for(var i = 0; i < m_symb; i++) {
            x = signal.array[2 * (i + base)] * mult;
            y = signal.array[2 * (i + base) + 1] * mult;
            //  console.log("re " + i + ":" + x + " " + y);
            symbols.push( {
                real: x,
                imag: y,
            });
        }

        cb({type: 're', symbols: [symbols], log: log});
    },

    npdschRE: function (log, signal, cb) {
        
        var m_symb = signal.len;
        var mult = 1.0 / 2048; /* normalisation factor */
        var symbols = [];
        var base = 0;
        /* Create  a nested level to mimic pdsch and allow live constellation plot */
        for(var i = 0; i < m_symb; i++) {
            x = signal.array[2 * (i + base)] * mult;
            y = signal.array[2 * (i + base) + 1] * mult;
            //  console.log("re " + i + ":" + x + " " + y);
            symbols.push({
                real: x,
                imag: y,
            });
        }

        cb({type: 're', symbols: [symbols], log: log});
    },
};


Ext.define("lte.constellation.win", {

    extend: 'Ext.window.Window',
    title: 'Constellations',
    width: 600,
    height: 600,
    constraint: true,
    layout: 'fit',
    maximizable: true,

    // Config
    fps: 10,
    timeUE: 8000, /* Keep UE with re for this time */
    timeRe: 2000, /* Skip older res */
    maxLogs: 10,  /* Max re */
    signals: [],

    listeners: {
        close: function () {
            clearTimeout(this.refreshId);
            this.client.setSignalViewer(null);
        }
    },

    constructor: function (config) {
        this.callParent(arguments);
    },

    initComponent: function () {
        this.callParent(arguments);

        var container = Ext.create('Ext.panel.Panel', {
            html: '<canvas></canvas>',
            listeners: {
                scope: this,
                resize: function(cont, width, height) {
                    var canvas = this._canvas = container.el.down("canvas").dom;
                    canvas.width = width;
                    canvas.height = height;
                    this.refreshFrame(false);
                }
            }
        });
        this.add(container);
        this.refreshId = 0;

        this.ueList = {};
        this.client.setSignalViewer(this);
    },

    addLog: function (log) {
        LTESignal.get(log, this.signalCb.bind(this), {re: true});
    },

    signalCb: function (result) {

        switch (result.type) {
        case 're':
            break;
        default:
            return;
        }

        // Init animation
        var now = new Date() * 1;
        var log = result.log;
        var ts  = log.timestamp;

        if (this.deltaTS === undefined) {
            this.deltaTS = ts - now;
            this.timestamp0 = ts;
            this.time0      = now;

        } else if (ts > now + this.deltaTS + 1500) {
            this.deltaTS = ts - now;
            this.timestamp0 = ts;
            this.time0      = now;
            console.log('Resync');
        }

        var ue = this.ueList[log.ue_id];
        if (!ue) {
            ue = this.ueList[log.ue_id] = {
                reList: [],
                id: id,
            };
        }
        ue.reList.push(result);
        ue.lastTime = now;

        this.refresh();
    },

    ueList: {},

    refresh: function () {
        if (!this.refreshId) {
            this.refreshId = setTimeout(this.refreshAsync.bind(this), 1000 / this.fps);
        }
    },

    refreshAsync: function () {
        window.requestAnimationFrame(this.refreshFrame.bind(this, true));
    },

    refreshFrame: function (animation) {

        if (!this.refreshId)
            animation = true;
        this.refreshId = 0;

        // Remove oldest re
        var now = new Date() * 1;
        var timeUE = now - this.timeUE;
        var timeRe = now + this.deltaTS - this.timeRe;
        var maxLogs = this.maxLogs;

        for (var id in this.ueList) {
            var ue = this.ueList[id];
            var reList = ue.reList;

            while (reList.length && (reList[0].log.timestamp < timeRe || reList.length > maxLogs)) {
                var re = reList.shift();
                re.log.clean();
            }

            if (!reList.length && ue.lastTime < timeUE)
                delete this.ueList[id];
        }

        var ids = Object.keys(this.ueList).map(function (id) { return id - 0; });
        ids.sort(function (a, b) { return a - b; });
        var N = ids.length;

        var canvas = this._canvas;
        var width = canvas.width;
        var height = canvas.height;
        var fs = 12;
        var margin = 10;
        var ctx = canvas.getContext('2d');

        ctx.save();
        ctx.translate(0.5,0.5);
        ctx.fillStyle = 'black';
        ctx.fillRect(0, 0, width, height);
        ctx.textBaseline = 'top';
        ctx.textAlign    = 'center';
        ctx.font = fs + 'px Arial';

        var size = Math.ceil(Math.sqrt(width * height / N));
        var nX = Math.max(1, width / size >> 0);
        var nY = Math.max(1, height / size >> 0);
        while (nX * nY < N) {
            if (width / nX <= height / nY) nY++;
            else                  nX++;
        }
        var w = (width / nX) >> 0;
        var h = (height / nY) >> 0;

        var w1 = (w / 1.1 - margin) >> 1;
        var h1 = (h / 1.1 - margin - fs) >> 1;

        for (var i = 0; i < N; i++) {
            var ue = this.ueList[ids[i]];
            var errors = 0;
            var total = 0;

            var x = i % nX;
            var y = (i / nX) >> 0;

            ctx.save();
            ctx.translate(x * w, y * h);
            ctx.strokeStyle = 'white';
            ctx.beginPath();
            ctx.rect(0, 0, w, h);
            ctx.stroke();
            ctx.clip();

            // Constellation
            ctx.save();
            ctx.translate(0.5 * w, 0.5 * h + 0.5 * fs);
            var r1 = ue.reList.length;
            var cs = 255 / r1 / 2;
            for (var r = 0; r < r1; r++) {
                var re = ue.reList[r];
                var symbols = re.symbols;
                var c = (255 - (r1 - r) * cs) >> 0;
                ctx.fillStyle = 'rgb(' + c + ',' + c + ',' + c + ')';
                for (var s = 0; s < symbols.length; s++) {
                    var symbol = symbols[s];
                    for (k = 0; k < symbol.length; k++) {
                        var sample = symbol[k];
                        ctx.fillRect(sample.real * w1 - 1, sample.imag * h1 - 1, 2, 2);
                    }
                }

                var tbs = re.log.tb;
                if (tbs) {
                    for (var j = 0; j < tbs.length; j++) {
                        if (!tbs[j].crc) errors++;
                        total++;
                    }
                }
            }
            ctx.restore();

            ctx.translate(w * 0.5, 4);
            ctx.fillStyle = '#0F0';
            var txt = 'UE ID #' + ids[i];
            if (total)
                txt += ', per=' + (100 * errors / total).toFixed(1) + '%';
            ctx.fillText(txt, 0, 0);

            //console.log('UE', ids[i], r1);

            ctx.restore();
        }

        ctx.restore();

        if (animation)
            this.refresh();
    },

});


