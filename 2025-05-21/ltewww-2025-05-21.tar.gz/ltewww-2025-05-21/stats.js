/*
 * Copyright (C) 2012-2025 Amarisoft
 *
 * Amarisoft Web interface 2025-05-21
 */

Ext.define("lte.analytics.win", {

    extend: 'Ext.window.Window',
    title: 'Analytics',
    width: 1200,
    height: 600,
    constraint: true,
    layout: 'fit',
    maximizable: true,

    constructor: function (config) {
        this.callParent(arguments);
    },

    initComponent: function () {
        this.callParent(arguments);
    },

    open: function (logs, ue_id) {

        var tabs = [];

        if (ue_id !== undefined)
            logs = logs.filter( function (l) { return ue_id === l.ue_id; });

        var stats = Ext.create('lte.analytics.stats');
        stats.generate(logs);
        tabs.push({comp: stats, title: lteLogs.getHTMLIcon('icon-chart') + ' Statistics'});

        if (0 && ue_id === undefined) {
            var ue = Ext.create('lte.analytics.ue');
            ue.generate(logs);
            tabs.push({comp: ue, title: 'UE throughput distribution'});
        }

        if (tabs.length > 1) {
            this.add(Ext.create('Ext.tab.Panel', {
                items: tabs.map(function (t) {
                    t.comp.setTitle(t.title);
                    return t.comp;
                })
            }));
        } else {
            this.setTitle(tabs[0].title);
            this.add(tabs[0].comp);
        }

        this.show();
    },
});

Ext.define("lte.analytics.ue", {

    extend: 'Ext.panel.Panel',
    layout: 'fit',

    constructor: function (config) {
        this.callParent(arguments);
    },

    initComponent: function () {
        this.callParent(arguments);
    },

    generate: function (logs) {

        var dts = (logs[logs.length - 1].timestamp - logs[0].timestamp) / 1000;
        var ueList = {};
        for (var i = 0; i < logs.length; i++) {
            var log = logs[i];

            var ue_id = log.global_ue_id;
            var ue = ueList[ue_id];
            if (!ue) ue = ueList[ue_id] = {ul: 0, dl: 0, id: ue_id};

            if (log.tb) {
                // XXX multi tb
                if (log.dir === lteLogs.DIR_UL) ue.ul += log.tb[0].tb_len;
                if (log.dir === lteLogs.DIR_DL) ue.dl += log.tb[0].tb_len;
            }
        }

        var dlList = [];
        var ulList = [];
        for (var id in ueList) {
            var ue = ueList[id];
            dlList.push({id: ue.id, y: ue.dl});
            ulList.push({id: ue.id, y: ue.ul});
        }
        dlList.sort(function (a, b) { return a.y - b.y; });
        dlList.forEach(function (ue, i) { ue.x = i; });
        ulList.sort(function (a, b) { return a.y - b.y; });
        ulList.forEach(function (ue, i) { ue.x = i; });

        var graph = this._graph = Ext.create('lte.graph', {
            title: 'UE',
            graph: {
                margin: {left: 60, bottom: 10},
                axis: {
                    y: {
                        unitPrecision: 1,
                        unit: 'brate'
                    },
                    x: {
                        hidden: true,
                    }
                },
                series: {
                    ul: {
                        title: 'UL',
                        values: ulList,
                    },
                    dl: {
                        title: 'DL',
                        values: dlList,
                    },
                },
            }
        });

        this.add(graph);
        graph.unlock();
    },
});

Ext.define("lte.analytics.stats", {

    extend: 'Ext.panel.Panel',
    layout: 'border',

    constructor: function (config) {

        lteLogs.setLogger("STATS", this);
        this.callParent(arguments);
    },

    initComponent: function () {
        this.callParent(arguments);
    },

    // Charts definition
    _chartDefinitions: [{
        title: 'Throughput',
        graph: {axis: {y: {unit: 'Brate'}, iy: {unit: 'Bsize'}}, overMode: 'time'},
        series: [
            {value: "tb_len",  dir: lteLogs.DIR_UL, title: "PHY UL <ue_id>", tb: true, crc: true, error: true, avg: 'time', global: true, split: ['cell', 'slot'], instant: 'iy'},
            {value: "tb_len",  dir: lteLogs.DIR_DL, title: "PHY DL <ue_id>", tb: true, crc: true, error: true, avg: 'time', global: true, split: ['cell', 'slot'], instant: 'iy'},
            {value: "s72_len", dir: lteLogs.DIR_UL, title: "eCPRI UL", avg: 'time', global: 'only'},
            {value: "s72_len", dir: lteLogs.DIR_DL, title: "eCPRI DL", avg: 'time', global: 'only'},
            {value: "sdu_len", dir: lteLogs.DIR_UL, title: "IP UL (gtp)", avg: 'time', global: 'only'},
            {value: "sdu_len", dir: lteLogs.DIR_DL, title: "IP DL (gtp)", avg: 'time', global: 'only'},
            {value: "ip_len", dir: lteLogs.DIR_UL, title: "IP UL", avg: 'time', global: 'only'},
            {value: "ip_len", dir: lteLogs.DIR_DL, title: "IP DL", avg: 'time', global: 'only'},
            {value: "mac_len", dir: lteLogs.DIR_UL, title: "UL MAC <ue_id>", avg: 'time', global: 'only', split: ['cell']},
            {value: "mac_len", dir: lteLogs.DIR_DL, title: "DL MAC <ue_id>", avg: 'time', global: 'only', split: ['cell']},
            {value: "mac_pad", dir: lteLogs.DIR_UL, title: "UL MAC padding <ue_id>", avg: 'time', global: 'only', split: ['cell']},
            {value: "mac_pad", dir: lteLogs.DIR_DL, title: "DL MAC padding <ue_id>", avg: 'time', global: 'only', split: ['cell']},
        ],
    }, {
        title: 'RX/TX packets',
        graph: {axis: {y: {unit: ' packets/s', noUnit: true, title: 'Packets per second'}}, margin: {top: 25}, overMode: 'time'},
        series: [
            {value: 'retx', tx: true, title: "TX transmissions <ue_id>", tb: true, avg: 'time', mode: 'count', global: true, split: ['cell', 'slot', 'cr']},
            {value: 'error', tx: true, title: "TX retransmissions <ue_id>", tb: true, avg: 'time', mode: 'count+', global: true, split: ['cell', 'slot', 'cr']},
            {value: 'crc', title: "RX CRC OK <ue_id>", tb: true, avg: 'time', mode: 'count+', global: true, split: ['cell', 'slot']},
            {value: 'crc', title: "RX Bad CRC <ue_id>", tb: true, avg: 'time', mode: 'count0', global: true, split: ['cell', 'slot']},
        ]
    }, {
        title: 'Rate',
        graph: {axis: {y: {unit: '%', min: 0, max: 1}}, overMode: 'time'},
        series: [
            {value: 'ber', title: "Control BER <ue_id>", split: ['cell'], channel: PUCCH},
            {value: 'ber', title: "Data BER <ue_id>", split: ['cell'], channel: PUSCH},
            {value: 'ber', title: "Data BER <ue_id>", split: ['cell'], channel: PDSCH},
            {value: 'error', tx: true, title: "TX retransmission <ue_id>", tb: true, mode: 'count+', global: true, split: ['cell', 'slot', 'cr']},
            {value: 'crc', tx: false, title: "RX error <ue_id>", tb: true, mode: 'count0', global: true, split: ['cell', 'slot', 'cr']},
            {value: 'cr', tx: true, title: 'TX coderate <ue_id>', split: ['cell', 'slot']},
            {value: 'cr', tx: false, title: 'RX coderate <ue_id>', split: ['cell', 'slot']},
        ]
    }, {
        title: 'TTI stats',
        graph: {axis: {y: {unit: ' per TTI', noUnit: true}}, overMode: 'time'},
        series: [
            {value: "hasRB", dir: lteLogs.DIR_DL, title: "DL users per TTI", avg: 'tti', global: 'only', cells: true, channel: PDSCH, split: ['slot']},
            {value: "hasRB", dir: lteLogs.DIR_UL, title: "UL users per TTI", avg: 'tti', global: 'only', cells: true, channel: PUSCH, split: ['slot']},
        ]
    }, {
        title: 'SNR',
        graph: {axis: {y: {unit: 'dB', index: 0}, epre: {unit: 'dBm', index: 1}, snr: {unit: 'dB', index: 2}}, overMode: 'time', columns: 1},
        series: [
            {value: "snr",  title: "SRS snr <ue_id>",         split: ['cell', 'slot'], global: true, channel: SRS},
            {value: "snr",  title: "PUCCH snr <ue_id>",       split: ['cell', 'slot'], global: true, channel: PUCCH },
            {value: "snr",  title: "PUSCH snr <ue_id>",       split: ['cell', 'slot'], global: true, channel: PUSCH },
            {value: "snr",  title: "NPUSCH snr <ue_id>",      split: ['cell', 'slot'], global: true, channel: NPUSCH},
            {value: "snr",  title: "PDSCH snr <ue_id>",       split: ['cell', 'slot'], global: true, channel: PDSCH},
            {value: "rsrp", title: "RSRP",                    split: ['cell'], global: 'only', channel: SLOT, y: 'snr'},
            {value: "rssi", title: "RSSI",                    split: ['cell'], global: 'only', channel: SLOT, y: 'snr'},
            {value: "snr",  title: "SS snr",                  split: ['cell'], global: 'only', channel: SLOT},
            {value: "epre", title: "UL data EPRE <ue_id>",    split: ['cell', 'slot'], global: true, channel: PUSCH, y: 'epre'},
            {value: "epre", title: "UL control EPRE <ue_id>", split: ['cell', 'slot'], global: true, channel: PUCCH, y: 'epre'},
            {value: "epre", title: "UL SRS EPRE <ue_id>",     split: ['cell', 'slot'], global: true, channel: SRS, y: 'epre'},
            {value: "epre", title: "UL NPUSCH EPRE <ue_id>",  split: ['cell', 'slot'], global: true, channel: NPUSCH, y: 'epre'},
            {value: "epre", title: "DL data EPRE <ue_id>",    split: ['cell', 'slot'], global: true, channel: PDSCH, y: 'epre'},
            {value: "epre", title: "DL control EPRE <ue_id>", split: ['cell', 'slot'], global: true, channel: PDCCH, y: 'epre'},
            {value: "mer",  title: "PDSCH mer <ue_id>",       split: ['cell', 'slot'], global: true, channel: PDSCH},
            {value: "mer",  title: "PUSCH mer <ue_id>",       split: ['cell', 'slot'], global: true, channel: PUSCH},
        ]
    }, {
        title: 'MCS',
        graph: {overMode: 'time', axis: {y: {min: 0, max: 28}}},
        series: [
            {value: "mcs_ul",        title: "UL <ue_id>", instant: 'y'},
            {value: "mcs_dl",        title: "DL <ue_id>", instant: 'y'},
        ]
    }, {
        title: "CQI",
        graph: {overMode: 'time'},
        series: [
            {value: "cqi",            title: "DL <ue_id>", global: true, instant: 'y'},
            {value: "ul_cqi",         title: "UE <ue_id>", global: true, split: ['cell', 'slot'], instant: 'y'},
        ]
    }, {
        title: "Time/Freq",
        graph: {overMode: 'time', axis: {z: {unit: 'Hz'}}},
        series: [
            {value: "ta", layer: 'PHY', title: "TA <ue_id>", split: ['cell'], instant: 'y'},
            {value: "ta", layer: 'MAC', title: "TA command <ue_id>", avg: 'no'},
            {value: "freq_shift", layer: 'PHY', title: "CFO <ue_id>", split: ['cell'], global: true, y: 'z', channel: SLOT},
        ]
    }, {
        title: "Rank",
        graph: {overMode: 'time'},
        series: [
            {value: 'ri',            title: "<ue_id>"},
        ]
    }, {
        title: "UL buffer",
        graph: {axis: {y: {unit: 'Bsize'}}, overMode: 'time'},
        series: [
            {value: 'ul_buffer_size', title: "UL buffer size <ue_id>"},
        ]
    }, , {
        title: "TPC",
        graph: {overMode: 'time', columns: 1, axis: {ul: {index: 1, stepFrac: 1}, y: {stepFrac: 1}}},
        series: [
            {value: 'tpc_command', dci: 'dl', title: "PUCCH TPC Command", instant: 'y'},
            {value: 'tpc_command', dci: 'ul', title: "PUSCH TPC Command", y: 'ul', instant: 'ul'},
        ]
    }, {
        title: "Power head room",
        graph: {axis: {y: {unit: ' dB'}}, overMode: 'time'},
        series: [
            {value: 'phr', title: "PHR <ue_id>"},
        ]
    }, {
        title: 'NTN',
        graph: {axis: {y: {unit: 'deg', index: 0}, ta: {unit: 'us', index: 1}}, overMode: 'time', columns: 1},
        series: [
            {value: "elevation",  title: "Sat elevation", global: 'only', channel: NTN, cells: 'only', instant: 'y'},
            {value: "azimuth",  title: "Azimtuh", global: 'only', channel: NTN, cells: 'only', instant: 'y'},
            {value: "ta_common", title: "TA common", global: 'only', channel: NTN, cells: 'only', y: 'ta', instant: 'ta'},
            {value: "ta_ue", title: "TA UE", global: 'only', channel: NTN, cells: 'only', y: 'ta', instant: 'ta'},
        ]
    }, ],

    splitList: {
        cell: {
            title: 'By cell',
            tagTitle: 'Cell <ID>',
            name: 'cell',
            param: 'cell',
        },
        slot: {
            title: 'By slot',
            tagTitle: 'Slot <ID>',
            name: 'slot',
            param: 'slot',
        },
        cr: {
            title: 'By coderate',
            tagTitle: 'Coderate <ID>',
            name: 'coderate',
            param: 'cr',
            sort: 'float',
            labelWidth: 90,
        }
    },

    _onClick: function (list) {
        lteLogs.gotoTime(list[0].value.x)
    },

    _fillSeries: function (logs, series, ueCount) {

        var t0 = new Date();

        for (var s = 0; s < series.length; s++) {
            series[s].logs = [];
        }

        var cells = {};

        // Filter relevant logs and format them
        for (var i = 0, length = logs.length; i < length; i++) {
            var log = logs[i];

            var g = false;
            var u = false;

            // For each wanted value
            for (var s = 0; s < series.length; s++) {
                var serie = series[s];

                // Control word level ?
                if (serie.tb) {
                    if (!log.tb || typeof log.harq === 'string') continue;
                } else {
                    if (!log.hasOwnProperty(serie.value)) continue;
                }

                // Filters
                if (serie.dir !== undefined && log.dir !== serie.dir) continue;
                if (serie.channel !== undefined && log.channel !== serie.channel) continue;
                if (serie.layer !== undefined && log.layer !== serie.layer) continue;
                if (serie.tx === true && log.dir !== log.client.txDir) continue;
                else if (serie.tx === false && log.dir !== log.client.rxDir) continue;
                if (serie.dci === 'ul') {
                    if (log.dci_ul === undefined) continue;
                } else if (serie.dci === 'dl') {
                    if (log.dci_dl === undefined) continue;
                }

                serie.logs.push(log);

                // Count UEs
                if (serie.global) g = true;
                if (log.global_ue_id !== undefined) {
                    if (serie.global === 'only')
                        g = true;
                    else
                        u = true;
                }
            }


            if (log.hasOwnProperty('cell'))
                cells[log.cell] = true;

            if (g) ueCount['undefined']++;
            if (u) ueCount[log.global_ue_id]++;
        }

        this._cells = Object.keys(cells).map( (id) => { return id - 0; } );

        this.prof("Read", logs.length, "logs for stats in ", new Date() - t0, "ms");
    },

    selUEs: [-1],
    minLogs: 2,

    generate: function (logs) {

        var ueCount = {};
        ueCount['undefined'] = 0;

        // Get UEs
        for (var i = 0; i < logs.length; i++) {
            var log = logs[i];
            ueCount[log.global_ue_id] = 0;
        }

        var series0 = [];
        this._chartDefinitions.forEach(function (chartDef) {
            chartDef.splitList = {};
            for (var i = 0; i < chartDef.series.length; i++) {
                var s = chartDef.series[i];
                series0.push(s);
                if (s.split)
                    s.split.forEach(function (s) { chartDef.splitList[s] = true; });
            }
        });
        this._fillSeries(logs, series0, ueCount);

        var minLogs = this.minLogs;
        var UEs = Object.keys(ueCount).filter(function (id) { return ueCount[id] >= minLogs; }).map(function (id) {
            var ue_id = id === 'undefined' ? -1 : id - 0;
            return {
                label: (ue_id === -1 ? 'Global' : id) + ' (' + ueCount[id] + ')',
                ue_id: ue_id
            };
        });
        UEs.sort(function (a, b) { return a.ue_id - b.ue_id; });

        // Select ue_id
        var ue_idGrid = Ext.create('Ext.grid.Panel', {
            frameHeader: false,
            store: {
                fields: ['label', 'ue_id'],
                data: UEs
            },
            columns: [{
                text: "UE ID",
                dataIndex: "label",
                flex: 1
            }],
            allowDeselect: true,
            multiSelect: true,
            listeners: {
                scope: this,
                selectionchange: function(view, selected, eOpts) {
                    this.selUEs = selected.map(function (r) { return r.get('ue_id'); });
                    this.reloadCharts();
                },
            }
        })

        this.showInstant = Ext.create('Ext.form.field.Checkbox', {
            fieldLabel: 'instant',
            labelWidth: 50,
            labelAlign: 'right',
            value: false,
            scope: this,
            handler: function (comp, checked) {
                this.reloadCharts();
            }
        });

        var tbarItems = [{
            xtype: 'numberfield',
            anchor: '100%',
            fieldLabel: 'Average time',
            labelWidth: 80,
            width: 160,
            value: this.avg_time,
            step: 10,
            maxValue: 10000,
            minValue: 10,
            listeners: {
                scope: this,
                change: function(num, newValue, oldValue, eOpts) {
                    if (newValue && num.isValid()) {
                        this.avg_time = newValue;
                        this.updateChart(this.selChart);
                    }
                }
            }
        }, this.showInstant];

        for (var id in this.splitList) {
            var s = this.splitList[id];
            s.comp = Ext.create('Ext.form.field.Checkbox', {
                fieldLabel: s.title,
                labelWidth: s.labelWidth || 50,
                labelAlign: 'right',
                value: false,
                hidden: true,
                scope: this,
                handler: function (comp, checked) {
                    this.reloadCharts();
                }
            });
            tbarItems.push(s.comp);
        }

        this._slotHisto = new Ext.create('Ext.Button', {
            text: 'Slots',
            scope: this,
            iconCls: 'icon-chart',
            hiddent: true,
            tooltip: lteLogs.tooltip('Show stats by slots'),
            handler: this.showSlotHisto.bind(this)
        });
        tbarItems.push('|', this._slotHisto);

        this.chartPanel = Ext.create('Ext.panel.Panel', {
            region: 'center',
            layout: 'fit',
            tbar: tbarItems,
            items: []
        });

        this.add({
            region: 'west',
            layout: 'fit',
            width: 140,
            split: true,
            items: ue_idGrid,
        });
        this.add(this.chartPanel);

        setTimeout( function () { ue_idGrid.setSelection(0); }, 100);
    },

    getSeriesBySplit: function (series, split, tagsDef) {

        var splitSeries = [];
        var def = split.def;
        var param = def.param;

        for (var s = 0; s < series.length; s++) {
            var serie = series[s];

            var sLogs = {};

            // Filter
            var logs = serie.logs;
            for (var i = 0; i < logs.length; i++) {
                var log = logs[i];
                var value = log[param];
                var slog = sLogs[value];
                if (!slog) sLogs[value] = [log];
                else       slog.push(log);
            }

            var keys = this.splitKeys(split, sLogs);

            // Create
            for (var i = 0; i < keys.length; i++) {
                var id = keys[i];
                var slog = sLogs[id];
                if (slog.length < this.minLogs) continue;

                var tags = (serie.tags || []).slice();
                var tag = def.name + id;
                tags.push(tag);

                if (!tagsDef.find( (td) => { return td.tag === tag; })) {
                    tagsDef.push({
                        tag: tag,
                        hidden: false,
                        group: def.name,
                        title: def.tagTitle.replace('<ID>', id),
                    });
                }

                var serieId = serie.id + '/' + def.name + id;
                splitSeries.push({
                    id: serieId,
                    title: serie.title.trim() + ', ' + def.name + ' ' + id,
                    definition: serie.definition,
                    logs: slog,
                    tags: tags,
                });
                split.list[id] = true;
            }
        }

        return splitSeries;
    },

    splitKeys: function (split, list) {
        var keys = Object.keys(list);
        keys.sort(function (a, b) {
            switch (split.def.sort) {
            case 'float':
                return parseFloat(a) - parseFloat(b);
            }
            return (a | 0) - (b | 0);
        });
        return keys;
    },

    showSlotHisto: function () {

        var chartDef = this.selChart.definition;

        var win = Ext.create('lte.analytics.histo', {
            title: chartDef.title + ' by slots',
            graph: chartDef.graph,
            graphUpdate: this.slotHistoUpdate.bind(this, chartDef),
        });
        win.show();
    },

    slotHistoUpdate: function (chartDef, graph, parent) {

        graph.reset(true);

        var slotCount = 0;
        var slotMax = parent.slotMaxField.getValue();

        for (var j = 0; j < this.selUEs.length; j++) {
            var selUE = this.selUEs[j];
            var ue_id = selUE === - 1 ? '' : selUE.toString(16);

            for (var s = 0; s < chartDef.series.length; s++) {
                var serieDef = chartDef.series[s];

                var slots = null;
                var logs = serieDef.logs;
                var count = 0;
                for (var i = 0; i < logs.length; i++) {
                    var log = logs[i];
                    if (typeof log.slot !== 'number') continue;

                    // Init ??
                    if (!slots) {
                        if (!slotCount) {
                            slotCount = log.getCell().getSlotCount();
                            if (!slotMax) {
                                parent.slotMaxField.setValue(slotCount);
                                slotMax = slotCount;
                                parent.slotPerFrame = slotCount;
                            }
                        }
                        slots = [];
                        for (var i = 0; i < slotMax; i++) slots[i] = [];
                    }

                    var slot = (log.frame * slotCount + log.slot) % slotMax;
                    slots[slot].push(log);
                    count++;
                }
                if (!count) continue; // No data

                graph.addSerie(
                    'ue' + ue_id + '.s' + s,
                    {
                        title: serieDef.title.replace('<ue_id>', ue_id),
                        drawStyle: 'histogram',
                        values: slots.map((function (logs, i) {

                            var data = this.getSerieAverageValues(serieDef, logs, 0);
                            if (data)
                                return {x: i, y: data[0].y};
                            return {x: i, y: null};
                        }).bind(this)),
                    }
                );
            }
        }
    },

    // Create chart
    createChartTab: function (chartDef) {

        var tagsDef = [];
        var allSeries = [];
        var splitList = {};
        for (var id in this.splitList) {
            var s = this.splitList[id];
            if (chartDef.splitList[id] && s.comp.getValue()) {
                splitList[id] = { list: {}, def: s };
            }
        }

        for (var i = 0; i < this.selUEs.length; i++) {
            var selUE = this.selUEs[i];
            var ue_id = selUE === - 1 ? '' : selUE.toString(16);

            for (var s = 0; s < chartDef.series.length; s++) {
                var serieDef = chartDef.series[s];

                switch (serieDef.global) {
                case true:
                    break;
                case 'only':
                    if (selUE !== -1) continue;
                    break;
                default:
                    if (selUE === -1) continue;
                    break;
                }

                var logs = serieDef.logs.slice();
                if (selUE !== -1) {
                    logs = logs.filter(function (log) { return log.ue_id === selUE; });
                }

                if (logs.length < this.minLogs) continue;

                // Serie template
                var series = [{
                    id: 'ue' + ue_id + '.s' + s,
                    definition: serieDef,
                    title: serieDef.title.replace('<ue_id>', ue_id),
                    logs: logs,
                }];

                if (serieDef.cells) {
                    var s0 = series[0];
                    this._cells.forEach( (id) => {
                        var logs1 = logs.filter( (log) => { return log.cell === id; } );
                        if (logs.length >= this.minLogs) {
                            series.push({
                                id: s0.id + 'cell' + id,
                                definition: serieDef,
                                title: s0.title + ' cell ' + id,
                                disabled: serieDef.cells === true,
                                logs: logs1,
                            });
                        }
                    });
                    if (serieDef.cells === 'only')
                        series.shift();
                }

                for (var id in splitList) {
                    if (serieDef.split && serieDef.split.indexOf(id) >= 0) {
                        series = this.getSeriesBySplit(series, splitList[id], tagsDef);
                    }
                }

                // Add
                if (series.length)
                    allSeries.push.apply(allSeries, series);
            }
        }

        if (!allSeries.length)
            return null;

        // Create chart
        var graph = chartDef.graph;
        if (!graph) graph = chartDef.graph = {};
        if (!chartDef.onClick) {
            graph.onClick = this._onClick.bind(this);

            var axis = graph.axis;
            if (!axis) axis = graph.axis = {};
            if (!axis.x) axis.x = {unit: 'time'};
            if (!axis.y) axis.y = {};
        }

        var chart = chartDef.chart = Ext.create('lte.graph', {
            title: chartDef.title,
            graph: graph,
            toolTipSort: 'desc',
            tags: tagsDef.length ? tagsDef : undefined,
        });

        for (var i = 0; i < allSeries.length; i++) {
            var serie = allSeries[i];
            var cfg = {
                title: serie.title,
                enabled: !serie.disabled,
                y: [serie.definition.y || 'y']
            };
            if (serie.definition.avg === 'no')
                cfg.drawStyle = 'cross';
            chart.addSerie(serie.id, cfg, serie.tags);

            if (serie.definition.instant && this.showInstant.getValue()) {
                cfg = Object.assign({}, cfg);
                cfg.drawStyle = 'cross';
                cfg.title += ' (instant)';
                cfg.y = [serie.definition.instant];
                chart.addSerie(serie.id + '#inst', cfg);
            }
        }

        chart.definition = chartDef;
        chart.series = allSeries;
        
        return chart;

    },

    reloadCharts: function () {

        // Replace chart
        this.chartPanel.removeAll();

        var curChartDef = this.selChart ? this.selChart.definition : null;

        var activeTab = 0;
        var chartList = [];
        for (var i in this._chartDefinitions) {
            var chartDef = this._chartDefinitions[i];
            var chart = this.createChartTab(chartDef);
            if (chart) {
                if (curChartDef === chartDef) activeTab = chartList.length;
                chartList.push(chart);
            }
        }

        var tab = this.chartPanel.add(Ext.create('Ext.tab.Panel', {
            items: chartList,
            activeTab: activeTab,
            listeners: {
                scope: this,
                tabchange: function(tabPanel, newCard, oldCard, eOpts) {
                    this.updateChart(newCard);
                }
            }
        }));

        if (chartList.length) {
            this.updateChart(chartList[activeTab]);
        }
    },

    selChart: null,
    avg_time: 250,

    updateChart: function (chart) {

        lteLogs.chart = chart;
        this.selChart = chart;

        for (var id in this.splitList) {
            this.splitList[id].comp.setHidden(!chart.definition.splitList[id]);
        }
        this._slotHisto.setHidden(!chart.definition.splitList.slot);

        var t0 = new Date();

        chart.graph.reset();
        chart.lock();

        // Filter each serie
        var hasInstant = false;
        var series = chart.series;
        for (var s = 0; s < series.length; s++) {
            var serie = series[s];
            var def   = serie.definition;
            var data = this.getSerieAverageValues(def, serie.logs, this.avg_time);
            if (data)
                chart.addValues(serie.id, data);

            if (def.instant) {
                hasInstant = true;
                if (this.showInstant.getValue()) {
                    def = Object.assign({}, def);
                    def.y = def.instant;
                    var data = this.getSerieInstantValues(def, serie.logs);
                    chart.addValues(serie.id + '#inst', data);
                }
            }
        }
        chart.unlock();

        this.showInstant.setDisabled(!hasInstant);

        this.prof("Average stats in", new Date() - t0, 'for', chart.definition.title);
    },

    getSerieInstantValues: function (serieDef, logs) {

        var valueId = serieDef.value;
        var yName   = serieDef.y || 'y';
        if (serieDef.tb) {
            var error = serieDef.error;
            var crc   = serieDef.crc;
            var mode  = serieDef.mode;
            var f = function (log) {
                var item = {x: log.timestamp, logs: [log], count: 1};

                var value = 0;
                for (var j = 0; j < log.tb.length; j++) {
                    var tb = log.tb[j];
                    if (!tb) continue;
                    if (error && tb.error === true) continue;
                    if (crc && tb.crc === false) continue;

                    if (log.ru !== undefined) continue;
                    if (log.rep || log.sf) continue;

                    var v = log.tb[j][valueId];
                    if (v !== undefined) {
                        value += this._getValue(v, mode);
                    }
                }
                item[yName] = value;
                return item;
            };
        } else {
            var f = function (log) {
                var item = {x: log.timestamp, logs: [log], count: 1};
                item[yName] = log[valueId];
                return item;
            };
        }
        return logs.map(f.bind(this));
    },

    getSerieAverageValues: function (serieDef, logs, avg_time) {

        var valueId  = serieDef.value;
        var useTB    = serieDef.tb;
        var avg      = serieDef.avg;
        var mode     = serieDef.mode;
        var error    = serieDef.error;
        var crc      = serieDef.crc;
        var dir      = serieDef.dir;
        var yName    = serieDef.y || 'y';

        if (!logs || !logs.length)
            return null;

        var ts = logs[0].timestamp;
        if (!avg_time) {
            avg_time = logs[logs.length - 1].timestamp - ts;
            if (!avg_time)
                return null;
        }
        var avg_time2 = avg_time >> 1;

        var data = [];
        for (var i = 0, length = logs.length; i < length;) {

            var alog  = 0; // Average log
            var count = 0;
            for (; i < length; i++) {
                var log = logs[i];
                if (log.timestamp - ts > avg_time) break;

                if (useTB) {
                    for (var j = 0; j < log.tb.length; j++) {
                        var tb = log.tb[j];
                        if (!tb) continue;
                        if (error && tb.error === true) continue;
                        if (crc && tb.crc === false) continue;

                        if (log.ru !== undefined) continue;
                        if (log.rep || log.sf) continue;

                        var v = log.tb[j][valueId];
                        if (v !== undefined) {
                            alog += this._getValue(v, mode);
                            count++;
                        }
                    }
                } else if (avg === 'tti') {
                    var cell = log.getCell();
                    if (cell) {
                        if (dir === lteLogs.DIR_DL) {
                            alog += log[valueId] / cell.getDLRatio();
                        } else {
                            alog += log[valueId] / cell.getULRatio();
                        }
                    } else {
                        alog += log[valueId];
                    }
                } else {
                    alog += this._getValue(log[valueId], mode);
                    count++;
                }
            }

            var value = null;
            switch (avg) {
            case 'time':
                value = alog * 1000 / avg_time;
                break;
            case 'tti':
                value = alog / avg_time;
                break;
            default:
                if (count > 0) {
                    value = alog / count;
                }
                break;
            }
            if (value !== null) {
                var item = {x: ts + avg_time2, logs: logs, count: count};
                item[yName] = value;
                data.push(item);
            }
            ts += avg_time;
        }
        if (data.length === 1) {
            // XXX: check graph boundaries and add values to 0 or same value
            var item = Object.assign({}, data[0]);
            item.x++;
            data.push(item);
        }
        return data;
    },

    _getValue: function (value, mode) {

        switch (mode) {
        case 'count+':
            if (value > 0)
                return 1;
            return 0;

        case 'count0':
            if (!value)
                return 1;
            return 0;

        case 'count':
            return 1;

        default:
            return value;
        }
    },
});


var lteStatsTab = {

    _stats: {},

    add: function(clientName, msg) {

        var now = new Date() * 1;
        var chart = this._stats.chart;
        if (!chart)
            chart = this._stats.chart = this._createChart(now);

        // CPU
        this._setStatsObj(msg.cpu, clientName, chart, now, 'cpu');

        // Prof
        this._setStatsObj(msg.prof, clientName, chart, now, 'cpu');

        // Cells
        for (var c in msg.cells) {
            this._setStatsObj(msg.cells[c].prof, clientName + ', cell ' + c, chart, now, 'cells');
        }

        // RF ports
        for (var r in msg.rf_ports) {
            this._setStatsObj(msg.rf_ports[r].prof, clientName + ', rf port ' + r, chart, now, 'rf_ports');
        }

        // PMC
        this._setStatsObj(msg['pmc.freq'], clientName, chart, now, 'pmc');
        this._setStatsObj(msg['pmc.ipc'], clientName, chart, now, 'ipc');

        chart.update();
    },

    _setStatsObj: function (obj, name, chart, time, type, unit) {
        for (var id in obj) {
            var value = {x: time};
            value[type] = obj[id];
            chart.addSerie(name + id, { title: name + ', ' + id, y: [type], values: [value] });
        }
    },

    _createChart: function (now) {
        var chart = Ext.create('lte.graph', {
            title: 'Stats',
            iconCls: 'icon-chart',
            resetFunc: (function () {
                now = new Date() * 1;
            }).bind(this),
            graph: {
                columns: 1,
                overMode: 'time',
                margin: {
                    top: 20,
                    bottom: 8,
                    left: 50,
                    right: 5,
                },
                axis: {
                    x: {
                        unit: 'date',
                        auto: 'max',
                        hidden: true,
                        min: function () { return now },
                        max: function () { return now + 300000},
                    },
                    cpu: {index: 0, title: 'Global CPU usage', unit: '100%', min: 0, max: 15},
                    cells: {index: 1, title: 'Cells CPU usage', unit: '100%', min: 0, max: 10},
                    rf_ports: {index: 2, title: 'RF Port CPU usage', unit: '100%', min: 0, max: 10},
                    pmc: {index: 3, title: 'Core frequency', unit: 'GHz', min: 0, max: 5},
                    ipc: {index: 3, title: 'Core instructions per cycles', unit: '', min: 0, max: 5},
                }
            },
        });
        lteLogs.addTab(chart);
        return chart;
    },
};




/*Ext.define('lte.analytics.test', {

    extend: 'Ext.window.Window',
    title: 'Test',
    width: 1200,
    height: 600,
    constraint: true,
    layout: 'fit',
    maximizable: true,

    constructor: function (config) {
        this.callParent(arguments);
    },

    initComponent: function () {
        this.callParent(arguments);

        var graph = Ext.create('lte.graph', {
            title: 'Tests',
            iconCls: 'icon-chart',
            graph: {
                columns: 1,
                overMode: 'time',
                margin: {
                    top: 20,
                    bottom: 28,
                    left: 50,
                    right: 5,
                },
                axis: {
                    x: {
                        auto: 'histogram',
                        unit: function (v) { return 'Slot ' + v; },
                        stepMin: 10
                    },
                    y: {
                    },
                },
            }
        });

        for (var j = 0; j < 2; j++) {
            var values = [];
            for (var i = 1; i <= 18; i++) {
                values.push({x: i, y: Math.random() * 10});
            }
            graph.addSerie('s' + j, { title: 'Serie ' + j, values: values, drawStyle: 'histogram' });
        }

        this.add(graph);
        graph.unlock();
        this._graph = graph;
    }
});*/


Ext.define('lte.analytics.histo', {

    extend: 'Ext.window.Window',
    title: lteLogs.getHTMLIcon('icon-chart') + ' Statistics',
    width: 1200,
    height: 600,
    constraint: true,
    layout: 'fit',
    maximizable: true,
    slotCount: 10,

    constructor: function (config) {
        this.callParent(arguments);
    },

    initComponent: function () {
        this.callParent(arguments);

        this.slotPerFrame = 0;
        var graph = Ext.create('lte.graph', {
            graph: {
                columns: 1,
                overMode: 'time',
                margin: {
                    top: 20,
                    bottom: 50,
                    left: 50,
                    right: 5,
                },
                axis: {
                    x: {
                        auto: 'histogram',
                        unit: (function (v) {
                            var unit = '' + (v % this.slotPerFrame);
                            if (v >= this.slotPerFrame) unit += ' (' + v + ')';
                            return unit;
                        }).bind(this),
                        stepMin: 10
                    },
                    y: this.graph.axis.y
                },
            }
        });

        this.slotMaxField = Ext.create('Ext.form.field.Number', {
            anchor: '100%',
            fieldLabel: 'Slot count',
            labelWidth: 80,
            width: 160,
            value: 0,
            step: 1,
            maxValue: 100,
            minValue: 1,
            listeners: {
                scope: this,
                change: function(num, newValue, oldValue, eOpts) {
                    if (oldValue) {
                        graph.lock();
                        this.graphUpdate(graph, this);
                        graph.unlock();
                    }
                }
            }
        });

        this.add(Ext.create('Ext.panel.Panel', {
            height: '100%',
            layout: 'fit',
            tbar: [this.slotMaxField],
            items: [graph]
        }));
        this.graphUpdate(graph, this);
        graph.unlock();
    },
});


