/*
 * Copyright (C) 2012-2025 Amarisoft
 *
 * Amarisoft Web interface 2025-05-21
 */

Ext.define("lte.ue.tab", {

    extend: 'lte.client.tab',

    useRefresh: true,

    constructor: function (config) {
        this.callParent(arguments);
        lteSim.registerTab(this);
    },

    listeners: {
        activate: function () {
            // Workaround
            this._ueGrid.view.refresh();
        },
    },

    initComponent: function () {

        this.callParent(arguments);

        this.addRFConfig(['pdsch', 'npdsch']);

        var startSimButton = new Ext.create('Ext.Button', {
            text: 'Scenario...',
            scope: this,
            iconCls: 'icon-play',
            tooltip: lteLogs.tooltip('Click to select scenario and start it'),
            handler: function (b, e) {

                var ueList = ueGrid.getSelection().map(function (rec) { return rec.get("ue_id"); });

                var items0 = [];
                var items1 = [];
                var sims = lteSim.get();
                for (var i = 0; i < sims.length; i++) {
                    var sim = sims[i];

                    if (sim.get("ue").count) {
                        items0.push({
                            text: 'Start scenario ' + sim.get('name'),
                            iconCls: 'icon-play',
                            scope: this,
                            handler: (function(sim) { this.createUESimTab(sim); }).bind(this, sim.getData()),
                        });
                    } else if (ueList.length) {
                        items1.push({
                            text: 'Start scenario ' + sim.get('name'),
                            iconCls: 'icon-play',
                            scope: this,
                            handler: (function(sim) { this.createUESimTab(sim, ueList); }).bind(this, sim.getData()),
                        });
                    }
                }

                if (!items0.length && !items1.length) {
                    Ext.Msg.alert('No scenario defined', 'Go to UE Scenario tab to create scenario.<br/>Only scenario creating UE are available.');
                    return;
                }

                if (items1.length) {
                    items0.unshift({
                        text: 'Start on selected UEs',
                        iconCls: 'icon-ue',
                        menu: {
                            items: items1,
                        }
                    });
                }

                var menu = new Ext.menu.Menu({items: items0});
                var position = e.getXY();
                menu.showAt(position);
            }
        });
        this.tbar.add(startSimButton);

        var stopSimButton = new Ext.create('Ext.Button', {
            text: 'Stop scenario',
            scope: this,
            iconCls: 'icon-stop',
            tooltip: lteLogs.tooltip('Stop all running scenario'),
            handler: function (b, e) {
                this.client.sendMessage({message: 'cancel'}, function (msg) {
                });
                lteSim.playerCancel(this.client);
            }
        });
        this.tbar.add(stopSimButton);

        var reestButton = new Ext.create('Ext.Button', {
            text: 'Reestablishment',
            scope: this,
            iconCls: 'icon-sync',
            tooltip: lteLogs.tooltip('Force reestablishment on selected UEs'),
            disabled: true,
            handler: function (b, e) {
                var ueList = ueGrid.getSelection().map(function (rec) { return rec.get("ue_id"); });

                this.client.sendMessage(ueList.map(function (ue_id) {
                    return { message: 'rrc_reest', ue_id: ue_id };
                }));
            }
        });
        var powerOnButton = new Ext.create('Ext.Button', {
            text: 'Power on',
            scope: this,
            iconCls: 'icon-ok',
            tooltip: lteLogs.tooltip('Force power on on selected UEs'),
            disabled: true,
            handler: function (b, e) {
                Ext.Msg.prompt('Power on', 'Number of connections per seconds:', (btn, text) => {
                    if (btn !== 'ok') return;
                    var caps = parseFloat(text);
                    if (isNaN(caps) || caps < 0) return;
                    var d = caps ? 1 / caps : 0;

                    var ueList = ueGrid.getSelection().map(function (rec) { return rec.get("ue_id"); });
                    var time = 0;
                    var msgList = [];
                    for (var time = 0; ueList.length > 0; time += d) {
                        var i = (Math.random() * ueList.length) >> 0;
                        msgList.push({
                            message: 'power_on',
                            start_time: time,
                            ue_id: ueList[i],
                        });
                        ueList.splice(i, 1);
                    }
                    this.client.sendMessage(msgList);
                }, this, false, '1');
            }
        });
        var powerOffButton = new Ext.create('Ext.Button', {
            text: 'Power off',
            scope: this,
            iconCls: 'icon-off',
            tooltip: lteLogs.tooltip('Force power off on selected UEs'),
            disabled: true,
            handler: function (b, e) {
                this.client.sendMessage(ueGrid.getSelection().map((rec) => {
                    return {
                        message: 'power_off',
                        ue_id: rec.get("ue_id"),
                    };
                }));
            }
        });
        this.tbar.add(powerOnButton);
        this.tbar.add(powerOffButton);
        this.tbar.add(reestButton);

        // Update UE list
        this._updater = Ext.create("lte.updater", {
            scope:            this,
            updateDelay:    1000,
            dirty:            true,
            lock:            1,
            handler:        function () {
            }
        });

        // UE list management
        this._ueList = {
            cache: {},
            timer: 0,
            request: false,
            time: new Date() * 1,
        };
        this.getUESend();

        var ueStore = this._ueStore = Ext.create('Ext.data.Store', {
            fields: ["imsi", "ue_id", "category", "power_on", "timing_advance", 'path_loss', "rnti", "rrc_state", "emm_state", 'pdn_list', 'cell_index']
        });

        var ueGrid = this._ueGrid = Ext.create('Ext.grid.Panel', {
            store: ueStore,
            selModel: {
                mode: "MULTI",
                allowDeselect: true,
                ignoreRightMouseSelection: true,
            },
            viewConfig:{
                markDirty: false
            },
            columns: [{
                xtype: 'actioncolumn',
                width: 30,
                text: "",
                dataIndex: 'power_on',
                items: [{
                    scope: this,
                    getClass: function (state, meta, rec, rowIndex, colIndex, store) {
                        return state ? 'icon-ok' : 'icon-off';
                    },
                    tooltip: lteLogs.tooltip('Power on/off'),
                    handler: function(view, rowIndex, colIndex, item, e, record) {
                        this.client.sendMessage({
                            message: record.get('power_on') ? 'power_off' : 'power_on',
                            ue_id: record.get('ue_id'),
                        }, function (resp) {
                        });
                    }
                }],
            }, {
                text: "ID",
                dataIndex: "ue_id",
                width: 45
            }, {
                text: "IMSI",
                dataIndex: "imsi",
                width: 150
            }, {
                text: 'RNTI',
                dataIndex: 'rnti',
                renderer: function (value) { return value !== undefined ? value.toString(16) : '&nbsp'; },
                width: 70
            }, {
                text: 'Cat.',
                dataIndex: 'category',
                width: 45,
                renderer: function (value) {
                    switch (value) {
                    case -2: return 'NB-IoT';
                    case -1: return 'M1';
                    default: return value;
                    }
                }
            }, {
                text: 'RRC',
                dataIndex: 'rrc_state',
                width: 110
            }, {
                text: 'EMM',
                dataIndex: 'emm_state',
                width: 150
            }, {
                text: 'Cell (PCI)',
                dataIndex: 'pci',
                scope: this,
                renderer: function (pci) {
                    if (pci === undefined) return '?';
                    return '0x' + pci;
                },
            }, {
                text: 'RSRP',
                dataIndex: 'rsrp',
                width: 70,
                renderer: function (value) { return value.toFixed(1); },
            }, {
                text: 'SNR',
                dataIndex: 'snr',
                width: 70,
                renderer: function (value) { return value.toFixed(1); },
            }, {
                text: 'TA',
                dataIndex: 'timing_advance',
                width: 35,
            }, {
                text: 'Pathloss',
                dataIndex: 'path_loss',
                width: 55,
            }, {
                text: 'Position',
                dataIndex: 'position',
                renderer: function (value) { return value || '&lt;none&gt;'; },
                width: 70,
            }, {
                text: 'IP',
                dataIndex: 'pdn_list',
                renderer: function (pdn_list) {
                    if (!pdn_list) return '&lt;none&gt;';

                    var ips = [];
                    pdn_list.forEach(function (pdn) {
                        if (pdn.ipv4) ips.push(pdn.ipv4);
                        if (pdn.ipv6) ips.push(pdn.ipv6);
                    });
                    return ips.join(', ');
                },
                flex: 1,
            }],
            listeners: {
                scope: this,
                selectionchange: function (view, selected, eOpts) {
                    reestButton.setDisabled(selected.length === 0);
                    powerOnButton.setDisabled(selected.length === 0);
                    powerOffButton.setDisabled(selected.length === 0);
                    var tags = selected.map( (rec) => { return 'ue' + rec.get('ue_id'); });
                    if (!tags.length) tags = [''];
                    this._ueChartList.forEach( (cl) => {
                        this._field2chart[cl[0]].comp.selectTags([tags]);
                    });
                    this.updateChartTabs('sel change');
                },
                cellcontextmenu: function(myGrid, td, cellIndex, record, tr, rowIndex, e, eOpts) {
                    var items = [];

                    var power_on = record.get("power_on");
                    items.push({
                        text: power_on ? 'Power off': 'Power on',
                        scope: this,
                        iconCls: power_on ? 'icon-off' : 'icon-ok',
                        handler: function() {
                            this.client.sendMessage({message: power_on ? 'power_off' : 'power_on', ue_id: record.get('ue_id')});
                        }
                    });
                    // Connect to PDN
                    items.push({
                        text: 'Connect pdn',
                        scope: this,
                        iconCls: 'icon-dial',
                        handler: function() {
                            lteLogs.popup('lte.ue.pdn_connect', (data) => {
                                if (data) {
                                    this.client.sendMessage({
                                        message: 'pdn_connect',
                                        ue_id: record.get('ue_id'),
                                        apn: data.apn,
                                        pdn_type: data.type,
                                    });
                                }
                            });
                        }
                    });
                    if (record.get("rrc_state") === "connected") {
                        items.push({
                            text: 'RRC reestablishment',
                            scope: this,
                            iconCls: 'icon-sync',
                            handler: function() {
                                this.client.sendMessage({message: 'rrc_reest', ue_id: record.get('ue_id')});
                            }
                        });
                    }

                    // Scenario
                    var sims = lteSim.get();
                    for (var i = 0; i < sims.length; i++) {
                        var sim = sims[i];

                        if (sim.get("ue").count) continue;
                        if (!sim.get('scripts').length && !sim.get('power').enabled) continue;

                        if (!i)
                            items.push({xtype: 'menuseparator'});

                        items.push({
                            text: 'Start scenario ' + sim.get('name'),
                            iconCls: 'icon-play',
                            scope: this,
                            handler: (function(sim, ue_id) { this.createUESimTab(sim, [ue_id]); }).bind(this, sim.getData(), record.get("ue_id")),
                        });
                    };

                    var menu = new Ext.menu.Menu({items: items});
                    var position = e.getXY();
                    e.stopEvent();
                    menu.showAt(position);

                    myGrid.select(record);
                }
            }
        });

        this.statsRFSamplesInit();

        this.add({
            region: 'center',
            layout: 'fit',
            items: [ueGrid],
        }, {
            region: 'south',
            layout: 'fit',
            height: 300,
            split: true,
            items: [this.getChartPanel(this._statsChart)],
        });
    },

    _chartList: [{
        title:    'Bitrate',
        fieldType:    ['bitrate'],
        unit:    'brate',
        serieWidth: 300,
        autoHide: true,
    }, {
        title:    'Packets',
        fieldType:    ['dl_rx_count', 'dl_err_count', 'ul_tx_count', 'ul_retx_count'],
        unit:    '',
        serieWidth: 300,
        autoHide: true,
    }, {
        title:    'Signal',
        fieldType:    ['cfo'],
        unit:    'Hz',
        serieWidth: 300,
        autoHide: true,
    }, {
        title:    'UE signal',
        fieldType:    ['signalue'],
        unit:    'dB',
        serieWidth: 300,
        autoHide: true,
    }, {
        title:    'Scheduler',
        fieldType:    ['sched'],
        unit:    '',
        serieWidth: 300,
        autoHide: true,
    }, {
        title:        'Messages',
        fieldType:    ['messages'],
        serieWidth: 400,
        unit: ''
    }, {
        title:        'Errors',
        fieldType:    ['errors'],
        serieWidth: 400,
        unit: ''
    }],

    _eventListener: function (event) {

        switch (event.type) {
        case 'stats':
            var bitrates = this._field2chart.bitrate;
            var packets = this._field2chart.dl_rx_count;
            var sched = this._field2chart.sched;
            var cfo = this._field2chart.cfo;
            if (!bitrates) return;

            var now = new Date() - 0;
            for (var cell_index in event.data.cells) {
                var data = event.data.cells[cell_index];

                for (var id in UEConfig.series.br) {
                    bitrates.comp.addValues(id + '.' + cell_index, [{ x: now, y: data[id] }]);
                }
                for (var id in UEConfig.series.packets) {
                    switch (id) {
                    case 'dl_bler':
                        var total = data.dl_rx_count + data.dl_err_count;
                        if (total) {
                            packets.comp.addValues(id + '.' + cell_index, [{ x: now, bler: data.dl_err_count / total }]);
                        }
                        break;
                    default:
                        packets.comp.addValues(id + '.' + cell_index, [{ x: now, y: data[id] }]);
                        break;
                    }
                }
                for (var id in UEConfig.series.sched) {
                    sched.comp.addValues(id + '.' + cell_index, [{ x: now, y: data[id] }]);
                }
                for (var id in UEConfig.series.signal) {
                    cfo.comp.addValues(id + '.' + cell_index, [{ x: now, y: data[id] }]);
                }
            }

            this.statsRFSamplesFeed(event);
            this._updateCounters(now, event.data.counters);
            break;

        case 'close':
            lteSim.unregisterTab(this);
            break;
        }
    },

    // Create UE main tab
    createUESimTab: function (sim, ue_ids) {
        if (!sim.ue.count && !ue_ids) {
            var cb = (function (ue_ids) { this.createUESimTab(sim, this.getUEIDs()); }).bind(this);

            // Defer simulation when UE list complete
            this._ueList.onComplete = cb;
            return;
        }

        var tab = Ext.create('lte.ue.sim', {
            title: this.client.getName() + ": " + sim.name,
            sim: sim,
            cells: this._cells,
            ue_ids: ue_ids,
            client: this.client,
            tab: this
        });
    },

    setClientConfig: function (config) {

        this._cells = config.cells;
        UEConfig.setSerie(this._field2chart.bitrate.comp, 'br', this._cells);
        UEConfig.setSerie(this._field2chart.dl_rx_count.comp, 'packets', this._cells);
        UEConfig.setSerie(this._field2chart.sched.comp, 'sched', this._cells);
        UEConfig.setSerie(this._field2chart.cfo.comp, 'signal', this._cells);

        this.setClientConfigRF(config);
    },

    getUE: function (ue_id) {
        var record = this._ueList.cache[ue_id];
        if (record)
            return record.getData();
        return null;
    },

    getUESend: function () {

        var ueList = this._ueList;
        if (this._closed || ueList.request) return;

        if (ueList.timer) {
            clearTimeout(ueList.timer);
            ueList.timer = 0;
        }

        this.client.sendMessage({message: 'ue_get', max: 256}, this.getUECb.bind(this));
        ueList.request = true;
    },

    _ueChartList: [['bitrate', 'br'], ['signalue', 'signalue']],

    getUECb: function (msg) {

        var ueList = this._ueList;
        ueList.request = false;
        if (this._closed) return;

        var store = this._ueStore;
        if (msg.ue_list) {
            var now = new Date() - 0;

            lteSim.ueGetUpdate(msg.ue_list);
            this.client.sendEvent({type: 'ue', data: msg.ue_list, time: msg.time});
            lteLogs.storeUpdate(ueList.cache, store, msg.ue_list, 'ue_id', msg.pending, (ue, prev) => {

                this._ueChartList.forEach( (cl) => {

                    var comp = this._field2chart[cl[0]].comp;
                    var serie = UEConfig.series[cl[1]];
                    for (var id in serie) {
                        var serieId = 'ue' + ue.ue_id + id;
                        if (!prev) {
                            comp.addSerie(serieId, {
                                enabled: true,
                                hidden: true,
                                title: serie[id].title.replace('#<cell>', 'UE #' + ue.ue_id).replace('<UE>', 'UE #' + ue.ue_id),
                            }, 'ue' + ue.ue_id);
                        }
                        comp.addValues(serieId, [{ x: now, y: ue[id] }]);
                    }
                });
                if (!prev)
                    this.updateChartTabs('ue get');
            });
        }

        if (!msg.pending) {
            if (ueList.onComplete) {
                ueList.onComplete();
                ueList.onComplete = null;
            }

            var now = new Date() * 1;
            var delay = this.client.getRefreshDelay();
            while (ueList.time < now) ueList.time += delay;

            ueList.timer = setTimeout(this.getUESend.bind(this), ueList.time - now);
        } else {
            this.getUESend();
        }
    },

    getUEIDs: function () {
        return Object.keys(this._ueList.cache).map(function (id) { return id | 0; });
    },
});



Ext.define("lte.ue.sim", {

    extend: 'Ext.panel.Panel',
    layout: 'border',
    closable: true,
    iconCls: 'icon-report',

    constructor: function (config) {
        this._sim = config.sim;
        this._cells = config.cells;
        this.player = new SimPlayer(config.sim, config.ue_ids, config.client, this.playerEvent.bind(this));
        this.callParent(arguments);
        this._listenerId = config.client.registerEventListener('*', this._eventListener.bind(this));
    },

    listeners: {
        activate: function () {
            this._updater.unlock();
            switch (this._testState) {
            case 'init':
            case 'start':
                this.setLoading(true);
                break;
            }
        },
        deactivate: function () {
            this._updater.lock();
        },
        close: function () {
            this._updater.destroy();
            this.player.destroy();
            this.client.unregisterEventListener(this._listenerId);
        },
    },

    playerEvent: function (event) {

        switch (event.type) {
        case 'starting':
            lteLogs.addTab(this);
            this._resetGraph();
            this._restartButton.setDisabled(true);
            this._exportButton.setDisabled(true);
            this._stopButton.setDisabled(false);
            break;
        case 'started':
            this._updater.update(true);
            this.setLoading(false);
            break;
        case 'script':
            this._scriptToolTipUpdate(event.script);
            break;
        case 'end':
            this._updater.update(true);
            this._updateGlobalStatus();
            if (!event.restart) {
                this._restartButton.setDisabled(false);
                this._exportButton.setDisabled(false);
                this._stopButton.setDisabled(true);
            } else {
                this._resetGraph();
            }
            break;
        case 'none':
            Ext.Msg.alert(this._sim.name, 'Done'); // XXX better
            break;

        case 'reset-ue':
            var ue = event.ue;
            var hUE = this._hUE;
            var tMargin = this._timeMargin;
            var sMargin = this._scriptMargin;
            for (var i = 0; i < ue.scripts.length; i++) {
                var script = ue.scripts[i];

                var x0 = (script.time + tMargin) * this._tScale;
                var x1 = x0 + script.duration * this._tScale;

                switch (script.type) {
                case 'power':
                    script.x0 = x0;
                    script.x1 = x1;
                    script.y0 = 0;
                    script.y1 = hUE;
                    break;

                default:
                    if (script.ip) {
                        var n = script.overlapList.reduce(function (a, b) { return Math.max(a, b.overlapMax); }, script.overlapMax);

                        var used = new Array(n); // Count me !
                        script.overlapList.forEach(function (s) { if (s.overlapIndex !== undefined) used[s.overlapIndex] = true});
                        for (var j = 0; j < n && used[j] !== undefined; j++);
                        script.overlapIndex = j;

                        script.x0 = x0;
                        script.x1 = x1;
                        script.y0 = Math.floor(j * hUE / n) + (sMargin >> 1);
                        script.y1 = Math.floor(++j * hUE / n) - (sMargin >> 1);
                    }
                    break;
                }
            }
            break;
        case 'error':
            Ext.Msg.alert('Error', event.error);
            break;
        }
    },

    initComponent: function () {
        this.callParent(arguments);

        this._restartButton = Ext.create('Ext.Button', {
            text: 'Retry',
            iconCls: 'icon-refresh',
            scope: this,
            disabled: true,
            handler: function () {
                this.player.restart();
            }
        });

        this._stopButton = new Ext.create('Ext.Button', {
            text: 'Stop',
            scope: this,
            iconCls: 'icon-stop',
            disabled: true,
            tooltip: lteLogs.tooltip('Stop current scenario'),
            handler: function (b, e) {
                this.player.stopTest();
            }
        });

        this._exportButton = Ext.create('Ext.Button', {
            text: 'Export',
            iconCls: 'icon-download',
            scope: this,
            disabled: true,
            handler: function () {
                this.player.exportReport();
            }
        });

        this.add({
            tbar: {items:[this._restartButton, this._stopButton, this._exportButton]},
            split: true,
            layout: 'fit',
            region: 'center',
            items: [this._createSimReport()]
        });

        this.player.start();
    },

    // Graph
    _resetGraph: function () {
        var gen = this.player.getGen();

        var graph = this._graph = new Graph({
            margin: {left: this._wName, top: 5, bottom: 20, right: 0},
            axis: {
                x: {
                    auto: 'fix',
                    min: -this._timeMargin * 1000,
                    max: (gen.duration + this._timeMargin) * 1000,
                    unit: 'duration',
                    stepFrac: Math.floor(gen.duration / 10),
                    //grad: false,
                },
                y: {
                    axis: 0,
                    unit: 'brate'
                },
                z: {
                    axis: 0,
                },
                bler: {
                    unit: '%',
                }
            },
            overMode: 'time',
            series: {},
            onOver: this._onGraphOver.bind(this),
        });
        UEConfig.setSerie(graph, 'count', this._cells);
        UEConfig.setSerie(graph, 'br', this._cells);
        UEConfig.setSerie(graph, 'packets', this._cells, 'z');
    },

    // Draw config
    _hUE: 30,
    _wName: 50,
    _tScale: 3,
    _marginWidth: 2.5,
    _marginHeight: 2.5,
    _graphHeight: 180,
    _scriptMargin: 4,
    _timeMargin: 1,
    _scrollSize: 20,

    _createSimReport: function () {

        this._scriptLabel = Ext.create('Ext.form.Label', {
            text: 'Status:',
            width: '100%',
            style: {'font-size':'16px'}
        });

        this._updater = Ext.create("lte.updater", {
            scope:            this,
            updateDelay:    500,
            dirty:            false,
            lock:            1,
            handler:        (function () {
                this._drawReport();
                this._updateGlobalStatus();
            }).bind(this)
        });

        // Create canvas
        this._canvasContainer = Ext.create('Ext.panel.Panel', {
            tbar: {items: [this._scriptLabel]},
            html: '<canvas></canvas>',
            layout: 'fit',
            listeners: {
                scope: this,
                resize: function(container, width, height) {
                    if (!this._canvas) {
                        // Configure canvas
                        var canvas = this._canvas = container.el.down("canvas").dom;
                        this._updateArea(canvas, width, height);
                        canvas.addEventListener("mousemove", this._mouseMoveEvent.bind(this), false);
                        canvas.addEventListener("mouseout", this._mouseOutEvent.bind(this), false);
                        canvas.addEventListener('mousedown', this._mouseDownEvent.bind(this), false);
                        canvas.addEventListener('mouseup', this._mouseUpEvent.bind(this), false);
                        canvas.addEventListener(lteLogs.getMouseWheelEvent(), this._mouseWheelEvent.bind(this), false);

                        this._toolTip = Ext.create('Ext.tip.ToolTip', {
                            target: canvas,
                            trackMouse: false,
                            autoHide: false,
                        });
                    }
                    this._updateArea(this._canvas, width, height);
                    this._setScroll(this._scrollX, this._scrollY);
                    this._updater.update(true);
                }
            }
        });
        return this._canvasContainer;
    },

    _formatGlobalStatus: function (status) {
        var list = [];

        if (status.ended > 0)
            list.push(Math.round(100 * status.result / status.ended) + "%");
        list.push(status.total + " simulation(s)");
        if (status.started > 0)
            list.push(status.started + " in progress");
        if (status.error > 0)
            list.push(status.error + " error(s)");
        if (status.ok > 0)
            list.push(status.ok + " ok");
        if (status.ended > 0)
            list.push(status.ended + " done");

        return list;
    },

    _updateGlobalStatus: function () {

        var status = this.player.getGlobalStatus(false);
        var list = this._formatGlobalStatus(status);

        if (this._sim.loop > 0) {
            var status = this.player.getGlobalStatus(true);
            var list1 = this._formatGlobalStatus(status);
            this._scriptLabel.setText('Run ' + (this.player.getLoopCount() + 1) + '/' + (this._sim.loop + 1) + ', ' + list.join(', ') + ' / Total: ' + list1.join(', '));
        } else {
            this._scriptLabel.setText(list.join(", "));
        }
    },

    _updateArea: function (canvas, width, height) {

        canvas.width = width - 3;
        canvas.height = height - 33; // HACK

        // Maximum canvas size
        var gen = this.player.getGen();
        var w1 = gen.duration + this._timeMargin * 2;
        var w2 = this._wName + this._marginWidth * 2;
        var sWidth = w2 + w1 * this._tScale;
        var sHeight = this._hUE * gen.list.length + this._marginHeight * 2 + this._graphHeight;

        var sx = sWidth > canvas.width;
        var sy = sHeight > canvas.height;

        // Horizontal scroll
        if (sx) {
            this._drawHeight = canvas.height - this._scrollSize;
            this._scrollMaxX = sWidth - canvas.width + (sy ? this._scrollSize : 0);
        } else {
            this._drawHeight = canvas.height;
            this._scrollMaxX = 0;
        }

        // Vertical scroll
        if (sy) {
            this._drawWidth = canvas.width - this._scrollSize;
            this._scrollMaxY = sHeight - canvas.height + (sx ? this._scrollSize : 0);
        } else {
            this._drawWidth = canvas.width;
            this._scrollMaxY = 0;
        }
    },

    _drawReport: function () {

        var canvas = this._canvas;
        if (!canvas || !this._graph) return;

        var t0 = new Date();
        var gen = this.player.getGen();

        var ctx    = canvas.getContext("2d");
        var hUE    = this._hUE - 0;
        var wName  = this._wName - 0;
        var tScale = this._tScale - 0;
        var tMargin = this._timeMargin - 0;
        var scrollX = this._scrollX - 0;
        var scrollY = this._scrollY - 0;

        ctx.fillStyle        = 'black';
        ctx.strokeStyle        = 'black';
        ctx.textBaseline    = 'middle';
        ctx.textAlign        = 'center';
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        ctx.save();
        ctx.beginPath();
        ctx.rect(0, 0, this._drawWidth, this._drawHeight);
        ctx.clip();

        var simWidth = (gen.duration + tMargin * 2) * tScale;
        var simHeight = this._drawHeight - this._graphHeight;

        // Draw graph
        ctx.save();
        this._graph.draw(canvas, {
            x: this._marginWidth - scrollX,
            y: this._marginHeight,
            w: wName + simWidth,
            h: this._graphHeight,
            clip: {x: 0, y: 0, w: this._drawWidth - 1, h: this._drawHeight}
        });
        ctx.restore();

        // Scripts
        ctx.save();
        ctx.translate(this._marginWidth, this._marginHeight + this._graphHeight);
        ctx.beginPath();
        ctx.rect(0, 0, wName + simWidth, simHeight);
        ctx.clip();

        var i0 = Math.floor(scrollY / hUE);
        var i1 = Math.ceil((scrollY + simHeight) / hUE);

        // Headers
        for (var i = i0; i < gen.list.length && i < i1; i++) {
            var ue = gen.list[i];
            var y = i * hUE;

            //var ref = this._ueTab.getUE(ue.ue_id);

            ctx.save();
            ctx.translate(0, y - scrollY);
            /*switch (ref.emm_state) {
            case 'registering':
                ctx.fillStyle = '#8080FF';
                ctx.fillRect(0, 0, wName, hUE);
                break;
            case 'registered':
                ctx.fillStyle = '#C0FFC0';
                ctx.fillRect(0, 0, wName, hUE);
                break;
            default:
                break;
            }*/
            ctx.strokeRect(0, 0, wName, hUE);
            ctx.font = (hUE >> 1) + "px Arial";
            ctx.fillStyle = 'black';
            ctx.fillText(ue.ue_id, wName >> 1, hUE >> 1);
            ctx.restore();
        }

        ctx.beginPath();
        ctx.rect(wName, 0, simWidth, simHeight);
        ctx.clip();

        // Scripts
        for (var i = i0; i < gen.list.length && i < i1; i++) {
            var ue = gen.list[i];
            var y = i * hUE;

            ctx.save();
            ctx.fillStyle = '#B0C0D0';
            ctx.font = (hUE >> 2) + "px Arial";
            ctx.translate(wName - scrollX, y - scrollY);
            ctx.fillRect(0, 0, simWidth, hUE);

            for (var s = 0; s < ue.scripts.length; s++) {
                var script = ue.scripts[s];
                if (script.x0 < this._drawWidth - wName + this._scrollX && script.x1 > this._scrollX)
                    this._drawScript(ctx, script);
            }

            // Frame
            ctx.strokeStyle = 'black';
            ctx.strokeRect(0, 0, simWidth, hUE);
            ctx.restore();
        }
        ctx.restore(); // End of scripts

        // Time
        ctx.save();
        ctx.translate(this._marginWidth + wName, this._marginHeight);
        ctx.beginPath();
        ctx.rect(0, 0, simWidth, this._drawHeight);
        ctx.clip();

        var ts = Math.min(this.player.getTimestamp() / 1000, gen.duration + tMargin);

        var x = Math.floor((ts + tMargin) * tScale - scrollX);
        ctx.beginPath();
        ctx.moveTo(x, 3);
        ctx.lineTo(x, gen.list.length * hUE + this._graphHeight - 2);
        ctx.strokeStyle = 'rgba(0,0,0,0.7)';
        ctx.lineWidth = 5;
        ctx.lineCap = 'round';
        ctx.stroke();
        ctx.restore();

        ctx.restore();

        // Scroller
        var ss = this._scrollSize;
        ctx.save();
        ctx.translate(-0.5, -0.5);
        ctx.fillStyle = '#e0e0e0';
        ctx.strokeStyle = 'black';
        if (this._scrollMaxX) {
            ctx.save();
            ctx.beginPath();
            ctx.rect(1, this._drawHeight, this._drawWidth - 1, ss);
            ctx.fill();
            ctx.stroke();
            var x = (this._scrollX / this._scrollMaxX) * (this._drawWidth - ss - 5) >> 0;

            ctx.beginPath();
            ctx.rect(x + 3, this._drawHeight + 2, ss, ss - 4);
            ctx.fillStyle = '#c0c0c0';
            ctx.fill();
            ctx.stroke();
            ctx.restore();
        }
        if (this._scrollMaxY) {
            ctx.save();
            ctx.beginPath();
            ctx.rect(this._drawWidth, 1, ss, this._drawHeight - 1);
            ctx.fill();
            ctx.stroke();
            var y = (this._scrollY / this._scrollMaxY) * (this._drawHeight - ss - 5) >> 0;

            ctx.beginPath();
            ctx.rect(this._drawWidth + 2, y + 3, ss - 4, ss);
            ctx.fillStyle = '#c0c0c0';
            ctx.fill();
            ctx.stroke();
            ctx.restore();
        }
        ctx.restore();

        lteLogs.prof("Draw sim in", new Date() - t0, "ms");
        //console.log("Draw sim in", new Date() - t0, "ms");
    },

    _drawScript: function (ctx, script) {

        switch (script.type) {
        case 'power':
            if (script.x0 === undefined) return;
            ctx.fillStyle = '#F0F8FF';
            break;

        default:
            switch (script.status) {
            case 'start':
                if (!script.network) {
                    ctx.fillStyle = '#FF8000';
                    var text = 'Network down';
                } else {
                    ctx.fillStyle = '#0080FF';
                    var text = "...";
                }
                break;
            case 'done':
                ctx.fillStyle = script.color || 'white';
                var text = Math.floor(script.ratio * 100) + "%";
                if (!script.network) {
                    ctx.fillStyle = '#FF8000';
                    text = '! ' + text;
                }
                break;
            case 'timeout':
                ctx.fillStyle = '#808080';
                var text = 'Timeout';
                break;
            case 'cancel':
                ctx.fillStyle = '#C0C000';
                var text = 'Cancelled';
                break;
            case "wait":
                ctx.fillStyle = '#80C0FF';
                break;
            default:
                return;
            }
            break;
        }

        var x = script.x0;
        var y = script.y0;
        var w = script.x1 - script.x0;
        var h = script.y1 - script.y0;

        ctx.fillRect(x, y, w, h);
        ctx.strokeStyle = 'black';
        ctx.strokeRect(x, y, w, h);
        if (text) {
            ctx.fillStyle = lteLogs.getTextColor(ctx.fillStyle);
            ctx.fillText(text, x + (w >> 1), y + (h >> 1));
        }
    },

    _drawPowerOff: function (ctx, t0, t1) {
        var x = (t0 + this._timeMargin) * this._tScale;
        var w = (t1 + this._timeMargin) * this._tScale - x;

        ctx.fillStyle = '#C0C0C0';
        ctx.fillRect(x, 0, w, this._hUE);
        ctx.strokeStyle = 'black';
        ctx.strokeRect(x, 0, w, this._hUE);
    },

    _scriptToolTipUpdate: function (script) {
        if (script === this._toolTipRef) {
            var lines = [
                "<b>" + script.name + "</b>:",
                "From " + script.time + "s to " + (script.time + script.duration) + "s"
            ].concat(script.events);
            lines.push(script.log);
            this._toolTip.update(lteLogs.tooltip(lines.join("<br/>")));
        }
    },

    _scrollX: 0,
    _scrollY: 0,

    _setScroll: function (sx, sy) {

        sx = Math.max(0, Math.min(this._scrollMaxX, sx));
        sy = Math.max(0, Math.min(this._scrollMaxY, sy));

        if (sx !== this._scrollX || sy != this._scrollY) {
            this._scrollX = sx;
            this._scrollY = sy;
            return true;
        }
        return false;
    },

    _getTypeByPos: function (x, y) {

        if (this._scrollMaxX && y >= this._drawHeight && x <= this._drawWidth)
            return 'scrollX';

        if (this._scrollMaxY && x >= this._drawWidth && y <= this._drawHeight)
            return 'scrollY';

        if (y <= this._graphHeight + this._marginHeight)
            return 'graph';

        if (x <= this._drawWidth && y <= this._drawHeight)
            return 'script';

        return null;
    },

    _mouseGetPos: function (event) {
        var rect = event.target.getBoundingClientRect();
        var x = event.clientX - rect.left;
        var y = event.clientY - rect.top;
        return {
            x: x,
            y: y,
            type: this._getTypeByPos(x, y)
        };
    },

    _mouseScrollEvent: function (pos, type) {
        switch (type) {
        case 'scrollX':
            if (this._setScroll(((pos.x - this._scrollSize / 2) / (this._drawWidth - this._scrollSize)) * this._scrollMaxX, this._scrollY))
                this._drawReport();
            return true;
        case 'scrollY':
            if (this._setScroll(this._scrollX, ((pos.y - this._scrollSize / 2) / (this._drawHeight - this._scrollSize)) * this._scrollMaxY))
                this._drawReport();
            return true;
        }
        return false;
    },

    _mouseWheelEvent: function (event) {
        var delta = lteLogs.getMouseWheelDelta(event);
        var offset = delta / Math.abs(delta) * this._hUE;
        if (offset) {
            if (this._setScroll(this._scrollX, this._scrollY - offset))
                this._drawReport();
        }
    },

    _mouseDownEvent: function (event) {

        var move = this._mouseGetPos(event);
        
        var X = event.clientX;
        var Y = event.clientY;

        switch (move.type) {
        case 'scrollX':
        case 'scrollY':
            this._mouseScrollEvent(move, move.type);
            break;
        case 'graph':
        case 'script':
            var scrollX0 = this._scrollX;
            var scrollY0 = this._scrollY;
            break;
        default:
            return;
        }

        lteLogs.registerMouseMove((function (event1) {
            switch (event1.type) {
            case 'mouseup':
            case 'mousemove':
                switch (move.type) {
                case 'scrollX':
                case 'scrollY':
                    this._mouseScrollEvent({x: event1.clientX - X + move.x, y: event1.clientY - Y + move.y}, move.type);
                    break;
                case 'graph':
                    if (this._setScroll(X - event1.clientX + scrollX0, this._scrollY))
                        this._drawReport();
                    break;
                case 'script':
                    if (this._setScroll(X - event1.clientX + scrollX0, Y - event1.clientY + scrollY0))
                        this._drawReport();
                    break;
                }
                break;
            }
        }).bind(this));
    },

    _mouseUpEvent: function (event) {
    },

    _mouseMoveEvent: function (event) {

        var canvas = event.target;
        var pos = this._mouseGetPos(event);

        // Send to graph
        if (this._graph && this._graph.mouseMoveEvent(event))
            return;

        // Try to find script
        if (pos.type === 'script') {
            var x = pos.x - this._marginWidth - this._wName + this._scrollX;
            var y = pos.y - this._marginHeight - this._graphHeight + this._scrollY;
            var index = Math.floor(y / this._hUE);

            var gen = this.player.getGen();
            if (index >= 0 && index < gen.list.length) {
                var ue = gen.list[index];

                y -= index * this._hUE;
                for (var i = 0; i < ue.scripts.length; i++) {
                    var script = ue.scripts[i];
                    if (!script.ip) continue;
                    if (x >= script.x0 && x < script.x1 && y >= script.y0 && y < script.y1) {
                        var rect = canvas.getBoundingClientRect();
                        this._toolTipRef = script;
                        this._scriptToolTipUpdate(script);
                        this._toolTip.showAt([
                            //rect.left + this._wName + Math.max(0, script.x0 + this._marginWidth - this._scrollX),
                            event.clientX + 10,
                            rect.top + this._graphHeight + script.y1 + this._marginHeight + index * this._hUE - this._scrollY]);
                        return;
                    }
                }
            }
        }
        this._mouseOutEvent();
    },

    _onGraphOver: function (data, X, Y) {
        if (data) {
            var data0 = data[0];
            var graph = this._graph;
            var text = 'At ' + data0.x + ':<br/><table>' + data.map(function (d, i) {
                var color = graph.getSerieColor(data[i].serie);
                var rect = '<div style="width:10px;height:10px;border:1px solid #000;background:' + color + '">';
                return '<tr><td>' + rect + '</td><td>' + lteLogs.tooltip(d.title) + ':</td><td align=right><b>' + d.y + '<b></td></tr>';
            }).join('') + '</table>';

            this._toolTipRef = null;
            this._toolTip.update(text);
            this._toolTip.showAt([X + 10, Y + 10]);
        }
    },

    _mouseOutEvent: function (event) {
        this._toolTipRef = null;
        this._toolTip.hide();
    },

    _eventListener: function (event) {

        switch (event.type) {
        case 'stats':
            var graph = this._graph;
            if (!graph || !this.player.eventListener(event)) return;

            var ts = this.player.getTimestamp();

            // For each cell
            if (ts >= 0) {
                for (var cell_index in event.data.cells) {
                    var data = event.data.cells[cell_index];
                    for (var id in UEConfig.series.br) {
                        graph.addValues(id + '.' + cell_index, [{
                            x: ts,
                            y: data[id]
                        }]);
                    }
                    for (var id in UEConfig.series.count) {
                        graph.addValues(id + '.' + cell_index, [{
                            x: ts,
                            z: data[id]
                        }]);
                    }
                    for (var id in UEConfig.series.packets) {
                        switch (id) {
                        case 'dl_bler':
                            if (data.dl_rx_count) {
                                graph.addValues(id + '.' + cell_index, [{ x: ts, bler: data.dl_err_count / data.dl_rx_count }]);
                            }
                            break;
                        default:
                            graph.addValues(id + '.' + cell_index, [{ x: ts, z: data[id] }]);
                            break;
                        }
                    }
                }
            }
            this._updater.update(true);
            break;

        case 'ue':
            this.player.eventListener(event);
            break;
        }
    },

});


Ext.define('lte.ue.pdn_connect', {

    title: 'Connect to PDN',
    extend: 'lte.popup',
    width: 300,

    constructor: function (options) {
        this.callParent(arguments);
    },

    initComponent: function () {
        this.fields = [{
            xtype: 'textfield',
            name: 'apn',
            fieldLabel: 'APN',
            value: '',
            width: '100%',
        }, {
            fieldLabel: 'Mode',
            xtype: 'radiogroup',
            name: 'type',
            columns: 2,
            items: [
                {boxLabel: 'IPv4', name: 'type', inputValue: 'ipv4', checked: true},
                {boxLabel: 'IPv6', name: 'type', inputValue: 'ipv6'},
                {boxLabel: 'IPv4v6', name: 'type', inputValue: 'ipv4v6'},
                {boxLabel: 'Ethernet', name: 'type', inputValue: 'ethernet' },
            ],
        }];
        this.callParent(arguments);
    },
});

