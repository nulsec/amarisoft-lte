
var LTEWorldView = function(config)
{
    this._canvas = config.canvas;
    this._zoomCenter = {'x': 0, 'y': 0};
    this._zoom = config.zoom;
    this._zoomFactor = config.zoomFactor;
    this._background = new Image();
    this._background.src = "resources/images/world_map.webp";
}

LTEWorldView.prototype.llaToCoord = function (dat) {
    var canvas = this._canvas;
    /* Equirectangular projection in 'world view' */
    var x = canvas.width * (dat.longitude + 180) / 360;
    var y = canvas.height * (1 - ((dat.latitude + 90) / 180));
    return {'x': x, 'y': y};
}

LTEWorldView.prototype.zoomCoord = function (c) {
    var canvas = this._canvas;
    if (this._zoom > 0 && this._zoomFactor != 1) {
        var center = this._zoomCenter;
        var zf = this._zoomFactor;
        /* East / west unwrap */
        if (center.x + canvas.width/(2*zf) > canvas.width && c.x < canvas.width/zf)
            c.x += canvas.width;
        if (center.x < canvas.width/(2*zf) && c.x > canvas.width - canvas.width/zf)
            c.x -= canvas.width;
        var x = canvas.width/2 + (c.x - center.x) * zf;
        var y = canvas.height/2 + (c.y - center.y) * zf;
        return {'x': x, 'y': y};
    } else {
        return c;
    }
}

LTEWorldView.prototype.llaToZoomCoord = function(lla) {
    var c = this.llaToCoord(lla);
    return this.zoomCoord(c);
}

LTEWorldView.prototype.setCanvas = function(canvas) {
    if (!this._canvas) {
        this._canvas = canvas;
    }
}

LTEWorldView.prototype.setZoom = function (z, zc) {
    this._zoom = z;
    this._zoomCenter = zc;
}

LTEWorldView.prototype.setZoomFactor = function (zf) {
    this._zoomFactor = zf;
}

LTEWorldView.prototype.drawBackground = function () {

    var background = this._background;
    if (!background) {
        var background = this._background = new Image();
        background.src = "resources/images/world_map.webp";
    }
    var canvas = this._canvas;
    var ctx = canvas.getContext("2d");
    var zf = this._zoomFactor;
    if (this._zoom > 0) {
        var center = this._zoomCenter;
        var zf = this._zoomFactor;
        var wratio = background.width/canvas.width;
        var hratio = background.height/canvas.height;
        var sy = (center.y - canvas.height / (2*zf)) * hratio;
        var sx = (center.x - canvas.width / (2*zf)) * wratio;
        var w = canvas.width * wratio;
        var h = canvas.height * hratio;
        /* Handle east/west wrap */
        if (sx + w/zf > w) {
            var sw = w - sx;
            ctx.drawImage(background, sx, sy, sw, h/zf, 0, 0, sw * zf / wratio, canvas.height);
            ctx.drawImage(background, 0, sy, w/zf - sw, h/zf, sw*zf-1, 0, canvas.width - sw*zf/wratio, canvas.height);
        } else if (sx < 0) {
            var sw = -sx;
            ctx.drawImage(background, w - sw, sy, sw, h/zf, 0, 0, sw*zf / wratio, canvas.height);
            ctx.drawImage(background, 0, sy, w/zf - sw, h/zf, sw*zf-1, 0, canvas.width - sw*zf / wratio, canvas.height);
        } else {
            ctx.drawImage(background, sx, sy, w/zf, h/zf, 0, 0, canvas.width, canvas.height);   
        }
    } else {
        ctx.drawImage(background,0,0);   
    }
}

Ext.define("lte.mcc.tab", {

    extend: 'lte.client.tab',

    useRefresh: true,

    constructor: function (config) {
        this.callParent(arguments);
    },

    listeners: {
        activate: function () {
        },
    },

    initComponent: function () {
        this.callParent(arguments);
        
        /* Internal state */
        this._selectedSatId = -1;
        this._filterCoverage = 0;
        this.worldView = new LTEWorldView({
            zoom: 0,
            zoomFactor: 4});
        this._zoom = 0;
        this._groundCellId = 0;
  
        /* Stores */
        this._cellStore = Ext.create('Ext.data.Store', {
            fields: [ 'latitude', 'longitude', 'radius', 'sat_link_list']
        });

        this._satStore = Ext.create('Ext.data.Store', {
            fields: [
                'id',
                'latitude', 'longitude', 'altitude',
                'pass_start', 'pass_start_str', 'pass_duration', 'pass_elevation',
                'elevation', 'azimuth', 'distance', 'doppler_ppm',
                'ran_link', 'ran_cell_id', 'ran_ues'
            ],
            filters: [
              {filterFn: this._filterSat.bind(this)}
            ],
        });

        this._gtStore = Ext.create('Ext.data.Store', {
            fields: ['epoch', 'latitude', 'longitude']
        });
        
        /* Canvas to draw the world map */
        this._worldPanel = Ext.create('Ext.panel.Panel', {
            html: '<canvas></canvas>',
            listeners: {
                scope: this,
                boxready: function(comp, width, height, eOpts) {
                    var canvas = this._worldPanel.el.down("canvas").dom;
                    canvas.addEventListener("mouseup", this._mouseUpEvent.bind(this), false);
                    canvas.width = 1280;
                    canvas.height = 640;
                },
                resize: function(cont, width, height) {
                }
            }
        });

        /* Toolbar */
        this.tbar.add('-');
        this._filterButtonText = ['Filter: all', 'Filter: coverage', 'Filter: link'];

        var filterCoverageButton = Ext.create('Ext.Button', {
            text: this._filterButtonText[0],
            scope: this,
            iconCls: 'icon-filter',
            tooltip: lteLogs.tooltip('Toggle satellite filters: all, coverage, link'),
            handler: function (b, e) {
                this._filterCoverage = (this._filterCoverage + 1) % 3;
                b.setText(this._filterButtonText[this._filterCoverage]);
            }
        });
        this.tbar.add(filterCoverageButton);

        this._zoomButtonText = ['Zoom: world', 'Zoom: cell', 'Zoom: sat'];
        var zoomButton = Ext.create('Ext.Button', {
            text: this._zoomButtonText[0],
            scope: this,
            iconCls: 'icon-zoom',
            tooltip: lteLogs.tooltip('Toggle zoom setting: world view, cell view, selected satellite view'),
            handler: function (b, e) {
                this._zoom = (this._zoom + 1) % 3;
                b.setText(this._zoomButtonText[this._zoom]);
            }
        });
        this.tbar.add(zoomButton);
        
        this.tbar.add('Ground cell:');
        this.tbar.add({
            xtype: 'numberfield',
            width: 50,
            value: this._groundCellId,
            step: 1,
            maxValue: 16,
            minValue: 0,
            tooltip: lteLogs.tooltip("Select ground cell of interest"),
            listeners: {
                scope: this,
                change: function(num, newValue, oldValue, eOpts) {
                    if (num.isValid() && newValue < this._cellStore.count()) {
                        this._groundCellId = newValue;
                    }
                }
            }
        });

        this._satInfoGrid = Ext.create('Ext.grid.Panel', {
            store: this._satStore,
            viewConfig: {
                markDirty: false,
                preserveScrollOnRefresh: true,
            },
            columns: [{
               text: "ID",
               dataIndex: "id",
               width: 70
            }, {
               text: "Next pass - start",
               dataIndex: "pass_start_str",
               width: 200
            }, {
               text: "Next pass - duration",
               dataIndex: "pass_duration",
               width: 150
            }, {
                text: "Next pass - max elev",
                dataIndex: "pass_elevation",
                width: 150,
                renderer: function (value) {
                    return Ext.util.Format.round(value, 2);
                }
            }, {
                text: "Elevation",
                dataIndex: "elevation",
                width: 100,
                renderer: function (value) {
                    value = Ext.util.Format.round(value, 2);
                    if (value < 0)
                        return '<span style="color:red">' + value + '</span>';
                    return '<span style="color:green">' + value + '</span>';
                }
            }, {
                text: "Azimuth",
                dataIndex: "azimuth",
                width: 100,
                renderer: function (value) {
                    return Ext.util.Format.round(value, 2);
                }
            }, {
                text: "Distance",
                dataIndex: "distance",
                width: 100,
                renderer: function (value) {
                    return Ext.util.Format.round(value/1000, 2);
                }
            }, {
                text: "RAN link",
                dataIndex: "ran_link",
                width: 100,
                renderer: function (value) {
                    if (value == "active")
                        return '<span style="color:green">' + value + '</span>';
                    else if (value == "none")
                        return '<span style="color:red">' + value + '</span>';
                    else
                        return '<span style="color:orange">' + value + '</span>';
                },
            }, {
                text: "RAN cell",
                dataIndex: "ran_cell_id",
                width: 100
            }, {
                text: "UEs",
                dataIndex: "ran_ues",
                width: 100
            }
            ],

            listeners: {
                scope: this,
                
                select: function(rowmodel, record, index, eOpts) {
                    this._selectedSatId = record.data.id;
                },
                
                sortchange: function() {
                    if (this._selectedSatId >= 0) {
                        var index = this._satStore.find('id', this._selectedSatId);
                        if (index >= 0)
                            this._satInfoGrid.getView().bufferedRenderer.scrollTo(index, true);
                    }
                }   
            }
        });

        this.add(
        {
            region: 'center',
            layout: 'fit',
            border: 0,
            items: [this._worldPanel],
        },
        {
            region: 'south',
            layout: 'fit',
            height: 250,
            split: true,
            items: [this._satInfoGrid],
        });
        
        this._updater = Ext.create("lte.updater", {
            scope:          this,
            updateDelay:    200,
            dirty:          true,
            lock:           1,
            handler: function () {
                /* Satellite list */
                this.client.sendMessage({message: 'sat_get', cell_id: this._groundCellId}, 
                    (function (msg) {
                        this._satStore.loadData(msg.sat_list);
                        /* select correct row */
                        if (this._selectedSatId >= 0 && this._satInfoGrid.getSelectionModel().getCount() == 0) {
                            var record = this._satStore.getById(this._selectedSatId);
                            if (record)
                                this._satInfoGrid.getSelectionModel().select(record, false, true);
                        } 
                    }).bind(this));
                /* Selected satellite, get the groundtrack */
                if (this._selectedSatId >= 0) {
                    this.client.sendMessage({message: 'sat_get', sat_id: this._selectedSatId}, 
                        (function (msg) {
                            this._gtStore.loadData(msg.ground_track);
                        }).bind(this));
                } else if (this._gtStore.count() > 0) {
                    this._gtStore.removeAll();
                }
                /* Cell list */
                this.client.sendMessage({message: 'cell_get', n_passes: 0}, 
                    (function (msg) {
                        this._cellStore.loadData(msg.cell_list);
                    }).bind(this));
                this._draw();
            }
        });
    },

    _mouseUpEvent: function (event) {
        if (event.button === 0) {
            this._selectSat(event);
        }
    },

    _chartList: [],
    _eventListener: function (event) {
        switch (event.type) {
        case 'stats':
            var now = new Date() * 1;
            this._updateCounters(now, event.data.counters);
            this._updater.update(true);
            break;
        }
    },

    setClientConfig: function (config) {
        console.log("Received config");
    },

    _zoomCenter: function () {
        if (this._zoom == 1) {
            var cell = this._cellStore.getAt(this._groundCellId);
            return this.worldView.llaToCoord(cell.data);
        } else if (this._zoom == 2 && this._selectedSatId >= 0) {
            var sat = this._satStore.getById(this._selectedSatId);
            if (sat)
                return this.worldView.llaToCoord(sat.data);
        }
        return {'x':0, 'y':0};
    },

    _filterSat: function(rec, id) { 
        if (this._filterCoverage === 2) {
            return (rec.data.ran_link != "none");
        } else if (this._filterCoverage === 1) {
            return (rec.data.elevation > 0);
        } else {
            return true;
        }
    },

    _selectSat: function(event) {
        var canvas = event.target;
        var rect = canvas.getBoundingClientRect();
        var x = event.clientX - rect.left;
        var y = event.clientY - rect.top;
        var sat_index = this._satStore.findBy(function (s, id) {
            var c = this.worldView.llaToZoomCoord(s.data);
            return (Math.abs(c.x - x) < 5 && Math.abs(c.y -y) < 5)
        }, this);
        if (sat_index < 0) {
            this._selectedSatId = -1;
        } else {
            var record = this._satStore.getAt(sat_index);
            this._selectedSatId = record.data.id;
            this._satInfoGrid.getSelectionModel().select(record, false, true);
        }
        this._updater.update();
    },

    _drawCell: function(c, ctx) {
        ctx.lineWidth = 2;
        ctx.setLineDash([]);
        ctx.beginPath();
        /* Radius of the cell in degrees over the surface of the earth */
        const radius_deg = 360 * c.data.radius/40075000;
        const n_points = 48;
        /* Describe a circle in lla and then project each point */
        for (let i=0; i <= n_points; i++) {
            var alpha = i * 2*Math.PI / n_points;
            var lat = c.data.latitude - radius_deg*Math.cos(alpha);
            /* Longitude distorted based on cos(latitude) */
            var lon = c.data.longitude - radius_deg*Math.sin(alpha)/Math.cos(lat * Math.PI/180);
            var p_lla = {latitude: lat, longitude: lon};
            var p = this.worldView.llaToZoomCoord(p_lla);
            ctx.lineTo(p.x, p.y);
        }
        ctx.stroke();
        ctx.fill();
    },

    _draw: function() {
        var canvas = this._worldPanel.el.down("canvas").dom;
        var ctx = canvas.getContext("2d");
        
        this.worldView.setCanvas(canvas);
        this.worldView.setZoom(this._zoom, this._zoomCenter());
        
        /* World map background */
        this.worldView.drawBackground();

        /* Draw the satellites */
        this._satStore.each(function (s) {
            var c = this.worldView.llaToZoomCoord(s.data);
            if (s.data.id === this._selectedSatId) {
                ctx.fillStyle = "rgba(255, 215, 0, 1.0)";
                ctx.fillRect(c.x-4, c.y-4, 8, 8);
            } else {
                if (s.data.ran_link != "none")
                    ctx.fillStyle = "rgba(0, 255, 0, 0.7)";
                else if (s.data.elevation < 0)
                    ctx.fillStyle = "rgba(255, 0, 0, 0.7)";
                else
                    ctx.fillStyle = "rgba(200, 150, 0, 0.7)";
                ctx.fillRect(c.x-2, c.y-2, 4, 4);
            }
        }, this);

        /* Draw the groundtrack */
        ctx.strokeStyle = "rgba(255, 215, 0, 0.5)";
        ctx.lineWidth = 3;
        if (this._gtStore.count() > 0) {
            ctx.beginPath();
            var prev_c = {x: canvas.width/2, y:canvas.height/2};
            this._gtStore.each(function (p) {
                var c = this.worldView.llaToZoomCoord(p.data);
                /* Check wrap of the groundtrack */
                if (Math.abs(c.x -prev_c.x) > 0.75*canvas.width ||
                    Math.abs(c.y - prev_c.y) > 0.75*canvas.height) {
                    ctx.moveTo(c.x, c.y);
                } else {
                    ctx.lineTo(c.x, c.y);
                }
                prev_c = c;
            }, this);
            ctx.stroke();
        }

        /* Draw the cells */
        ctx.strokeStyle = "rgb(255, 255, 255, 1.0)";
        ctx.fillStyle =  "rgba(0, 0, 0, 0.5)";
        this._cellStore.each(function(c) {
            /* Cell outline */
            this._drawCell(c, ctx);
            /* Link to the sats */
            if (c.data.sat_link_list) {
                ctx.lineWidth = 1;
                if (this._zoom > 0)
                    ctx.setLineDash([15, 5]);
                else
                    ctx.setLineDash([5, 2]); 
                var center = this.worldView.llaToZoomCoord(c.data);
                c.data.sat_link_list.forEach(function(link) {
                    var sat = this._satStore.getById(link.sat_id);
                    if (sat) {
                        var c = this.worldView.llaToZoomCoord(sat.data);
                        ctx.beginPath();
                        ctx.moveTo(center.x, center.y);
                        ctx.lineTo(c.x, c.y);
                        ctx.stroke();
                    }
                }, this);
            }
        }, this);
    }
});


 
