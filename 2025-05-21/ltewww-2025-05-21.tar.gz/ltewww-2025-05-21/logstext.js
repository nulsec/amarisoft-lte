
const _regExpStart        = new RegExp(/^([\-\d:\. ]+) \[([\w\d]+)\] (UL|DL|-|TO|FROM)\s+(.*)/); // date [layer] dir
const _regExpSignalRecord = new RegExp(/Link:\s([\w\d]+)@(\d+)/);
const _regExpDate         = new RegExp(/^(\d+):(\d+):(\d+)(\.(\d+))?/);
const _regExpDate2        = new RegExp(/^(\d+)-(\d+)-(\d+) (\d+):(\d+):(\d+)(\.(\d+))?/);
const _regExpDate3        = new RegExp(/^(\d+)(\.(\d+))?/);
const _regExpHeader       = new RegExp(/^([\da-f\-]+)\s+(.+)/);
const _regExpIndent       = new RegExp(/^\s*/);

const LOG_BURST_SIZE      = 500000; // 500KB

var Debug = function (text)
{
    postMessage({type: 'debug', text: text});
}

var parser = {
    headers: [],

    data: [],

    lastLog: null,
    lastIndent: null,
    logCount: 0,
    logIndex: 0,
    aborted: false,
    microseconds: false,

    filter: {
        range: null,
        layers: null
    },

    init: function (mode, filter) {

        // Info is filtered later so avoid max check here
        if (filter.info !== null) filter.max = Number.POSITIVE_INFINITY;

        this.mode = mode;
        this.filter = filter;

        switch (mode) {
        case 'text':
            this.buffer = '';
            this.index = 0;
            this.flush = this.textFlush;
            break;
        }
    },

    logCheckRange: function (range, index) {
        for (var i = 0; i < range.length; i++) {
            var r = range[i];
            if (index >= r[0] && index <= r[1]) return 1;
        }
        if (index > r[1]) return -1;
        return 0;
    },

    logLineParse: function (line) {
        var date;

        // Parse line
        var info = line.match(_regExpStart);
        if (!info) {
            var log = this.lastLog;
            if (!log)
                return null;

            if (log.layer === 'PHY') {
                var sigRec = line.match(_regExpSignalRecord);
                if (sigRec) {
                    if (!log.signalRecord) {
                        log.signalRecord = {};
                    }
                    log.signalRecord[sigRec[1]] = {offset: sigRec[2] >>> 0};
                    return null;
                }
            }

            if (this.lastIndent === null) {
                // Assume indent size is determined by first info line
                this.lastIndent = new RegExp("^" + line.match(_regExpIndent)[0]);
            }
            var data = line.replace(this.lastIndent, '');

            var md = data.match(/^#GUI\.(\w+)=(.+)$/);
            if (md) {
                log[md[1]] = md[2];
            } else if (!log.data) {
                log.data = [data];
            } else {
                log.data.push(data);
            }

            return null;
        }
        this.lastIndent = null;

        if (this.logCount >= this.filter.max)
            return this.abort();

        var layer = info[2];
        var layers = this.filter.layers;
        if (layers && layers.indexOf(layer) < 0) {
            this.lastLog = null;
            return null;
        }

        var index = this.logIndex++;
        var range = this.filter.range;
        if (range) {
            switch (this.logCheckRange(range, index)) {
            case 1:
                break;
            case 0:
                this.lastLog = null;
                return null;
            case -1:
                return this.abort();
            }
        }

        // Time
        var time = info[1];
        if (date = time.match(_regExpDate)) {
            var timestamp = date[1] * 3600e3 + date[2] * 60e3 + date[3] * 1e3;
            var dec = date[5];

        } else if (date = time.match(_regExpDate2)) {
            var d = new Date(0);
            d.setYear(date[1]);
            d.setMonth(date[2] - 1);
            d.setDate(date[3]);
            d.setHours(date[4]);
            d.setMinutes(date[5]);
            d.setSeconds(date[6]);
            var timestamp = d * 1;
            var dec = date[8];
        } else if (date = time.match(_regExpDate3)) {
            var timestamp = date[1] * 1e3;
            var dec = date[3];
        } else {
            return null;
        }

        var msg   = info[4];
        var log = this.lastLog = {
            layer: layer,
            dir: info[3],
            msg: msg,
            index: index,
        };

        if (dec === undefined) {
            log.timestamp = timestamp;
        } else {
            if (dec.length <= 3) {
                log.timestamp = timestamp + ((dec + '00').slice(0,3) - 0);
            } else {
                log.timestamp = timestamp + (dec.slice(0,3) - 0);
                log.timestamp_us = timestamp * 1000 + ((dec + '00').slice(0,6) - 0);
                this.microseconds = true;
            }
        }

        switch (layer) {
        case 'M2AP':
        case 'X2AP':
        case 'M2AP':
        case 'GTPU':
        case 'CX':
        case 'RX':
        case 'S6':
        case 'S13':
        case 'SGsAP':
        case 'SBcAP':
        case 'N8':
        case 'N12':
        case 'N13':
        case 'N14':
        case 'N17':
        case 'N50':
        case 'NL1':
        case 'N5':
        case 'N20':
        case 'N62':
        case 'ERROR':
        case 'HTTP2':
        case 'S1AP':
        case 'NGAP':
        case 'LCSAP':
        case 'LPPa':
        case 'NRPPa':
        case 'LPP':
        case 'TRX':
        case 'S72':
            break;
        default:
            if (info = msg.match(_regExpHeader)) {
                var ue_id = parseInt(info[1], 16);
                if (!isNaN(ue_id)) log.ue_id = ue_id;
                log.msg = info[2];
            }
            break;
        }

        this.logCount++;
        return log;
    },

    linesParse: function (lines) {
        var lines1 = [];
        var logs = [];

        if (this.lastLog)
            logs.push(this.lastLog);

        // Parse comment
        var length = lines.length;
        for (i = 0; i < length && !this.aborted; i++) {

            var line = lines[i];
            switch (line[0]) {
            case "#":
                if (this.headers)
                    this.headers.push(line);
                continue;
            case '{':
                if (!this.lastLog) {
                    this.headers = null;
                    postMessage({type: 'logs.ws', line: line});
                    continue;
                }
                break;
            }

            var log = this.logLineParse(line);
            if (log)
                logs.push(log);
        }

        if (this.headers) {
            postMessage({type: 'headers', headers: this.headers});
            this.headers = null;
        }

        if (this.lastLog)
            logs.pop(); // Keep last

        return logs;
    },

    textResume: function (data) {

        var size = Math.min(data.byteLength - this.index, LOG_BURST_SIZE);
        var chunk = data.subarray(this.index, this.index + size);
        var text = this.buffer + (new TextDecoder()).decode(chunk);
        this.index += size;

        // Get lines and store last one
        var lines = text.split(/\r?\n/);
        this.buffer = lines.pop();

        // Parse logs
        var logs = this.linesParse(lines);
        this.sendLogs('logs.text', logs);

        // Data pending
        if (this.index < data.byteLength) {
            this.data.unshift(data);
            return;
        }
        this.index = 0;
    },

    textFlush: function () {

        if (this.buffer !== null) {
            var logs = this.linesParse([this.buffer]);
            if (this.lastLog) {
                logs.push(this.lastLog);
                this.lastLog = null;
            }
            this.sendLogs('logs.text', logs);
            this.buffer = null;
            return false;
        }
        return true;
    },

    sendLogs: function (type, logs) {
        this.sending = true;
        postMessage({type: type, logs, microseconds: this.microseconds});
    },

    add: function (bytes) {

        if (this.data.push(bytes) === 1)
            this.resume();
    },

    terminate: function () {

        this.ended = true;
        if (!this.sending)
            parser.resume();
    },

    abort: function () {
        this.aborted = true;
        this.lastLog = null;
        return null;
    },

    resume: function () {

        this.sending = false;
        var data = this.data.shift();
        if (!data) {
            if (this.ended && this.flush()) {
                postMessage({type: 'end'});
            }
            return;
        }

        switch (this.mode) {
        case 'text':
            this.textResume(data);
            break;
        }
    },

    parseJSON: function (txt) {
        var log = null;
        try {
            log = JSON.parse(txt);
        } catch (e) {
            postMessage({type: 'error', error: txt});
        }
        return log;
    },
}

//self.importScripts('jszip.js');

onmessage = function (e)
{
    switch (e.data.type) {
    case 'init':
        parser.init(e.data.mode, e.data.filter);
        break;
    case 'data':
        parser.add(e.data.data);
        break;
    case 'end':
        parser.terminate();
        break;
    case 'next':
        if (e.data.room > 0 && !parser.aborted) {
            parser.resume();
        } else {
            postMessage({type: 'end'});
        }
        break;
    default:
        return;
    }

};

onerror = function (e)
{
    console.log("Log parsing error: " + e);
}
