/* 16 bit conversion utilities version 2025-05-21
 * Copyright (C) 2014-2025 Amarisoft
 */
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <immintrin.h>

/* Note: src and dst must be 16 byte aligned */
void float_to_int16(int16_t *dst, const float *src, int n, float mult)
{
    const __m128 *p;
    __m128i *q, a0, a1;
    __m128 mult1;

    mult1 = _mm_set1_ps(mult);
    p = (const void *)src;
    q = (void *)dst;

    while (n >= 16) {
        a0 = _mm_cvtps_epi32(p[0] * mult1);
        a1 = _mm_cvtps_epi32(p[1] * mult1);
        q[0] = _mm_packs_epi32(a0, a1);
        a0 = _mm_cvtps_epi32(p[2] * mult1);
        a1 = _mm_cvtps_epi32(p[3] * mult1);
        q[1] = _mm_packs_epi32(a0, a1);
        p += 4;
        q += 2;
        n -= 16;
    }
    if (n >= 8) {
        a0 = _mm_cvtps_epi32(p[0] * mult1);
        a1 = _mm_cvtps_epi32(p[1] * mult1);
        q[0] = _mm_packs_epi32(a0, a1);
        p += 2;
        q += 1;
        n -= 8;
    }
    if (n != 0) {
        /* remaining samples (n <= 7) */
        do {
            a0 = _mm_cvtps_epi32(_mm_load_ss((float *)p) * mult);
            *(int16_t *)q = _mm_cvtsi128_si32 (_mm_packs_epi32(a0, a0));
            p = (__m128 *)((float *)p + 1);
            q = (__m128i *)((int16_t *)q + 1);
            n--;
        } while (n != 0);
    }
}

/* Note: src and dst must be 16 byte aligned */
void int16_to_float(float *dst, const int16_t *src, int len, float mult)
{
    __m128i a0, a1, a, b, sign;
    __m128 mult1;

    mult1 = _mm_set1_ps(mult);

    while (len >= 8) {
        a = *(__m128i *)&src[0];
        a0 = _mm_cvtepi16_epi32(a);
        b  = _mm_srli_si128(a, 8);
        a1 = _mm_cvtepi16_epi32(b);
        *(__m128 *)&dst[0] = _mm_cvtepi32_ps(a0) * mult1;
        *(__m128 *)&dst[4] = _mm_cvtepi32_ps(a1) * mult1;
        dst += 8;
        src += 8;
        len -= 8;
    }
    /* remaining data */
    while (len != 0) {
        _mm_store_ss(&dst[0], _mm_cvtsi32_ss(_mm_setzero_ps(), src[0]) * mult1);
        dst++;
        src++;
        len--;
    }
}

int main(int argc, char **argv)
{
    float *tab1, *tab3, mult;
    int16_t *tab2;
    int n, i;

    n = 1001;

    posix_memalign((void **)&tab1, 16, sizeof(float) * n);
    posix_memalign((void **)&tab2, 16, sizeof(int16_t) * n);
    posix_memalign((void **)&tab3, 16, sizeof(float) * n);

    for(i = 0; i < n; i++) {
        tab1[i] = sin(2 * M_PI * i / n) * 1.2;
    }

    float_to_int16(tab2, tab1, n, 32767);
    
    for(i = 0; i < n; i++) {
        int v = lrintf(tab1[i] * 32767);
        if (v > 32767)
            v = 32767;
        else if (v < -32768)
            v = -32768;
        assert(v == tab2[i]);
    }

    mult = 1. / 32767.;
    int16_to_float(tab3, tab2, n, mult);
    
    for(i = 0; i < n; i++) {
        float v = tab1[i];
        if (v > 1) v = 1;
        if (v < -1) v = -1;
        if (tab3[i] - v > mult || tab3[i] - v < -mult)
            assert(v == tab3[i]);
    }

    free(tab1);
    free(tab2);
    free(tab3);

    return 0;
}
