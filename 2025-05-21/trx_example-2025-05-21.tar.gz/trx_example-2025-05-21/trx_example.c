/* 
 * Dummy transceiver driver (receives zeros and sync to real time)
 *
 * Copyright (C) 2012-2025 Amarisoft
 */
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <inttypes.h>
#include <string.h>
#include <getopt.h>
#include <math.h>
#include <assert.h>
#include <unistd.h>
#include <sys/time.h>

#include "trx_driver.h"

typedef int BOOL;

typedef struct {
    int sample_rate;
    int tx_channel_count;
    int rx_channel_count;
    int64_t rx_timestamp;
    int64_t rx_count;
    int64_t tx_count;
    BOOL dump_max;

    float max_sample;
    int sat_count;
    int64_t last_disp_time;
} TRXDummyState;

static int64_t get_time_us(void)
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (int64_t)tv.tv_sec * 1000000 + tv.tv_usec;
}

static void trx_dummy_end(TRXState *s1)
{
    TRXDummyState *s = s1->opaque;
    printf("rx_count: %" PRId64 "\n", s->rx_count);
    printf("tx_count: %" PRId64 "\n", s->tx_count);
    free(s);
}

static inline int64_t ts_to_time(const TRXDummyState *s, int64_t ts)
{
    int n, r;
    n = (ts / s->sample_rate);
    r = (ts % s->sample_rate);
    return (int64_t)n * 1000000 + (((int64_t)r * 1000000) / s->sample_rate);
}

static void trx_dummy_write(TRXState *s1, trx_timestamp_t timestamp, const void **samples, int count,
                            int rf_port_index, TRXWriteMetadata *md)
{
    TRXDummyState *s = s1->opaque;

    if (!(md->flags & TRX_WRITE_FLAG_PADDING) && s->dump_max) {
        const float *tab;
        int i, j;
        float v_max, v;

        v_max = s->max_sample;
        for(j = 0; j < s->tx_channel_count; j++) {
            tab = (const float *)samples[j];
            for(i = 0; i < count * 2; i++) {
                v = fabsf(tab[i]);
                /* Note: 1.0 corresponds to the maximum value */
                if (v >= 1.0)
                    s->sat_count++;
                if (v > v_max) {
                    v_max = v;
                }
            }
        }
        s->max_sample = v_max;
        if ((get_time_us() - s->last_disp_time) >= 2000000) {
            printf("max_sample=%0.3f sat=%d\n", s->max_sample, s->sat_count);
            s->max_sample = 0;
            s->sat_count = 0;
            s->last_disp_time = get_time_us();
        }
    }

    s->tx_count += count;
}

static int trx_dummy_read(TRXState *s1, trx_timestamp_t *ptimestamp, void **psamples, int count,
                          int rf_port_index, TRXReadMetadata *md)
{
    TRXDummyState *s = s1->opaque;
    int64_t end_time, d;
    TRXComplex *samples;
    int j;

    *ptimestamp = s->rx_timestamp;
    s->rx_timestamp += count;
    s->rx_count += count;
    end_time = ts_to_time(s, s->rx_timestamp);
    /* Since we don't have a real sample source, we just return zero
       samples and use the PC real time clock as time source */
    for(;;) {
        d = end_time - get_time_us();
        if (d <= 0)
            break;
        if (d > 10000)
            d = 10000;
        usleep(d);
    }
    
    for(j = 0; j < s->rx_channel_count; j++) {
        samples = psamples[j];
        memset(samples, 0, count * sizeof(TRXComplex));
    }
    return count;
}

/* This function can be used to automatically set the sample
   rate. Here we don't implement it, so the user has to force a given
   sample rate with the "sample_rate" configuration option */
static int trx_dummy_get_sample_rate(TRXState *s, TRXFraction *psample_rate,
                                     int *psample_rate_num, int sample_rate_min)
{
    return -1;
}

static int trx_dummy_start(TRXState *s1, const TRXDriverParams2 *p)
{
    TRXDummyState *s = s1->opaque;
    struct timeval tv;

    if (p->rf_port_count != 1)
        return -1; /* only one TX port is supported */

    s->sample_rate = p->sample_rate[0].num / p->sample_rate[0].den;
    s->tx_channel_count = p->tx_channel_count;
    s->rx_channel_count = p->rx_channel_count;

    gettimeofday(&tv, NULL);
    /* compute first RX timetamp in sample rate units */
    s->rx_timestamp = (int64_t)tv.tv_sec * s->sample_rate + 
        ((int64_t)tv.tv_usec * s->sample_rate / 1000000); 

    s->last_disp_time = get_time_us();
    return 0;
}

int trx_driver_init(TRXState *s1)
{
    TRXDummyState *s;
    double val;

    if (s1->trx_api_version != TRX_API_VERSION) {
        fprintf(stderr, "ABI compatibility mismatch between LTEENB and TRX driver (LTEENB ABI version=%d, TRX driver ABI version=%d)\n",
                s1->trx_api_version, TRX_API_VERSION);
        return -1;
    }

    s = malloc(sizeof(TRXDummyState));
    memset(s, 0, sizeof(*s));
    s->dump_max = 0;

    /* option to dump the maximum sample value */
    if (trx_get_param_double(s1, &val, "dump_max") >= 0) 
        s->dump_max = (val != 0);
    
    s1->opaque = s;
    s1->trx_end_func = trx_dummy_end;
    s1->trx_write_func2 = trx_dummy_write;
    s1->trx_read_func2 = trx_dummy_read;
    s1->trx_start_func2 = trx_dummy_start;
    s1->trx_get_sample_rate_func = trx_dummy_get_sample_rate;
    return 0;
}
