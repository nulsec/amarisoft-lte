/*
 * Copyright (C) 2020-2025 Amarisoft
 * LTE Monitor version 2025-05-21
 */

const path = require('path');
const fs = require('fs');

/*
 * Configuration file parser
 */
var ConfigNode = module.exports.Node = function (ctx, node, id, file)
{
    this.ctx  = ctx;
    this.node = node;
    this.id   = id;
    this.file = file;
};

ConfigNode.prototype.raiseError = function (name, error)
{
    var msg = 'Config: ' + this.file + ': ' + this.getSubID(name) + ': ' + error;
    this.ctx.log(LOG_ERROR, msg);

    throw msg;
}

ConfigNode.prototype.getSubID = function (name)
{
    if (this.node instanceof Array)
        return this.id + '[' + name + ']';

    return this.id + '.' + name;
};

ConfigNode.prototype.get = function (name, type, options)
{
    options = options || {};

    this._getIsdef = false;
    var node = this.node[name];
    if (node === undefined) {
        if (!options.optional && options.default === undefined) {
            this.raiseError(name, 'missing property');
        }
        this._getIsdef = true;
        if (options.update) {
            this.node[name] = options.default;
        }
        return options.default;
    }

    var type1 = typeof node;
    switch (type1) {
    case 'object':
        if (node instanceof Array) {
            if (type === 'array') {
                return new ConfigNode(this.ctx, node, this.getSubID(name), this.file);
            }
            type1 = 'array';
        } else {
            if (type === 'object') {
                return new ConfigNode(this.ctx, node, this.getSubID(name), this.file);
            }
        }
        break;
    default:
        if (type === typeof node) {
            return node;
        }
        break;
    }

    this.raiseError(name, 'but should be ' + type + ' instead of ' + type1);
};

ConfigNode.prototype.getObject = function (name, options)
{
    return this.get(name, 'object', options);
};

ConfigNode.prototype.getArray = function (name, options)
{
    return this.get(name, 'array', options);
};

ConfigNode.prototype.getArrayExt = function (name, options)
{
    var node = this.node[name];
    if (!(node instanceof Array) && node !== undefined) this.node[name] = [node];

    return this.getArray(name, options);
};

ConfigNode.prototype.getString = function (name, options)
{
    return this.get(name, 'string', options);
};

ConfigNode.prototype.getNumber = function (name, options)
{
    options = options || {};

    var number = this.get(name, 'number', options);
    if (this._getIsdef)
        return number;

    if (options.min !== undefined && number < options.min) {
        this.raiseError(name, 'must be greater or equal to ' + options.min);
    }
    if (options.max !== undefined && number > options.max) {
        this.raiseError(name, 'must be lower or equal to ' + options.max);
    }
    return number;
};

ConfigNode.prototype.getBool = function (name, options)
{
    return this.get(name, 'boolean', options);
};

ConfigNode.prototype.getNode = function ()
{
    return this.node;
};

ConfigNode.prototype.forEach = function (f, type)
{
    type = type || 'object';

    for (var i = 0; i < this.node.length; i++) {
        f(this.get(i, type));
    }
};

ConfigNode.prototype.checkLevel = function (name)
{
    var value = this.node[name];
    switch (typeof value) {
    case 'number':
        if (value >= 0 && value < LOG_LEVEL_STRING.length) {
            return true;
        }
        break;
    case 'string':
        var level = LOG_LEVEL_STRING.indexOf(value);
        if (level >= 0) {
            this.node[name] = level;
            return true;
        }
        break;
    case 'undefined':
        return true;
    default:
        break;
    }

    this.raiseError(name, value + ' is not a valid level');
};

/*
 * Can be an array of emails
 */
ConfigNode.prototype.checkEMail = function (name)
{
    var id = this.getSubID(name);
    var value = this.node[name];

    if (typeof value === 'string') {
        if (!value.match(this.emailRegExp)) {
            this.raiseError(name, 'not a valid email');
        }

    } else if (typeof value === 'object' && value instanceof Array) {

        var node = this.get(name, 'array');
        for (var i = 0; i < value.length; i++) {
            node.checkEMail(i);
        }
    } else {
        this.raiseError(name, 'should be a tring or an array of string');
    }
};

ConfigNode.prototype.emailRegExp = /^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;

ConfigNode.prototype.getFile = function (name, options)
{
    options = options || {};

    var filename = this.node[name];
    var filename0 = filename;
    if (filename === undefined) {
        if (!options.optional)
            this.raiseError(name, 'missing');

        if (!options.default)
            return;

        filename = options.default;
    }

    if (typeof filename !== 'string') {
        this.raiseError(name, 'must be a string');
    }

    if (!path.isAbsolute(filename)) {
        filename = path.dirname(this.file) + '/' + filename;
    }
    filename = path.normalize(filename);

    if (options.type === 'dir')
        filename = filename.replace(/[\/]*$/, '/');

    if (!options.noexist) {
        if (!fs.existsSync(filename)) {
            switch (options.type) {
            case 'dir':
                this.raiseError(name, 'unknown directory ' + filename0);
                break;
            case 'file':
            default:
                this.raiseError(name, 'unknown file ' + filename0);
                break;
            }
        } else {
            var stats = fs.lstatSync(filename);
            switch (options.type) {
            case 'dir':
                if (!stats.isDirectory())
                    this.raiseError(name, filename0 + ' is not a directory');
                break;
            case 'file':
            default:
                if (!stats.isFile() && !stats.isSymbolicLink())
                    this.raiseError(name, filename0 + ' is not a file');
                break;
            }
        }
    }

    if (options.load) {
        try {
            var data = fs.readFileSync(filename);
        } catch (e) {
            this.raiseError("can't load " + filename);
        }
        data = data.toString('utf8');

        // Remove comments
        if (options.comment) {
            var lines = data.replace(/\r?\n$/, '').split(/\r?\n/);
            for (var i = 0; i < lines.length;) {
                var line = lines[i];
                if (line.match(options.comment)) {
                    line = line.replace(options.comment, '');
                    if (line === '') {
                        lines.splice(i, 1);
                        continue;
                    }
                    lines[i] = line;
                }
                i++;
            }
            data = lines.join("\n");
        }

        this.node[name] = data;

    } else {
        this.node[name] = filename;
    }

    return this.node[name];
};

ConfigNode.prototype.getIP = function (name, options)
{
    var ip = this.getString(name, options);
    if (!ip)
        return ip;

    var m = ip.match(/^(\d+)\.(\d+)\.(\d+)\.(\d+)(:(\d+))?$/);
    if (m) {
        // IPv4
        var host = m.slice(1, 5).map((i) => {
            i -= 0;
            if (i >= 255)
                this.raiseError(name, 'is not a valid IPv4 address');
            return i;
        }).join('.');
        var pIdx = 6;
    } else {
        var m = ip.match(/^\[([\da-fA-F:]+)\](:(\d+))?$/);
        if (!m)
            this.raiseError(name, 'is not a valid ip address');

        host = m[1].split(/:/).map((i) => {
            if (i.length > 4)
                this.raiseError(name, 'is not a valid ip address');
            return i;
        }).join(':')
        host = '[' + host + ']';
        pIdx = 3;
    }

    var port = 0;
    if (m[pIdx] !== undefined) {
        port = m[pIdx] - 0;
        if (port <= 1024 || port > 65535)
            this.raiseError(name, 'invalid port');
    } else if (options && options.port) {
        port = options.port;
        m[6] = port;
    }

    return { host: host, port: port, value: ip };
};

ConfigNode.prototype.getGroupId = function (name, options)
{
    var group = this.get(name, 'string', options);
    if (group) {
        try {
            var id = require('child_process').execSync('id ' + group);
            var m = id.toString().match(new RegExp('gid=(\\d+)\\(' + group + '\\)'));
            return m[1] - 0;
        } catch (e) {
            this.raiseError(name, e.toString());
        }
    }
    return undefined;
}

