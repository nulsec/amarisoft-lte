/*
 * Copyright (C) 2020-2025 Amarisoft
 * LTE Monitor component version 2025-05-21
 */

const WebSocket = require('nodejs-websocket');
const path = require('path');
const child_process = require('child_process');
const configModule = global.loadLib('config');
const utilsModule = global.loadLib('utils');


const STATS_VERSION = 1;


var Component = module.exports.Instance = function (monitor, params)
{
    this.id         = params.id;
    this.type       = params.id;
    this.name       = params.id;
    this.prog       = params.prog;
    this.started    = false;
    this.state      = 'stopped';
    this.address    = {};
    this.url        = '';
    this.configFile = params.config;

    var cc = this.componentConfig[this.type];
    for (var id in cc) {
        this[id] = cc[id];
    }

    monitor.utilsInit(this);
    utilsModule.timerInit(this);
    utilsModule.initFs(this);
    utilsModule.dataLoad(this);

    this.timerCreate('start', this.onStart);
    this.timerCreate('stats', this.statsSend);

    this.setState(params.state);
};

Component.prototype.setState = function (state)
{
    if (this.state === state)
        return;

    switch (state) {
    case 'starting':
        break;
    case 'started':
        if (!this.start())
            state = 'error';
        break;
    case 'stopped':
    case 'error':
    case 'disabled':
        this.stop();
        break;
    }
    this.state = state;

    this.monitor.compUpdate();
};

Component.prototype.export = function ()
{
    var version = this.version;
    var info = this.lastInfo;

    switch (this.state) {
    case 'error':
        info = this.dataGet('error');
        break;
    case 'disabled':
        if (!version) version = '-';
        break;
    }

    return {
        state: this.state,
        id: this.id,
        type: this.type,
        name: this.name,
        info: info,
        port: this.address.port,
        version: version || '?',
    };
};

Component.prototype.terminate = function ()
{
    this.timerKill();

    this.log(LOG_DEBUG, 'Terminate');
    if (this.ws) {
        this.ws.close();
        this.ws = null;
    }
    this.dataSave();
};

Component.prototype.getConfig = function ()
{
    var fs = require('fs');
    try {
        return fs.realpathSync(this.configFile);
    } catch (e) {
        return null;
    }
};

Component.prototype.setConfig = function (config, filename)
{
    var fs = require('fs');
    if (!filename) filename = 'import-' + this.id + '.cfg';

    if (path.basename(this.configFile) === filename) {
        // Avoid same name as symbolic link
        filename = filename.replace(/(\.cfg)?$/, '-import$1');
    }

    var file0 = this.getConfig();

    // Check current config
    if (file0) {
        var s = fs.lstatSync(this.configFile);
        if (!s.isSymbolicLink())
            return 'Current config file must be a symbolic link';
    }

    var dir   = path.dirname(this.configFile) + '/';
    var file1 = dir + filename;
    var tmp   = file1 + '.tmp';

    // Dump to temporary file
    if (!this.writeFileSync(tmp, config)) {
        return this.fsError;
    }

    // Check JSON
    if (!this.parseJSONFile(tmp, true)) {
        fs.unlinkSync(tmp);
        return this.fsError;
    }
    if (this.dryRun) {
        try {
            child_process.execSync(this.prog + ' -d "' + tmp + '"');
        } catch (e) {
            var error = e.stderr.toString().replace(tmp, filename);
            return error;
        }
    }

    // Backup
    if (file0) {
        var bakd = dir + 'backup/';
        var bak  = bakd + path.basename(file0) + '-' + this.monitor.formatDateLog(new Date());

        try {
            this.mkdir(dir + 'backup');
            fs.copyFileSync(file0, bak);
        } catch (e) {
            this.log(LOG_WARN, "Can't backup " + file0);
        }

        fs.readdir(bakd, { withFileTypes: true }, (err, files) => {
            if (err) {
                this.log(LOG_ERROR, "Can't parse config directory", err);
                return;
            }

            // Sort by modification date
            files = files.filter( (f) => { return f.isFile(); } )
                         .map( (f) => { return { name: f.name, time: fs.statSync(bakd + f.name) }; })
                         .sort( (a, b) => { return a.time - b.time; });

            for (var i = 0; i < files.length - COMP_IMPORT_HIST_SIZE; i++) {
                this.log(LOG_DEBUG, 'Remove deprecated config file: ' + files[i].name);
                fs.unlinkSync(dir + files[i].name);
            }
        });
    }

    try {
        fs.copyFileSync(tmp, file1);
        fs.unlinkSync(tmp);
        if (file0)
            fs.unlinkSync(this.configFile);
        fs.symlinkSync(filename, this.configFile);
    } catch (e) {
        return e.toString();
    }

    // Restart component
    if (this.ws) {
        this.log(LOG_INFO, 'Upload config, restart component');
        this.ws.send(JSON.stringify({message: 'quit'}));
    }
    return null;
};

Component.prototype.backupConfigs = function (cb, bin)
{
    var name = path.dirname(this.configFile);
    var root = path.dirname(name);
    var dir  = path.basename(name);
    var bufs = [];

    var error = (e) => {
        if (cb) {
            this.log(LOG_ERROR, "Can't backup: " + e);
            cb('error', e);
            cb = null;
        }
    };

    this.log(LOG_INFO, "Backup");
    try {
        var proc = child_process.spawn('tar', ['czf', '-', 'config'], { cwd: root, detached: true });
    } catch (e) {
        error(e);
        return false;
    }

    proc.on('error', (e) => { error(e); });
    proc.on('exit', (code) => { if (code) error(code); });

    proc.on('close', () => {
        if (cb) {
            var data = Buffer.concat(bufs);
            cb('data', { data: bin ? data : data.toString('base64') });
        }
    });

    proc.stdout.on('readable', () => {
        var data = proc.stdout.read();
        if (data)
            bufs.push(data);
    });

    //proc.stdout.on('data', (chunk) => {});

    proc.stderr.on('data', (chunk) => {
        console.log('############ STDERR', chunk);
        console.log('E', chunk.toString());
    });
    proc.stderr.on('error', () => {});

    //proc.stdin.setEncoding('utf-8');
    //proc.stdin.on('error', function (e) {});;
}

// Internal API
Component.prototype.start = function ()
{
    this.lastInfo = '';

    if (this.started) {
        this.log(LOG_ERROR, 'Not stopped !');
        this.stop();
    }

    // Config
    var config = this.config = this.parseJSONFile(this.configFile, true);
    if (!config) {
        this.log(LOG_ERROR, 'Can\'t load config file: ' + this.fsError);
        this.setError('CONFIG', 'internal error', "can't load config file: " + this.configFile);
        return false;
    }

    var c = new configModule.Node(this, config, 'com', '');
    try {
        this.address = c.getIP('com_addr', { port: 9000 });
        this.url = 'ws://' + this.address.host + ':' + this.address.port + '/';

        // Check
        c.getString('com_name', { optional: true });
        c.getString('label', { optional: true });

        if (config.com_name)
            this.name = config.com_name;

        if (config.label)
            this.name = config.label;

    } catch (e) {
        this.setError('CONFIG', 'internal error', e);
        return false;
    }

    this.started = true;
    this.connected = false;
    this.timerStart('start', COMP_WS_CONNECT_RETRY_DELAY);
    return true;
}

Component.prototype.stop = function ()
{
    if (this.started) {
        this.started = false;
        if (this.ws) {
            this.ws.close();
            this.ws = null;
        }

        // Consider
        if (this.connected) {
            this.eventInfo('STATE', 'stopped');
        }
    }
};

Component.prototype.onStart = function ()
{
    var ws = this.ws = WebSocket.connect(this.url, { extraHeaders: { origin: MON_TYPE }});

    this.log(LOG_DEBUG, 'Connecting to ' + this.url);

    ws.on('connect', this.onConnect.bind(this));
    ws.on('text', this.onMessage.bind(this));
    ws.on('close', this.onClose.bind(this));
    ws.on('error', this.onError.bind(this));
};

Component.prototype.onConnect = function ()
{
    this.log(LOG_INFO, 'Connected');
    this.connected = true;
};

Component.prototype.onMessage = function (data)
{
    var msg = this.parseJSONData(data);
    if (!msg)
        return;

    if (msg.message !== 'stats')
        this.log(LOG_DEBUG, 'Receive message: ' + msg.message, msg);

    switch (msg.message) {
    case 'authenticate':
        if (msg.ready) {
            this.log(LOG_DEBUG, 'Authenticated');
            this.setReady(msg);
            return;
        }
        this.version = msg.version;
        this.monitor.compUpdate();

        if (msg.error) {
            this.setError('AUTH', 'failure', msg.error);
            return;
        }

        var com_auth = this.config.com_auth;
        if (!com_auth) {
            this.setError('CONFIG', 'internal error', 'missing com_auth in config file');
            return;
        }

        var password = com_auth.password;
        if (!password) {
            // XXX: file
            this.setError('CONFIG', 'internal error', 'missing password in config file');
            return;
        }

        var hmac = require('crypto').createHmac('sha256', msg.type + ':' + password + ':' + msg.name);
        hmac.update(msg.challenge);
        this.ws.send(JSON.stringify({message: 'authenticate', res: hmac.digest('hex')}));
        break;
    case 'ready':
        this.version = msg.version;
        this.monitor.compUpdate();
        this.setReady(msg);
        break;

    case 'link':
        this.onMessageLink(msg);
        break;

    case 'dialog':
        this.onMessageDialog(msg);
        break;

    case 'sms':
        this.onMessageSMS(msg);
        break;

    case 'eps_bearer_notification':
    case 'qos_flow_notification':
        this.onMessageBearer(msg);
        break;

    case 'config_get':
        switch (this.id) {
        case 'ENB':
            this.cellsInfo = this.enbGetCellsInfo(msg);
            break;
        }
        break;

    case 'register':
        if (msg.links) {
            for (var i = 0; i < msg.links.length; i++) {
                this.onMessageLink(msg.links[i]);
            }
        }
        break;

    case 'stats':
        this.statsRecv(msg);
        break;

    default:
        this.log(LOG_WARN, 'Unkown message: ' + msg.message, msg);
        break;
    }

    this.lastMsgRecvTime = new Date() * 1;
};

Component.prototype.onMessageLink = function (msg)
{
    var id = 'link.' + msg.link + '.' + msg.addr;

    // Update state based on transition
    var state = this.dataGet(id);
    if (typeof state !== 'object') {
        state = { event: state, error: false };
    }

    var e = utilsModule.linkStateUpdate(state, msg.event, msg.error);
    if (e) {
        this.eventSet(e.level, msg.link, state.event, 'link ' + msg.addr + ' ' + e.text);

        // Store
        this.dataSet(id, state, true);
    }
};

Component.prototype.onMessageSMS = function (msg)
{
    this.cdrAdd('sms', {
        sender: msg.sender,
        destination: msg.destination,
        date: msg.date,
        type: msg.type,
    });
}

Component.prototype.onMessageDialog = function (msg)
{
    this.cdrAdd('calls', msg.dialog);
}

Component.prototype.onMessageBearer = function (msg)
{
    if (msg.activated === false) { // End of bearer
        delete msg.erab_id;
        delete msg.linked_erab_id;
        delete msg.pdu_session_id;
        delete msg.qos_flow_id;
        delete msg.time;
        delete msg.message;
        delete msg.activated;
        this.cdrAdd('bearers', msg);
    }
}

Component.prototype.setError = function (section, error, msg)
{
    this.dataSet('error', {
        section: section,
        error: error,
        msg: msg
    });
    this.log(LOG_ERROR, 'section=' + section + ' error="' + error + '"', msg);
    this.eventSet(LOG_ERROR, section, error, msg);
    this.monitor.compUpdate();
    this.setState('error');
};

Component.prototype.setInfo = function (section, title, msg)
{
    var lastInfo = 'section=' + section + ' title=' + title + ' msg="' + msg + '"';
    if (lastInfo !== this.lastInfo) {
        this.eventInfo(section, title, msg);
        this.lastInfo = lastInfo;
        this.monitor.compUpdate();
    }
}

Component.prototype.setReady = function (msg)
{
    var error = this.dataGet('error');
    if (typeof error === 'object') {
        this.eventSet(LOG_WARN, 'STATE', 'started', 'recovered from ' + error.section + ' ' + error.error + ': ' + error.msg);
        this.dataSet('error', '');
    } else {
        this.eventInfo('STATE', 'started');
    }

    // Register to link events
    if (this.registeredEvents) {
        this.ws.send(JSON.stringify({
            message: 'register',
            register: this.registeredEvents,
        }));
    }

    if (this.useStats && this.monitor.statsOn()) {
        if (this.useConfigGet) {
            // Get informations
            this.ws.send(JSON.stringify({ message: 'config_get' }));
        }
        this.statsInit();
    }
};

Component.prototype.onClose = function ()
{
    this.log(LOG_DEBUG, 'Disconnected');
    this.timerStop('stats');

    this.statsEnd();
};

Component.prototype.onError = function (error)
{
    switch (error.errno) {
    case 'ECONNREFUSED':
        if (this.started) {
            // Retry
            this.timerStart('start', COMP_WS_CONNECT_RETRY_DELAY);
        }
        break;
    case 'ENOTFOUND':
        this.log(LOG_ERROR, 'Bad ws host: ' + this.url);
        this.setInfo('WS', "Bad host", '');
        break;
    default:
        this.log(LOG_ERROR, 'Error: ' + error);
        // XXX
        break;
    }
};

Component.prototype.eventSet = function (level, section, title, msg)
{
    this.monitor.eventSet(this.monitor.hostname, this.id, level, section, title, msg, this.version);
};

Component.prototype.eventInfo = function (section, title, msg)
{
    this.eventSet(LOG_INFO, section, title, msg);
};


Component.prototype.useLink = false;
Component.prototype.useStats = false;

Component.prototype.componentConfig = {
    ENB: {
        registeredEvents: ['link'],
        useStats: true,
        useConfigGet: true,
        dryRun: true,
    },

    MME: {
        registeredEvents: ['link', 'eps_bearer_notification', 'qos_flow_notification'],
        useStats: true,
        dryRun: true,
    },

    IMS: {
        registeredEvents: ['link', 'dialog', 'sms'],
        useStats: true,
        dryRun: true,
    },

};




/*
 * Statistics
 */
Component.prototype.statsDefinition = {
    cells: {
        dl_bytes: { type: 'bitrate', id: 'dl_bitrate' },
        ul_bytes: { type: 'bitrate', id: 'ul_bitrate' },
        dl_use_avg: { type: 'avg', id: 'dl_use_avg', decimal: 3, sub_sampling: true },
        ul_use_avg: { type: 'avg', id: 'ul_use_avg', decimal: 3, sub_sampling: true },
        ue_active_count_max: { type: 'max', id: 'ue_active_count_max'},
        ue_active_count_avg: { type: 'avg', id: 'ue_active_count_avg', decimal: 3},
        ue_inactive_count_max: { type: 'max', id: 'ue_inactive_count_max'},
        ue_inactive_count_avg: { type: 'avg', id: 'ue_inactive_count_avg', decimal: 3},
    },
    pdn: {
        dl_bytes: {},
        ul_bytes: {},
    },
    IMS: {
        users: {
            total: { type: 'max', sub_sampling: true },
            max_registered: { type: 'max', sub_sampling: true },
        },
    },
    MME: {
        users: {
            total: { type: 'max', sub_sampling: true },
            max_registered: { type: 'max', sub_sampling: true },
        },
    },
};

Component.prototype.statsSend = function ()
{
    this.ws.send(JSON.stringify({
        message: 'stats',
        initial_delay: 0,
        reset: this.statsMsgReset,
    }));
}

/*
 * Stats or events
 */
Component.prototype.statsList = ['stats', 'cdr'];

Component.prototype.statsReset = function (type)
{
    this.dataSet(type, {
        type: type,
        info: {
            version: STATS_VERSION,
            count: 0,
            ss_idx: 0, // Sub sampling
            id: this.id,
            name: this.name,
            start: Math.floor(new Date() / 1000),
            end: this.monitor.statsGetEndTime() / 1000,
            sub_sampling: this.monitor.stats.sub_sampling,
            lifetime: 0,
        },
    });

    this.statsMsgReset = true;
    this.dataDirty();
}

Component.prototype.statsProcess = function (stats)
{
    if (stats.info.count > 0) {
        delete stats.info.count;
        delete stats.info.ss_idx;

        switch (stats.type) {
        case 'stats':
            this.statsLifetimeUpdate(stats, true);
            this.statsLastTime = 0;
            break;
        }
        this.monitor.statsProcess(stats);
    }
}

Component.prototype.statsInit = function ()
{
    this.statsOn = true;
    this.statsTime = 0;
    this.statsLastTime = 0;
    this.statsList.forEach(this.statsInit1.bind(this));
    this.statsSend();
}

Component.prototype.statsEnd = function ()
{
    if (this.statsOn) {
        var stats = this.dataGet('stats');
        if (stats) {
            // Update lifetime ?
            this.statsLifetimeUpdate(stats, false);
        }

        this.statsOn = false;
    }
}

Component.prototype.statsInit1 = function (type)
{
    /* Stats */
    var stats = this.dataGet(type);
    if (stats) {
        if (stats.info && stats.info.version >= STATS_VERSION) {
            if (stats.info.end * 1000 >= this.monitor.statsGetEndTime()) {
                if (type === 'stats' && stats.info.lifetime === undefined) stats.info.lifetime = 0;
                return;
            }
            this.log(LOG_DEBUG, 'Flush previous ' + type);

            this.statsProcess(stats);
        }
        if (!stats.type) stats.type = type; // Legacy
    }
    this.statsReset(type);
};

Component.prototype.cdrAdd = function (section, value)
{
    var cdr = this.dataGet('cdr');
    if (cdr) {
        if (!cdr[section]) cdr[section] = [value];
        else cdr[section].push(value);

        cdr.info.count++;
    }
}

/*
 * Called by monitor
 */
Component.prototype.statsFlush = function ()
{
    this.statsList.forEach( (type) => {
        var stats = this.dataGet(type);
        if (stats) {
            switch (type) {
            case 'stats':
                if (this.timerStop('stats')) {
                    this.statsSend();
                }
                break;
            }
            this.statsProcess(stats);
            this.statsReset(type);
        }
    });
    this.statsTimeReset = new Date() * 1;
};
Component.prototype.statsTimeReset = 0;

/*
 * Receive stats message from component
 */
Component.prototype.statsRecv = function (msg)
{
    var stats = this.dataGet('stats');
    var newStats = stats.info.count++ == 0;

    this.statsLastTime = new Date() * 1;

    // Instance has changed, reset previous state
    var previous = this.dataGet('stats.previous');
    if (!previous) previous = {};

    var newInst = previous.instance_id !== msg.instance_id;
    if (newInst) {
        previous.instance_id = msg.instance_id;
        previous.sub_sampling_time = this.statsLastTime;
        this.dataSet('stats.previous', previous);
    }

    // Update event stats
    if (newInst) delete previous.counters;
    this.statsDiff('counters', stats, previous, msg);

    // Update lifetime
    if (this.statsTimeReset) {
        stats.info.lifetime += (this.statsLastTime - this.statsTimeReset) / 1000;
        this.statsTimeReset = 0;
    } else {
        stats.info.lifetime += msg.time - this.statsTime;
    }
    this.statsTime = msg.time;

    var ss = false;
    if (stats.info.sub_sampling != Number.POSITIVE_INFINITY) {
        var ss_idx = Math.floor(stats.info.lifetime / stats.info.sub_sampling);
        if (ss_idx > stats.info.ss_idx) {
            ss = 'flush';
            stats.info.ss_idx = ss_idx;
            this.statsMsgReset = true;
        } else {
            ss = true;
        }
    }

    // Cells
    if (msg.cells) {
        for (var cid in msg.cells) {
            var cell = msg.cells[cid];
            var name = cell.label || cid;

            var cell1 = this.statsSectionGet(stats, previous, 'cells', name);
            this.statsAdd(cell1, cell, this.statsDefinition.cells, msg.duration, newStats, ss);

            if (newInst) delete cell1.previous.counters;
            this.statsDiff('counters', cell1.stats, cell1.previous, cell);

            // Add config
            // XXX: if tech has changed (or anything else relevant), raise an error
            var cellInfo = this.cellsInfo[name];
            cell1.stats.technology = cellInfo.technology;
            cell1.stats.band = (cellInfo.rat === 'nr' ? 'n' : '') + cellInfo.band;
        }
    }

    // PDNs
    if (msg.pdn_list) {
        for (var i in msg.pdn_list) {
            var pdn = msg.pdn_list[i];
            var name = pdn.access_point_name;

            var pdn1 = this.statsSectionGet(stats, previous, 'pdn_list', name);
            this.statsAdd(pdn1, pdn, this.statsDefinition.pdn, 0, newStats, ss);
        }
    }

    // Component specific
    var cDef = this.statsDefinition[this.type];
    if (cDef) {
        for (var def in cDef) {
            this.statsAdd(this.statsSectionGet(stats, previous, def), msg[def], cDef[def], msg.duration, newStats, ss);
        }
    }

    this.dataDirty();
    this.timerStart('stats', this.monitor.stats.comp_poll_delay);
};

/* Stats merge utilities */
Component.prototype.statsSectionGet = function (stats, previous)
{
    for (var i = 2; i < arguments.length; i++) {
        var id = arguments[i];

        if (!stats[id]) stats = stats[id] = {};
        else            stats = stats[id];
        if (!previous[id]) previous = previous[id] = {};
        else               previous = previous[id];
    }

    return { stats: stats, previous: previous };
}

Component.prototype.statsAdd = function (section, src, def, duration, newStats, ss)
{
    var dst = section.stats;
    var previous = section.previous;

    for (var id in def) {
        var d = def[id];

        var value = src[d.id || id];
        if (value === undefined) continue;

        if (newStats) {
            delete previous[id];
            var p = undefined;
        } else {
            var p = previous[id];
        }
        if (p === undefined) {
            p = previous[id] = { duration: 0 }
        }

        switch (d.type) {
        case 'bitrate':
            value = (value * duration / 8) >>> 0;
            value = (p.value || 0) + value;
            break;
        case 'avg':
            var d0 = p.duration + duration;
            value = ((p.value || 0) * p.duration + value * duration) / d0;
            break;
        case 'max':
        case 'min':
            if (p.value !== undefined) value = Math[d.type](value, p.value);
            break;
        default:
            value = (p.value || 0) + value;
            break;
        }
        if (d.decimal) value = value.toFixed(d.decimal) - 0;

        p.value = value;
        p.duration += duration;
        if (d.sub_sampling && ss) {
            var list = dst[id];
            if (list === undefined) list = dst[id] = [];
            else if (!(list instanceof Array)) {
                list = dst[id] = [list];
                p.sub = true;
            }
            if (p.sub) {
                list[list.length - 1] = value;
            } else {
                if (!(list instanceof Array))
                    console.log(id, typeof list, list);
                list.push(value)
                p.sub = true;
            }
            if (ss === 'flush') {
                delete previous[id];
            }
        } else {
            dst[id] = value;
        }
    }
};

Component.prototype.statsDiff = function (id, stats, previous, data)
{
    var s = stats[id];
    var p = previous[id];
    var d = data[id];

    // Recurse ?
    switch (typeof d) {
    case 'object':
        if (s === undefined) s = stats[id] = {};
        if (p === undefined) p = previous[id] = {};

        for (var id1 in d) {
            this.statsDiff(id1, s, p, d);
        }
        break;
    case 'number':
        previous[id] = d;
        if (p !== undefined) {
            d -= p;
        }
        if (s === undefined) {
            stats[id] = d;
        } else {
            stats[id] += d;
        }
        if (stats[id] === 0) {
            delete stats[id];
        }
        break;
    case 'undefined':
        break;
    default:
        console.log('Stats', id, d);
        break;
    }
}

Component.prototype.statsLifetimeUpdate = function (stats, send)
{
    var time  = this.statsLastTime;
    if (time) {
        var diff = (new Date() - time) / 1000;

        stats.info.lifetime += diff;
    }

    if (send) {
        // Rouding
        stats.info.lifetime = Math.round(stats.info.lifetime);
    }
}


/*
 * Sepcific component functions
 */
Component.prototype.enbGetCellsInfo = function (msg)
{
    var cellsInfo = {};

    // NR
    for (var id in msg.nr_cells) {
        var cell = msg.nr_cells[id];
        cellsInfo[cell.label || id] = cell;

        cell.technology = {};
        cell.rat = 'nr';
        if (cell.plmn_list.length) {
            cell.technology['SA'] = true;
        }
    }

    // NB-IoT
    for (var id in msg.nb_cells) {
        var cell = msg.nb_cells[id];
        cellsInfo[cell.label || id] = cell;

        cell.rat = 'nbiot';
        cell.technology = {'NB-IoT': true};
        // XXX: check cell.operation_mode
    }

    // LTE (after NR)
    for (var id in msg.cells) {
        var cell = msg.cells[id];
        cellsInfo[cell.label || id] = cell;

        cell.rat = 'lte';
        cell.technology = {LTE: true};
        if (cell.en_dc_scg_cell_list) {
            for (var i in cell.en_dc_scg_cell_list) {
                msg.nr_cells[cell.en_dc_scg_cell_list[i].cell_id].technology['NSA'] = true;
            }
        } else if (cell.nr_scell_list) {
            for (var i in cell.nr_scell_list) {
                msg.nr_cells[cell.nr_scell_list[i].cell_id].technology['NSA'] = true;
            }
        }
    }

    return cellsInfo;
}

