#!/bin/bash
# Copyright (C) 2012-2023 Amarisoft
# LTEMME system config version 2023-12-15

# Run once as root after the boot to init the network for LTEMME.

# Configuration
ipv6=0
nat=1
nat6=1
dummy=0

# IP tables
IPTABLES_COM="ltemme-lteinit.sh-rule"
IPTABLES="iptables -w 5"
IP6TABLES="ip6tables -w 5"
IPTABLES_C="$IPTABLES -m comment --comment \"$IPTABLES_COM\""
IP6TABLES_C="$IP6TABLES -m comment --comment \"$IPTABLES_COM\""

# Check root access
if [ `id -u` != 0 ] ; then 
    echo -e "\033[33mWarning, script must be run with root permissions\033[0m"
    exit 1
fi

function GetDefIF()
{
    if [ "$defif" = "" ] ; then
        # Try IPv4 first
        defif=$(netstat -rn | grep UG | awk '{print $8}')
        if [ "$ipv6" = "1" ] ; then
            defif6=$(netstat -rn -A inet6 | grep UG | awk '{print $7}')
            if [ "$defif" != "$defif6" ] ; then
                defif+=" $defif6"
            fi
        fi
        NormalizeIfList "defif"
    fi
}

function NormalizeIfList()
{
    local name="$1"
    local list=$(echo "${!name}" | sed -e "s/\s/\n/g" | sort | uniq | xargs -r echo)
    eval "$name=\"$list\""
}

function ListIf()
{
    echo "Available interfaces:"
    for f in $allif ; do
        if [[ $defif =~ $f ]] ; then
            echo -e "  - \033[32m$f\033[0m (default)"
        else
            echo "  - $f"
        fi
    done
}

# Name of the network interfaces which are used to access to the local
# network (and Internet)
# If not set, default gateway interface will be used
iflist=""
defif=""
while [ "$1" != "" ] ; do
  case $1 in
    -h|--help)
      echo "Usage:"
      echo "> $0 [options] [<ifname0> [<ifname1> ...]]";
      echo "  ifname: interface name of the network connect to the outside world"
      echo "    If set to default or omitted, script will use default gateway interface(s)"
      echo "    If set to lo, configuration will be discarded"
      echo "  options:"
      echo "    -6: configure ipv6"
      echo "    -d: do nothing"
      echo "    --no-nat: disable NAT for IPv4"
      echo "    --no-nat6: disable NAT for IPv6"
      exit 1;
      ;;
    -6)
      echo "Use IPv6 configuration"
      ipv6=1
      ;;
    --no-nat)
      nat=0
      ;;
    --no-nat6)
      nat6=0
      ;;
    -d)
      dummy=1
      ;;
    *)
      if [ "$1" = "default" ] ; then
        GetDefIF
        iflist+=" $defif"
        echo "Select $defif default interface(s)";
      else
        iflist+=" $1"
        echo "Select $1 interface";
      fi
      ;;
  esac
  shift
done

# May be ipv6
allif=$(ifconfig -a | sed 's/[: \t].*//;/^$/d')

NormalizeIfList "iflist"
if [ "$iflist" = "" ] ; then
    GetDefIF
    if [ "$defif" = "" ] ; then
        echo "Can't find default interface"
        ListIf
        exit 2
    fi
    iflist="$defif"
    echo "Select $defif default interface";
fi

# Interface lookup
for ifname in $iflist ; do
    if [ "$ifname" = "lo" ] ; then continue; fi # Skip lo

    # Interface present ?
    found=0;
    for i in $allif; do
        if [ "$i" = "$ifname" ] ; then
            found=1;
            break
        fi
    done
    if [ "$found" = "0" ] ; then
        echo -e "\033[33mWarning, $ifname interface not found\033[0m"
        GetDefIF
        ListIf
        echo "You may edit this script to force interface and/or to edit iptables rules"
        exit 1
    fi
done


# Remove rules
# list them in reverse order as delete will change numbers
function IptablesFlush()
{
    type="$1"
    shift

    for c in $@; do
        CURRENT=$($IPTABLES $type -L $c -v -n --line-numbers | tac | grep "$IPTABLES_COM" | awk '{print $1;}')
        for i in $CURRENT ; do
            $IPTABLES $type -D $c $i
        done
        if [ "$ipv6" = "1" ] ; then
            CURRENT=$($IP6TABLES $type -L $c -v -n --line-numbers | tac | grep "$IPTABLES_COM" | awk '{print $1;}')
            for i in $CURRENT ; do
                $IP6TABLES $type -D $c $i
            done
        fi
    done
}
IptablesFlush "-t nat" "POSTROUTING"
IptablesFlush "" "OUTPUT"
#IptablesFlush "-t nat" "PREROUTING" "INPUT" "OUTPUT" "POSTROUTING"
#IptablesFlush "-t filter" "INPUT" "FORWARD" "OUTPUT"
#IptablesFlush "-t mangle" "PREROUTING" "INPUT" "FORWARD" "OUTPUT" "POSTROUTING"

# Don't do anything
if [ "$dummy" = "1" ] ; then
    exit 0
fi


########################################################################
# Activate masquerading and forwarding so that the UEs connected to
# the eNodeB can access the local network.
echo 1 > /proc/sys/net/ipv4/ip_forward


# Configure NAT
if [ "$nat" = "1" ] ; then
    for ifname in $iflist ; do
        if [ "$ifname" = "lo" ] ; then continue; fi # Skip lo
        echo "Configure NAT for $ifname"

        # Disable NAT on own subnet
        SUBNET=$(ip addr show dev ${ifname} | grep -w inet | awk '{print $2;}')
        if [ "$SUBNET" != "" ] ; then
            echo "1" > /proc/sys/net/ipv4/conf/${ifname}/proxy_arp
            for i in $SUBNET ; do
                $IPTABLES_C -t nat -A POSTROUTING -o ${ifname} -s $i -j RETURN
            done
        fi

        # Enable NAT
        $IPTABLES_C -t nat -A POSTROUTING -o ${ifname} -j MASQUERADE
    done
else
    echo "1" > /proc/sys/net/ipv4/conf/${ifname}/proxy_arp
fi

########################################################################
# Note: the two following rules are only needed if a firewall is enabled
# on your PC.

# Warning: Fedora 17 specific: remove the rule blocking the
# forwarding.
RULE=$($IPTABLES -v -n --line-numbers -L FORWARD | grep -w REJECT | cut -d ' ' -f1 | head -n1)
if [ "$RULE" != "" ] ; then
    $IPTABLES -D FORWARD $RULE
fi

# IPv6
if [ "$ipv6" = "1" ] ; then
    echo 1 > /proc/sys/net/ipv6/conf/all/forwarding
    for ifname in $iflist ; do
        # Enable stateless address autoconfiguration also in case of ipv6 forwarding
        echo 2 > /proc/sys/net/ipv6/conf/${ifname}/accept_ra

        if [ "$ifname" != "lo" -a "$nat6" = "1" ] ; then
            $IP6TABLES_C -t nat -A POSTROUTING -o ${ifname} -j MASQUERADE
        fi
    done
    if [ "$nat6" = "0" ] ; then
        echo 1 > /proc/sys/net/ipv6/conf/all/proxy_ndp
    fi
fi

########################################################################
# Improve network stack behavior
sysctl -w net.ipv4.tcp_congestion_control=bbr 2>/dev/null

########################################################################
# increase network buffers
sysctl -w net.core.rmem_max=50000000
sysctl -w net.core.wmem_max=5000000

exit 0;
